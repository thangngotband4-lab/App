package androidx.compose.ui.platform;

import android.content.Context;
import android.content.res.Configuration;
import android.os.Build;
import android.os.Bundle;
import android.os.Vibrator;
import android.view.View;
import com.example.autosocialmedia.R;
import defpackage.a61;
import defpackage.a81;
import defpackage.aa1;
import defpackage.b6;
import defpackage.ba;
import defpackage.ba1;
import defpackage.bn;
import defpackage.bw1;
import defpackage.c5;
import defpackage.c6;
import defpackage.c61;
import defpackage.ct;
import defpackage.e6;
import defpackage.eo0;
import defpackage.f6;
import defpackage.fl;
import defpackage.g4;
import defpackage.g6;
import defpackage.go0;
import defpackage.h50;
import defpackage.jl;
import defpackage.ju0;
import defpackage.k5;
import defpackage.ka1;
import defpackage.kc0;
import defpackage.l50;
import defpackage.l61;
import defpackage.lp;
import defpackage.mp;
import defpackage.na1;
import defpackage.ro;
import defpackage.st;
import defpackage.ua0;
import defpackage.vj1;
import defpackage.x4;
import defpackage.xo;
import defpackage.yv;
import defpackage.z5;
import defpackage.z91;
import defpackage.zi;
import defpackage.zv;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import kotlin.Metadata;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0006\" \u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\u00010\u00008FX\u0087\u0004¢\u0006\f\u0012\u0004\b\u0004\u0010\u0005\u001a\u0004\b\u0002\u0010\u0003¨\u0006\u0007"}, d2 = {"La61;", "Len0;", "getLocalLifecycleOwner", "()La61;", "getLocalLifecycleOwner$annotations", "()V", "LocalLifecycleOwner", "ui"}, k = 2, mv = {2, 0, 0}, xi = 48)
public final class AndroidCompositionLocals_androidKt {
    public static final mp a = new mp(z5.f);
    public static final vj1 b = new vj1(z5.g);
    public static final mp c = new mp(c5.h);
    public static final vj1 d = new vj1(z5.h);
    public static final vj1 e = new vj1(z5.i);
    public static final vj1 f = new vj1(z5.j);

    public static final void a(k5 k5Var, l50 l50Var, xo xoVar, int i) {
        boolean z;
        xoVar.X(-520299287);
        int i2 = (xoVar.h(k5Var) ? 4 : 2) | i | (xoVar.h(l50Var) ? 32 : 16);
        int i3 = 1;
        if (xoVar.O(i2 & 1, (i2 & 19) != 18)) {
            Context context = k5Var.getContext();
            Object objL = xoVar.L();
            Object obj = ro.a;
            if (objL == obj) {
                objL = new ba();
                xoVar.g0(objL);
            }
            ba baVar = (ba) objL;
            x4 viewTreeOwners = k5Var.getViewTreeOwners();
            if (viewTreeOwners == null) {
                zi.f("Called when the ViewTreeOwnersAvailability is not yet in Available state");
                return;
            }
            na1 na1Var = viewTreeOwners.b;
            Object objL2 = xoVar.L();
            if (objL2 == obj) {
                Object parent = k5Var.getParent();
                parent.getClass();
                View view = (View) parent;
                Object tag = view.getTag(R.id.compose_view_saveable_id_tag);
                LinkedHashMap linkedHashMap = null;
                String strValueOf = tag instanceof String ? (String) tag : null;
                if (strValueOf == null) {
                    strValueOf = String.valueOf(view.getId());
                }
                String str = z91.class.getSimpleName() + ':' + strValueOf;
                ka1 savedStateRegistry = na1Var.getSavedStateRegistry();
                Bundle bundleA = savedStateRegistry.a(str);
                if (bundleA != null) {
                    linkedHashMap = new LinkedHashMap();
                    for (String str2 : bundleA.keySet()) {
                        ArrayList parcelableArrayList = bundleA.getParcelableArrayList(str2);
                        parcelableArrayList.getClass();
                        linkedHashMap.put(str2, parcelableArrayList);
                    }
                }
                c5 c5Var = c5.C;
                vj1 vj1Var = ba1.a;
                aa1 aa1Var = new aa1(linkedHashMap, c5Var);
                try {
                    savedStateRegistry.c(str, new bn(i3, aa1Var));
                    z = true;
                } catch (IllegalArgumentException unused) {
                    z = false;
                }
                Object yvVar = new yv(aa1Var, new zv(z, savedStateRegistry, str));
                xoVar.g0(yvVar);
                objL2 = yvVar;
            }
            Object obj2 = (yv) objL2;
            boolean zH = xoVar.h(obj2);
            Object objL3 = xoVar.L();
            if (zH || objL3 == obj) {
                objL3 = new g4(5, obj2);
                xoVar.g0(objL3);
            }
            ct.h(bw1.a, (h50) objL3, xoVar);
            Object objL4 = xoVar.L();
            if (objL4 == obj) {
                objL4 = (Build.VERSION.SDK_INT < 31 || !((Vibrator) context.getSystemService(Vibrator.class)).areAllPrimitivesSupported(1, 7, 2)) ? new ju0() : new st(k5Var.getView(), 0);
                xoVar.g0(objL4);
            }
            ua0 ua0Var = (ua0) objL4;
            Configuration configuration = k5Var.getConfiguration();
            Object objL5 = xoVar.L();
            if (objL5 == obj) {
                objL5 = new kc0();
                xoVar.g0(objL5);
            }
            kc0 kc0Var = (kc0) objL5;
            Object objL6 = xoVar.L();
            Object obj3 = objL6;
            if (objL6 == obj) {
                Configuration configuration2 = new Configuration();
                if (configuration != null) {
                    configuration2.setTo(configuration);
                }
                xoVar.g0(configuration2);
                obj3 = configuration2;
            }
            Configuration configuration3 = (Configuration) obj3;
            Object objL7 = xoVar.L();
            if (objL7 == obj) {
                objL7 = new f6(configuration3, kc0Var);
                xoVar.g0(objL7);
            }
            f6 f6Var = (f6) objL7;
            boolean zH2 = xoVar.h(context);
            Object objL8 = xoVar.L();
            if (zH2 || objL8 == obj) {
                objL8 = new e6(context, 0, f6Var);
                xoVar.g0(objL8);
            }
            ct.h(kc0Var, (h50) objL8, xoVar);
            Object objL9 = xoVar.L();
            if (objL9 == obj) {
                objL9 = new a81();
                xoVar.g0(objL9);
            }
            a81 a81Var = (a81) objL9;
            Object objL10 = xoVar.L();
            if (objL10 == obj) {
                objL10 = new g6(a81Var);
                xoVar.g0(objL10);
            }
            g6 g6Var = (g6) objL10;
            boolean zH3 = xoVar.h(context);
            Object objL11 = xoVar.L();
            if (zH3 || objL11 == obj) {
                objL11 = new e6(context, 1, g6Var);
                xoVar.g0(objL11);
            }
            ct.h(a81Var, (h50) objL11, xoVar);
            a61 a61Var = lp.v;
            fl.b(new c61[]{a.a(k5Var.getConfiguration()), b.a(context), eo0.a.a(viewTreeOwners.a), go0.a.a(na1Var), ba1.a.a(obj2), f.a(k5Var.getView()), d.a(kc0Var), e.a(a81Var), a61Var.a(Boolean.valueOf(((Boolean) xoVar.j(a61Var)).booleanValue() | k5Var.getScrollCaptureInProgress$ui())), lp.l.a(ua0Var)}, jl.C(1059770793, new b6(k5Var, baVar, l50Var), xoVar), xoVar, 56);
        } else {
            xoVar.R();
        }
        l61 l61VarR = xoVar.r();
        if (l61VarR != null) {
            l61VarR.d = new c6(k5Var, l50Var, i);
        }
    }

    public static final void b(String str) {
        throw new IllegalStateException(("CompositionLocal " + str + " not present").toString());
    }

    public static final a61 getLocalLifecycleOwner() {
        return eo0.a;
    }
}
