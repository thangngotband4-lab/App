package androidx.lifecycle;

import android.app.Application;
import android.content.Context;
import android.os.Handler;
import defpackage.an0;
import defpackage.bn0;
import defpackage.e51;
import defpackage.f51;
import defpackage.pd0;
import defpackage.uz;
import defpackage.xm0;
import defpackage.yc;
import defpackage.zi;
import java.util.HashSet;
import java.util.List;
import kotlin.Metadata;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001B\u0007¢\u0006\u0004\b\u0003\u0010\u0004¨\u0006\u0005"}, d2 = {"Landroidx/lifecycle/ProcessLifecycleInitializer;", "Lpd0;", "Len0;", "<init>", "()V", "lifecycle-process_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
public final class ProcessLifecycleInitializer implements pd0 {
    @Override // defpackage.pd0
    public final List a() {
        return uz.d;
    }

    @Override // defpackage.pd0
    public final Object b(Context context) {
        context.getClass();
        yc ycVarH = yc.h(context);
        ycVarH.getClass();
        if (!((HashSet) ycVarH.b).contains(ProcessLifecycleInitializer.class)) {
            zi.f("ProcessLifecycleInitializer cannot be initialized lazily.\n               Please ensure that you have:\n               <meta-data\n                   android:name='androidx.lifecycle.ProcessLifecycleInitializer'\n                   android:value='androidx.startup' />\n               under InitializationProvider in your AndroidManifest.xml");
            return null;
        }
        if (!bn0.a.getAndSet(true)) {
            Context applicationContext = context.getApplicationContext();
            applicationContext.getClass();
            ((Application) applicationContext).registerActivityLifecycleCallbacks(new an0());
        }
        f51 f51Var = f51.l;
        f51Var.getClass();
        f51Var.h = new Handler();
        f51Var.i.e(xm0.ON_CREATE);
        Context applicationContext2 = context.getApplicationContext();
        applicationContext2.getClass();
        ((Application) applicationContext2).registerActivityLifecycleCallbacks(new e51(f51Var));
        return f51Var;
    }
}
