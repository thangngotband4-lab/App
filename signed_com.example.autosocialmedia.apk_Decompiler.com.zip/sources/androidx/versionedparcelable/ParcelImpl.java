package androidx.versionedparcelable;

import android.os.Parcel;
import android.os.Parcelable;
import defpackage.c2;
import defpackage.cy1;
import defpackage.dy1;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public class ParcelImpl implements Parcelable {
    public static final Parcelable.Creator<ParcelImpl> CREATOR = new c2(2);
    public final dy1 d;

    public ParcelImpl(Parcel parcel) {
        this.d = new cy1(parcel).g();
    }

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i) {
        new cy1(parcel).i(this.d);
    }
}
