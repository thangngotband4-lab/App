package androidx.profileinstaller;

import android.content.Context;
import android.view.Choreographer;
import defpackage.m51;
import defpackage.pd0;
import defpackage.qk0;
import java.util.Collections;
import java.util.List;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public class ProfileInstallerInitializer implements pd0 {
    @Override // defpackage.pd0
    public final List a() {
        return Collections.EMPTY_LIST;
    }

    @Override // defpackage.pd0
    public final Object b(Context context) {
        Choreographer.getInstance().postFrameCallback(new m51(this, context.getApplicationContext()));
        return new qk0(16);
    }
}
