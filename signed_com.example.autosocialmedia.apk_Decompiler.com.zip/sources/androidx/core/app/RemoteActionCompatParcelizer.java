package androidx.core.app;

import android.app.PendingIntent;
import android.os.Parcel;
import android.text.TextUtils;
import androidx.core.graphics.drawable.IconCompat;
import defpackage.by1;
import defpackage.cy1;
import defpackage.dy1;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public class RemoteActionCompatParcelizer {
    public static RemoteActionCompat read(by1 by1Var) {
        RemoteActionCompat remoteActionCompat = new RemoteActionCompat();
        dy1 dy1VarG = remoteActionCompat.a;
        boolean z = true;
        if (by1Var.e(1)) {
            dy1VarG = by1Var.g();
        }
        remoteActionCompat.a = (IconCompat) dy1VarG;
        CharSequence charSequence = remoteActionCompat.b;
        if (by1Var.e(2)) {
            charSequence = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(((cy1) by1Var).e);
        }
        remoteActionCompat.b = charSequence;
        CharSequence charSequence2 = remoteActionCompat.c;
        if (by1Var.e(3)) {
            charSequence2 = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(((cy1) by1Var).e);
        }
        remoteActionCompat.c = charSequence2;
        remoteActionCompat.d = (PendingIntent) by1Var.f(remoteActionCompat.d, 4);
        boolean z2 = remoteActionCompat.e;
        if (by1Var.e(5)) {
            z2 = ((cy1) by1Var).e.readInt() != 0;
        }
        remoteActionCompat.e = z2;
        boolean z3 = remoteActionCompat.f;
        if (!by1Var.e(6)) {
            z = z3;
        } else if (((cy1) by1Var).e.readInt() == 0) {
            z = false;
        }
        remoteActionCompat.f = z;
        return remoteActionCompat;
    }

    public static void write(RemoteActionCompat remoteActionCompat, by1 by1Var) {
        by1Var.getClass();
        IconCompat iconCompat = remoteActionCompat.a;
        by1Var.h(1);
        by1Var.i(iconCompat);
        CharSequence charSequence = remoteActionCompat.b;
        by1Var.h(2);
        Parcel parcel = ((cy1) by1Var).e;
        TextUtils.writeToParcel(charSequence, parcel, 0);
        CharSequence charSequence2 = remoteActionCompat.c;
        by1Var.h(3);
        TextUtils.writeToParcel(charSequence2, parcel, 0);
        PendingIntent pendingIntent = remoteActionCompat.d;
        by1Var.h(4);
        parcel.writeParcelable(pendingIntent, 0);
        boolean z = remoteActionCompat.e;
        by1Var.h(5);
        parcel.writeInt(z ? 1 : 0);
        boolean z2 = remoteActionCompat.f;
        by1Var.h(6);
        parcel.writeInt(z2 ? 1 : 0);
    }
}
