package androidx.emoji2.text;

import android.content.Context;
import androidx.lifecycle.ProcessLifecycleInitializer;
import defpackage.dz;
import defpackage.en0;
import defpackage.ez;
import defpackage.j40;
import defpackage.l1;
import defpackage.pd0;
import defpackage.yc;
import defpackage.zm0;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public class EmojiCompatInitializer implements pd0 {
    @Override // defpackage.pd0
    public final List a() {
        return Collections.singletonList(ProcessLifecycleInitializer.class);
    }

    @Override // defpackage.pd0
    public final Object b(Context context) {
        Object objD;
        j40 j40Var = new j40(new l1(context));
        j40Var.b = 1;
        if (dz.k == null) {
            synchronized (dz.j) {
                try {
                    if (dz.k == null) {
                        dz.k = new dz(j40Var);
                    }
                } finally {
                }
            }
        }
        yc ycVarH = yc.h(context);
        ycVarH.getClass();
        synchronized (yc.e) {
            try {
                objD = ((HashMap) ycVarH.a).get(ProcessLifecycleInitializer.class);
                if (objD == null) {
                    objD = ycVarH.d(ProcessLifecycleInitializer.class, new HashSet());
                }
            } finally {
            }
        }
        zm0 lifecycle = ((en0) objD).getLifecycle();
        lifecycle.a(new ez(this, lifecycle));
        return Boolean.TRUE;
    }
}
