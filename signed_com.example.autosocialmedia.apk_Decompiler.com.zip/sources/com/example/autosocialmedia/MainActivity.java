package com.example.autosocialmedia;

import android.content.Context;
import android.content.IntentFilter;
import android.content.res.Resources;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import defpackage.cj1;
import defpackage.ct;
import defpackage.f30;
import defpackage.jj1;
import defpackage.ln;
import defpackage.mn;
import defpackage.ng0;
import defpackage.nw1;
import defpackage.po;
import defpackage.qn;
import defpackage.qy;
import defpackage.ry;
import defpackage.sy;
import defpackage.ty;
import defpackage.ui1;
import defpackage.uy;
import defpackage.wl1;
import kotlin.Metadata;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0007\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0019\u0010\u0007\u001a\u00020\u00062\b\u0010\u0005\u001a\u0004\u0018\u00010\u0004H\u0014¢\u0006\u0004\b\u0007\u0010\b¨\u0006\t"}, d2 = {"Lcom/example/autosocialmedia/MainActivity;", "Lln;", "<init>", "()V", "Landroid/os/Bundle;", "savedInstanceState", "Lbw1;", "onCreate", "(Landroid/os/Bundle;)V", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class MainActivity extends ln {
    public static final int $stable = 8;

    @Override // defpackage.ln, defpackage.kn, android.app.Activity
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        int i = qy.a;
        f30 f30Var = f30.z;
        wl1 wl1Var = new wl1(0, 0, f30Var);
        wl1 wl1Var2 = new wl1(qy.a, qy.b, f30Var);
        View decorView = getWindow().getDecorView();
        decorView.getClass();
        Resources resources = decorView.getResources();
        resources.getClass();
        boolean zBooleanValue = ((Boolean) f30Var.g(resources)).booleanValue();
        Resources resources2 = decorView.getResources();
        resources2.getClass();
        boolean zBooleanValue2 = ((Boolean) f30Var.g(resources2)).booleanValue();
        int i2 = Build.VERSION.SDK_INT;
        uy tyVar = i2 >= 29 ? new ty() : i2 >= 26 ? new sy() : new ry();
        Window window = getWindow();
        window.getClass();
        tyVar.a(wl1Var, wl1Var2, window, decorView, zBooleanValue, zBooleanValue2);
        Context applicationContext = getApplicationContext();
        applicationContext.getClass();
        nw1 nw1Var = new nw1();
        IntentFilter intentFilter = new IntentFilter("com.example.autosocialmedia.action.INSTALL_RESULT");
        if (i2 >= 33) {
            applicationContext.registerReceiver(nw1Var, intentFilter, 4);
        } else {
            applicationContext.registerReceiver(nw1Var, intentFilter);
        }
        if ((getApplicationInfo().flags & 2) != 0) {
            String strY = ng0.y(this);
            Log.i("AutoSocialSec", "===== APK CERT SHA256 (dán vào Rust EXPECTED_CERT_SHA256) =====");
            Log.i("AutoSocialSec", strY);
            Log.i("AutoSocialSec", "================================================================");
        }
        qn qnVar = ct.i;
        ViewGroup.LayoutParams layoutParams = mn.a;
        View childAt = ((ViewGroup) getWindow().getDecorView().findViewById(android.R.id.content)).getChildAt(0);
        po poVar = childAt instanceof po ? (po) childAt : null;
        if (poVar != null) {
            poVar.setParentCompositionContext(null);
            poVar.setContent(qnVar);
            return;
        }
        po poVar2 = new po(this);
        poVar2.setParentCompositionContext(null);
        poVar2.setContent(qnVar);
        View decorView2 = getWindow().getDecorView();
        if (ui1.g(decorView2) == null) {
            decorView2.setTag(R.id.view_tree_lifecycle_owner, this);
        }
        if (jj1.l(decorView2) == null) {
            decorView2.setTag(R.id.view_tree_view_model_store_owner, this);
        }
        if (cj1.f(decorView2) == null) {
            decorView2.setTag(R.id.view_tree_saved_state_registry_owner, this);
        }
        setContentView(poVar2, mn.a);
    }
}
