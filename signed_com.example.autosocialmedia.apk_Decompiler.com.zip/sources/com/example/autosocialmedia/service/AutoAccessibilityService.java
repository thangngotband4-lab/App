package com.example.autosocialmedia.service;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.util.Log;
import android.view.accessibility.AccessibilityEvent;
import defpackage.al1;
import defpackage.bh0;
import defpackage.bm;
import defpackage.cj1;
import defpackage.d;
import defpackage.ds;
import defpackage.l50;
import defpackage.m22;
import defpackage.ud;
import defpackage.um;
import kotlin.Metadata;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000V\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u000e\n\u0002\b\b\b\u0007\u0018\u0000 %2\u00020\u0001:\u0001&B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u000f\u0010\u0005\u001a\u00020\u0004H\u0014¢\u0006\u0004\b\u0005\u0010\u0003J\u0019\u0010\b\u001a\u00020\u00042\b\u0010\u0007\u001a\u0004\u0018\u00010\u0006H\u0016¢\u0006\u0004\b\b\u0010\tJ\u000f\u0010\n\u001a\u00020\u0004H\u0016¢\u0006\u0004\b\n\u0010\u0003J\u0019\u0010\u000e\u001a\u00020\r2\b\u0010\f\u001a\u0004\u0018\u00010\u000bH\u0016¢\u0006\u0004\b\u000e\u0010\u000fJ1\u0010\u0015\u001a\u00020\u00142\"\u0010\u0013\u001a\u001e\b\u0001\u0012\u0004\u0012\u00020\u0000\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00040\u0011\u0012\u0006\u0012\u0004\u0018\u00010\u00120\u0010¢\u0006\u0004\b\u0015\u0010\u0016R\u0014\u0010\u0018\u001a\u00020\u00178\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0018\u0010\u0019R\u0017\u0010\u001b\u001a\u00020\u001a8\u0006¢\u0006\f\n\u0004\b\u001b\u0010\u001c\u001a\u0004\b\u001d\u0010\u001eR(\u0010!\u001a\u0004\u0018\u00010\u001f2\b\u0010 \u001a\u0004\u0018\u00010\u001f8\u0006@BX\u0086\u000e¢\u0006\f\n\u0004\b!\u0010\"\u001a\u0004\b#\u0010$¨\u0006'"}, d2 = {"Lcom/example/autosocialmedia/service/AutoAccessibilityService;", "Landroid/accessibilityservice/AccessibilityService;", "<init>", "()V", "Lbw1;", "onServiceConnected", "Landroid/view/accessibility/AccessibilityEvent;", "event", "onAccessibilityEvent", "(Landroid/view/accessibility/AccessibilityEvent;)V", "onInterrupt", "Landroid/content/Intent;", "intent", "", "onUnbind", "(Landroid/content/Intent;)Z", "Lkotlin/Function2;", "Ltq;", "", "block", "Lbh0;", "runAutomation", "(Ll50;)Lbh0;", "Lum;", "serviceJob", "Lum;", "Lds;", "scope", "Lds;", "getScope", "()Lds;", "", "value", "latestEventPackage", "Ljava/lang/String;", "getLatestEventPackage", "()Ljava/lang/String;", "Companion", "ud", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class AutoAccessibilityService extends AccessibilityService {
    public static final int $stable = 8;
    public static final ud Companion = new ud();
    private static final String TAG = "AutoAccessibility";
    private static volatile AutoAccessibilityService instance;
    private volatile String latestEventPackage;
    private final ds scope;
    private final um serviceJob;

    public AutoAccessibilityService() {
        al1 al1VarA = cj1.a();
        this.serviceJob = al1VarA;
        this.scope = bm.a(al1VarA);
    }

    public final String getLatestEventPackage() {
        return this.latestEventPackage;
    }

    public final ds getScope() {
        return this.scope;
    }

    @Override // android.accessibilityservice.AccessibilityService
    public void onAccessibilityEvent(AccessibilityEvent event) {
        CharSequence packageName;
        if (event == null || (packageName = event.getPackageName()) == null) {
            return;
        }
        this.latestEventPackage = packageName.toString();
    }

    @Override // android.accessibilityservice.AccessibilityService
    public void onInterrupt() {
        Log.d(TAG, "AccessibilityService interrupted");
    }

    @Override // android.accessibilityservice.AccessibilityService
    public void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
        Log.d(TAG, "AccessibilityService connected");
    }

    @Override // android.app.Service
    public boolean onUnbind(Intent intent) {
        if (instance == this) {
            instance = null;
        }
        bm.l(this.scope, null);
        return super.onUnbind(intent);
    }

    public final bh0 runAutomation(l50 block) {
        block.getClass();
        return m22.y(this.scope, null, new d(block, this, null, 5), 3);
    }
}
