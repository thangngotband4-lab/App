package com.example.autosocialmedia.security;

import defpackage.bw1;
import defpackage.d81;
import kotlin.Metadata;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u00004\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0005\n\u0002\u0010\t\n\u0002\b\n\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\b\n\u0002\b\r\bÇ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\r\u0010\u0005\u001a\u00020\u0004¢\u0006\u0004\b\u0005\u0010\u0006J@\u0010\u000f\u001a\u00020\r2\u0006\u0010\b\u001a\u00020\u00072\u0006\u0010\t\u001a\u00020\u00072\u0006\u0010\n\u001a\u00020\u00072\u0006\u0010\u000b\u001a\u00020\u00072\u0006\u0010\f\u001a\u00020\u00072\u0006\u0010\u000e\u001a\u00020\rH\u0086 ¢\u0006\u0004\b\u000f\u0010\u0010J\u0018\u0010\u0012\u001a\u00020\u00072\u0006\u0010\u0011\u001a\u00020\rH\u0086 ¢\u0006\u0004\b\u0012\u0010\u0013J \u0010\u0015\u001a\u00020\u00072\u0006\u0010\u0011\u001a\u00020\r2\u0006\u0010\u0014\u001a\u00020\u0004H\u0086 ¢\u0006\u0004\b\u0015\u0010\u0016J\u0018\u0010\u0017\u001a\u00020\u00072\u0006\u0010\u0011\u001a\u00020\rH\u0086 ¢\u0006\u0004\b\u0017\u0010\u0013J\u0018\u0010\u0019\u001a\u00020\u00182\u0006\u0010\u0011\u001a\u00020\rH\u0086 ¢\u0006\u0004\b\u0019\u0010\u001aJ\u0018\u0010\u001b\u001a\u00020\u00182\u0006\u0010\u0011\u001a\u00020\rH\u0086 ¢\u0006\u0004\b\u001b\u0010\u001aJ(\u0010\u001f\u001a\u00020\u00182\u0006\u0010\u0011\u001a\u00020\r2\u0006\u0010\u001c\u001a\u00020\u00072\u0006\u0010\u001e\u001a\u00020\u001dH\u0086 ¢\u0006\u0004\b\u001f\u0010 J \u0010\"\u001a\u00020\u00042\u0006\u0010\u0011\u001a\u00020\r2\u0006\u0010!\u001a\u00020\u0004H\u0086 ¢\u0006\u0004\b\"\u0010#J\u0018\u0010$\u001a\u00020\u00182\u0006\u0010\u0011\u001a\u00020\rH\u0086 ¢\u0006\u0004\b$\u0010\u001aJ\u0018\u0010%\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\u0007H\u0086 ¢\u0006\u0004\b%\u0010&J\u0018\u0010'\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\u0007H\u0086 ¢\u0006\u0004\b'\u0010&R\u0016\u0010(\u001a\u00020\u00048\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b(\u0010)¨\u0006*"}, d2 = {"Lcom/example/autosocialmedia/security/NativeGoLike;", "", "<init>", "()V", "", "isAvailable", "()Z", "", "authorization", "configJson", "licenseStr", "deviceFp", "certSha256", "", "nowUnix", "nativeNewRunner", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;J)J", "handle", "nativeTick", "(J)Ljava/lang/String;", "success", "nativeReportFollowResult", "(JZ)Ljava/lang/String;", "nativeStats", "Lbw1;", "nativeStop", "(J)V", "nativeReportRevoked", "token", "", "budget", "nativeRefreshSession", "(JLjava/lang/String;I)V", "wasUnfollowed", "nativeReportUnfollowCheck", "(JZ)Z", "nativeFreeRunner", "nativeGetUser", "(Ljava/lang/String;)Ljava/lang/String;", "nativeGetTikTokAccounts", "available", "Z", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class NativeGoLike {
    public static final int $stable;
    public static final NativeGoLike INSTANCE = new NativeGoLike();
    private static volatile boolean available;

    static {
        Object d81Var;
        try {
            System.loadLibrary("asm_crypto");
            d81Var = bw1.a;
        } catch (Throwable th) {
            d81Var = new d81(th);
        }
        available = !(d81Var instanceof d81);
        $stable = 8;
    }

    private NativeGoLike() {
    }

    public final boolean isAvailable() {
        return available;
    }

    public final native void nativeFreeRunner(long handle);

    public final native String nativeGetTikTokAccounts(String authorization);

    public final native String nativeGetUser(String authorization);

    public final native long nativeNewRunner(String authorization, String configJson, String licenseStr, String deviceFp, String certSha256, long nowUnix);

    public final native void nativeRefreshSession(long handle, String token, int budget);

    public final native String nativeReportFollowResult(long handle, boolean success);

    public final native void nativeReportRevoked(long handle);

    public final native boolean nativeReportUnfollowCheck(long handle, boolean wasUnfollowed);

    public final native String nativeStats(long handle);

    public final native void nativeStop(long handle);

    public final native String nativeTick(long handle);
}
