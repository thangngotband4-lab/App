package com.example.autosocialmedia.security;

import kotlin.Metadata;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0010\b\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0003\bÇ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J+\u0010\u0004\u001a\u0004\u0018\u00010\u00052\u0006\u0010\u0006\u001a\u00020\u00052\u0006\u0010\u0007\u001a\u00020\u00052\u0006\u0010\b\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u000bH\u0087 J\u0019\u0010\f\u001a\u00020\r2\u0006\u0010\u000e\u001a\u00020\u00052\u0006\u0010\u000f\u001a\u00020\u0005H\u0087 ¨\u0006\u0010"}, d2 = {"Lcom/example/autosocialmedia/security/NativeUpdate;", "", "<init>", "()V", "nativeVerifyManifest", "", "manifest", "nonce", "currentVersionCode", "", "nowUnix", "", "nativeVerifyApk", "", "filePath", "expectedSha256", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class NativeUpdate {
    public static final int $stable = 0;
    public static final NativeUpdate INSTANCE = new NativeUpdate();

    static {
        try {
            System.loadLibrary("asm_crypto");
        } catch (Throwable unused) {
        }
    }

    private NativeUpdate() {
    }

    public static final native boolean nativeVerifyApk(String filePath, String expectedSha256);

    public static final native String nativeVerifyManifest(String manifest, String nonce, int currentVersionCode, long nowUnix);
}
