package com.example.autosocialmedia.security;

import defpackage.bw1;
import defpackage.d81;
import kotlin.Metadata;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0010\u000e\n\u0002\b\u0004\n\u0002\u0010\t\n\u0002\b\u0006\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0013\bÇ\u0002\u0018\u00002\u00020\u0001J8\u0010\t\u001a\u00020\u00072\u0006\u0010\u0003\u001a\u00020\u00022\u0006\u0010\u0004\u001a\u00020\u00022\u0006\u0010\u0005\u001a\u00020\u00022\u0006\u0010\u0006\u001a\u00020\u00022\u0006\u0010\b\u001a\u00020\u0007H\u0086 ¢\u0006\u0004\b\t\u0010\nJ\u0018\u0010\f\u001a\u00020\u00022\u0006\u0010\u000b\u001a\u00020\u0007H\u0086 ¢\u0006\u0004\b\f\u0010\rJ \u0010\u0011\u001a\u00020\u00102\u0006\u0010\u000b\u001a\u00020\u00072\u0006\u0010\u000f\u001a\u00020\u000eH\u0086 ¢\u0006\u0004\b\u0011\u0010\u0012J \u0010\u0014\u001a\u00020\u00102\u0006\u0010\u000b\u001a\u00020\u00072\u0006\u0010\u0013\u001a\u00020\u0002H\u0086 ¢\u0006\u0004\b\u0014\u0010\u0015JP\u0010\u001d\u001a\u00020\u00102\u0006\u0010\u000b\u001a\u00020\u00072\u0006\u0010\u0016\u001a\u00020\u000e2\u0006\u0010\u0017\u001a\u00020\u000e2\u0006\u0010\u0018\u001a\u00020\u000e2\u0006\u0010\u0019\u001a\u00020\u000e2\u0006\u0010\u001a\u001a\u00020\u000e2\u0006\u0010\u001b\u001a\u00020\u000e2\u0006\u0010\u001c\u001a\u00020\u000eH\u0086 ¢\u0006\u0004\b\u001d\u0010\u001eJ\u0018\u0010\u001f\u001a\u00020\u00022\u0006\u0010\u000b\u001a\u00020\u0007H\u0086 ¢\u0006\u0004\b\u001f\u0010\rJ\u0018\u0010 \u001a\u00020\u00102\u0006\u0010\u000b\u001a\u00020\u0007H\u0086 ¢\u0006\u0004\b \u0010!J\u0018\u0010\"\u001a\u00020\u00102\u0006\u0010\u000b\u001a\u00020\u0007H\u0086 ¢\u0006\u0004\b\"\u0010!¨\u0006#"}, d2 = {"Lcom/example/autosocialmedia/security/NativeNurture;", "", "", "configJson", "licenseStr", "deviceFp", "certSha256", "", "nowUnix", "nativeNewNurture", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;J)J", "handle", "nativeNurtureTick", "(J)Ljava/lang/String;", "", "success", "Lbw1;", "nativeReportBeginResult", "(JZ)V", "threatReason", "nativeReportGuardResult", "(JLjava/lang/String;)V", "swiped", "liked", "followed", "downloaded", "shared", "favorited", "cancelled", "nativeReportVideoDone", "(JZZZZZZZ)V", "nativeNurtureStats", "nativeStopNurture", "(J)V", "nativeFreeNurture", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class NativeNurture {
    public static final NativeNurture a = new NativeNurture();
    public static volatile boolean b;

    static {
        Object d81Var;
        try {
            System.loadLibrary("asm_crypto");
            d81Var = bw1.a;
        } catch (Throwable th) {
            d81Var = new d81(th);
        }
        b = !(d81Var instanceof d81);
    }

    public final native void nativeFreeNurture(long handle);

    public final native long nativeNewNurture(String configJson, String licenseStr, String deviceFp, String certSha256, long nowUnix);

    public final native String nativeNurtureStats(long handle);

    public final native String nativeNurtureTick(long handle);

    public final native void nativeReportBeginResult(long handle, boolean success);

    public final native void nativeReportGuardResult(long handle, String threatReason);

    public final native void nativeReportVideoDone(long handle, boolean swiped, boolean liked, boolean followed, boolean downloaded, boolean shared, boolean favorited, boolean cancelled);

    public final native void nativeStopNurture(long handle);
}
