package com.example.autosocialmedia.security;

import android.content.Context;
import android.provider.Settings;
import defpackage.ak;
import defpackage.bk1;
import defpackage.d81;
import defpackage.ll;
import defpackage.tf0;
import defpackage.tl;
import defpackage.tt0;
import defpackage.uf0;
import defpackage.ut0;
import defpackage.uz;
import defpackage.vt0;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import kotlin.Metadata;
import org.json.JSONArray;
import org.json.JSONObject;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0010\t\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u0003\bÇ\u0002\u0018\u00002\u00020\u0001:\u0001\u0014B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J2\u0010\n\u001a\u0004\u0018\u00010\u00042\u0006\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0006\u001a\u00020\u00042\u0006\u0010\u0007\u001a\u00020\u00042\u0006\u0010\t\u001a\u00020\bH\u0087 ¢\u0006\u0004\b\n\u0010\u000bJ\u0015\u0010\u000e\u001a\u00020\u00042\u0006\u0010\r\u001a\u00020\f¢\u0006\u0004\b\u000e\u0010\u000fJ\u0017\u0010\u0011\u001a\u00020\u00042\b\u0010\u0010\u001a\u0004\u0018\u00010\u0004¢\u0006\u0004\b\u0011\u0010\u0012J\u0017\u0010\u0015\u001a\u00020\u00142\b\u0010\u0013\u001a\u0004\u0018\u00010\u0004¢\u0006\u0004\b\u0015\u0010\u0016¨\u0006\u0017"}, d2 = {"Lcom/example/autosocialmedia/security/NativeLicense;", "", "<init>", "()V", "", "licenseStr", "deviceFp", "certSha256", "", "nowUnix", "nativeVerify", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;J)Ljava/lang/String;", "Landroid/content/Context;", "context", "deviceFingerprint", "(Landroid/content/Context;)Ljava/lang/String;", "code", "errorMessage", "(Ljava/lang/String;)Ljava/lang/String;", "json", "Lvt0;", "parseResult", "(Ljava/lang/String;)Lvt0;", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class NativeLicense {
    public static final int $stable = 0;
    public static final NativeLicense INSTANCE = new NativeLicense();

    static {
        try {
            System.loadLibrary("asm_crypto");
        } catch (Throwable unused) {
        }
    }

    private NativeLicense() {
    }

    public static final CharSequence deviceFingerprint$lambda$1(byte b) {
        return String.format("%02x", Arrays.copyOf(new Object[]{Byte.valueOf(b)}, 1));
    }

    public static final native String nativeVerify(String licenseStr, String deviceFp, String certSha256, long nowUnix);

    public final String deviceFingerprint(Context context) {
        context.getClass();
        String string = Settings.Secure.getString(context.getContentResolver(), "android_id");
        if (string == null) {
            string = "";
        }
        byte[] bytes = (string + "|" + context.getPackageName()).getBytes(ak.a);
        bytes.getClass();
        byte[] bArrDigest = MessageDigest.getInstance("SHA-256").digest(bytes);
        bArrDigest.getClass();
        StringBuilder sb = new StringBuilder();
        sb.append((CharSequence) "");
        int i = 0;
        for (byte b : bArrDigest) {
            i++;
            if (i > 1) {
                sb.append((CharSequence) "");
            }
            sb.append(deviceFingerprint$lambda$1(b));
        }
        sb.append((CharSequence) "");
        return sb.toString();
    }

    /* JADX WARN: Failed to restore switch over string. Please report as a decompilation issue */
    public final String errorMessage(String code) {
        if (code == null) {
            return "Mã kích hoạt không hợp lệ";
        }
        switch (code.hashCode()) {
            case -1973897213:
                return !code.equals("bad_public_key") ? "Mã kích hoạt không hợp lệ" : "Lỗi nội bộ ứng dụng (public key không hợp lệ)";
            case -1680811663:
                return !code.equals("bad_format") ? "Mã kích hoạt không hợp lệ" : "Mã kích hoạt không đúng định dạng";
            case -1309235419:
                return !code.equals("expired") ? "Mã kích hoạt không hợp lệ" : "Mã kích hoạt đã hết hạn";
            case -674812076:
                return !code.equals("bad_payload") ? "Mã kích hoạt không hợp lệ" : "Mã kích hoạt bị hỏng (sai dữ liệu)";
            case -634457861:
                return !code.equals("no_features") ? "Mã kích hoạt không hợp lệ" : "Mã kích hoạt không mở quyền nào";
            case 16868759:
                return !code.equals("device_mismatch") ? "Mã kích hoạt không hợp lệ" : "Mã kích hoạt không thuộc về máy này";
            case 659808462:
                return !code.equals("unsupported_version") ? "Mã kích hoạt không hợp lệ" : "Mã kích hoạt cũ, vui lòng xin mã mới";
            case 661977456:
                return !code.equals("signature_invalid") ? "Mã kích hoạt không hợp lệ" : "Mã kích hoạt không hợp lệ (sai chữ ký)";
            case 884840525:
                return !code.equals("bad_encoding") ? "Mã kích hoạt không hợp lệ" : "Mã kích hoạt bị hỏng (sai mã hoá)";
            case 1189523783:
                return !code.equals("bad_signature_length") ? "Mã kích hoạt không hợp lệ" : "Mã kích hoạt bị hỏng (chữ ký sai độ dài)";
            case 1888182032:
                return !code.equals("bad_input") ? "Mã kích hoạt không hợp lệ" : "Đầu vào không hợp lệ";
            default:
                return "Mã kích hoạt không hợp lệ";
        }
    }

    public final vt0 parseResult(String json) {
        Object d81Var;
        List list;
        if (json == null || bk1.s(json)) {
            return new tt0("Lỗi không xác định");
        }
        try {
            d81Var = new JSONObject(json);
        } catch (Throwable th) {
            d81Var = new d81(th);
        }
        if (d81Var instanceof d81) {
            d81Var = null;
        }
        JSONObject jSONObject = (JSONObject) d81Var;
        if (jSONObject == null) {
            return new tt0("Phản hồi không hợp lệ");
        }
        if (!jSONObject.optBoolean("valid", false)) {
            return new tt0(errorMessage(jSONObject.optString("error")));
        }
        JSONArray jSONArrayOptJSONArray = jSONObject.optJSONArray("feat");
        if (jSONArrayOptJSONArray == null) {
            list = uz.d;
        } else {
            uf0 uf0VarR = tl.R(0, jSONArrayOptJSONArray.length());
            ArrayList arrayList = new ArrayList(ll.R(uf0VarR));
            Iterator it = uf0VarR.iterator();
            while (true) {
                tf0 tf0Var = (tf0) it;
                if (!tf0Var.f) {
                    break;
                }
                arrayList.add(jSONArrayOptJSONArray.getString(tf0Var.nextInt()));
            }
            list = arrayList;
        }
        String strOptString = jSONObject.optString("uid");
        strOptString.getClass();
        String strOptString2 = jSONObject.optString("name");
        strOptString2.getClass();
        String strOptString3 = jSONObject.optString("tier");
        strOptString3.getClass();
        return new ut0(strOptString, strOptString2, strOptString3, list, jSONObject.optLong("iat"), jSONObject.optLong("exp"));
    }
}
