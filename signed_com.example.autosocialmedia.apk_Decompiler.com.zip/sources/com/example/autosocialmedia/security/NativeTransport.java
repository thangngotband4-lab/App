package com.example.autosocialmedia.security;

import kotlin.Metadata;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0010\u0012\n\u0002\b\u0004\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\t\n\u0002\b\u000b\n\u0002\u0010\u000b\n\u0002\b\u0004\bÇ\u0002\u0018\u00002\u00020\u0001:\u0001\u0019J\u001a\u0010\u0004\u001a\u0004\u0018\u00010\u00022\u0006\u0010\u0003\u001a\u00020\u0002H\u0087 ¢\u0006\u0004\b\u0004\u0010\u0005JJ\u0010\u000f\u001a\u0004\u0018\u00010\u00072\u0006\u0010\u0006\u001a\u00020\u00022\u0006\u0010\b\u001a\u00020\u00072\u0006\u0010\t\u001a\u00020\u00072\u0006\u0010\u000b\u001a\u00020\n2\u0006\u0010\f\u001a\u00020\u00072\u0006\u0010\r\u001a\u00020\u00022\u0006\u0010\u000e\u001a\u00020\u0007H\u0087 ¢\u0006\u0004\b\u000f\u0010\u0010J\"\u0010\u0013\u001a\u0004\u0018\u00010\u00022\u0006\u0010\u0011\u001a\u00020\u00022\u0006\u0010\u0012\u001a\u00020\u0002H\u0087 ¢\u0006\u0004\b\u0013\u0010\u0014JP\u0010\u0017\u001a\u00020\u00162\u0006\u0010\u0006\u001a\u00020\u00022\u0006\u0010\b\u001a\u00020\u00072\u0006\u0010\t\u001a\u00020\u00072\u0006\u0010\u000b\u001a\u00020\n2\u0006\u0010\f\u001a\u00020\u00072\u0006\u0010\r\u001a\u00020\u00022\u0006\u0010\u000e\u001a\u00020\u00072\u0006\u0010\u0015\u001a\u00020\u0007H\u0087 ¢\u0006\u0004\b\u0017\u0010\u0018¨\u0006\u001a"}, d2 = {"Lcom/example/autosocialmedia/security/NativeTransport;", "", "", "plaintext", "nativePrepareRequest", "([B)[B", "macKey", "", "method", "path", "", "ts", "nonce", "body", "ephPubB64", "nativeSignRequest", "([BLjava/lang/String;Ljava/lang/String;JLjava/lang/String;[BLjava/lang/String;)Ljava/lang/String;", "encKey", "ciphertext", "nativeOpenResponse", "([B[B)[B", "sigB64", "", "nativeVerifyResponseSig", "([BLjava/lang/String;Ljava/lang/String;JLjava/lang/String;[BLjava/lang/String;Ljava/lang/String;)Z", "l4", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
public abstract class NativeTransport {
    public static final /* synthetic */ int a = 0;

    static {
        try {
            System.loadLibrary("asm_crypto");
        } catch (Throwable unused) {
        }
    }

    public static final native byte[] nativeOpenResponse(byte[] encKey, byte[] ciphertext);

    public static final native byte[] nativePrepareRequest(byte[] plaintext);

    public static final native String nativeSignRequest(byte[] macKey, String method, String path, long ts, String nonce, byte[] body, String ephPubB64);

    public static final native boolean nativeVerifyResponseSig(byte[] macKey, String method, String path, long ts, String nonce, byte[] body, String ephPubB64, String sigB64);
}
