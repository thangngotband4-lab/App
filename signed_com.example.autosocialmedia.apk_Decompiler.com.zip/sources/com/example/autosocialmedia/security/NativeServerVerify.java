package com.example.autosocialmedia.security;

import java.util.Arrays;
import kotlin.Metadata;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u001c\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0005\n\u0002\u0010\t\n\u0002\b\u0002\bÇ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J3\u0010\u0004\u001a\u0004\u0018\u00010\u00052\u0006\u0010\u0006\u001a\u00020\u00052\u0006\u0010\u0007\u001a\u00020\u00052\u0006\u0010\b\u001a\u00020\u00052\u0006\u0010\t\u001a\u00020\u00052\u0006\u0010\n\u001a\u00020\u000bH\u0087 J\b\u0010\f\u001a\u0004\u0018\u00010\u0005¨\u0006\r"}, d2 = {"Lcom/example/autosocialmedia/security/NativeServerVerify;", "", "<init>", "()V", "nativeVerifyServerResponse", "", "response", "expectedNonce", "expectedUid", "expectedDeviceFp", "nowUnix", "", "generateNonce", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class NativeServerVerify {
    public static final int $stable = 0;
    public static final NativeServerVerify INSTANCE = new NativeServerVerify();

    static {
        try {
            System.loadLibrary("asm_crypto");
        } catch (Throwable unused) {
        }
    }

    private NativeServerVerify() {
    }

    public static final CharSequence generateNonce$lambda$1(byte b) {
        return String.format("%02x", Arrays.copyOf(new Object[]{Byte.valueOf(b)}, 1));
    }

    public static final native String nativeVerifyServerResponse(String response, String expectedNonce, String expectedUid, String expectedDeviceFp, long nowUnix);

    public final String generateNonce() {
        byte[] bArrNativeRandomBytes = NativeCrypto.INSTANCE.nativeRandomBytes(32);
        if (bArrNativeRandomBytes == null) {
            return null;
        }
        StringBuilder sb = new StringBuilder();
        sb.append((CharSequence) "");
        int i = 0;
        for (byte b : bArrNativeRandomBytes) {
            i++;
            if (i > 1) {
                sb.append((CharSequence) "");
            }
            sb.append(generateNonce$lambda$1(b));
        }
        sb.append((CharSequence) "");
        return sb.toString();
    }
}
