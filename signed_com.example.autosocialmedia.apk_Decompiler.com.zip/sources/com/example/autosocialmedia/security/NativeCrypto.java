package com.example.autosocialmedia.security;

import defpackage.bw1;
import defpackage.d81;
import kotlin.Metadata;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000*\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\u0012\n\u0000\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0004\bÇ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0006\u0010\u0006\u001a\u00020\u0005J\u0013\u0010\u0007\u001a\u0004\u0018\u00010\b2\u0006\u0010\t\u001a\u00020\nH\u0086 J#\u0010\u000b\u001a\u0004\u0018\u00010\b2\u0006\u0010\f\u001a\u00020\b2\u0006\u0010\r\u001a\u00020\u000e2\u0006\u0010\u000f\u001a\u00020\bH\u0086 J#\u0010\u0010\u001a\u0004\u0018\u00010\b2\u0006\u0010\f\u001a\u00020\b2\u0006\u0010\r\u001a\u00020\u000e2\u0006\u0010\u0011\u001a\u00020\bH\u0086 R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006\u0012"}, d2 = {"Lcom/example/autosocialmedia/security/NativeCrypto;", "", "<init>", "()V", "available", "", "isAvailable", "nativeRandomBytes", "", "length", "", "nativeEncrypt", "masterKey", "context", "", "plaintext", "nativeDecrypt", "ciphertext", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class NativeCrypto {
    public static final int $stable;
    public static final NativeCrypto INSTANCE = new NativeCrypto();
    private static volatile boolean available;

    static {
        Object d81Var;
        try {
            System.loadLibrary("asm_crypto");
            d81Var = bw1.a;
        } catch (Throwable th) {
            d81Var = new d81(th);
        }
        available = !(d81Var instanceof d81);
        $stable = 8;
    }

    private NativeCrypto() {
    }

    public final boolean isAvailable() {
        return available;
    }

    public final native byte[] nativeDecrypt(byte[] masterKey, String context, byte[] ciphertext);

    public final native byte[] nativeEncrypt(byte[] masterKey, String context, byte[] plaintext);

    public final native byte[] nativeRandomBytes(int length);
}
