package com.example.autosocialmedia.security;

import defpackage.bw1;
import defpackage.d81;
import kotlin.Metadata;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0010\u000e\n\u0002\b\u0006\n\u0002\u0010\t\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u0006\bÇ\u0002\u0018\u00002\u00020\u0001JH\u0010\u000b\u001a\u00020\t2\u0006\u0010\u0003\u001a\u00020\u00022\u0006\u0010\u0004\u001a\u00020\u00022\u0006\u0010\u0005\u001a\u00020\u00022\u0006\u0010\u0006\u001a\u00020\u00022\u0006\u0010\u0007\u001a\u00020\u00022\u0006\u0010\b\u001a\u00020\u00022\u0006\u0010\n\u001a\u00020\tH\u0086 ¢\u0006\u0004\b\u000b\u0010\fJ\u0018\u0010\u000e\u001a\u00020\u00022\u0006\u0010\r\u001a\u00020\tH\u0086 ¢\u0006\u0004\b\u000e\u0010\u000fJ\u0018\u0010\u0010\u001a\u00020\u00022\u0006\u0010\r\u001a\u00020\tH\u0086 ¢\u0006\u0004\b\u0010\u0010\u000fJ\u0018\u0010\u0012\u001a\u00020\u00112\u0006\u0010\r\u001a\u00020\tH\u0086 ¢\u0006\u0004\b\u0012\u0010\u0013J\u0018\u0010\u0014\u001a\u00020\u00112\u0006\u0010\r\u001a\u00020\tH\u0086 ¢\u0006\u0004\b\u0014\u0010\u0013J\u0018\u0010\u0015\u001a\u00020\u00022\u0006\u0010\u0003\u001a\u00020\u0002H\u0086 ¢\u0006\u0004\b\u0015\u0010\u0016¨\u0006\u0017"}, d2 = {"Lcom/example/autosocialmedia/security/NativeX;", "", "", "authorization", "accountsJson", "configJson", "licenseStr", "deviceFp", "certSha256", "", "nowUnix", "nativeNewRunner", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;J)J", "handle", "nativeTick", "(J)Ljava/lang/String;", "nativeStats", "Lbw1;", "nativeStop", "(J)V", "nativeFreeRunner", "nativeGetTwitterAccounts", "(Ljava/lang/String;)Ljava/lang/String;", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class NativeX {
    public static final NativeX a = new NativeX();
    public static volatile boolean b;

    static {
        Object d81Var;
        try {
            System.loadLibrary("asm_crypto");
            d81Var = bw1.a;
        } catch (Throwable th) {
            d81Var = new d81(th);
        }
        b = !(d81Var instanceof d81);
    }

    public final native void nativeFreeRunner(long handle);

    public final native String nativeGetTwitterAccounts(String authorization);

    public final native long nativeNewRunner(String authorization, String accountsJson, String configJson, String licenseStr, String deviceFp, String certSha256, long nowUnix);

    public final native String nativeStats(long handle);

    public final native void nativeStop(long handle);

    public final native String nativeTick(long handle);
}
