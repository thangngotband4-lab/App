package android.support.v4.graphics.drawable;

import androidx.core.graphics.drawable.IconCompat;
import defpackage.by1;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class IconCompatParcelizer extends androidx.core.graphics.drawable.IconCompatParcelizer {
    public static IconCompat read(by1 by1Var) {
        return androidx.core.graphics.drawable.IconCompatParcelizer.read(by1Var);
    }

    public static void write(IconCompat iconCompat, by1 by1Var) {
        androidx.core.graphics.drawable.IconCompatParcelizer.write(iconCompat, by1Var);
    }
}
