package android.support.v4.app;

import androidx.core.app.RemoteActionCompat;
import defpackage.by1;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class RemoteActionCompatParcelizer extends androidx.core.app.RemoteActionCompatParcelizer {
    public static RemoteActionCompat read(by1 by1Var) {
        return androidx.core.app.RemoteActionCompatParcelizer.read(by1Var);
    }

    public static void write(RemoteActionCompat remoteActionCompat, by1 by1Var) {
        androidx.core.app.RemoteActionCompatParcelizer.write(remoteActionCompat, by1Var);
    }
}
