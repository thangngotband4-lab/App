package defpackage;

import android.content.Context;
import android.content.res.AssetManager;
import android.graphics.Typeface;
import android.graphics.fonts.FontVariationAxis;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.util.Log;
import java.io.IOException;
import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public class fv1 extends dv1 {
    public final Class e;
    public final Constructor f;
    public final Method g;
    public final Method h;
    public final Method i;
    public final Method j;
    public final Method k;

    public fv1() throws NoSuchMethodException {
        Method methodL;
        Constructor<?> constructor;
        Method methodK;
        Method method;
        Method method2;
        Method method3;
        Class<?> cls = null;
        try {
            Class<?> cls2 = Class.forName("android.graphics.FontFamily");
            constructor = cls2.getConstructor(null);
            methodK = k(cls2);
            Class cls3 = Integer.TYPE;
            method = cls2.getMethod("addFontFromBuffer", ByteBuffer.class, cls3, FontVariationAxis[].class, cls3, cls3);
            method2 = cls2.getMethod("freeze", null);
            method3 = cls2.getMethod("abortCreation", null);
            methodL = l(cls2);
            cls = cls2;
        } catch (ClassNotFoundException | NoSuchMethodException e) {
            Log.e("TypefaceCompatApi26Impl", "Unable to collect necessary methods for class ".concat(e.getClass().getName()), e);
            methodL = null;
            constructor = null;
            methodK = null;
            method = null;
            method2 = null;
            method3 = null;
        }
        this.e = cls;
        this.f = constructor;
        this.g = methodK;
        this.h = method;
        this.i = method2;
        this.j = method3;
        this.k = methodL;
    }

    public static Method k(Class cls) {
        Class cls2 = Boolean.TYPE;
        Class cls3 = Integer.TYPE;
        return cls.getMethod("addFontFromAssetManager", AssetManager.class, String.class, cls3, cls2, cls3, cls3, cls3, FontVariationAxis[].class);
    }

    @Override // defpackage.dv1, defpackage.yj1
    public final Typeface d(Context context, r40[] r40VarArr) throws IOException {
        Object objNewInstance;
        boolean zBooleanValue;
        Typeface typefaceJ;
        boolean zBooleanValue2;
        if (r40VarArr.length >= 1) {
            Method method = this.g;
            if (method == null) {
                Log.w("TypefaceCompatApi26Impl", "Unable to collect necessary private methods. Fallback to legacy implementation.");
            }
            try {
                if (method != null) {
                    HashMap map = new HashMap();
                    for (r40 r40Var : r40VarArr) {
                        if (r40Var.e == 0) {
                            Uri uri = r40Var.a;
                            if (!map.containsKey(uri)) {
                                map.put(uri, ak1.l(context, uri));
                            }
                        }
                    }
                    Map mapUnmodifiableMap = Collections.unmodifiableMap(map);
                    try {
                        objNewInstance = this.f.newInstance(null);
                    } catch (IllegalAccessException | InstantiationException | InvocationTargetException unused) {
                        objNewInstance = null;
                    }
                    if (objNewInstance != null) {
                        int length = r40VarArr.length;
                        int i = 0;
                        boolean z = false;
                        while (true) {
                            Method method2 = this.j;
                            if (i < length) {
                                r40 r40Var2 = r40VarArr[i];
                                ByteBuffer byteBuffer = (ByteBuffer) mapUnmodifiableMap.get(r40Var2.a);
                                if (byteBuffer != null) {
                                    try {
                                        zBooleanValue2 = ((Boolean) this.h.invoke(objNewInstance, byteBuffer, Integer.valueOf(r40Var2.b), null, Integer.valueOf(r40Var2.c), Integer.valueOf(r40Var2.d ? 1 : 0))).booleanValue();
                                    } catch (IllegalAccessException | InvocationTargetException unused2) {
                                        zBooleanValue2 = false;
                                    }
                                    if (!zBooleanValue2) {
                                        method2.invoke(objNewInstance, null);
                                        break;
                                    }
                                    z = true;
                                }
                                i++;
                                z = z;
                            } else if (z) {
                                try {
                                    zBooleanValue = ((Boolean) this.i.invoke(objNewInstance, null)).booleanValue();
                                } catch (IllegalAccessException | InvocationTargetException unused3) {
                                    zBooleanValue = false;
                                }
                                if (zBooleanValue && (typefaceJ = j(objNewInstance)) != null) {
                                    return Typeface.create(typefaceJ, 0);
                                }
                            } else {
                                method2.invoke(objNewInstance, null);
                            }
                        }
                    }
                } else {
                    r40 r40VarE = yj1.e(r40VarArr);
                    ParcelFileDescriptor parcelFileDescriptorOpenFileDescriptor = context.getContentResolver().openFileDescriptor(r40VarE.a, "r", null);
                    if (parcelFileDescriptorOpenFileDescriptor != null) {
                        try {
                            Typeface typefaceBuild = new Typeface.Builder(parcelFileDescriptorOpenFileDescriptor.getFileDescriptor()).setWeight(r40VarE.c).setItalic(r40VarE.d).build();
                            parcelFileDescriptorOpenFileDescriptor.close();
                            return typefaceBuild;
                        } finally {
                        }
                    }
                    if (parcelFileDescriptorOpenFileDescriptor != null) {
                        parcelFileDescriptorOpenFileDescriptor.close();
                        return null;
                    }
                }
            } catch (IOException | IllegalAccessException | InvocationTargetException unused4) {
            }
        }
        return null;
    }

    public Typeface j(Object obj) {
        try {
            Object objNewInstance = Array.newInstance((Class<?>) this.e, 1);
            Array.set(objNewInstance, 0, obj);
            return (Typeface) this.k.invoke(null, objNewInstance, -1, -1);
        } catch (IllegalAccessException | InvocationTargetException unused) {
            return null;
        }
    }

    public Method l(Class cls) throws NoSuchMethodException {
        Class<?> cls2 = Array.newInstance((Class<?>) cls, 1).getClass();
        Class cls3 = Integer.TYPE;
        Method declaredMethod = Typeface.class.getDeclaredMethod("createFromFamiliesWithDefault", cls2, cls3, cls3);
        declaredMethod.setAccessible(true);
        return declaredMethod;
    }
}
