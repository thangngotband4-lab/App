package defpackage;

import android.graphics.RadialGradient;
import android.graphics.Shader;
import java.util.List;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class e61 extends lf1 {
    public final List c;
    public final long d;

    public e61(List list, long j) {
        this.c = list;
        this.d = j;
    }

    @Override // defpackage.lf1
    public final Shader b(long j) {
        float fIntBitsToFloat;
        float fIntBitsToFloat2;
        long j2 = this.d;
        if ((9223372034707292159L & j2) == 9205357640488583168L) {
            long jV = jl.v(j);
            fIntBitsToFloat = Float.intBitsToFloat((int) (jV >> 32));
            fIntBitsToFloat2 = Float.intBitsToFloat((int) (jV & 4294967295L));
        } else {
            int i = (int) (j2 >> 32);
            if (Float.intBitsToFloat(i) == Float.POSITIVE_INFINITY) {
                i = (int) (j >> 32);
            }
            fIntBitsToFloat = Float.intBitsToFloat(i);
            int i2 = (int) (j2 & 4294967295L);
            fIntBitsToFloat2 = Float.intBitsToFloat(i2) == Float.POSITIVE_INFINITY ? Float.intBitsToFloat((int) (j & 4294967295L)) : Float.intBitsToFloat(i2);
        }
        long jFloatToRawIntBits = (((long) Float.floatToRawIntBits(fIntBitsToFloat2)) & 4294967295L) | (((long) Float.floatToRawIntBits(fIntBitsToFloat)) << 32);
        List list = this.c;
        vh0.P(list);
        int iU = vh0.u(list);
        return new RadialGradient(Float.intBitsToFloat((int) (jFloatToRawIntBits >> 32)), Float.intBitsToFloat((int) (jFloatToRawIntBits & 4294967295L)), 600.0f, vh0.E(iU, list), vh0.F(iU, list), Shader.TileMode.CLAMP);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof e61)) {
            return false;
        }
        e61 e61Var = (e61) obj;
        return this.c.equals(e61Var.c) && jw0.b(this.d, e61Var.d);
    }

    public final int hashCode() {
        return Integer.hashCode(0) + f0.a(600.0f, f0.c(this.c.hashCode() * 961, 31, this.d), 31);
    }

    public final String toString() {
        String str;
        long j = this.d;
        if ((9223372034707292159L & j) != 9205357640488583168L) {
            str = "center=" + ((Object) jw0.g(j)) + ", ";
        } else {
            str = "";
        }
        return "RadialGradient(colors=" + this.c + ", stops=null, " + str + ((Float.floatToRawIntBits(600.0f) & Integer.MAX_VALUE) < 2139095040 ? "radius=600.0, " : "") + "tileMode=Clamp)";
    }
}
