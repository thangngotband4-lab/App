package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class i extends jl1 implements l50 {
    public final /* synthetic */ int e = 1;
    public int f;
    public final /* synthetic */ boolean g;
    public final /* synthetic */ ks0 h;
    public Object i;
    public final /* synthetic */ Object j;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public i(ks0 ks0Var, y41 y41Var, boolean z, xk xkVar, tq tqVar) {
        super(2, tqVar);
        this.h = ks0Var;
        this.i = y41Var;
        this.g = z;
        this.j = xkVar;
    }

    @Override // defpackage.l50
    public final Object f(Object obj, Object obj2) {
        int i = this.e;
        bw1 bw1Var = bw1.a;
        ds dsVar = (ds) obj;
        tq tqVar = (tq) obj2;
        switch (i) {
        }
        return ((i) o(tqVar, dsVar)).r(bw1Var);
    }

    @Override // defpackage.kf
    public final tq o(tq tqVar, Object obj) {
        int i = this.e;
        Object obj2 = this.j;
        switch (i) {
            case 0:
                return new i(this.h, (y41) this.i, this.g, (xk) obj2, tqVar);
            default:
                return new i((gt0) obj2, this.g, this.h, tqVar);
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:31:0x0081, code lost:
    
        if (r2.a(r0, r11) == r5) goto L32;
     */
    @Override // defpackage.kf
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final java.lang.Object r(java.lang.Object r12) {
        /*
            r11 = this;
            int r0 = r11.e
            bw1 r1 = defpackage.bw1.a
            ks0 r2 = r11.h
            boolean r3 = r11.g
            java.lang.String r4 = "call to 'resume' before 'invoke' with coroutine"
            es r5 = defpackage.es.d
            r6 = 1
            java.lang.Object r7 = r11.j
            r8 = 0
            switch(r0) {
                case 0: goto L53;
                default: goto L13;
            }
        L13:
            gt0 r7 = (defpackage.gt0) r7
            int r0 = r11.f
            if (r0 == 0) goto L29
            if (r0 != r6) goto L24
            java.lang.Object r11 = r11.i
            r7 = r11
            gt0 r7 = (defpackage.gt0) r7
            defpackage.vl.Q(r12)
            goto L4f
        L24:
            defpackage.zi.f(r4)
            r1 = r8
            goto L52
        L29:
            defpackage.vl.Q(r12)
            java.lang.Object r12 = r7.getValue()
            y41 r12 = (defpackage.y41) r12
            if (r12 == 0) goto L52
            if (r3 == 0) goto L3c
            z41 r0 = new z41
            r0.<init>(r12)
            goto L41
        L3c:
            x41 r0 = new x41
            r0.<init>(r12)
        L41:
            if (r2 == 0) goto L4f
            r11.i = r7
            r11.f = r6
            java.lang.Object r11 = r2.a(r0, r11)
            if (r11 != r5) goto L4f
            r1 = r5
            goto L52
        L4f:
            r7.setValue(r8)
        L52:
            return r1
        L53:
            java.lang.Object r0 = r11.i
            y41 r0 = (defpackage.y41) r0
            int r9 = r11.f
            r10 = 2
            if (r9 == 0) goto L6d
            if (r9 == r6) goto L69
            if (r9 != r10) goto L64
            defpackage.vl.Q(r12)
            goto L85
        L64:
            defpackage.zi.f(r4)
            r1 = r8
            goto L8e
        L69:
            defpackage.vl.Q(r12)
            goto L7b
        L6d:
            defpackage.vl.Q(r12)
            long r8 = defpackage.yk.a
            r11.f = r6
            java.lang.Object r12 = defpackage.jl.l(r8, r11)
            if (r12 != r5) goto L7b
            goto L83
        L7b:
            r11.f = r10
            java.lang.Object r11 = r2.a(r0, r11)
            if (r11 != r5) goto L85
        L83:
            r1 = r5
            goto L8e
        L85:
            xk r7 = (defpackage.xk) r7
            if (r3 == 0) goto L8c
            r7.H = r0
            goto L8e
        L8c:
            r7.D = r0
        L8e:
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.i.r(java.lang.Object):java.lang.Object");
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public i(gt0 gt0Var, boolean z, ks0 ks0Var, tq tqVar) {
        super(2, tqVar);
        this.j = gt0Var;
        this.g = z;
        this.h = ks0Var;
    }
}
