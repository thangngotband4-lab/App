package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class ih {
    public static final /* synthetic */ ih a = new ih();
    public static final yi1 b = y5.F(0.0f, 0.0f, null, 7);
    public static final hh c = new hh();
}
