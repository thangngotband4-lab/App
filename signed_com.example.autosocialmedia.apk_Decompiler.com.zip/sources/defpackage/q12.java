package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class q12 extends uq {
    public /* synthetic */ Object d;
    public final /* synthetic */ re0 e;
    public int f;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public q12(re0 re0Var, uq uqVar) {
        super(uqVar);
        this.e = re0Var;
    }

    @Override // defpackage.kf
    public final Object r(Object obj) {
        this.d = obj;
        this.f |= Integer.MIN_VALUE;
        return this.e.c(null, this);
    }
}
