package defpackage;

import android.os.Build;
import android.os.Bundle;
import android.window.OnBackInvokedDispatcher;
import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class w61 implements cn0 {
    public final /* synthetic */ int d;
    public final Object e;

    public /* synthetic */ w61(int i, Object obj) {
        this.d = i;
        this.e = obj;
    }

    @Override // defpackage.cn0
    public final void e(en0 en0Var, xm0 xm0Var) {
        int i = this.d;
        Object obj = this.e;
        switch (i) {
            case 0:
                na1 na1Var = (na1) obj;
                if (xm0Var != xm0.ON_CREATE) {
                    throw new AssertionError("Next event must be ON_CREATE");
                }
                en0Var.getLifecycle().b(this);
                Bundle bundleA = na1Var.getSavedStateRegistry().a("androidx.savedstate.Restarter");
                if (bundleA == null) {
                    return;
                }
                ArrayList<String> stringArrayList = bundleA.getStringArrayList("classes_to_restore");
                if (stringArrayList == null) {
                    zi.f("SavedState with restored state for the component \"androidx.savedstate.Restarter\" must contain list of strings by the key \"classes_to_restore\"");
                    return;
                }
                int size = stringArrayList.size();
                int i2 = 0;
                while (i2 < size) {
                    String str = stringArrayList.get(i2);
                    i2++;
                    String str2 = str;
                    try {
                        Class<? extends U> clsAsSubclass = Class.forName(str2, false, w61.class.getClassLoader()).asSubclass(ia1.class);
                        clsAsSubclass.getClass();
                        try {
                            Constructor declaredConstructor = clsAsSubclass.getDeclaredConstructor(null);
                            declaredConstructor.setAccessible(true);
                            try {
                                Object objNewInstance = declaredConstructor.newInstance(null);
                                objNewInstance.getClass();
                                if (!(na1Var instanceof dz1)) {
                                    throw new IllegalStateException(("Internal error: OnRecreation should be registered only on components that implement ViewModelStoreOwner. Received owner: " + na1Var).toString());
                                }
                                cz1 viewModelStore = ((dz1) na1Var).getViewModelStore();
                                ka1 savedStateRegistry = na1Var.getSavedStateRegistry();
                                viewModelStore.getClass();
                                LinkedHashMap linkedHashMap = viewModelStore.a;
                                for (String str3 : new HashSet(linkedHashMap.keySet())) {
                                    str3.getClass();
                                    yy1 yy1Var = (yy1) linkedHashMap.get(str3);
                                    if (yy1Var != null) {
                                        vl.g(yy1Var, savedStateRegistry, na1Var.getLifecycle());
                                    }
                                }
                                if (!new HashSet(linkedHashMap.keySet()).isEmpty()) {
                                    savedStateRegistry.d();
                                }
                            } catch (Exception e) {
                                throw new RuntimeException(f0.m("Failed to instantiate ", str2), e);
                            }
                        } catch (NoSuchMethodException e2) {
                            throw new IllegalStateException("Class " + clsAsSubclass.getSimpleName() + " must have default constructor in order to be automatically recreated", e2);
                        }
                    } catch (ClassNotFoundException e3) {
                        throw new RuntimeException(f0.n("Class ", str2, " wasn't found"), e3);
                    }
                }
                return;
            case 1:
                if (xm0Var != xm0.ON_CREATE || Build.VERSION.SDK_INT < 33) {
                    return;
                }
                ww0 ww0Var = ((ln) obj).mOnBackPressedDispatcher;
                OnBackInvokedDispatcher onBackInvokedDispatcherA = fn.a((ln) en0Var);
                ww0Var.getClass();
                onBackInvokedDispatcherA.getClass();
                ww0Var.e = onBackInvokedDispatcherA;
                ww0Var.b(ww0Var.g);
                return;
            case 2:
                new HashMap();
                z50[] z50VarArr = (z50[]) obj;
                if (z50VarArr.length > 0) {
                    z50 z50Var = z50VarArr[0];
                    throw null;
                }
                if (z50VarArr.length <= 0) {
                    return;
                }
                z50 z50Var2 = z50VarArr[0];
                throw null;
            default:
                if (xm0Var != xm0.ON_CREATE) {
                    throw new IllegalStateException(("Next event must be ON_CREATE, it was " + xm0Var).toString());
                }
                en0Var.getLifecycle().b(this);
                ((ga1) obj).b();
                return;
        }
    }
}
