package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class h12 extends er0 implements zi0 {
    public lv r;
    public l50 s;

    @Override // defpackage.zi0
    public final mq0 d(final nq0 nq0Var, gq0 gq0Var, long j) {
        final k21 k21VarE = gq0Var.e(yp.a(this.r != lv.d ? 0 : xp.j(j), xp.h(j), this.r == lv.e ? xp.i(j) : 0, xp.g(j)));
        final int iO = tl.o(k21VarE.d, xp.j(j), xp.h(j));
        final int iO2 = tl.o(k21VarE.e, xp.i(j), xp.g(j));
        return nq0Var.i0(iO, iO2, vz.d, new h50() { // from class: g12
            @Override // defpackage.h50
            public final Object g(Object obj) {
                l50 l50Var = this.d.s;
                k21 k21Var = k21VarE;
                j21.i((j21) obj, k21Var, ((rf0) l50Var.f(new yf0((((long) (iO - k21Var.d)) << 32) | (((long) (iO2 - k21Var.e)) & 4294967295L)), nq0Var.getLayoutDirection())).a);
                return bw1.a;
            }
        });
    }
}
