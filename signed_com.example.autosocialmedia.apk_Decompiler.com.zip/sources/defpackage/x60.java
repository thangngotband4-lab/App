package defpackage;

import android.graphics.Typeface;
import android.text.Spannable;
import androidx.compose.ui.input.pointer.PointerInputEventHandler;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class x60 implements m50 {
    public final /* synthetic */ int d;
    public final /* synthetic */ Object e;
    public final /* synthetic */ Object f;

    public /* synthetic */ x60(w40 w40Var, Object obj, int i) {
        this.d = i;
        this.f = w40Var;
        this.e = obj;
    }

    private final Object d(Object obj, Object obj2, Object obj3) {
        w40 w40Var = (w40) this.f;
        o12 o12Var = (o12) this.e;
        xo xoVar = (xo) obj2;
        int iIntValue = ((Integer) obj3).intValue();
        ((lm) obj).getClass();
        if (xoVar.O(iIntValue & 1, (iIntValue & 17) != 16)) {
            k91 k91VarA = j91.a(ng0.e, a4.o, xoVar, 48);
            int iHashCode = Long.hashCode(xoVar.T);
            t11 t11VarL = xoVar.l();
            cr0 cr0Var = cr0.a;
            fr0 fr0VarM = om.M(xoVar, cr0Var);
            oo.b.getClass();
            kp kpVar = no.b;
            xoVar.Z();
            if (xoVar.S) {
                xoVar.k(kpVar);
            } else {
                xoVar.j0();
            }
            oa oaVar = no.e;
            ak1.o(xoVar, oaVar, k91VarA);
            oa oaVar2 = no.d;
            ak1.o(xoVar, oaVar2, t11VarL);
            Integer numValueOf = Integer.valueOf(iHashCode);
            oa oaVar3 = no.f;
            ak1.j(xoVar, numValueOf, oaVar3);
            c5 c5Var = no.g;
            ak1.n(xoVar, c5Var);
            oa oaVar4 = no.c;
            ak1.o(xoVar, oaVar4, fr0VarM);
            fr0 fr0VarQ = eq0.q(ng0.t(ig1.f(cr0Var, 40.0f), g91.a(10.0f)), ql.b(0.15f, sl.b()), eq0.G);
            lq0 lq0VarD = tg.d(a4.i, false);
            int iHashCode2 = Long.hashCode(xoVar.T);
            t11 t11VarL2 = xoVar.l();
            fr0 fr0VarM2 = om.M(xoVar, fr0VarQ);
            xoVar.Z();
            if (xoVar.S) {
                xoVar.k(kpVar);
            } else {
                xoVar.j0();
            }
            ak1.o(xoVar, oaVar, lq0VarD);
            ak1.o(xoVar, oaVar2, t11VarL2);
            f0.t(iHashCode2, xoVar, oaVar3, xoVar, c5Var);
            ak1.o(xoVar, oaVar4, fr0VarM2);
            bc0.a(vh0.x(), null, ig1.f(cr0Var, 22.0f), sl.b(), xoVar, 432, 0);
            xoVar.p(true);
            om.d(xoVar, ig1.f(cr0Var, 12.0f));
            xj0 xj0Var = new xj0(1.0f, true);
            km kmVarA = im.a(ng0.g, a4.q, xoVar, 0);
            int iHashCode3 = Long.hashCode(xoVar.T);
            t11 t11VarL3 = xoVar.l();
            fr0 fr0VarM3 = om.M(xoVar, xj0Var);
            xoVar.Z();
            if (xoVar.S) {
                xoVar.k(kpVar);
            } else {
                xoVar.j0();
            }
            ak1.o(xoVar, oaVar, kmVarA);
            ak1.o(xoVar, oaVar2, t11VarL3);
            f0.t(iHashCode3, xoVar, oaVar3, xoVar, c5Var);
            ak1.o(xoVar, oaVar4, fr0VarM3);
            mp1.b(f0.m("@", o12Var.c()), null, sl.l(), ak1.h(15), p40.h, null, 0L, null, 0L, 0, false, 0, 0, null, xoVar, 1597440, 0, 262058);
            mp1.b("GoLike #" + o12Var.b() + " • cookies đã lưu", null, sl.n(), ak1.h(12), null, null, 0L, null, 0L, 0, false, 0, 0, null, xoVar, 24576, 0, 262122);
            xoVar.p(true);
            m22.h(w40Var, null, false, null, null, mg0.J, xoVar, 1572864, 62);
            xoVar.p(true);
        } else {
            xoVar.R();
        }
        return bw1.a;
    }

    @Override // defpackage.m50
    public final Object c(Object obj, Object obj2, Object obj3) {
        boolean z;
        Typeface typeface;
        int i = this.d;
        cr0 cr0Var = cr0.a;
        int i2 = 16;
        tq tqVar = null;
        bw1 bw1Var = bw1.a;
        Object obj4 = this.e;
        Object obj5 = this.f;
        switch (i) {
            case 0:
                q90 q90Var = (q90) obj4;
                w40 w40Var = (w40) obj5;
                xo xoVar = (xo) obj2;
                int iIntValue = ((Integer) obj3).intValue();
                zf zfVar = a4.q;
                bg bgVar = a4.i;
                ag agVar = a4.o;
                ((lm) obj).getClass();
                if (!xoVar.O(iIntValue & 1, (iIntValue & 17) != 16)) {
                    xoVar.R();
                    return bw1Var;
                }
                if (q90Var == null) {
                    xoVar.W(1636973513);
                    f10 f10Var = ig1.a;
                    k91 k91VarA = j91.a(new hd(14.0f, new dd(0)), agVar, xoVar, 54);
                    int iHashCode = Long.hashCode(xoVar.T);
                    t11 t11VarL = xoVar.l();
                    fr0 fr0VarM = om.M(xoVar, f10Var);
                    oo.b.getClass();
                    kp kpVar = no.b;
                    xoVar.Z();
                    if (xoVar.S) {
                        xoVar.k(kpVar);
                    } else {
                        xoVar.j0();
                    }
                    oa oaVar = no.e;
                    ak1.o(xoVar, oaVar, k91VarA);
                    oa oaVar2 = no.d;
                    ak1.o(xoVar, oaVar2, t11VarL);
                    Integer numValueOf = Integer.valueOf(iHashCode);
                    oa oaVar3 = no.f;
                    ak1.j(xoVar, numValueOf, oaVar3);
                    c5 c5Var = no.g;
                    ak1.n(xoVar, c5Var);
                    oa oaVar4 = no.c;
                    ak1.o(xoVar, oaVar4, fr0VarM);
                    fr0 fr0VarQ = eq0.q(ig1.f(cr0Var, 48.0f), ql.b(0.12f, sl.c()), g91.a(14.0f));
                    lq0 lq0VarD = tg.d(bgVar, false);
                    int iHashCode2 = Long.hashCode(xoVar.T);
                    t11 t11VarL2 = xoVar.l();
                    fr0 fr0VarM2 = om.M(xoVar, fr0VarQ);
                    xoVar.Z();
                    if (xoVar.S) {
                        xoVar.k(kpVar);
                    } else {
                        xoVar.j0();
                    }
                    ak1.o(xoVar, oaVar, lq0VarD);
                    ak1.o(xoVar, oaVar2, t11VarL2);
                    f0.t(iHashCode2, xoVar, oaVar3, xoVar, c5Var);
                    ak1.o(xoVar, oaVar4, fr0VarM2);
                    bc0.a(jl.y(), "Đăng nhập GoLike", ig1.f(cr0Var, 26.0f), sl.c(), xoVar, 432, 0);
                    xoVar.p(true);
                    xj0 xj0Var = new xj0(1.0f, true);
                    km kmVarA = im.a(new hd(2.0f, new dd(0)), zfVar, xoVar, 6);
                    int iHashCode3 = Long.hashCode(xoVar.T);
                    t11 t11VarL3 = xoVar.l();
                    fr0 fr0VarM3 = om.M(xoVar, xj0Var);
                    xoVar.Z();
                    if (xoVar.S) {
                        xoVar.k(kpVar);
                    } else {
                        xoVar.j0();
                    }
                    ak1.o(xoVar, oaVar, kmVarA);
                    ak1.o(xoVar, oaVar2, t11VarL3);
                    f0.t(iHashCode3, xoVar, oaVar3, xoVar, c5Var);
                    ak1.o(xoVar, oaVar4, fr0VarM3);
                    mp1.b("Chưa đăng nhập GoLike", null, sl.l(), ak1.h(16), p40.h, null, 0L, null, 0L, 0, false, 0, 0, null, xoVar, 1597446, 0, 262058);
                    mp1.b("Bấm để mở trình duyệt nhúng đăng nhập GoLike", null, sl.m(), ak1.h(13), null, null, 0L, null, ak1.h(18), 0, false, 0, 0, null, xoVar, 24582, 48, 260074);
                    xoVar.p(true);
                    bc0.a(fl.n(), "Đăng nhập", ig1.f(cr0Var, 28.0f), sl.c(), xoVar, 432, 0);
                    xoVar.p(true);
                    xoVar.p(false);
                    return bw1Var;
                }
                xoVar.W(1638929396);
                f10 f10Var2 = ig1.a;
                k91 k91VarA2 = j91.a(new hd(14.0f, new dd(0)), agVar, xoVar, 54);
                int iHashCode4 = Long.hashCode(xoVar.T);
                t11 t11VarL4 = xoVar.l();
                fr0 fr0VarM4 = om.M(xoVar, f10Var2);
                oo.b.getClass();
                kp kpVar2 = no.b;
                xoVar.Z();
                if (xoVar.S) {
                    xoVar.k(kpVar2);
                } else {
                    xoVar.j0();
                }
                oa oaVar5 = no.e;
                ak1.o(xoVar, oaVar5, k91VarA2);
                oa oaVar6 = no.d;
                ak1.o(xoVar, oaVar6, t11VarL4);
                Integer numValueOf2 = Integer.valueOf(iHashCode4);
                oa oaVar7 = no.f;
                ak1.j(xoVar, numValueOf2, oaVar7);
                c5 c5Var2 = no.g;
                ak1.n(xoVar, c5Var2);
                oa oaVar8 = no.c;
                ak1.o(xoVar, oaVar8, fr0VarM4);
                fr0 fr0VarQ2 = eq0.q(ig1.f(cr0Var, 48.0f), ql.b(0.15f, sl.b()), g91.a(14.0f));
                lq0 lq0VarD2 = tg.d(bgVar, false);
                int iHashCode5 = Long.hashCode(xoVar.T);
                t11 t11VarL5 = xoVar.l();
                fr0 fr0VarM5 = om.M(xoVar, fr0VarQ2);
                xoVar.Z();
                if (xoVar.S) {
                    xoVar.k(kpVar2);
                } else {
                    xoVar.j0();
                }
                ak1.o(xoVar, oaVar5, lq0VarD2);
                ak1.o(xoVar, oaVar6, t11VarL5);
                f0.t(iHashCode5, xoVar, oaVar7, xoVar, c5Var2);
                ak1.o(xoVar, oaVar8, fr0VarM5);
                bc0.a(ct.C(), "Tài khoản GoLike", ig1.f(cr0Var, 28.0f), sl.b(), xoVar, 432, 0);
                xoVar.p(true);
                fr0 fr0VarA = l91.a();
                km kmVarA2 = im.a(new hd(2.0f, new dd(0)), zfVar, xoVar, 6);
                int iHashCode6 = Long.hashCode(xoVar.T);
                t11 t11VarL6 = xoVar.l();
                fr0 fr0VarM6 = om.M(xoVar, fr0VarA);
                xoVar.Z();
                if (xoVar.S) {
                    xoVar.k(kpVar2);
                } else {
                    xoVar.j0();
                }
                ak1.o(xoVar, oaVar5, kmVarA2);
                ak1.o(xoVar, oaVar6, t11VarL6);
                f0.t(iHashCode6, xoVar, oaVar7, xoVar, c5Var2);
                ak1.o(xoVar, oaVar8, fr0VarM6);
                String strD = q90Var.d();
                if (bk1.s(strD)) {
                    strD = q90Var.f();
                }
                mp1.b(strD, null, sl.l(), ak1.h(16), p40.i, null, 0L, null, 0L, 0, false, 0, 0, null, xoVar, 1597440, 0, 262058);
                mp1.b(f0.m("@", q90Var.f()), null, sl.n(), ak1.h(13), null, null, 0L, null, 0L, 0, false, 0, 0, null, xoVar, 24576, 0, 262122);
                xoVar.p(true);
                m22.h(w40Var, null, false, null, null, ng0.q, xoVar, 1572864, 62);
                xoVar.p(true);
                om.d(xoVar, ig1.b(cr0Var, 12.0f));
                fr0 fr0VarB = y5.B(eq0.q(f10Var2, ql.b(0.1f, sl.c()), g91.a(12.0f)), 12.0f, 10.0f);
                k91 k91VarA3 = j91.a(new hd(8.0f, new dd(0)), agVar, xoVar, 54);
                int iHashCode7 = Long.hashCode(xoVar.T);
                t11 t11VarL7 = xoVar.l();
                fr0 fr0VarM7 = om.M(xoVar, fr0VarB);
                xoVar.Z();
                if (xoVar.S) {
                    xoVar.k(kpVar2);
                } else {
                    xoVar.j0();
                }
                ak1.o(xoVar, oaVar5, k91VarA3);
                ak1.o(xoVar, oaVar6, t11VarL7);
                f0.t(iHashCode7, xoVar, oaVar7, xoVar, c5Var2);
                ak1.o(xoVar, oaVar8, fr0VarM7);
                bc0.a(vl.y(), null, ig1.f(cr0Var, 20.0f), sl.c(), xoVar, 432, 0);
                fr0 fr0VarA2 = l91.a();
                km kmVarA3 = im.a(ng0.g, zfVar, xoVar, 0);
                int iHashCode8 = Long.hashCode(xoVar.T);
                t11 t11VarL8 = xoVar.l();
                fr0 fr0VarM8 = om.M(xoVar, fr0VarA2);
                xoVar.Z();
                if (xoVar.S) {
                    xoVar.k(kpVar2);
                } else {
                    xoVar.j0();
                }
                ak1.o(xoVar, oaVar5, kmVarA3);
                ak1.o(xoVar, oaVar6, t11VarL8);
                f0.t(iHashCode8, xoVar, oaVar7, xoVar, c5Var2);
                ak1.o(xoVar, oaVar8, fr0VarM8);
                mp1.b("Số dư GoLike", null, sl.n(), ak1.h(11), p40.g, null, ak1.g(0.3d), null, 0L, 0, false, 0, 0, null, xoVar, 102260742, 0, 261802);
                mp1.b(q90Var.c() + " xu", null, sl.l(), ak1.h(18), p40.j, null, ak1.g(-0.3d), null, 0L, 0, false, 0, 0, null, xoVar, 1597440, 0, 261802);
                xoVar.p(true);
                bc0.a(fl.n(), "Mở Auto GoLike", ig1.f(cr0Var, 22.0f), sl.c(), xoVar, 432, 0);
                xoVar.p(true);
                xoVar.p(false);
                return bw1Var;
            case 1:
                ((Boolean) obj).getClass();
                int iIntValue2 = ((Integer) obj3).intValue();
                ((e71) obj4).d = (String) obj2;
                ((c71) obj5).d += iIntValue2;
                return bw1Var;
            case 2:
                h50 h50Var = (h50) obj4;
                nq nqVar = (nq) obj5;
                xo xoVar2 = (xo) obj2;
                int iIntValue3 = ((Integer) obj3).intValue();
                if (xoVar2.O(iIntValue3 & 1, (iIntValue3 & 17) != 16)) {
                    Object objL = xoVar2.L();
                    if (objL == ro.a) {
                        objL = new oq();
                        xoVar2.g0(objL);
                    }
                    oq oqVar = (oq) objL;
                    oqVar.a.clear();
                    h50Var.g(oqVar);
                    oqVar.a(nqVar, xoVar2, 0);
                } else {
                    xoVar2.R();
                }
                return bw1Var;
            case 3:
                w40 w40Var2 = (w40) obj5;
                kj1 kj1Var = (kj1) obj4;
                xo xoVar3 = (xo) obj2;
                int iIntValue4 = ((Integer) obj3).intValue();
                ((bk0) obj).getClass();
                if (xoVar3.O(iIntValue4 & 1, (iIntValue4 & 17) != 16)) {
                    vh0.f((jm0) kj1Var.getValue(), null, w40Var2, xoVar3, 0);
                    om.d(xoVar3, ig1.b(cr0Var, 20.0f));
                } else {
                    xoVar3.R();
                }
                return bw1Var;
            case 4:
                ib1 ib1Var = (ib1) obj4;
                kj1 kj1Var2 = (kj1) obj5;
                xo xoVar4 = (xo) obj2;
                ((Integer) obj3).getClass();
                ((tb) obj).getClass();
                k91 k91VarA4 = j91.a(ng0.e, a4.o, xoVar4, 48);
                int iHashCode9 = Long.hashCode(xoVar4.T);
                t11 t11VarL9 = xoVar4.l();
                fr0 fr0VarM9 = om.M(xoVar4, cr0Var);
                oo.b.getClass();
                kp kpVar3 = no.b;
                xoVar4.Z();
                if (xoVar4.S) {
                    xoVar4.k(kpVar3);
                } else {
                    xoVar4.j0();
                }
                ak1.o(xoVar4, no.e, k91VarA4);
                ak1.o(xoVar4, no.d, t11VarL9);
                ak1.j(xoVar4, Integer.valueOf(iHashCode9), no.f);
                ak1.n(xoVar4, no.g);
                ak1.o(xoVar4, no.c, fr0VarM9);
                om.d(xoVar4, ig1.i(cr0Var, 6.0f));
                mp1.b(ib1Var.b, null, ((ql) kj1Var2.getValue()).a, ak1.h(12), p40.h, null, 0L, null, 0L, 0, false, 0, 0, null, xoVar4, 1597440, 0, 262058);
                xoVar4.p(true);
                return bw1Var;
            case 5:
                w40 w40Var3 = (w40) obj5;
                cc0 cc0Var = (cc0) obj4;
                xo xoVar5 = (xo) obj2;
                int iIntValue5 = ((Integer) obj3).intValue();
                ((lm) obj).getClass();
                if (xoVar5.O(iIntValue5 & 1, (iIntValue5 & 17) != 16)) {
                    k91 k91VarA5 = j91.a(ng0.e, a4.o, xoVar5, 48);
                    int iHashCode10 = Long.hashCode(xoVar5.T);
                    t11 t11VarL10 = xoVar5.l();
                    fr0 fr0VarM10 = om.M(xoVar5, cr0Var);
                    oo.b.getClass();
                    kp kpVar4 = no.b;
                    xoVar5.Z();
                    if (xoVar5.S) {
                        xoVar5.k(kpVar4);
                    } else {
                        xoVar5.j0();
                    }
                    oa oaVar9 = no.e;
                    ak1.o(xoVar5, oaVar9, k91VarA5);
                    oa oaVar10 = no.d;
                    ak1.o(xoVar5, oaVar10, t11VarL10);
                    Integer numValueOf3 = Integer.valueOf(iHashCode10);
                    oa oaVar11 = no.f;
                    ak1.j(xoVar5, numValueOf3, oaVar11);
                    c5 c5Var3 = no.g;
                    ak1.n(xoVar5, c5Var3);
                    oa oaVar12 = no.c;
                    ak1.o(xoVar5, oaVar12, fr0VarM10);
                    fr0 fr0VarQ3 = eq0.q(ng0.t(ig1.f(cr0Var, 40.0f), g91.a(10.0f)), ql.b(0.15f, sl.d()), eq0.G);
                    lq0 lq0VarD3 = tg.d(a4.i, false);
                    int iHashCode11 = Long.hashCode(xoVar5.T);
                    t11 t11VarL11 = xoVar5.l();
                    fr0 fr0VarM11 = om.M(xoVar5, fr0VarQ3);
                    xoVar5.Z();
                    if (xoVar5.S) {
                        xoVar5.k(kpVar4);
                    } else {
                        xoVar5.j0();
                    }
                    ak1.o(xoVar5, oaVar9, lq0VarD3);
                    ak1.o(xoVar5, oaVar10, t11VarL11);
                    f0.t(iHashCode11, xoVar5, oaVar11, xoVar5, c5Var3);
                    ak1.o(xoVar5, oaVar12, fr0VarM11);
                    bc0.a(hl.A(), null, ig1.f(cr0Var, 22.0f), sl.d(), xoVar5, 432, 0);
                    xoVar5.p(true);
                    om.d(xoVar5, ig1.f(cr0Var, 12.0f));
                    xj0 xj0Var2 = new xj0(1.0f, true);
                    km kmVarA4 = im.a(ng0.g, a4.q, xoVar5, 0);
                    int iHashCode12 = Long.hashCode(xoVar5.T);
                    t11 t11VarL12 = xoVar5.l();
                    fr0 fr0VarM12 = om.M(xoVar5, xj0Var2);
                    xoVar5.Z();
                    if (xoVar5.S) {
                        xoVar5.k(kpVar4);
                    } else {
                        xoVar5.j0();
                    }
                    ak1.o(xoVar5, oaVar9, kmVarA4);
                    ak1.o(xoVar5, oaVar10, t11VarL12);
                    f0.t(iHashCode12, xoVar5, oaVar11, xoVar5, c5Var3);
                    ak1.o(xoVar5, oaVar12, fr0VarM12);
                    mp1.b(f0.m("@", cc0Var.c()), null, sl.l(), ak1.h(15), p40.h, null, 0L, null, 0L, 0, false, 0, 0, null, xoVar5, 1597440, 0, 262058);
                    mp1.b("GoLike #" + cc0Var.b() + " • cookies đã lưu", null, sl.n(), ak1.h(12), null, null, 0L, null, 0L, 0, false, 0, 0, null, xoVar5, 24576, 0, 262122);
                    xoVar5.p(true);
                    m22.h(w40Var3, null, false, null, null, m22.j, xoVar5, 1572864, 62);
                    xoVar5.p(true);
                } else {
                    xoVar5.R();
                }
                return bw1Var;
            case 6:
                w40 w40Var4 = (w40) obj5;
                h50 h50Var2 = (h50) obj4;
                xo xoVar6 = (xo) obj2;
                ((Integer) obj3).getClass();
                xoVar6.W(759876635);
                Object objL2 = xoVar6.L();
                dp1 dp1Var = ro.a;
                if (objL2 == dp1Var) {
                    objL2 = hl.s(w40Var4);
                    xoVar6.g0(objL2);
                }
                kj1 kj1Var3 = (kj1) objL2;
                Object objL3 = xoVar6.L();
                if (objL3 == dp1Var) {
                    objL3 = new va(new jw0(((jw0) kj1Var3.getValue()).a), id1.b, new jw0(id1.c), 8);
                    xoVar6.g0(objL3);
                }
                va vaVar = (va) objL3;
                boolean zH = xoVar6.h(vaVar);
                Object objL4 = xoVar6.L();
                if (zH || objL4 == dp1Var) {
                    objL4 = new f(kj1Var3, vaVar, tqVar, i2);
                    xoVar6.g0(objL4);
                }
                ct.o(xoVar6, (l50) objL4, bw1Var);
                ac acVar = vaVar.c;
                boolean zF = xoVar6.f(acVar);
                Object objL5 = xoVar6.L();
                if (zF || objL5 == dp1Var) {
                    z = false;
                    objL5 = new hd1(acVar, 0);
                    xoVar6.g0(objL5);
                } else {
                    z = false;
                }
                fr0 fr0Var = (fr0) h50Var2.g((w40) objL5);
                xoVar6.p(z);
                return fr0Var;
            case 7:
                Spannable spannable = (Spannable) obj4;
                e8 e8Var = (e8) obj5;
                si1 si1Var = (si1) obj;
                int iIntValue6 = ((Integer) obj2).intValue();
                int iIntValue7 = ((Integer) obj3).intValue();
                xl1 xl1Var = si1Var.f;
                p40 p40Var = si1Var.c;
                if (p40Var == null) {
                    p40Var = p40.f;
                }
                n40 n40Var = si1Var.d;
                int i3 = n40Var != null ? n40Var.a : 0;
                o40 o40Var = si1Var.e;
                int i4 = o40Var != null ? o40Var.a : 65535;
                f8 f8Var = (f8) e8Var.e;
                lv1 lv1VarB = ((a40) f8Var.e).b(xl1Var, p40Var, i3, i4);
                if (lv1VarB instanceof lv1) {
                    Object obj6 = lv1VarB.d;
                    obj6.getClass();
                    typeface = (Typeface) obj6;
                } else {
                    yc ycVar = new yc(lv1VarB, f8Var.j);
                    f8Var.j = ycVar;
                    Object obj7 = ycVar.c;
                    obj7.getClass();
                    typeface = (Typeface) obj7;
                }
                spannable.setSpan(new c40(1, typeface), iIntValue6, iIntValue7, 33);
                return bw1Var;
            case 8:
                h50 h50Var3 = (h50) obj4;
                ks0 ks0Var = (ks0) obj5;
                xo xoVar7 = (xo) obj2;
                ((Integer) obj3).getClass();
                xoVar7.W(-102778667);
                Object objL6 = xoVar7.L();
                dp1 dp1Var2 = ro.a;
                if (objL6 == dp1Var2) {
                    objL6 = ct.B(xoVar7);
                    xoVar7.g0(objL6);
                }
                ds dsVar = (ds) objL6;
                Object objL7 = xoVar7.L();
                if (objL7 == dp1Var2) {
                    objL7 = hl.I(null);
                    xoVar7.g0(objL7);
                }
                gt0 gt0Var = (gt0) objL7;
                gt0 gt0VarV = hl.V(h50Var3, xoVar7);
                boolean zF2 = xoVar7.f(ks0Var);
                Object objL8 = xoVar7.L();
                if (zF2 || objL8 == dp1Var2) {
                    objL8 = new c(gt0Var, ks0Var);
                    xoVar7.g0(objL8);
                }
                ct.h(ks0Var, (h50) objL8, xoVar7);
                boolean zH2 = xoVar7.h(dsVar) | xoVar7.f(ks0Var) | xoVar7.f(gt0VarV);
                Object objL9 = xoVar7.L();
                if (zH2 || objL9 == dp1Var2) {
                    objL9 = new go1(dsVar, gt0Var, ks0Var, gt0VarV);
                    xoVar7.g0(objL9);
                }
                fr0 fr0VarA3 = ll1.a(cr0Var, ks0Var, (PointerInputEventHandler) objL9);
                xoVar7.p(false);
                return fr0VarA3;
            case 9:
                w40 w40Var5 = (w40) obj5;
                oq1 oq1Var = (oq1) obj4;
                xo xoVar8 = (xo) obj2;
                int iIntValue8 = ((Integer) obj3).intValue();
                ((lm) obj).getClass();
                if (xoVar8.O(iIntValue8 & 1, (iIntValue8 & 17) != 16)) {
                    k91 k91VarA6 = j91.a(ng0.e, a4.o, xoVar8, 48);
                    int iHashCode13 = Long.hashCode(xoVar8.T);
                    t11 t11VarL13 = xoVar8.l();
                    fr0 fr0VarM13 = om.M(xoVar8, cr0Var);
                    oo.b.getClass();
                    kp kpVar5 = no.b;
                    xoVar8.Z();
                    if (xoVar8.S) {
                        xoVar8.k(kpVar5);
                    } else {
                        xoVar8.j0();
                    }
                    oa oaVar13 = no.e;
                    ak1.o(xoVar8, oaVar13, k91VarA6);
                    oa oaVar14 = no.d;
                    ak1.o(xoVar8, oaVar14, t11VarL13);
                    Integer numValueOf4 = Integer.valueOf(iHashCode13);
                    oa oaVar15 = no.f;
                    ak1.j(xoVar8, numValueOf4, oaVar15);
                    c5 c5Var4 = no.g;
                    ak1.n(xoVar8, c5Var4);
                    oa oaVar16 = no.c;
                    ak1.o(xoVar8, oaVar16, fr0VarM13);
                    fr0 fr0VarQ4 = eq0.q(ng0.t(ig1.f(cr0Var, 40.0f), g91.a(10.0f)), ql.b(0.15f, sl.b()), eq0.G);
                    lq0 lq0VarD4 = tg.d(a4.i, false);
                    int iHashCode14 = Long.hashCode(xoVar8.T);
                    t11 t11VarL14 = xoVar8.l();
                    fr0 fr0VarM14 = om.M(xoVar8, fr0VarQ4);
                    xoVar8.Z();
                    if (xoVar8.S) {
                        xoVar8.k(kpVar5);
                    } else {
                        xoVar8.j0();
                    }
                    ak1.o(xoVar8, oaVar13, lq0VarD4);
                    ak1.o(xoVar8, oaVar14, t11VarL14);
                    f0.t(iHashCode14, xoVar8, oaVar15, xoVar8, c5Var4);
                    ak1.o(xoVar8, oaVar16, fr0VarM14);
                    bc0.a(vh0.x(), null, ig1.f(cr0Var, 22.0f), sl.b(), xoVar8, 432, 0);
                    xoVar8.p(true);
                    om.d(xoVar8, ig1.f(cr0Var, 12.0f));
                    xj0 xj0Var3 = new xj0(1.0f, true);
                    km kmVarA5 = im.a(ng0.g, a4.q, xoVar8, 0);
                    int iHashCode15 = Long.hashCode(xoVar8.T);
                    t11 t11VarL15 = xoVar8.l();
                    fr0 fr0VarM15 = om.M(xoVar8, xj0Var3);
                    xoVar8.Z();
                    if (xoVar8.S) {
                        xoVar8.k(kpVar5);
                    } else {
                        xoVar8.j0();
                    }
                    ak1.o(xoVar8, oaVar13, kmVarA5);
                    ak1.o(xoVar8, oaVar14, t11VarL15);
                    f0.t(iHashCode15, xoVar8, oaVar15, xoVar8, c5Var4);
                    ak1.o(xoVar8, oaVar16, fr0VarM15);
                    mp1.b(f0.m("@", oq1Var.c()), null, sl.l(), ak1.h(15), p40.h, null, 0L, null, 0L, 0, false, 0, 0, null, xoVar8, 1597440, 0, 262058);
                    mp1.b("GoLike #" + oq1Var.b() + " • cookies đã lưu", null, sl.n(), ak1.h(12), null, null, 0L, null, 0L, 0, false, 0, 0, null, xoVar8, 24576, 0, 262122);
                    xoVar8.p(true);
                    m22.h(w40Var5, null, false, null, null, zu1.n, xoVar8, 1572864, 62);
                    xoVar8.p(true);
                } else {
                    xoVar8.R();
                }
                return bw1Var;
            case 10:
                kj1 kj1Var4 = (kj1) obj4;
                kj1 kj1Var5 = (kj1) obj5;
                xo xoVar9 = (xo) obj2;
                int iIntValue9 = ((Integer) obj3).intValue();
                ((bk0) obj).getClass();
                if (xoVar9.O(iIntValue9 & 1, (iIntValue9 & 17) != 16)) {
                    om.d(xoVar9, ig1.b(cr0Var, 12.0f));
                    String str = (String) kj1Var4.getValue();
                    if (str == null) {
                        str = "";
                    }
                    mp1.b(str, y5.B(cr0Var, 20.0f, 4.0f), ((Boolean) kj1Var5.getValue()).booleanValue() ? sl.b : sl.m(), ak1.h(13), p40.g, null, 0L, null, 0L, 0, false, 0, 0, null, xoVar9, 1597488, 0, 262056);
                } else {
                    xoVar9.R();
                }
                return bw1Var;
            case 11:
                return d(obj, obj2, obj3);
            default:
                w40 w40Var6 = (w40) obj5;
                z12 z12Var = (z12) obj4;
                xo xoVar10 = (xo) obj2;
                int iIntValue10 = ((Integer) obj3).intValue();
                ((lm) obj).getClass();
                if (!xoVar10.O(iIntValue10 & 1, (iIntValue10 & 17) != 16)) {
                    xoVar10.R();
                    return bw1Var;
                }
                k91 k91VarA7 = j91.a(ng0.e, a4.o, xoVar10, 48);
                int iHashCode16 = Long.hashCode(xoVar10.T);
                t11 t11VarL16 = xoVar10.l();
                fr0 fr0VarM16 = om.M(xoVar10, cr0Var);
                oo.b.getClass();
                kp kpVar6 = no.b;
                xoVar10.Z();
                if (xoVar10.S) {
                    xoVar10.k(kpVar6);
                } else {
                    xoVar10.j0();
                }
                oa oaVar17 = no.e;
                ak1.o(xoVar10, oaVar17, k91VarA7);
                oa oaVar18 = no.d;
                ak1.o(xoVar10, oaVar18, t11VarL16);
                Integer numValueOf5 = Integer.valueOf(iHashCode16);
                oa oaVar19 = no.f;
                ak1.j(xoVar10, numValueOf5, oaVar19);
                c5 c5Var5 = no.g;
                ak1.n(xoVar10, c5Var5);
                oa oaVar20 = no.c;
                ak1.o(xoVar10, oaVar20, fr0VarM16);
                fr0 fr0VarT = ng0.t(ig1.f(cr0Var, 40.0f), g91.a(10.0f));
                long j = j22.a;
                fr0 fr0VarQ5 = eq0.q(fr0VarT, ql.b(0.15f, j), eq0.G);
                lq0 lq0VarD5 = tg.d(a4.i, false);
                int iHashCode17 = Long.hashCode(xoVar10.T);
                t11 t11VarL17 = xoVar10.l();
                fr0 fr0VarM17 = om.M(xoVar10, fr0VarQ5);
                xoVar10.Z();
                if (xoVar10.S) {
                    xoVar10.k(kpVar6);
                } else {
                    xoVar10.j0();
                }
                ak1.o(xoVar10, oaVar17, lq0VarD5);
                ak1.o(xoVar10, oaVar18, t11VarL17);
                f0.t(iHashCode17, xoVar10, oaVar19, xoVar10, c5Var5);
                ak1.o(xoVar10, oaVar20, fr0VarM17);
                bc0.a(vl.z(), null, ig1.f(cr0Var, 22.0f), j, xoVar10, 3504, 0);
                xoVar10.p(true);
                om.d(xoVar10, ig1.f(cr0Var, 12.0f));
                xj0 xj0Var4 = new xj0(1.0f, true);
                km kmVarA6 = im.a(ng0.g, a4.q, xoVar10, 0);
                int iHashCode18 = Long.hashCode(xoVar10.T);
                t11 t11VarL18 = xoVar10.l();
                fr0 fr0VarM18 = om.M(xoVar10, xj0Var4);
                xoVar10.Z();
                if (xoVar10.S) {
                    xoVar10.k(kpVar6);
                } else {
                    xoVar10.j0();
                }
                ak1.o(xoVar10, oaVar17, kmVarA6);
                ak1.o(xoVar10, oaVar18, t11VarL18);
                f0.t(iHashCode18, xoVar10, oaVar19, xoVar10, c5Var5);
                ak1.o(xoVar10, oaVar20, fr0VarM18);
                mp1.b(f0.m("@", z12Var.c()), null, sl.l(), ak1.h(15), p40.h, null, 0L, null, 0L, 0, false, 0, 0, null, xoVar10, 1597440, 0, 262058);
                mp1.b("GoLike #" + z12Var.b() + " • cookies đã lưu", null, sl.n(), ak1.h(12), null, null, 0L, null, 0L, 0, false, 0, 0, null, xoVar10, 24576, 0, 262122);
                xoVar10.p(true);
                m22.h(w40Var6, null, false, null, null, vh0.o, xoVar10, 1572864, 62);
                xoVar10.p(true);
                return bw1Var;
        }
    }

    public /* synthetic */ x60(Object obj, int i, Object obj2) {
        this.d = i;
        this.e = obj;
        this.f = obj2;
    }
}
