package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class f9 implements l50 {
    public final /* synthetic */ int d = 0;
    public final /* synthetic */ boolean e;
    public final /* synthetic */ int f;
    public final /* synthetic */ Object g;
    public final /* synthetic */ Object h;

    public /* synthetic */ f9(fr0 fr0Var, w40 w40Var, boolean z, int i) {
        this.g = fr0Var;
        this.h = w40Var;
        this.e = z;
        this.f = i;
    }

    @Override // defpackage.l50
    public final Object f(Object obj, Object obj2) {
        int i = this.d;
        bw1 bw1Var = bw1.a;
        int i2 = this.f;
        Object obj3 = this.h;
        Object obj4 = this.g;
        boolean z = this.e;
        switch (i) {
            case 0:
                ((Integer) obj2).getClass();
                ng0.f((fr0) obj4, (w40) obj3, z, (xo) obj, bm.T(i2 | 1));
                break;
            default:
                ((Integer) obj2).getClass();
                cd.a(z, (z71) obj4, (so1) obj3, (xo) obj, bm.T(i2 | 1));
                break;
        }
        return bw1Var;
    }

    public /* synthetic */ f9(boolean z, z71 z71Var, so1 so1Var, int i) {
        this.e = z;
        this.g = z71Var;
        this.h = so1Var;
        this.f = i;
    }
}
