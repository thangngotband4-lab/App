package defpackage;

import kotlin.Metadata;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u000e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001¨\u0006\u0003"}, d2 = {"Lvk;", "Ljr0;", "Lxk;", "foundation"}, k = 1, mv = {2, 0, 0}, xi = 48)
final class vk extends jr0 {
    public final ks0 a;
    public final xc0 b;
    public final boolean c;
    public final boolean d;
    public final String e;
    public final a91 f;
    public final w40 g;

    public vk(ks0 ks0Var, xc0 xc0Var, boolean z, boolean z2, String str, a91 a91Var, w40 w40Var) {
        this.a = ks0Var;
        this.b = xc0Var;
        this.c = z;
        this.d = z2;
        this.e = str;
        this.f = a91Var;
        this.g = w40Var;
    }

    @Override // defpackage.jr0
    public final er0 e() {
        return new xk(this.a, this.b, this.c, this.d, this.e, this.f, this.g);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || vk.class != obj.getClass()) {
            return false;
        }
        vk vkVar = (vk) obj;
        return ng0.o(this.a, vkVar.a) && ng0.o(this.b, vkVar.b) && this.c == vkVar.c && this.d == vkVar.d && ng0.o(this.e, vkVar.e) && ng0.o(this.f, vkVar.f) && this.g == vkVar.g;
    }

    @Override // defpackage.jr0
    public final void f(er0 er0Var) {
        ((xk) er0Var).V0(this.a, this.b, this.c, this.d, this.e, this.f, this.g);
    }

    public final int hashCode() {
        ks0 ks0Var = this.a;
        int iHashCode = (ks0Var != null ? ks0Var.hashCode() : 0) * 31;
        xc0 xc0Var = this.b;
        int iF = f0.f(f0.f((iHashCode + (xc0Var != null ? xc0Var.hashCode() : 0)) * 31, 31, this.c), 31, this.d);
        String str = this.e;
        int iHashCode2 = (iF + (str != null ? str.hashCode() : 0)) * 31;
        a91 a91Var = this.f;
        return this.g.hashCode() + ((iHashCode2 + (a91Var != null ? Integer.hashCode(a91Var.a) : 0)) * 31);
    }
}
