package defpackage;

import android.os.Build;
import java.util.ArrayList;
import java.util.Set;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class zy extends bm {
    public final /* synthetic */ az h;

    public zy(az azVar) {
        this.h = azVar;
    }

    @Override // defpackage.bm
    public final void M(Throwable th) {
        this.h.a.f(th);
    }

    @Override // defpackage.bm
    public final void N(l4 l4Var) {
        az azVar = this.h;
        azVar.c = l4Var;
        l4 l4Var2 = azVar.c;
        dz dzVar = azVar.a;
        dp1 dp1Var = dzVar.g;
        rt rtVar = dzVar.i;
        Set<int[]> setA = Build.VERSION.SDK_INT >= 34 ? iz.a() : om.y();
        yc ycVar = new yc();
        ycVar.a = dp1Var;
        ycVar.b = l4Var2;
        ycVar.c = rtVar;
        if (!setA.isEmpty()) {
            for (int[] iArr : setA) {
                String str = new String(iArr, 0, iArr.length);
                ycVar.m(str, 0, str.length(), 1, true, new lz(str, 0));
            }
        }
        azVar.b = ycVar;
        dz dzVar2 = azVar.a;
        ArrayList arrayList = new ArrayList();
        dzVar2.a.writeLock().lock();
        try {
            dzVar2.c = 1;
            arrayList.addAll(dzVar2.b);
            dzVar2.b.clear();
            dzVar2.a.writeLock().unlock();
            dzVar2.d.post(new bz(arrayList, dzVar2.c, null));
        } catch (Throwable th) {
            dzVar2.a.writeLock().unlock();
            throw th;
        }
    }
}
