package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class vu1 extends tu1 {
    public final y11 g;

    public vu1(y11 y11Var) {
        this.g = y11Var;
    }

    @Override // java.util.Iterator
    public final Object next() {
        int i = this.f;
        this.f = i + 2;
        Object[] objArr = this.d;
        return new os0(this.g, objArr[i], objArr[i + 1]);
    }
}
