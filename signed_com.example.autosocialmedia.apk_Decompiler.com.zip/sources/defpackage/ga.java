package defpackage;

import android.view.MotionEvent;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class ga extends ki0 implements h50 {
    public final /* synthetic */ int e;
    public final /* synthetic */ ty1 f;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ ga(ty1 ty1Var, int i) {
        super(1);
        this.e = i;
        this.f = ty1Var;
    }

    @Override // defpackage.h50
    public final Object g(Object obj) {
        boolean zDispatchTouchEvent;
        int i = this.e;
        bw1 bw1Var = bw1.a;
        ty1 ty1Var = this.f;
        switch (i) {
            case 0:
                nz0 nz0Var = (nz0) obj;
                k5 k5Var = nz0Var instanceof k5 ? (k5) nz0Var : null;
                if (k5Var != null) {
                    k5Var.getAndroidViewsHandler$ui().removeViewInLayout(ty1Var);
                    zu1.f(k5Var.getAndroidViewsHandler$ui().getLayoutNodeToHolder()).remove(k5Var.getAndroidViewsHandler$ui().getHolderToLayoutNode().remove(ty1Var));
                    ty1Var.setImportantForAccessibility(0);
                }
                ty1Var.removeAllViewsInLayout();
                return bw1Var;
            case 1:
                ty1Var.t = (h50) obj;
                return bw1Var;
            default:
                MotionEvent motionEvent = (MotionEvent) obj;
                switch (motionEvent.getActionMasked()) {
                    case 0:
                    case 1:
                    case 2:
                    case 3:
                    case 4:
                    case 5:
                    case 6:
                        zDispatchTouchEvent = ty1Var.dispatchTouchEvent(motionEvent);
                        break;
                    default:
                        zDispatchTouchEvent = ty1Var.dispatchGenericMotionEvent(motionEvent);
                        break;
                }
                return Boolean.valueOf(zDispatchTouchEvent);
        }
    }
}
