package defpackage;

import android.os.Handler;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class z61 {
    public final p7 a;
    public final ar1 b;
    public final ts0 c;
    public boolean d;
    public boolean e;
    public boolean f;
    public m2 g;
    public long h;
    public final k8 i;
    public final zs0 j;

    public z61() {
        p7 p7Var = new p7();
        p7Var.b = new long[192];
        p7Var.c = new long[192];
        this.a = p7Var;
        this.b = new ar1();
        this.c = new ts0();
        this.h = -1L;
        this.i = new k8(12, this);
        this.j = new zs0();
    }

    public static boolean c(pu0 pu0Var) {
        mz0 mz0Var = pu0Var.O;
        return (mz0Var == null || fl.y(((ba0) mz0Var).b())) ? false : true;
    }

    public static long g(ij0 ij0Var) {
        nu0 nu0Var = ij0Var.J;
        pu0 pu0Var = nu0Var.d;
        long jC = 0;
        for (pu0 pu0Var2 = nu0Var.c; pu0Var2 != null && pu0Var2 != pu0Var; pu0Var2 = pu0Var2.t) {
            if (c(pu0Var2)) {
                return 9223372034707292159L;
            }
            jC = rf0.c(jC, pu0Var2.C);
        }
        return jC;
    }

    public static void i(ij0 ij0Var) {
        if (!ij0Var.f || c(ij0Var.J.d)) {
            return;
        }
        ij0Var.f = false;
        if (ij0Var.j) {
            ij0Var.i = g(ij0Var);
            ij0Var.j = false;
        }
        if (rf0.a(ij0Var.i, 9223372034707292159L)) {
            return;
        }
        it0 it0VarY = ij0Var.y();
        Object[] objArr = it0VarY.d;
        int i = it0VarY.f;
        for (int i2 = 0; i2 < i; i2++) {
            i((ij0) objArr[i2]);
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:106:0x025a  */
    /* JADX WARN: Removed duplicated region for block: B:115:0x0272  */
    /* JADX WARN: Removed duplicated region for block: B:142:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:71:0x0181  */
    /* JADX WARN: Removed duplicated region for block: B:77:0x01d2  */
    /* JADX WARN: Removed duplicated region for block: B:88:0x0217  */
    /* JADX WARN: Removed duplicated region for block: B:92:0x021f  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void a() {
        /*
            Method dump skipped, instruction units count: 630
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.z61.a():void");
    }

    public final long b(ij0 ij0Var) {
        long j;
        int i = ij0Var.e & 33554431;
        p7 p7Var = this.a;
        long[] jArr = (long[]) p7Var.b;
        int i2 = p7Var.a;
        for (int i3 = 0; i3 < jArr.length - 2 && i3 < i2; i3 += 3) {
            if ((((int) jArr[i3 + 2]) & 33554431) == i) {
                j = jArr[i3];
                break;
            }
        }
        j = Long.MAX_VALUE;
        if (j == Long.MAX_VALUE) {
            return 9223372034707292159L;
        }
        return (((long) ((int) j)) & 4294967295L) | (((long) ((int) (j >> 32))) << 32);
    }

    /* JADX WARN: Removed duplicated region for block: B:31:0x0105  */
    /* JADX WARN: Removed duplicated region for block: B:33:0x010a  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void d(defpackage.ij0 r24) {
        /*
            Method dump skipped, instruction units count: 330
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.z61.d(ij0):void");
    }

    public final void e(ij0 ij0Var) {
        if (ij0Var.k) {
            this.d = true;
            int i = ij0Var.e & 33554431;
            p7 p7Var = this.a;
            long[] jArr = (long[]) p7Var.b;
            int i2 = p7Var.a;
            int i3 = 0;
            while (true) {
                if (i3 >= jArr.length - 2 || i3 >= i2) {
                    break;
                }
                int i4 = i3 + 2;
                long j = jArr[i4];
                if ((((int) j) & 33554431) == i) {
                    jArr[i4] = (((j >> 63) & 1) << 60) | j;
                    break;
                }
                i3 += 3;
            }
        }
        j();
    }

    /* JADX WARN: Code restructure failed: missing block: B:53:0x0131, code lost:
    
        r33 = r5;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void f(defpackage.ij0 r37, boolean r38) {
        /*
            Method dump skipped, instruction units count: 636
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.z61.f(ij0, boolean):void");
    }

    public final void h(ij0 ij0Var) {
        if (ij0Var.k) {
            int i = ij0Var.e & 33554431;
            p7 p7Var = this.a;
            long[] jArr = (long[]) p7Var.b;
            int i2 = p7Var.a;
            int i3 = 0;
            while (true) {
                if (i3 >= jArr.length - 2 || i3 >= i2) {
                    break;
                }
                int i4 = i3 + 2;
                if ((((int) jArr[i4]) & 33554431) == i) {
                    jArr[i3] = -1;
                    jArr[i3 + 1] = -1;
                    jArr[i4] = y61.a;
                    break;
                }
                i3 += 3;
            }
            ij0Var.k = false;
            this.d = true;
            this.f = true;
        }
    }

    public final void j() {
        m2 m2Var = this.g;
        boolean z = m2Var != null;
        long j = this.b.c;
        if (j >= 0 || !z) {
            if (this.h == j && z) {
                return;
            }
            if (m2Var != null) {
                Handler handler = n2.a;
                n2.a.removeCallbacks(m2Var);
            }
            Handler handler2 = n2.a;
            long jCurrentTimeMillis = System.currentTimeMillis();
            long jMax = Math.max(j, 16 + jCurrentTimeMillis);
            this.h = jMax;
            m2 m2Var2 = new m2(this.i, 0);
            n2.a.postDelayed(m2Var2, jMax - jCurrentTimeMillis);
            this.g = m2Var2;
        }
    }
}
