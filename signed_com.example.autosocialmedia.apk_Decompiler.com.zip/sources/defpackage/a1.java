package defpackage;

import java.text.BreakIterator;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class a1 extends z0 {
    public static a1 e;
    public static a1 f;
    public static a1 g;
    public static final z71 h = z71.e;
    public static final z71 i = z71.d;
    public final /* synthetic */ int c;
    public Object d;

    @Override // defpackage.z0
    public final int[] a(int i2) {
        int iD;
        switch (this.c) {
            case 0:
                int length = c().length();
                if (length <= 0 || i2 >= length) {
                    return null;
                }
                if (i2 < 0) {
                    i2 = 0;
                }
                do {
                    BreakIterator breakIterator = (BreakIterator) this.d;
                    if (breakIterator == null) {
                        ng0.N("impl");
                        throw null;
                    }
                    boolean zIsBoundary = breakIterator.isBoundary(i2);
                    BreakIterator breakIterator2 = (BreakIterator) this.d;
                    if (zIsBoundary) {
                        if (breakIterator2 == null) {
                            ng0.N("impl");
                            throw null;
                        }
                        int iFollowing = breakIterator2.following(i2);
                        if (iFollowing == -1) {
                            return null;
                        }
                        return b(i2, iFollowing);
                    }
                    if (breakIterator2 == null) {
                        ng0.N("impl");
                        throw null;
                    }
                    i2 = breakIterator2.following(i2);
                } while (i2 != -1);
                return null;
            case 1:
                if (c().length() <= 0 || i2 >= c().length()) {
                    return null;
                }
                if (i2 < 0) {
                    i2 = 0;
                }
                while (!h(i2) && (!h(i2) || (i2 != 0 && h(i2 - 1)))) {
                    BreakIterator breakIterator3 = (BreakIterator) this.d;
                    if (breakIterator3 == null) {
                        ng0.N("impl");
                        throw null;
                    }
                    i2 = breakIterator3.following(i2);
                    if (i2 == -1) {
                        return null;
                    }
                }
                BreakIterator breakIterator4 = (BreakIterator) this.d;
                if (breakIterator4 == null) {
                    ng0.N("impl");
                    throw null;
                }
                int iFollowing2 = breakIterator4.following(i2);
                if (iFollowing2 == -1 || !g(iFollowing2)) {
                    return null;
                }
                return b(i2, iFollowing2);
            default:
                if (c().length() <= 0 || i2 >= c().length()) {
                    return null;
                }
                pp1 pp1Var = (pp1) this.d;
                z71 z71Var = h;
                if (i2 < 0) {
                    if (pp1Var == null) {
                        ng0.N("layoutResult");
                        throw null;
                    }
                    iD = pp1Var.b.d(0);
                } else {
                    if (pp1Var == null) {
                        ng0.N("layoutResult");
                        throw null;
                    }
                    int iD2 = pp1Var.b.d(i2);
                    iD = e(iD2, z71Var) == i2 ? iD2 : iD2 + 1;
                }
                pp1 pp1Var2 = (pp1) this.d;
                if (pp1Var2 == null) {
                    ng0.N("layoutResult");
                    throw null;
                }
                if (iD >= pp1Var2.b.f) {
                    return null;
                }
                return b(e(iD, z71Var), e(iD, i) + 1);
        }
    }

    @Override // defpackage.z0
    public final int[] d(int i2) {
        int iD;
        switch (this.c) {
            case 0:
                int length = c().length();
                if (length <= 0 || i2 <= 0) {
                    return null;
                }
                if (i2 > length) {
                    i2 = length;
                }
                do {
                    BreakIterator breakIterator = (BreakIterator) this.d;
                    if (breakIterator == null) {
                        ng0.N("impl");
                        throw null;
                    }
                    boolean zIsBoundary = breakIterator.isBoundary(i2);
                    BreakIterator breakIterator2 = (BreakIterator) this.d;
                    if (zIsBoundary) {
                        if (breakIterator2 == null) {
                            ng0.N("impl");
                            throw null;
                        }
                        int iPreceding = breakIterator2.preceding(i2);
                        if (iPreceding == -1) {
                            return null;
                        }
                        return b(iPreceding, i2);
                    }
                    if (breakIterator2 == null) {
                        ng0.N("impl");
                        throw null;
                    }
                    i2 = breakIterator2.preceding(i2);
                } while (i2 != -1);
                return null;
            case 1:
                int length2 = c().length();
                if (length2 <= 0 || i2 <= 0) {
                    return null;
                }
                if (i2 > length2) {
                    i2 = length2;
                }
                while (i2 > 0 && !h(i2 - 1) && !g(i2)) {
                    BreakIterator breakIterator3 = (BreakIterator) this.d;
                    if (breakIterator3 == null) {
                        ng0.N("impl");
                        throw null;
                    }
                    i2 = breakIterator3.preceding(i2);
                    if (i2 == -1) {
                        return null;
                    }
                }
                BreakIterator breakIterator4 = (BreakIterator) this.d;
                if (breakIterator4 == null) {
                    ng0.N("impl");
                    throw null;
                }
                int iPreceding2 = breakIterator4.preceding(i2);
                if (iPreceding2 == -1 || !h(iPreceding2)) {
                    return null;
                }
                if (iPreceding2 == 0 || !h(iPreceding2 - 1)) {
                    return b(iPreceding2, i2);
                }
                return null;
            default:
                if (c().length() <= 0 || i2 <= 0) {
                    return null;
                }
                int length3 = c().length();
                pp1 pp1Var = (pp1) this.d;
                z71 z71Var = i;
                if (i2 > length3) {
                    if (pp1Var == null) {
                        ng0.N("layoutResult");
                        throw null;
                    }
                    iD = pp1Var.b.d(c().length());
                } else {
                    if (pp1Var == null) {
                        ng0.N("layoutResult");
                        throw null;
                    }
                    int iD2 = pp1Var.b.d(i2);
                    iD = e(iD2, z71Var) + 1 == i2 ? iD2 : iD2 - 1;
                }
                if (iD < 0) {
                    return null;
                }
                return b(e(iD, h), e(iD, z71Var) + 1);
        }
    }

    public int e(int i2, z71 z71Var) {
        pp1 pp1Var = (pp1) this.d;
        if (pp1Var == null) {
            ng0.N("layoutResult");
            throw null;
        }
        int iF = pp1Var.f(i2);
        pp1 pp1Var2 = (pp1) this.d;
        if (pp1Var2 == null) {
            ng0.N("layoutResult");
            throw null;
        }
        z71 z71VarG = pp1Var2.g(iF);
        pp1 pp1Var3 = (pp1) this.d;
        if (z71Var != z71VarG) {
            if (pp1Var3 != null) {
                return pp1Var3.f(i2);
            }
            ng0.N("layoutResult");
            throw null;
        }
        if (pp1Var3 != null) {
            return pp1Var3.b.c(i2, false) - 1;
        }
        ng0.N("layoutResult");
        throw null;
    }

    public void f(String str) {
        switch (this.c) {
            case 0:
                this.a = str;
                BreakIterator breakIterator = (BreakIterator) this.d;
                if (breakIterator != null) {
                    breakIterator.setText(str);
                    return;
                } else {
                    ng0.N("impl");
                    throw null;
                }
            default:
                this.a = str;
                BreakIterator breakIterator2 = (BreakIterator) this.d;
                if (breakIterator2 != null) {
                    breakIterator2.setText(str);
                    return;
                } else {
                    ng0.N("impl");
                    throw null;
                }
        }
    }

    public boolean g(int i2) {
        if (i2 <= 0 || !h(i2 - 1)) {
            return false;
        }
        return i2 == c().length() || !h(i2);
    }

    public boolean h(int i2) {
        if (i2 < 0 || i2 >= c().length()) {
            return false;
        }
        return Character.isLetterOrDigit(c().codePointAt(i2));
    }
}
