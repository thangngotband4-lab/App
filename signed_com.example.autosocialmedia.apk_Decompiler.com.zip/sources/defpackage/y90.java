package defpackage;

import android.graphics.Outline;
import android.graphics.Path;
import android.graphics.RectF;
import android.os.Build;
import java.util.Locale;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class y90 {
    public final aa0 a;
    public Outline f;
    public float j;
    public hl k;
    public g8 l;
    public g8 m;
    public boolean n;
    public fj o;
    public y7 p;
    public int q;
    public boolean s;
    public long t;
    public long u;
    public long v;
    public boolean w;
    public RectF x;
    public wu b = m22.A;
    public ri0 c = ri0.d;
    public h50 d = f30.h;
    public final g4 e = new g4(14, this);
    public boolean g = true;
    public long h = 0;
    public long i = 9205357640488583168L;
    public final nk r = new nk();

    static {
        String lowerCase = Build.FINGERPRINT.toLowerCase(Locale.ROOT);
        lowerCase.getClass();
        lowerCase.equals("robolectric");
    }

    public y90(aa0 aa0Var) {
        this.a = aa0Var;
        aa0Var.t(false);
        this.t = 0L;
        this.u = 0L;
        this.v = 9205357640488583168L;
    }

    public final void a() {
        Outline outline;
        if (this.g) {
            boolean z = this.w;
            Outline outline2 = null;
            aa0 aa0Var = this.a;
            if (z || aa0Var.G() > 0.0f) {
                g8 g8Var = this.l;
                if (g8Var != null) {
                    RectF rectF = this.x;
                    if (rectF == null) {
                        rectF = new RectF();
                        this.x = rectF;
                    }
                    boolean z2 = g8Var instanceof g8;
                    if (!z2) {
                        throw new UnsupportedOperationException("Unable to obtain android.graphics.Path");
                    }
                    Path path = g8Var.a;
                    path.computeBounds(rectF, false);
                    int i = Build.VERSION.SDK_INT;
                    if (i > 28 || path.isConvex()) {
                        outline = this.f;
                        if (outline == null) {
                            outline = new Outline();
                            this.f = outline;
                        }
                        if (i >= 30) {
                            if (!z2) {
                                throw new UnsupportedOperationException("Unable to obtain android.graphics.Path");
                            }
                            outline.setPath(path);
                        } else {
                            if (!z2) {
                                throw new UnsupportedOperationException("Unable to obtain android.graphics.Path");
                            }
                            outline.setConvexPath(path);
                        }
                        this.n = !outline.canClip();
                    } else {
                        Outline outline3 = this.f;
                        if (outline3 != null) {
                            outline3.setEmpty();
                        }
                        this.n = true;
                        outline = null;
                    }
                    this.l = g8Var;
                    if (outline != null) {
                        outline.setAlpha(aa0Var.a());
                        outline2 = outline;
                    }
                    aa0Var.k(outline2, (4294967295L & ((long) Math.round(rectF.height()))) | (((long) Math.round(rectF.width())) << 32));
                    if (this.n && this.w) {
                        aa0Var.t(false);
                        aa0Var.p();
                    } else {
                        aa0Var.t(this.w);
                    }
                } else {
                    aa0Var.t(this.w);
                    Outline outline4 = this.f;
                    if (outline4 == null) {
                        outline4 = new Outline();
                        this.f = outline4;
                    }
                    Outline outline5 = outline4;
                    long jR = bm.R(this.u);
                    long j = this.h;
                    long j2 = this.i;
                    if (j2 != 9205357640488583168L) {
                        jR = j2;
                    }
                    int i2 = (int) (j >> 32);
                    int i3 = (int) (j & 4294967295L);
                    int i4 = (int) (jR >> 32);
                    int i5 = (int) (jR & 4294967295L);
                    outline5.setRoundRect(Math.round(Float.intBitsToFloat(i2)), Math.round(Float.intBitsToFloat(i3)), Math.round(Float.intBitsToFloat(i4) + Float.intBitsToFloat(i2)), Math.round(Float.intBitsToFloat(i5) + Float.intBitsToFloat(i3)), this.j);
                    outline5.setAlpha(aa0Var.a());
                    aa0Var.k(outline5, (4294967295L & ((long) Math.round(Float.intBitsToFloat(i5)))) | (((long) Math.round(Float.intBitsToFloat(i4))) << 32));
                }
            } else {
                aa0Var.t(false);
                aa0Var.k(null, 0L);
            }
        }
        this.g = false;
    }

    /* JADX WARN: Removed duplicated region for block: B:23:0x005c  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void b() {
        /*
            r15 = this;
            boolean r0 = r15.s
            if (r0 == 0) goto L69
            int r0 = r15.q
            if (r0 != 0) goto L69
            nk r0 = r15.r
            java.lang.Object r1 = r0.b
            y90 r1 = (defpackage.y90) r1
            if (r1 == 0) goto L16
            r1.e()
            r1 = 0
            r0.b = r1
        L16:
            java.lang.Object r0 = r0.d
            bt0 r0 = (defpackage.bt0) r0
            if (r0 == 0) goto L64
            java.lang.Object[] r1 = r0.b
            long[] r2 = r0.a
            int r3 = r2.length
            int r3 = r3 + (-2)
            if (r3 < 0) goto L61
            r4 = 0
            r5 = r4
        L27:
            r6 = r2[r5]
            long r8 = ~r6
            r10 = 7
            long r8 = r8 << r10
            long r8 = r8 & r6
            r10 = -9187201950435737472(0x8080808080808080, double:-2.937446524422997E-306)
            long r8 = r8 & r10
            int r8 = (r8 > r10 ? 1 : (r8 == r10 ? 0 : -1))
            if (r8 == 0) goto L5c
            int r8 = r5 - r3
            int r8 = ~r8
            int r8 = r8 >>> 31
            r9 = 8
            int r8 = 8 - r8
            r10 = r4
        L41:
            if (r10 >= r8) goto L5a
            r11 = 255(0xff, double:1.26E-321)
            long r11 = r11 & r6
            r13 = 128(0x80, double:6.3E-322)
            int r11 = (r11 > r13 ? 1 : (r11 == r13 ? 0 : -1))
            if (r11 >= 0) goto L56
            int r11 = r5 << 3
            int r11 = r11 + r10
            r11 = r1[r11]
            y90 r11 = (defpackage.y90) r11
            r11.e()
        L56:
            long r6 = r6 >> r9
            int r10 = r10 + 1
            goto L41
        L5a:
            if (r8 != r9) goto L61
        L5c:
            if (r5 == r3) goto L61
            int r5 = r5 + 1
            goto L27
        L61:
            r0.b()
        L64:
            aa0 r15 = r15.a
            r15.p()
        L69:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.y90.b():void");
    }

    /* JADX WARN: Removed duplicated region for block: B:29:0x0088  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void c(defpackage.ay r14) {
        /*
            r13 = this;
            nk r0 = r13.r
            java.lang.Object r1 = r0.b
            y90 r1 = (defpackage.y90) r1
            r0.c = r1
            java.lang.Object r1 = r0.d
            bt0 r1 = (defpackage.bt0) r1
            if (r1 == 0) goto L29
            boolean r2 = r1.h()
            if (r2 == 0) goto L29
            java.lang.Object r2 = r0.e
            bt0 r2 = (defpackage.bt0) r2
            if (r2 != 0) goto L23
            bt0 r2 = defpackage.ab1.a
            bt0 r2 = new bt0
            r2.<init>()
            r0.e = r2
        L23:
            r2.j(r1)
            r1.b()
        L29:
            r1 = 1
            r0.a = r1
            h50 r13 = r13.d
            r13.g(r14)
            r13 = 0
            r0.a = r13
            java.lang.Object r14 = r0.c
            y90 r14 = (defpackage.y90) r14
            if (r14 == 0) goto L3d
            r14.e()
        L3d:
            java.lang.Object r14 = r0.e
            bt0 r14 = (defpackage.bt0) r14
            if (r14 == 0) goto L90
            boolean r0 = r14.h()
            if (r0 == 0) goto L90
            java.lang.Object[] r0 = r14.b
            long[] r1 = r14.a
            int r2 = r1.length
            int r2 = r2 + (-2)
            if (r2 < 0) goto L8d
            r3 = r13
        L53:
            r4 = r1[r3]
            long r6 = ~r4
            r8 = 7
            long r6 = r6 << r8
            long r6 = r6 & r4
            r8 = -9187201950435737472(0x8080808080808080, double:-2.937446524422997E-306)
            long r6 = r6 & r8
            int r6 = (r6 > r8 ? 1 : (r6 == r8 ? 0 : -1))
            if (r6 == 0) goto L88
            int r6 = r3 - r2
            int r6 = ~r6
            int r6 = r6 >>> 31
            r7 = 8
            int r6 = 8 - r6
            r8 = r13
        L6d:
            if (r8 >= r6) goto L86
            r9 = 255(0xff, double:1.26E-321)
            long r9 = r9 & r4
            r11 = 128(0x80, double:6.3E-322)
            int r9 = (r9 > r11 ? 1 : (r9 == r11 ? 0 : -1))
            if (r9 >= 0) goto L82
            int r9 = r3 << 3
            int r9 = r9 + r8
            r9 = r0[r9]
            y90 r9 = (defpackage.y90) r9
            r9.e()
        L82:
            long r4 = r4 >> r7
            int r8 = r8 + 1
            goto L6d
        L86:
            if (r6 != r7) goto L8d
        L88:
            if (r3 == r2) goto L8d
            int r3 = r3 + 1
            goto L53
        L8d:
            r14.b()
        L90:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.y90.c(ay):void");
    }

    public final hl d() {
        hl uy0Var;
        hl hlVar = this.k;
        g8 g8Var = this.l;
        if (hlVar != null) {
            return hlVar;
        }
        if (g8Var != null) {
            ty0 ty0Var = new ty0(g8Var);
            this.k = ty0Var;
            return ty0Var;
        }
        long jR = bm.R(this.u);
        long j = this.h;
        long j2 = this.i;
        if (j2 != 9205357640488583168L) {
            jR = j2;
        }
        float fIntBitsToFloat = Float.intBitsToFloat((int) (j >> 32));
        float fIntBitsToFloat2 = Float.intBitsToFloat((int) (j & 4294967295L));
        float fIntBitsToFloat3 = Float.intBitsToFloat((int) (jR >> 32)) + fIntBitsToFloat;
        float fIntBitsToFloat4 = Float.intBitsToFloat((int) (jR & 4294967295L)) + fIntBitsToFloat2;
        float f = this.j;
        if (f > 0.0f) {
            uy0Var = new vy0(rm.i(fIntBitsToFloat, fIntBitsToFloat2, fIntBitsToFloat3, fIntBitsToFloat4, (((long) Float.floatToRawIntBits(f)) << 32) | (4294967295L & ((long) Float.floatToRawIntBits(f)))));
        } else {
            uy0Var = new uy0(new x61(fIntBitsToFloat, fIntBitsToFloat2, fIntBitsToFloat3, fIntBitsToFloat4));
        }
        this.k = uy0Var;
        return uy0Var;
    }

    public final void e() {
        this.q--;
        b();
    }

    public final void f(float f, long j, long j2) {
        if (jw0.b(this.h, j) && gg1.a(this.i, j2) && this.j == f && this.l == null) {
            return;
        }
        this.k = null;
        this.l = null;
        this.g = true;
        this.n = false;
        this.h = j;
        this.i = j2;
        this.j = f;
        a();
    }
}
