package defpackage;

import android.view.accessibility.AccessibilityNodeInfo;
import java.util.List;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class vv1 {
    public static final vv1 a = new vv1();
    public static final List b = kl.N("Để sau", "Để sau nhé", "Không phải bây giờ", "Không, cảm ơn", "Không cảm ơn", "Bỏ qua", "Hủy", "Hủy bỏ", "Đóng", "Bỏ qua quảng cáo", "Tắt", "Tiếp tục sau", "Lần sau", "Not now", "No thanks", "Skip", "Skip Ads", "Cancel", "Close", "Maybe later", "Dismiss", "Ignore", "Don't allow", "Block", "Từ chối", "Không cho phép", "OK", "Ok", "Đã hiểu", "Tôi hiểu", "Got it");
    public static final List c = kl.N("Bật thông báo", "Cho phép thông báo", "Cập nhật ứng dụng", "Đăng nhập để tiếp tục", "Tiếp tục bằng", "Enable notifications", "Update app", "Log in to continue");

    public static void b(AccessibilityNodeInfo accessibilityNodeInfo, h50 h50Var) {
        h50Var.g(accessibilityNodeInfo);
        int childCount = accessibilityNodeInfo.getChildCount();
        for (int i = 0; i < childCount; i++) {
            AccessibilityNodeInfo child = accessibilityNodeInfo.getChild(i);
            if (child != null) {
                b(child, h50Var);
            }
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:43:0x00dd, code lost:
    
        if (defpackage.jl.l(600, r0) == r6) goto L44;
     */
    /* JADX WARN: Code restructure failed: missing block: B:50:0x00ae, code lost:
    
        r4 = r9;
     */
    /* JADX WARN: Path cross not found for [B:40:0x00b0, B:24:0x0072], limit reached: 51 */
    /* JADX WARN: Removed duplicated region for block: B:18:0x0047  */
    /* JADX WARN: Removed duplicated region for block: B:48:0x00ea  */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0013  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final java.lang.Object a(android.accessibilityservice.AccessibilityService r10, int r11, defpackage.uq r12) {
        /*
            Method dump skipped, instruction units count: 241
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.vv1.a(android.accessibilityservice.AccessibilityService, int, uq):java.lang.Object");
    }
}
