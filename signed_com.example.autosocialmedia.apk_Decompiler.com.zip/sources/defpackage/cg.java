package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class cg extends xz0 {
    public final o7 e;
    public final long f;
    public final int g;
    public final long h;
    public float i;
    public dg j;

    public cg(o7 o7Var) {
        int i;
        long width = (((long) o7Var.a.getWidth()) << 32) | (((long) o7Var.a.getHeight()) & 4294967295L);
        this.e = o7Var;
        this.f = width;
        this.g = 1;
        int i2 = (int) (width >> 32);
        if (i2 < 0 || (i = (int) (width & 4294967295L)) < 0 || i2 > o7Var.a.getWidth() || i > o7Var.a.getHeight()) {
            tz.l("Failed requirement.");
            throw null;
        }
        this.h = width;
        this.i = 1.0f;
    }

    @Override // defpackage.xz0
    public final void a(float f) {
        this.i = f;
    }

    @Override // defpackage.xz0
    public final void b(dg dgVar) {
        this.j = dgVar;
    }

    @Override // defpackage.xz0
    public final long d() {
        return bm.R(this.h);
    }

    @Override // defpackage.xz0
    public final void e(kj0 kj0Var) {
        fj fjVar = kj0Var.d;
        ay.R(kj0Var, this.e, this.f, (((long) Math.round(Float.intBitsToFloat((int) (fjVar.c() >> 32)))) << 32) | (((long) Math.round(Float.intBitsToFloat((int) (fjVar.c() & 4294967295L)))) & 4294967295L), this.i, this.j, this.g, 328);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof cg)) {
            return false;
        }
        cg cgVar = (cg) obj;
        return ng0.o(this.e, cgVar.e) && rf0.a(0L, 0L) && yf0.a(this.f, cgVar.f) && this.g == cgVar.g;
    }

    public final int hashCode() {
        return Integer.hashCode(this.g) + f0.c(f0.c(this.e.hashCode() * 31, 31, 0L), 31, this.f);
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder("BitmapPainter(image=");
        sb.append(this.e);
        sb.append(", srcOffset=");
        sb.append((Object) rf0.d(0L));
        sb.append(", srcSize=");
        sb.append((Object) yf0.b(this.f));
        sb.append(", filterQuality=");
        int i = this.g;
        sb.append((Object) (i == 0 ? "None" : i == 1 ? "Low" : i == 2 ? "Medium" : i == 3 ? "High" : "Unknown"));
        sb.append(')');
        return sb.toString();
    }
}
