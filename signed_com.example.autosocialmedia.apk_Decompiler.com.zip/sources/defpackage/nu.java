package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class nu implements w40 {
    public final /* synthetic */ int d;
    public final /* synthetic */ pu e;

    public /* synthetic */ nu(pu puVar, int i) {
        this.d = i;
        this.e = puVar;
    }

    @Override // defpackage.w40
    public final Object a() {
        int i = this.d;
        pu puVar = this.e;
        switch (i) {
            case 0:
                u81 u81Var = (u81) rm.x(puVar, x81.a);
                z8 z8Var = puVar.x;
                if (u81Var == null) {
                    if (z8Var != null) {
                        puVar.N0(z8Var);
                    }
                    puVar.x = null;
                } else if (z8Var == null) {
                    ou ouVar = new ou(puVar);
                    nu nuVar = new nu(puVar, 1);
                    ks0 ks0Var = puVar.t;
                    boolean z = puVar.u;
                    float f = puVar.v;
                    xu1 xu1Var = y81.a;
                    z8 z8Var2 = new z8(ks0Var, z, f, ouVar, nuVar);
                    puVar.M0(z8Var2);
                    puVar.x = z8Var2;
                }
                return bw1.a;
            default:
                return zu1.h0;
        }
    }
}
