package defpackage;

import android.content.Context;
import com.example.autosocialmedia.service.AutoAccessibilityService;
import java.io.File;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class fv0 implements w40 {
    public final /* synthetic */ int d;
    public final /* synthetic */ Context e;
    public final /* synthetic */ gt0 f;

    public /* synthetic */ fv0(gt0 gt0Var, Context context) {
        this.d = 2;
        this.f = gt0Var;
        this.e = context;
    }

    @Override // defpackage.w40
    public final Object a() {
        int i = this.d;
        bw1 bw1Var = bw1.a;
        Context context = this.e;
        gt0 gt0Var = this.f;
        switch (i) {
            case 0:
                gt0Var.setValue(Boolean.FALSE);
                ze.d(context);
                break;
            case 1:
                gt0Var.setValue(Boolean.FALSE);
                AutoAccessibilityService.Companion.getClass();
                ud.a(context);
                break;
            default:
                File file = (File) gt0Var.getValue();
                if (file != null) {
                    yj1.h(context, file);
                }
                break;
        }
        return bw1Var;
    }

    public /* synthetic */ fv0(Context context, gt0 gt0Var, int i) {
        this.d = i;
        this.e = context;
        this.f = gt0Var;
    }
}
