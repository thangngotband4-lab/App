package defpackage;

import android.os.Build;
import android.view.View;
import java.util.List;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class je0 extends oz1 implements Runnable, pw0, View.OnAttachStateChangeListener {
    public final r02 f;
    public boolean g;
    public boolean h;
    public m02 i;

    public je0(r02 r02Var) {
        super(!r02Var.s ? 1 : 0);
        this.f = r02Var;
    }

    @Override // defpackage.oz1
    public final void a(xz1 xz1Var) {
        this.g = false;
        this.h = false;
        m02 m02Var = this.i;
        if (xz1Var.a.b() > 0 && m02Var != null) {
            j02 j02Var = m02Var.a;
            r02 r02Var = this.f;
            r02Var.r.f(ui1.n(j02Var.g(8)));
            r02Var.q.f(ui1.n(j02Var.g(8)));
            r02.a(r02Var, m02Var);
        }
        this.i = null;
    }

    @Override // defpackage.pw0
    public final m02 b(View view, m02 m02Var) {
        this.i = m02Var;
        r02 r02Var = this.f;
        fx1 fx1Var = r02Var.q;
        j02 j02Var = m02Var.a;
        fx1Var.f(ui1.n(j02Var.g(8)));
        if (this.g) {
            if (Build.VERSION.SDK_INT == 30) {
                view.post(this);
            }
        } else if (!this.h) {
            r02Var.r.f(ui1.n(j02Var.g(8)));
            r02.a(r02Var, m02Var);
        }
        return r02Var.s ? m02.b : m02Var;
    }

    @Override // defpackage.oz1
    public final void c() {
        this.g = true;
        this.h = true;
    }

    @Override // defpackage.oz1
    public final m02 d(m02 m02Var, List list) {
        r02 r02Var = this.f;
        r02.a(r02Var, m02Var);
        return r02Var.s ? m02.b : m02Var;
    }

    @Override // defpackage.oz1
    public final ae0 e(xz1 xz1Var, ae0 ae0Var) {
        this.g = false;
        return ae0Var;
    }

    @Override // android.view.View.OnAttachStateChangeListener
    public final void onViewAttachedToWindow(View view) {
        view.requestApplyInsets();
    }

    @Override // java.lang.Runnable
    public final void run() {
        if (this.g) {
            this.g = false;
            this.h = false;
            m02 m02Var = this.i;
            if (m02Var != null) {
                r02 r02Var = this.f;
                r02Var.r.f(ui1.n(m02Var.a.g(8)));
                r02.a(r02Var, m02Var);
                this.i = null;
            }
        }
    }

    @Override // android.view.View.OnAttachStateChangeListener
    public final void onViewDetachedFromWindow(View view) {
    }
}
