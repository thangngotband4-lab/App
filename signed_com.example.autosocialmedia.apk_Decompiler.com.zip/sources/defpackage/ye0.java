package defpackage;

import android.content.Context;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class ye0 implements h50 {
    public final /* synthetic */ int d;
    public final /* synthetic */ ds e;
    public final /* synthetic */ gt0 f;
    public final /* synthetic */ gt0 g;
    public final /* synthetic */ Context h;
    public final /* synthetic */ gt0 i;
    public final /* synthetic */ gt0 j;

    public /* synthetic */ ye0(ds dsVar, gt0 gt0Var, gt0 gt0Var2, Context context, gt0 gt0Var3, gt0 gt0Var4, int i) {
        this.d = i;
        this.e = dsVar;
        this.f = gt0Var;
        this.g = gt0Var2;
        this.h = context;
        this.i = gt0Var3;
        this.j = gt0Var4;
    }

    @Override // defpackage.h50
    public final Object g(Object obj) {
        int i = this.d;
        gt0 gt0Var = this.f;
        bw1 bw1Var = bw1.a;
        ds dsVar = this.e;
        switch (i) {
            case 0:
                String str = (String) obj;
                str.getClass();
                gt0 gt0Var2 = this.f;
                if (!((Boolean) gt0Var2.getValue()).booleanValue()) {
                    gt0Var2.setValue(Boolean.TRUE);
                    m22.y(dsVar, null, new gf0(this.h, str, this.g, gt0Var2, this.i, this.j, null, 0), 3);
                }
                break;
            case 1:
                String str2 = (String) obj;
                str2.getClass();
                gt0Var.setValue(Boolean.FALSE);
                Boolean bool = Boolean.TRUE;
                gt0 gt0Var3 = this.g;
                gt0Var3.setValue(bool);
                m22.y(dsVar, null, new if0(this.h, str2, this.i, gt0Var3, this.j, null, 0), 3);
                break;
            case 2:
                String str3 = (String) obj;
                str3.getClass();
                gt0 gt0Var4 = this.f;
                if (!((Boolean) gt0Var4.getValue()).booleanValue()) {
                    gt0Var4.setValue(Boolean.TRUE);
                    m22.y(dsVar, null, new gf0(this.h, str3, this.g, gt0Var4, this.i, this.j, null, 1), 3);
                }
                break;
            case 3:
                String str4 = (String) obj;
                str4.getClass();
                gt0Var.setValue(Boolean.FALSE);
                Boolean bool2 = Boolean.TRUE;
                gt0 gt0Var5 = this.g;
                gt0Var5.setValue(bool2);
                m22.y(dsVar, null, new if0(this.h, str4, this.i, gt0Var5, this.j, null, 1), 3);
                break;
            case 4:
                String str5 = (String) obj;
                str5.getClass();
                gt0 gt0Var6 = this.f;
                if (!((Boolean) gt0Var6.getValue()).booleanValue()) {
                    gt0Var6.setValue(Boolean.TRUE);
                    m22.y(dsVar, null, new gf0(this.h, str5, this.g, gt0Var6, this.i, this.j, null, 2), 3);
                }
                break;
            case 5:
                String str6 = (String) obj;
                str6.getClass();
                gt0Var.setValue(Boolean.FALSE);
                Boolean bool3 = Boolean.TRUE;
                gt0 gt0Var7 = this.g;
                gt0Var7.setValue(bool3);
                m22.y(dsVar, null, new if0(this.h, str6, this.i, gt0Var7, this.j, null, 2), 3);
                break;
            case 6:
                String str7 = (String) obj;
                str7.getClass();
                gt0 gt0Var8 = this.f;
                if (!((Boolean) gt0Var8.getValue()).booleanValue()) {
                    gt0Var8.setValue(Boolean.TRUE);
                    m22.y(dsVar, null, new gf0(this.h, str7, this.g, gt0Var8, this.i, this.j, null, 3), 3);
                }
                break;
            default:
                String str8 = (String) obj;
                str8.getClass();
                gt0Var.setValue(Boolean.FALSE);
                Boolean bool4 = Boolean.TRUE;
                gt0 gt0Var9 = this.g;
                gt0Var9.setValue(bool4);
                m22.y(dsVar, null, new if0(this.h, str8, this.i, gt0Var9, this.j, null, 3), 3);
                break;
        }
        return bw1Var;
    }

    public /* synthetic */ ye0(ds dsVar, gt0 gt0Var, Context context, gt0 gt0Var2, gt0 gt0Var3, gt0 gt0Var4, int i) {
        this.d = i;
        this.e = dsVar;
        this.f = gt0Var;
        this.h = context;
        this.g = gt0Var2;
        this.i = gt0Var3;
        this.j = gt0Var4;
    }
}
