package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class hd implements gd, id {
    public final float d;
    public final dd e;
    public final float f;

    public hd(float f, dd ddVar) {
        this.d = f;
        this.e = ddVar;
        this.f = f;
    }

    @Override // defpackage.gd, defpackage.id
    public final float a() {
        return this.f;
    }

    @Override // defpackage.gd
    public final void b(nq0 nq0Var, int i, int[] iArr, ri0 ri0Var, int[] iArr2) {
        int i2;
        int i3;
        if (iArr.length == 0) {
            return;
        }
        int iP = nq0Var.P(this.d);
        if (ri0Var == ri0.e) {
            int length = iArr.length - 1;
            i2 = 0;
            i3 = 0;
            while (-1 < length) {
                int i4 = iArr[length];
                int iMin = Math.min(i2, i - i4);
                iArr2[length] = iMin;
                int iMin2 = Math.min(iP, (i - iMin) - i4);
                int i5 = iArr2[length] + i4 + iMin2;
                length--;
                i3 = iMin2;
                i2 = i5;
            }
        } else {
            int length2 = iArr.length;
            i2 = 0;
            i3 = 0;
            int i6 = 0;
            int i7 = 0;
            while (i6 < length2) {
                int i8 = iArr[i6];
                int iMin3 = Math.min(i2, i - i8);
                iArr2[i7] = iMin3;
                int iMin4 = Math.min(iP, (i - iMin3) - i8);
                int i9 = iArr2[i7] + i8 + iMin4;
                i6++;
                i3 = iMin4;
                i2 = i9;
                i7++;
            }
        }
        int i10 = i2 - i3;
        if (i10 < i) {
            int iIntValue = ((Number) this.e.f(Integer.valueOf(i - i10), ri0Var)).intValue();
            int length3 = iArr2.length;
            for (int i11 = 0; i11 < length3; i11++) {
                iArr2[i11] = iArr2[i11] + iIntValue;
            }
        }
    }

    @Override // defpackage.id
    public final void c(int i, nq0 nq0Var, int[] iArr, int[] iArr2) {
        b(nq0Var, i, iArr, ri0.d, iArr2);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof hd) {
            hd hdVar = (hd) obj;
            return hw.b(this.d, hdVar.d) && this.e == hdVar.e;
        }
        return false;
    }

    public final int hashCode() {
        return this.e.hashCode() + f0.f(Float.hashCode(this.d) * 31, 31, true);
    }

    public final String toString() {
        return "Arrangement#spacedAligned(" + ((Object) hw.c(this.d)) + ", " + this.e + ')';
    }
}
