package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class ce1 extends w50 implements l50 {
    public static final ce1 l = new ce1(2, ee1.class, "createSegment", "createSegment(JLkotlinx/coroutines/sync/SemaphoreSegment;)Lkotlinx/coroutines/sync/SemaphoreSegment;", 1);

    @Override // defpackage.l50
    public final Object f(Object obj, Object obj2) {
        int i = ee1.a;
        return new fe1(((Number) obj).longValue(), (fe1) obj2, 0);
    }
}
