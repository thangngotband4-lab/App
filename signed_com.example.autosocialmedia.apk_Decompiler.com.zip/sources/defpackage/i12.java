package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class i12 extends jl1 implements l50 {
    public final /* synthetic */ int e;
    public int f;
    public final /* synthetic */ k12 g;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ i12(k12 k12Var, tq tqVar, int i) {
        super(2, tqVar);
        this.e = i;
        this.g = k12Var;
    }

    @Override // defpackage.l50
    public final Object f(Object obj, Object obj2) {
        int i = this.e;
        bw1 bw1Var = bw1.a;
        ds dsVar = (ds) obj;
        tq tqVar = (tq) obj2;
        switch (i) {
        }
        return ((i12) o(tqVar, dsVar)).r(bw1Var);
    }

    @Override // defpackage.kf
    public final tq o(tq tqVar, Object obj) {
        int i = this.e;
        k12 k12Var = this.g;
        switch (i) {
            case 0:
                return new i12(k12Var, tqVar, 0);
            default:
                return new i12(k12Var, tqVar, 1);
        }
    }

    @Override // defpackage.kf
    public final Object r(Object obj) throws Throwable {
        int i = this.e;
        k12 k12Var = this.g;
        es esVar = es.d;
        bw1 bw1Var = bw1.a;
        switch (i) {
            case 0:
                int i2 = this.f;
                if (i2 == 0) {
                    vl.Q(obj);
                    k5 k5Var = k12Var.d;
                    this.f = 1;
                    Object objE = k5Var.B.e(this);
                    if (objE != esVar) {
                        objE = bw1Var;
                    }
                    if (objE == esVar) {
                    }
                } else if (i2 != 1) {
                    zi.f("call to 'resume' before 'invoke' with coroutine");
                } else {
                    vl.Q(obj);
                }
                break;
            default:
                int i3 = this.f;
                if (i3 == 0) {
                    vl.Q(obj);
                    k5 k5Var2 = k12Var.d;
                    this.f = 1;
                    Object objD = k5Var2.C.d(this);
                    if (objD != esVar) {
                        objD = bw1Var;
                    }
                    if (objD == esVar) {
                    }
                } else if (i3 != 1) {
                    zi.f("call to 'resume' before 'invoke' with coroutine");
                } else {
                    vl.Q(obj);
                }
                break;
        }
        return esVar;
    }
}
