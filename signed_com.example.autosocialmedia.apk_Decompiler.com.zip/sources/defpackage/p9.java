package defpackage;

import android.os.Handler;
import android.os.Looper;
import android.view.ActionMode;
import android.view.View;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class p9 extends jl1 implements h50 {
    public final /* synthetic */ int e;
    public int f;
    public final /* synthetic */ fn1 g;
    public final /* synthetic */ Object h;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ p9(fn1 fn1Var, Object obj, tq tqVar, int i) {
        super(1, tqVar);
        this.e = i;
        this.g = fn1Var;
        this.h = obj;
    }

    @Override // defpackage.h50
    public final Object g(Object obj) {
        int i = this.e;
        bw1 bw1Var = bw1.a;
        Object obj2 = this.h;
        fn1 fn1Var = this.g;
        tq tqVar = (tq) obj;
        switch (i) {
            case 0:
                return new p9((q9) fn1Var, (wm1) obj2, tqVar, 0).r(bw1Var);
            default:
                return new p9((pf) fn1Var, (of) obj2, tqVar, 1).r(bw1Var);
        }
    }

    @Override // defpackage.kf
    public final Object r(Object obj) {
        Handler handler;
        m9 m9Var;
        int i = this.e;
        es esVar = es.d;
        fn1 fn1Var = this.g;
        Object obj2 = this.h;
        bw1 bw1Var = bw1.a;
        switch (i) {
            case 0:
                q9 q9Var = (q9) fn1Var;
                li1 li1Var = q9Var.e;
                View view = q9Var.a;
                int i2 = this.f;
                try {
                    if (i2 == 0) {
                        vl.Q(obj);
                        n9 n9Var = new n9();
                        wm1 wm1Var = (wm1) obj2;
                        m9 m9Var2 = new m9(n9Var, new j9(q9Var, wm1Var, 0), new j9(q9Var, wm1Var, 1), view);
                        h50 h50Var = q9Var.b;
                        if (h50Var != null && (m9Var = (m9) h50Var.g(m9Var2)) != null) {
                            m9Var2 = m9Var;
                        }
                        Looper looperMyLooper = Looper.myLooper();
                        Handler handler2 = view.getHandler();
                        if (looperMyLooper == (handler2 != null ? handler2.getLooper() : null)) {
                            ActionMode actionModeStartActionMode = view.startActionMode(new d20(m9Var2), 1);
                            if (actionModeStartActionMode != null) {
                                q9Var.h = actionModeStartActionMode;
                            }
                            return bw1Var;
                        }
                        o9 o9Var = q9Var.i;
                        if (o9Var == null) {
                            o9Var = new o9(q9Var, m9Var2, n9Var, 0);
                            q9Var.i = o9Var;
                        }
                        view.post(o9Var);
                        this.f = 1;
                        uh uhVar = n9Var.a;
                        uhVar.getClass();
                        Object objD = uh.D(uhVar, this);
                        if (objD != esVar) {
                            objD = bw1Var;
                        }
                        if (objD == esVar) {
                            return esVar;
                        }
                    } else {
                        if (i2 != 1) {
                            zi.f("call to 'resume' before 'invoke' with coroutine");
                            return null;
                        }
                        vl.Q(obj);
                    }
                    if (Looper.myLooper() != (handler != null ? handler.getLooper() : null)) {
                        l5 l5Var = q9Var.j;
                        if (l5Var == null) {
                            l5Var = new l5(2, q9Var);
                            q9Var.j = l5Var;
                        }
                        view.post(l5Var);
                    } else {
                        ActionMode actionMode = q9Var.h;
                        if (actionMode != null) {
                            actionMode.finish();
                        }
                    }
                    o9 o9Var2 = q9Var.i;
                    if (o9Var2 != null) {
                        view.removeCallbacks(o9Var2);
                    }
                    q9Var.h = null;
                    return bw1Var;
                } finally {
                    li1Var.a();
                    Looper looperMyLooper2 = Looper.myLooper();
                    handler = view.getHandler();
                    if (looperMyLooper2 != (handler != null ? handler.getLooper() : null)) {
                        l5 l5Var2 = q9Var.j;
                        if (l5Var2 == null) {
                            l5Var2 = new l5(2, q9Var);
                            q9Var.j = l5Var2;
                        }
                        view.post(l5Var2);
                    } else {
                        ActionMode actionMode2 = q9Var.h;
                        if (actionMode2 != null) {
                            actionMode2.finish();
                        }
                    }
                    o9 o9Var3 = q9Var.i;
                    if (o9Var3 != null) {
                        view.removeCallbacks(o9Var3);
                    }
                    q9Var.h = null;
                }
            default:
                of ofVar = (of) obj2;
                m01 m01Var = ((pf) fn1Var).c;
                int i3 = this.f;
                try {
                    if (i3 == 0) {
                        vl.Q(obj);
                        m01Var.setValue(ofVar);
                        this.f = 1;
                        uh uhVar2 = ofVar.b;
                        uhVar2.getClass();
                        Object objD2 = uh.D(uhVar2, this);
                        if (objD2 != esVar) {
                            objD2 = bw1Var;
                        }
                        if (objD2 == esVar) {
                            return esVar;
                        }
                    } else {
                        if (i3 != 1) {
                            zi.f("call to 'resume' before 'invoke' with coroutine");
                            return null;
                        }
                        vl.Q(obj);
                    }
                    return bw1Var;
                } finally {
                    m01Var.setValue(null);
                }
        }
    }
}
