package defpackage;

import android.view.accessibility.AccessibilityNodeInfo;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class er1 implements h50 {
    public final /* synthetic */ int d;

    public /* synthetic */ er1(int i) {
        this.d = i;
    }

    @Override // defpackage.h50
    public final Object g(Object obj) {
        String str;
        String string;
        String string2;
        String string3;
        String string4;
        String string5;
        String string6;
        String string7;
        String string8;
        String string9;
        String string10;
        String string11;
        String string12;
        String string13;
        switch (this.d) {
            case 0:
                AccessibilityNodeInfo accessibilityNodeInfo = (AccessibilityNodeInfo) obj;
                accessibilityNodeInfo.getClass();
                CharSequence contentDescription = accessibilityNodeInfo.getContentDescription();
                return Boolean.valueOf(ng0.o(contentDescription != null ? contentDescription.toString() : null, "Trang tính dưới cùng"));
            case 1:
                AccessibilityNodeInfo accessibilityNodeInfo2 = (AccessibilityNodeInfo) obj;
                accessibilityNodeInfo2.getClass();
                CharSequence text = accessibilityNodeInfo2.getText();
                return Boolean.valueOf(ng0.o(text != null ? text.toString() : null, "Tôi"));
            case 2:
                AccessibilityNodeInfo accessibilityNodeInfo3 = (AccessibilityNodeInfo) obj;
                accessibilityNodeInfo3.getClass();
                CharSequence contentDescription2 = accessibilityNodeInfo3.getContentDescription();
                return Boolean.valueOf(ng0.o(contentDescription2 != null ? contentDescription2.toString() : null, "Cài đặt và quyền riêng tư"));
            case 3:
                AccessibilityNodeInfo accessibilityNodeInfo4 = (AccessibilityNodeInfo) obj;
                accessibilityNodeInfo4.getClass();
                CharSequence contentDescription3 = accessibilityNodeInfo4.getContentDescription();
                return Boolean.valueOf(ng0.o(contentDescription3 != null ? contentDescription3.toString() : null, "Tài khoản"));
            case 4:
                AccessibilityNodeInfo accessibilityNodeInfo5 = (AccessibilityNodeInfo) obj;
                accessibilityNodeInfo5.getClass();
                CharSequence contentDescription4 = accessibilityNodeInfo5.getContentDescription();
                return Boolean.valueOf(ng0.o(contentDescription4 != null ? contentDescription4.toString() : null, "Trang tính dưới cùng"));
            case 5:
                AccessibilityNodeInfo accessibilityNodeInfo6 = (AccessibilityNodeInfo) obj;
                accessibilityNodeInfo6.getClass();
                CharSequence contentDescription5 = accessibilityNodeInfo6.getContentDescription();
                return Boolean.valueOf(ng0.o(contentDescription5 != null ? contentDescription5.toString() : null, "Cài đặt và quyền riêng tư"));
            case 6:
                AccessibilityNodeInfo accessibilityNodeInfo7 = (AccessibilityNodeInfo) obj;
                accessibilityNodeInfo7.getClass();
                CharSequence contentDescription6 = accessibilityNodeInfo7.getContentDescription();
                return Boolean.valueOf(ng0.o(contentDescription6 != null ? contentDescription6.toString() : null, "Tài khoản"));
            case 7:
                AccessibilityNodeInfo accessibilityNodeInfo8 = (AccessibilityNodeInfo) obj;
                accessibilityNodeInfo8.getClass();
                CharSequence contentDescription7 = accessibilityNodeInfo8.getContentDescription();
                return Boolean.valueOf(ng0.o(contentDescription7 != null ? contentDescription7.toString() : null, "Trang tính dưới cùng"));
            case 8:
                AccessibilityNodeInfo accessibilityNodeInfo9 = (AccessibilityNodeInfo) obj;
                accessibilityNodeInfo9.getClass();
                CharSequence contentDescription8 = accessibilityNodeInfo9.getContentDescription();
                if (contentDescription8 != null && (string = contentDescription8.toString()) != null) {
                    string = bk1.A(string).toString();
                }
                str = string != null ? string : "";
                List list = es1.b;
                if (list == null || !list.isEmpty()) {
                    Iterator it = list.iterator();
                    while (it.hasNext()) {
                        if (kk1.m(str, (String) it.next(), true)) {
                        }
                    }
                    z = false;
                } else {
                    z = false;
                }
                return Boolean.valueOf(z);
            case 9:
                AccessibilityNodeInfo accessibilityNodeInfo10 = (AccessibilityNodeInfo) obj;
                accessibilityNodeInfo10.getClass();
                CharSequence className = accessibilityNodeInfo10.getClassName();
                return Boolean.valueOf(className != null && (string2 = className.toString()) != null && bk1.n(string2, "EditText", false) && accessibilityNodeInfo10.isEditable());
            case 10:
                ((AccessibilityNodeInfo) obj).getClass();
                return Boolean.FALSE;
            case 11:
                AccessibilityNodeInfo accessibilityNodeInfo11 = (AccessibilityNodeInfo) obj;
                accessibilityNodeInfo11.getClass();
                CharSequence text2 = accessibilityNodeInfo11.getText();
                String string14 = (text2 == null || (string4 = text2.toString()) == null) ? null : bk1.A(string4).toString();
                if (string14 == null) {
                    string14 = "";
                }
                CharSequence contentDescription9 = accessibilityNodeInfo11.getContentDescription();
                if (contentDescription9 != null && (string3 = contentDescription9.toString()) != null) {
                    string = bk1.A(string3).toString();
                }
                str = string != null ? string : "";
                List<String> list2 = es1.c;
                if (list2 == null || !list2.isEmpty()) {
                    for (String str2 : list2) {
                        if (!string14.equalsIgnoreCase(str2) && !str.equalsIgnoreCase(str2)) {
                            if (!kk1.m(string14, str2 + " ", true)) {
                                if (!kk1.m(str, str2 + " ", true)) {
                                    if (bk1.n(str, str2 + " bình luận", true)) {
                                    }
                                }
                            }
                        }
                    }
                    z = false;
                } else {
                    z = false;
                }
                return Boolean.valueOf(z);
            case 12:
                AccessibilityNodeInfo accessibilityNodeInfo12 = (AccessibilityNodeInfo) obj;
                accessibilityNodeInfo12.getClass();
                CharSequence contentDescription10 = accessibilityNodeInfo12.getContentDescription();
                return Boolean.valueOf(ng0.o(contentDescription10 != null ? contentDescription10.toString() : null, "Cài đặt và quyền riêng tư"));
            case 13:
                AccessibilityNodeInfo accessibilityNodeInfo13 = (AccessibilityNodeInfo) obj;
                accessibilityNodeInfo13.getClass();
                CharSequence contentDescription11 = accessibilityNodeInfo13.getContentDescription();
                string = contentDescription11 != null ? contentDescription11.toString() : null;
                return Boolean.valueOf(accessibilityNodeInfo13.isClickable() && kk1.m(string != null ? string : "", "Follow ", true));
            case 14:
                AccessibilityNodeInfo accessibilityNodeInfo14 = (AccessibilityNodeInfo) obj;
                accessibilityNodeInfo14.getClass();
                CharSequence contentDescription12 = accessibilityNodeInfo14.getContentDescription();
                return Boolean.valueOf(ng0.o(contentDescription12 != null ? contentDescription12.toString() : null, "Trang chủ"));
            case 15:
                AccessibilityNodeInfo accessibilityNodeInfo15 = (AccessibilityNodeInfo) obj;
                accessibilityNodeInfo15.getClass();
                CharSequence contentDescription13 = accessibilityNodeInfo15.getContentDescription();
                string = contentDescription13 != null ? contentDescription13.toString() : null;
                return Boolean.valueOf(accessibilityNodeInfo15.isClickable() && kk1.m(string != null ? string : "", "Đọc hoặc viết bình luận.", false));
            case 16:
                AccessibilityNodeInfo accessibilityNodeInfo16 = (AccessibilityNodeInfo) obj;
                accessibilityNodeInfo16.getClass();
                CharSequence contentDescription14 = accessibilityNodeInfo16.getContentDescription();
                return Boolean.valueOf(ng0.o(contentDescription14 != null ? contentDescription14.toString() : null, "Tài khoản"));
            case 17:
                AccessibilityNodeInfo accessibilityNodeInfo17 = (AccessibilityNodeInfo) obj;
                accessibilityNodeInfo17.getClass();
                CharSequence contentDescription15 = accessibilityNodeInfo17.getContentDescription();
                return Boolean.valueOf(ng0.o(contentDescription15 != null ? contentDescription15.toString() : null, "Đóng") && accessibilityNodeInfo17.isClickable());
            case 18:
                AccessibilityNodeInfo accessibilityNodeInfo18 = (AccessibilityNodeInfo) obj;
                accessibilityNodeInfo18.getClass();
                CharSequence contentDescription16 = accessibilityNodeInfo18.getContentDescription();
                return Boolean.valueOf((contentDescription16 == null || (string5 = contentDescription16.toString()) == null || !kk1.m(string5, "Chia sẻ video", false)) ? false : true);
            case 19:
                AccessibilityNodeInfo accessibilityNodeInfo19 = (AccessibilityNodeInfo) obj;
                accessibilityNodeInfo19.getClass();
                CharSequence text3 = accessibilityNodeInfo19.getText();
                String string15 = (text3 == null || (string7 = text3.toString()) == null) ? null : bk1.A(string7).toString();
                if (string15 == null) {
                    string15 = "";
                }
                CharSequence contentDescription17 = accessibilityNodeInfo19.getContentDescription();
                if (contentDescription17 != null && (string6 = contentDescription17.toString()) != null) {
                    string = bk1.A(string6).toString();
                }
                str = string != null ? string : "";
                ArrayList arrayListD0 = il.d0(il.d0(ft1.b, ft1.c), ft1.d);
                if (arrayListD0.isEmpty()) {
                    z = false;
                } else {
                    int size = arrayListD0.size();
                    int i = 0;
                    while (i < size) {
                        Object obj2 = arrayListD0.get(i);
                        i++;
                        String str3 = (String) obj2;
                        if (string15.equalsIgnoreCase(str3) || str.equalsIgnoreCase(str3) || kk1.m(string15, str3, true) || kk1.m(str, str3, true)) {
                        }
                    }
                    z = false;
                }
                return Boolean.valueOf(z);
            case e80.MAX_VERIFY /* 20 */:
                AccessibilityNodeInfo accessibilityNodeInfo20 = (AccessibilityNodeInfo) obj;
                accessibilityNodeInfo20.getClass();
                CharSequence contentDescription18 = accessibilityNodeInfo20.getContentDescription();
                String string16 = (contentDescription18 == null || (string9 = contentDescription18.toString()) == null) ? null : bk1.A(string9).toString();
                if (string16 == null) {
                    string16 = "";
                }
                CharSequence text4 = accessibilityNodeInfo20.getText();
                if (text4 != null && (string8 = text4.toString()) != null) {
                    string = bk1.A(string8).toString();
                }
                str = string != null ? string : "";
                List<String> list3 = ft1.d;
                if (list3 == null || !list3.isEmpty()) {
                    for (String str4 : list3) {
                        if (kk1.k(str4, string16) || kk1.k(str4, str)) {
                        }
                    }
                    z = false;
                } else {
                    z = false;
                }
                return Boolean.valueOf(z);
            case 21:
                AccessibilityNodeInfo accessibilityNodeInfo21 = (AccessibilityNodeInfo) obj;
                accessibilityNodeInfo21.getClass();
                CharSequence contentDescription19 = accessibilityNodeInfo21.getContentDescription();
                if (contentDescription19 != null && (string10 = contentDescription19.toString()) != null) {
                    string = bk1.A(string10).toString();
                }
                str = string != null ? string : "";
                List list4 = ft1.e;
                if (list4 == null || !list4.isEmpty()) {
                    Iterator it2 = list4.iterator();
                    while (it2.hasNext()) {
                        if (kk1.m(str, (String) it2.next(), true)) {
                        }
                    }
                    z = false;
                } else {
                    z = false;
                }
                return Boolean.valueOf(z);
            case 22:
                ((w40) obj).a();
                return bw1.a;
            case 23:
                AccessibilityNodeInfo accessibilityNodeInfo22 = (AccessibilityNodeInfo) obj;
                accessibilityNodeInfo22.getClass();
                CharSequence text5 = accessibilityNodeInfo22.getText();
                String string17 = (text5 == null || (string12 = text5.toString()) == null) ? null : bk1.A(string12).toString();
                if (string17 == null) {
                    string17 = "";
                }
                CharSequence contentDescription20 = accessibilityNodeInfo22.getContentDescription();
                if (contentDescription20 != null && (string11 = contentDescription20.toString()) != null) {
                    string = bk1.A(string11).toString();
                }
                str = string != null ? string : "";
                List<String> list5 = vv1.b;
                if (list5 == null || !list5.isEmpty()) {
                    for (String str5 : list5) {
                        if (string17.equalsIgnoreCase(str5) || str.equalsIgnoreCase(str5)) {
                        }
                    }
                    z = false;
                } else {
                    z = false;
                }
                return Boolean.valueOf(z);
            case 24:
                AccessibilityNodeInfo accessibilityNodeInfo23 = (AccessibilityNodeInfo) obj;
                accessibilityNodeInfo23.getClass();
                CharSequence text6 = accessibilityNodeInfo23.getText();
                if (text6 != null && (string13 = text6.toString()) != null) {
                    string = bk1.A(string13).toString();
                }
                str = string != null ? string : "";
                List<String> list6 = vv1.c;
                if (list6 == null || !list6.isEmpty()) {
                    for (String str6 : list6) {
                        if (kk1.k(str6, str) || bk1.n(str, str6, true)) {
                        }
                    }
                    z = false;
                } else {
                    z = false;
                }
                return Boolean.valueOf(z);
            case 25:
                return new bc(((Float) obj).floatValue());
            case 26:
                return new bc(((Integer) obj).intValue());
            case 27:
                return Integer.valueOf((int) ((bc) obj).a);
            case 28:
                return new bc(((hw) obj).d);
            default:
                return new hw(((bc) obj).a);
        }
    }
}
