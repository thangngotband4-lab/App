package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class yc1 extends uq {
    public ol1 d;
    public /* synthetic */ Object e;
    public int f;

    @Override // defpackage.kf
    public final Object r(Object obj) {
        this.e = obj;
        this.f |= Integer.MIN_VALUE;
        return fl.e(null, this);
    }
}
