package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class ku1 extends ph1 {
    public final ph1 e;
    public final boolean f;
    public final boolean g;
    public h50 h;
    public final long i;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public ku1(ph1 ph1Var, h50 h50Var, boolean z, boolean z2) {
        h50 h50VarE;
        super(0L, vh1.h);
        sa1 sa1Var = yh1.a;
        this.e = ph1Var;
        this.f = z;
        this.g = z2;
        this.h = yh1.k(h50Var, (ph1Var == null || (h50VarE = ph1Var.e()) == null) ? yh1.j.e : h50VarE, z);
        this.i = cd.b();
    }

    @Override // defpackage.ph1
    public final void c() {
        ph1 ph1Var;
        this.c = true;
        if (!this.g || (ph1Var = this.e) == null) {
            return;
        }
        ph1Var.c();
    }

    @Override // defpackage.ph1
    public final vh1 d() {
        return v().d();
    }

    @Override // defpackage.ph1
    public final h50 e() {
        return this.h;
    }

    @Override // defpackage.ph1
    public final boolean f() {
        return v().f();
    }

    @Override // defpackage.ph1
    public final long g() {
        return v().g();
    }

    @Override // defpackage.ph1
    public final h50 i() {
        return null;
    }

    @Override // defpackage.ph1
    public final void k() {
        jl.I();
        throw null;
    }

    @Override // defpackage.ph1
    public final void l() {
        jl.I();
        throw null;
    }

    @Override // defpackage.ph1
    public final void m() {
        v().m();
    }

    @Override // defpackage.ph1
    public final void n(rj1 rj1Var) {
        v().n(rj1Var);
    }

    @Override // defpackage.ph1
    public final ph1 u(h50 h50Var) {
        h50 h50VarK = yh1.k(h50Var, this.h, true);
        return !this.f ? yh1.g(v().u(null), h50VarK, true) : v().u(h50VarK);
    }

    public final ph1 v() {
        ph1 ph1Var = this.e;
        return ph1Var == null ? yh1.j : ph1Var;
    }
}
