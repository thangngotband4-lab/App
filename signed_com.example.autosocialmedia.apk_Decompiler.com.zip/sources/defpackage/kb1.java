package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class kb1 extends p2 implements h50 {
    @Override // defpackage.h50
    public final Object g(Object obj) {
        ((it0) this.d).b((lb1) obj);
        return bw1.a;
    }
}
