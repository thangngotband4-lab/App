package defpackage;

import android.content.Context;
import android.graphics.Rect;
import android.graphics.Region;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import com.example.autosocialmedia.R;
import java.util.LinkedHashMap;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public abstract class ma extends ViewGroup implements eo, oz0, pw0 {
    public final qk0 A;
    public boolean B;
    public final ij0 C;
    public final du0 d;
    public final View e;
    public final nz0 f;
    public w40 g;
    public boolean h;
    public w40 i;
    public w40 j;
    public fr0 k;
    public h50 l;
    public wu m;
    public h50 n;
    public en0 o;
    public na1 p;
    public final int[] q;
    public long r;
    public m02 s;
    public h50 t;
    public final la u;
    public final la v;
    public h50 w;
    public final int[] x;
    public int y;
    public int z;

    public ma(Context context, vo voVar, int i, du0 du0Var, View view, nz0 nz0Var) {
        super(context);
        this.d = du0Var;
        this.e = view;
        this.f = nz0Var;
        LinkedHashMap linkedHashMap = c12.a;
        setTag(R.id.androidx_compose_ui_view_composition_context, voVar);
        int i2 = 0;
        setSaveFromParentEnabled(false);
        addView(view);
        ty1 ty1Var = (ty1) this;
        oy1.c(this, new ea(ty1Var, i2));
        jy1.b(this, this);
        this.g = z5.r;
        this.i = z5.q;
        this.j = z5.p;
        this.k = cr0.a;
        this.m = rm.d();
        int i3 = 2;
        this.q = new int[2];
        this.r = 0L;
        int i4 = 1;
        this.u = new la(ty1Var, i4);
        this.v = new la(ty1Var, i2);
        this.x = new int[2];
        this.y = Integer.MIN_VALUE;
        this.z = Integer.MIN_VALUE;
        this.A = new qk0(5);
        ij0 ij0Var = new ij0(3);
        ij0Var.s = ty1Var;
        fr0 fr0VarA = md1.a(y5.x(du0Var), true, c5.q);
        z31 z31Var = new z31();
        z31Var.a = new ga(ty1Var, i3);
        nh nhVar = new nh();
        nh nhVar2 = z31Var.b;
        if (nhVar2 != null) {
            nhVar2.e = null;
        }
        z31Var.b = nhVar;
        nhVar.e = z31Var;
        setOnRequestDisallowInterceptTouchEvent$ui(nhVar);
        fr0 fr0VarC = ng0.G(y5.p(fr0VarA.c(z31Var), new ia(ty1Var, ij0Var, ty1Var)), new fa(ty1Var, ij0Var, i3)).c(new xg(new ga(ty1Var, i4)));
        ij0Var.f0(this.k.c(fr0VarC));
        this.l = new e6(ij0Var, 7, fr0VarC);
        ij0Var.b0(this.m);
        this.n = new g4(6, ij0Var);
        ij0Var.Q = new fa(ty1Var, ij0Var, i2);
        ij0Var.R = new ga(ty1Var, i2);
        ij0Var.e0(new ha(ty1Var, ij0Var));
        this.C = ij0Var;
    }

    public static final int e(ty1 ty1Var, int i, int i2, int i3) {
        return (i3 >= 0 || i == i2) ? View.MeasureSpec.makeMeasureSpec(tl.o(i3, i, i2), 1073741824) : (i3 != -2 || i2 == Integer.MAX_VALUE) ? (i3 != -1 || i2 == Integer.MAX_VALUE) ? View.MeasureSpec.makeMeasureSpec(0, 0) : View.MeasureSpec.makeMeasureSpec(i2, 1073741824) : View.MeasureSpec.makeMeasureSpec(i2, Integer.MIN_VALUE);
    }

    public static ge0 f(ge0 ge0Var, int i, int i2, int i3, int i4) {
        int i5 = ge0Var.a - i;
        if (i5 < 0) {
            i5 = 0;
        }
        int i6 = ge0Var.b - i2;
        if (i6 < 0) {
            i6 = 0;
        }
        int i7 = ge0Var.c - i3;
        if (i7 < 0) {
            i7 = 0;
        }
        int i8 = ge0Var.d - i4;
        return ge0.b(i5, i6, i7, i8 >= 0 ? i8 : 0);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final pz0 getSnapshotObserver() {
        if (!isAttachedToWindow()) {
            sd0.b("Expected AndroidViewHolder to be attached when observing reads.");
        }
        return ((k5) this.f).getSnapshotObserver();
    }

    @Override // defpackage.eo
    public final void a() {
        this.j.a();
    }

    @Override // defpackage.pw0
    public final m02 b(View view, m02 m02Var) {
        this.s = new m02(m02Var);
        return g(m02Var);
    }

    @Override // defpackage.eo
    public final void c() {
        this.i.a();
        removeAllViewsInLayout();
    }

    public final m02 g(m02 m02Var) {
        j02 j02Var = m02Var.a;
        ge0 ge0VarG = j02Var.g(-1);
        ge0 ge0Var = ge0.e;
        if (!ge0VarG.equals(ge0Var) || !j02Var.h(-9).equals(ge0Var) || j02Var.f() != null) {
            yd0 yd0Var = this.C.J.c;
            if (yd0Var.U.q) {
                long jO = tl.O(yd0Var.Q(0L));
                int i = (int) (jO >> 32);
                if (i < 0) {
                    i = 0;
                }
                int i2 = (int) (jO & 4294967295L);
                if (i2 < 0) {
                    i2 = 0;
                }
                long jL = bm.z(yd0Var).L();
                int i3 = (int) (jL >> 32);
                int i4 = (int) (jL & 4294967295L);
                long j = yd0Var.f;
                long jO2 = tl.O(yd0Var.Q((((long) Float.floatToRawIntBits((int) (j >> 32))) << 32) | (((long) Float.floatToRawIntBits((int) (j & 4294967295L))) & 4294967295L)));
                int i5 = i3 - ((int) (jO2 >> 32));
                if (i5 < 0) {
                    i5 = 0;
                }
                int i6 = i4 - ((int) (4294967295L & jO2));
                int i7 = i6 >= 0 ? i6 : 0;
                if (i != 0 || i2 != 0 || i5 != 0 || i7 != 0) {
                    return m02Var.a.n(i, i2, i5, i7);
                }
            }
        }
        return m02Var;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final boolean gatherTransparentRegion(Region region) {
        if (region == null) {
            return true;
        }
        int[] iArr = this.x;
        getLocationInWindow(iArr);
        int i = iArr[0];
        region.op(i, iArr[1], getWidth() + i, getHeight() + iArr[1], Region.Op.DIFFERENCE);
        return true;
    }

    @Override // android.view.ViewGroup, android.view.View
    public CharSequence getAccessibilityClassName() {
        return getClass().getName();
    }

    public final wu getDensity() {
        return this.m;
    }

    public final View getInteropView() {
        return this.e;
    }

    public final ij0 getLayoutNode() {
        return this.C;
    }

    @Override // android.view.View
    public ViewGroup.LayoutParams getLayoutParams() {
        ViewGroup.LayoutParams layoutParams = this.e.getLayoutParams();
        return layoutParams == null ? new ViewGroup.LayoutParams(-1, -1) : layoutParams;
    }

    public final en0 getLifecycleOwner() {
        return this.o;
    }

    public final fr0 getModifier() {
        return this.k;
    }

    @Override // android.view.ViewGroup
    public int getNestedScrollAxes() {
        this.A.getClass();
        return 0;
    }

    public final h50 getOnDensityChanged$ui() {
        return this.n;
    }

    public final h50 getOnModifierChanged$ui() {
        return this.l;
    }

    public final h50 getOnRequestDisallowInterceptTouchEvent$ui() {
        return this.w;
    }

    public final w40 getRelease() {
        return this.j;
    }

    public final w40 getReset() {
        return this.i;
    }

    public final na1 getSavedStateRegistryOwner() {
        return this.p;
    }

    public final w40 getUpdate() {
        return this.g;
    }

    public final View getView() {
        return this.e;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final ViewParent invalidateChildInParent(int[] iArr, Rect rect) {
        super.invalidateChildInParent(iArr, rect);
        if (!this.B) {
            this.C.C();
            return null;
        }
        this.e.postOnAnimation(new m2(this.v, 3));
        return null;
    }

    @Override // android.view.View
    public final boolean isNestedScrollingEnabled() {
        return this.e.isNestedScrollingEnabled();
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.u.a();
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onDescendantInvalidated(View view, View view2) {
        super.onDescendantInvalidated(view, view2);
        if (!this.B) {
            this.C.C();
        } else {
            this.e.postOnAnimation(new m2(this.v, 3));
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:10:0x0026  */
    /* JADX WARN: Removed duplicated region for block: B:24:0x0079  */
    @Override // android.view.ViewGroup, android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void onDetachedFromWindow() {
        /*
            r22 = this;
            r0 = r22
            super.onDetachedFromWindow()
            pz0 r1 = r0.getSnapshotObserver()
            li1 r1 = r1.a
            java.lang.Object r2 = r1.g
            monitor-enter(r2)
            it0 r1 = r1.f     // Catch: java.lang.Throwable -> L96
            int r3 = r1.f     // Catch: java.lang.Throwable -> L96
            r5 = 0
            r6 = 0
        L14:
            java.lang.Object[] r7 = r1.d
            if (r5 >= r3) goto L9c
            r7 = r7[r5]     // Catch: java.lang.Throwable -> L96
            ki1 r7 = (defpackage.ki1) r7     // Catch: java.lang.Throwable -> L96
            at0 r8 = r7.f     // Catch: java.lang.Throwable -> L96
            java.lang.Object r8 = r8.k(r0)     // Catch: java.lang.Throwable -> L96
            ps0 r8 = (defpackage.ps0) r8     // Catch: java.lang.Throwable -> L96
            if (r8 != 0) goto L29
        L26:
            r16 = r5
            goto L80
        L29:
            java.lang.Object[] r9 = r8.b     // Catch: java.lang.Throwable -> L96
            int[] r10 = r8.c     // Catch: java.lang.Throwable -> L96
            long[] r8 = r8.a     // Catch: java.lang.Throwable -> L96
            int r11 = r8.length     // Catch: java.lang.Throwable -> L96
            int r11 = r11 + (-2)
            if (r11 < 0) goto L26
            r12 = 0
        L35:
            r13 = r8[r12]     // Catch: java.lang.Throwable -> L96
            r16 = r5
            long r4 = ~r13     // Catch: java.lang.Throwable -> L96
            r17 = 7
            long r4 = r4 << r17
            long r4 = r4 & r13
            r17 = -9187201950435737472(0x8080808080808080, double:-2.937446524422997E-306)
            long r4 = r4 & r17
            int r4 = (r4 > r17 ? 1 : (r4 == r17 ? 0 : -1))
            if (r4 == 0) goto L79
            int r4 = r12 - r11
            int r4 = ~r4     // Catch: java.lang.Throwable -> L96
            int r4 = r4 >>> 31
            r5 = 8
            int r4 = 8 - r4
            r15 = 0
        L54:
            if (r15 >= r4) goto L77
            r18 = 255(0xff, double:1.26E-321)
            long r18 = r13 & r18
            r20 = 128(0x80, double:6.3E-322)
            int r18 = (r18 > r20 ? 1 : (r18 == r20 ? 0 : -1))
            if (r18 >= 0) goto L6e
            int r18 = r12 << 3
            int r18 = r18 + r15
            r19 = r5
            r5 = r9[r18]     // Catch: java.lang.Throwable -> L96
            r18 = r10[r18]     // Catch: java.lang.Throwable -> L96
            r7.c(r0, r5)     // Catch: java.lang.Throwable -> L96
            goto L70
        L6e:
            r19 = r5
        L70:
            long r13 = r13 >> r19
            int r15 = r15 + 1
            r5 = r19
            goto L54
        L77:
            if (r4 != r5) goto L80
        L79:
            if (r12 == r11) goto L80
            int r12 = r12 + 1
            r5 = r16
            goto L35
        L80:
            at0 r4 = r7.f     // Catch: java.lang.Throwable -> L96
            boolean r4 = r4.j()     // Catch: java.lang.Throwable -> L96
            if (r4 != 0) goto L8b
            int r6 = r6 + 1
            goto L98
        L8b:
            if (r6 <= 0) goto L98
            java.lang.Object[] r4 = r1.d     // Catch: java.lang.Throwable -> L96
            int r5 = r16 - r6
            r7 = r4[r16]     // Catch: java.lang.Throwable -> L96
            r4[r5] = r7     // Catch: java.lang.Throwable -> L96
            goto L98
        L96:
            r0 = move-exception
            goto La6
        L98:
            int r5 = r16 + 1
            goto L14
        L9c:
            int r0 = r3 - r6
            r4 = 0
            java.util.Arrays.fill(r7, r0, r3, r4)     // Catch: java.lang.Throwable -> L96
            r1.f = r0     // Catch: java.lang.Throwable -> L96
            monitor-exit(r2)
            return
        La6:
            monitor-exit(r2)
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.ma.onDetachedFromWindow():void");
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z, int i, int i2, int i3, int i4) {
        this.e.layout(0, 0, i3 - i, i4 - i2);
    }

    @Override // android.view.View
    public final void onMeasure(int i, int i2) {
        View view = this.e;
        if (view.getParent() != this) {
            setMeasuredDimension(View.MeasureSpec.getSize(i), View.MeasureSpec.getSize(i2));
            return;
        }
        if (view.getVisibility() == 8) {
            setMeasuredDimension(0, 0);
            return;
        }
        view.measure(i, i2);
        setMeasuredDimension(view.getMeasuredWidth(), view.getMeasuredHeight());
        this.y = i;
        this.z = i2;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onNestedFling(View view, float f, float f2, boolean z) {
        if (!this.e.isNestedScrollingEnabled()) {
            return false;
        }
        m22.y(this.d.c(), null, new ja(z, this, jj1.c(f * (-1.0f), f2 * (-1.0f)), null), 3);
        return false;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onNestedPreFling(View view, float f, float f2) {
        if (!this.e.isNestedScrollingEnabled()) {
            return false;
        }
        m22.y(this.d.c(), null, new ka(this, jj1.c(f * (-1.0f), f2 * (-1.0f)), null, 0), 3);
        return false;
    }

    @Override // android.view.View
    public final void onWindowVisibilityChanged(int i) {
        super.onWindowVisibilityChanged(i);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean requestChildRectangleOnScreen(View view, Rect rect, boolean z) {
        h50 h50Var = this.t;
        if (h50Var == null) {
            return true;
        }
        h50Var.g(rect != null ? rm.b0(rect) : null);
        return true;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void requestDisallowInterceptTouchEvent(boolean z) {
        h50 h50Var = this.w;
        if (h50Var != null) {
            h50Var.g(Boolean.valueOf(z));
        }
        super.requestDisallowInterceptTouchEvent(z);
    }

    public final void setDensity(wu wuVar) {
        if (wuVar != this.m) {
            this.m = wuVar;
            h50 h50Var = this.n;
            if (h50Var != null) {
                h50Var.g(wuVar);
            }
        }
    }

    public final void setLifecycleOwner(en0 en0Var) {
        if (en0Var != this.o) {
            this.o = en0Var;
            setTag(R.id.view_tree_lifecycle_owner, en0Var);
        }
    }

    public final void setModifier(fr0 fr0Var) {
        if (fr0Var != this.k) {
            this.k = fr0Var;
            h50 h50Var = this.l;
            if (h50Var != null) {
                h50Var.g(fr0Var);
            }
        }
    }

    public final void setOnDensityChanged$ui(h50 h50Var) {
        this.n = h50Var;
    }

    public final void setOnModifierChanged$ui(h50 h50Var) {
        this.l = h50Var;
    }

    public final void setOnRequestDisallowInterceptTouchEvent$ui(h50 h50Var) {
        this.w = h50Var;
    }

    public final void setRelease(w40 w40Var) {
        this.j = w40Var;
    }

    public final void setReset(w40 w40Var) {
        this.i = w40Var;
    }

    public final void setSavedStateRegistryOwner(na1 na1Var) {
        if (na1Var != this.p) {
            this.p = na1Var;
            setTag(R.id.view_tree_saved_state_registry_owner, na1Var);
        }
    }

    public final void setUpdate(w40 w40Var) {
        this.g = w40Var;
        this.h = true;
        this.u.a();
    }

    @Override // android.view.ViewGroup
    public final boolean shouldDelayChildPressedState() {
        return true;
    }

    @Override // defpackage.oz0
    public final boolean z() {
        return isAttachedToWindow();
    }
}
