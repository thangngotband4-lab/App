package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class u6 extends ki0 implements w40 {
    public final /* synthetic */ kv e;
    public final /* synthetic */ w40 f;
    public final /* synthetic */ iv g;
    public final /* synthetic */ ri0 h;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public u6(kv kvVar, w40 w40Var, iv ivVar, ri0 ri0Var) {
        super(0);
        this.e = kvVar;
        this.f = w40Var;
        this.g = ivVar;
        this.h = ri0Var;
    }

    @Override // defpackage.w40
    public final Object a() {
        this.e.e(this.f, this.g, this.h);
        return bw1.a;
    }
}
