package defpackage;

import java.io.Serializable;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public abstract class ki0 implements v50, Serializable {
    public final int d;

    public ki0(int i) {
        this.d = i;
    }

    @Override // defpackage.v50
    public final int b() {
        return this.d;
    }

    public final String toString() {
        f71.a.getClass();
        return g71.a(this);
    }
}
