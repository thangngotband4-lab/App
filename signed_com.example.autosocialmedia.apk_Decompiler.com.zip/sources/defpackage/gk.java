package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class gk implements w40 {
    public final /* synthetic */ int d;
    public final /* synthetic */ h50 e;
    public final /* synthetic */ boolean f;

    public /* synthetic */ gk(h50 h50Var, boolean z, int i) {
        this.d = i;
        this.e = h50Var;
        this.f = z;
    }

    @Override // defpackage.w40
    public final Object a() {
        int i = this.d;
        bw1 bw1Var = bw1.a;
        boolean z = this.f;
        h50 h50Var = this.e;
        switch (i) {
            case 0:
                h50Var.g(Boolean.valueOf(!z));
                break;
            case 1:
                h50Var.g(Boolean.valueOf(!z));
                break;
            default:
                h50Var.g(Boolean.valueOf(!z));
                break;
        }
        return bw1Var;
    }
}
