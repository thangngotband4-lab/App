package defpackage;

import android.os.Parcel;
import android.os.Parcelable;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class j01 extends sj1 implements Parcelable, ci1, kj1, gt0 {
    public static final Parcelable.Creator<j01> CREATOR = new c2(4);
    public ai1 e;

    public j01(int i) {
        ph1 ph1VarJ = yh1.j();
        ai1 ai1Var = new ai1(i, ph1VarJ.g());
        if (!(ph1VarJ instanceof k60)) {
            ai1Var.b = new ai1(i, 1L);
        }
        this.e = ai1Var;
    }

    @Override // defpackage.rj1
    public final tj1 a() {
        return this.e;
    }

    @Override // defpackage.rj1
    public final tj1 b(tj1 tj1Var, tj1 tj1Var2, tj1 tj1Var3) {
        if (((ai1) tj1Var2).c == ((ai1) tj1Var3).c) {
            return tj1Var2;
        }
        return null;
    }

    @Override // defpackage.rj1
    public final void c(tj1 tj1Var) {
        tj1Var.getClass();
        this.e = (ai1) tj1Var;
    }

    @Override // defpackage.ci1
    public final a4 d() {
        return a4.Z;
    }

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    public final int g() {
        return ((ai1) yh1.t(this.e, this)).c;
    }

    @Override // defpackage.kj1
    public final Object getValue() {
        return Integer.valueOf(g());
    }

    public final void h(int i) {
        ph1 ph1VarJ;
        ai1 ai1Var = (ai1) yh1.h(this.e);
        if (ai1Var.c != i) {
            ai1 ai1Var2 = this.e;
            synchronized (yh1.c) {
                ph1VarJ = yh1.j();
                ((ai1) yh1.o(ai1Var2, this, ph1VarJ, ai1Var)).c = i;
            }
            yh1.n(ph1VarJ, this);
        }
    }

    @Override // defpackage.gt0
    public final void setValue(Object obj) {
        h(((Number) obj).intValue());
    }

    public final String toString() {
        return "MutableIntState(value=" + ((ai1) yh1.h(this.e)).c + ")@" + hashCode();
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(g());
    }
}
