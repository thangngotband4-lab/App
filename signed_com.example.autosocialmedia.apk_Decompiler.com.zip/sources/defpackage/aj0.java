package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class aj0 extends fp0 {
    public final /* synthetic */ bj0 x;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public aj0(bj0 bj0Var) {
        super(bj0Var);
        this.x = bj0Var;
    }

    @Override // defpackage.gq0
    public final int S(int i) {
        bj0 bj0Var = this.x;
        zi0 zi0Var = bj0Var.U;
        pu0 pu0Var = bj0Var.s;
        pu0Var.getClass();
        fp0 fp0VarS0 = pu0Var.S0();
        fp0VarS0.getClass();
        return zi0Var.Q(this, fp0VarS0, i);
    }

    @Override // defpackage.gq0
    public final int Z(int i) {
        bj0 bj0Var = this.x;
        zi0 zi0Var = bj0Var.U;
        pu0 pu0Var = bj0Var.s;
        pu0Var.getClass();
        fp0 fp0VarS0 = pu0Var.S0();
        fp0VarS0.getClass();
        return zi0Var.e(this, fp0VarS0, i);
    }

    @Override // defpackage.gq0
    public final int c0(int i) {
        bj0 bj0Var = this.x;
        zi0 zi0Var = bj0Var.U;
        pu0 pu0Var = bj0Var.s;
        pu0Var.getClass();
        fp0 fp0VarS0 = pu0Var.S0();
        fp0VarS0.getClass();
        return zi0Var.B(this, fp0VarS0, i);
    }

    @Override // defpackage.gq0
    public final k21 e(long j) {
        n0(j);
        new xp(j);
        bj0 bj0Var = this.x;
        zi0 zi0Var = bj0Var.U;
        pu0 pu0Var = bj0Var.s;
        pu0Var.getClass();
        fp0 fp0VarS0 = pu0Var.S0();
        fp0VarS0.getClass();
        fp0.J0(this, zi0Var.d(this, fp0VarS0, j));
        return this;
    }

    @Override // defpackage.gq0
    public final int f(int i) {
        bj0 bj0Var = this.x;
        zi0 zi0Var = bj0Var.U;
        pu0 pu0Var = bj0Var.s;
        pu0Var.getClass();
        fp0 fp0VarS0 = pu0Var.S0();
        fp0VarS0.getClass();
        return zi0Var.m(this, fp0VarS0, i);
    }

    @Override // defpackage.dp0
    public final int r0(c4 c4Var) {
        int iH = om.h(this, c4Var);
        this.w.g(iH, c4Var);
        return iH;
    }
}
