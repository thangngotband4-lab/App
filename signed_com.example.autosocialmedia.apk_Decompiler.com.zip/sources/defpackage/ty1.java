package defpackage;

import android.content.Context;
import android.os.Parcelable;
import android.util.SparseArray;
import android.view.View;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class ty1 extends ma {
    public final View D;
    public final du0 E;
    public y91 F;
    public h50 G;
    public h50 H;
    public h50 I;

    public ty1(Context context, h50 h50Var, vo voVar, z91 z91Var, int i, nz0 nz0Var) {
        View view = (View) h50Var.g(context);
        du0 du0Var = new du0();
        super(context, voVar, i, du0Var, view, nz0Var);
        this.D = view;
        this.E = du0Var;
        setClipChildren(false);
        String strValueOf = String.valueOf(i);
        Object objD = z91Var != null ? z91Var.d(strValueOf) : null;
        SparseArray<Parcelable> sparseArray = objD instanceof SparseArray ? (SparseArray) objD : null;
        if (sparseArray != null) {
            view.restoreHierarchyState(sparseArray);
        }
        if (z91Var != null) {
            setSavableRegistryEntry(z91Var.a(strValueOf, new la(this, 2)));
        }
        c5 c5Var = c5.r;
        this.G = c5Var;
        this.H = c5Var;
        this.I = c5Var;
    }

    public static final void h(ty1 ty1Var) {
        ty1Var.setSavableRegistryEntry(null);
    }

    private final void setSavableRegistryEntry(y91 y91Var) {
        y91 y91Var2 = this.F;
        if (y91Var2 != null) {
            ((yc) y91Var2).s();
        }
        this.F = y91Var;
    }

    public final du0 getDispatcher() {
        return this.E;
    }

    public final h50 getReleaseBlock() {
        return this.I;
    }

    public final h50 getResetBlock() {
        return this.H;
    }

    public /* bridge */ /* synthetic */ o getSubCompositionView() {
        return null;
    }

    public final h50 getUpdateBlock() {
        return this.G;
    }

    public final void setReleaseBlock(h50 h50Var) {
        this.I = h50Var;
        setRelease(new la(this, 3));
    }

    public final void setResetBlock(h50 h50Var) {
        this.H = h50Var;
        setReset(new la(this, 4));
    }

    public final void setUpdateBlock(h50 h50Var) {
        this.G = h50Var;
        setUpdate(new la(this, 5));
    }

    public View getViewRoot() {
        return this;
    }
}
