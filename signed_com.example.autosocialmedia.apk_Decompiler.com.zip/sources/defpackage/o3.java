package defpackage;

import android.content.Context;
import android.graphics.Rect;
import android.view.ScrollCaptureSession;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Consumer;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class o3 extends jl1 implements l50 {
    public final /* synthetic */ int e;
    public int f;
    public Object g;
    public Object h;
    public /* synthetic */ Object i;
    public final /* synthetic */ Object j;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public o3(Context context, ax1 ax1Var, i01 i01Var, gt0 gt0Var, tq tqVar) {
        super(2, tqVar);
        this.e = 11;
        this.g = context;
        this.i = ax1Var;
        this.j = i01Var;
        this.h = gt0Var;
    }

    @Override // defpackage.l50
    public final Object f(Object obj, Object obj2) throws Throwable {
        int i = this.e;
        es esVar = es.d;
        bw1 bw1Var = bw1.a;
        switch (i) {
            case 0:
                return ((o3) o((tq) obj2, (ds) obj)).r(bw1Var);
            case 1:
                ((o3) o((tq) obj2, (l8) obj)).r(bw1Var);
                return esVar;
            case 2:
                return ((o3) o((tq) obj2, (ds) obj)).r(bw1Var);
            case 3:
                return ((o3) o((tq) obj2, (ds) obj)).r(bw1Var);
            case 4:
                return ((o3) o((tq) obj2, (ag1) obj)).r(bw1Var);
            case 5:
                return ((o3) o((tq) obj2, (ds) obj)).r(bw1Var);
            case 6:
                return ((o3) o((tq) obj2, (ds) obj)).r(bw1Var);
            case 7:
                ((o3) o((tq) obj2, (ds) obj)).r(bw1Var);
                return esVar;
            case 8:
                return ((o3) o((tq) obj2, (ds) obj)).r(bw1Var);
            case 9:
                return ((o3) o((tq) obj2, (ds) obj)).r(bw1Var);
            case 10:
                return ((o3) o((tq) obj2, (ds) obj)).r(bw1Var);
            default:
                return ((o3) o((tq) obj2, (ds) obj)).r(bw1Var);
        }
    }

    @Override // defpackage.kf
    public final tq o(tq tqVar, Object obj) {
        int i = this.e;
        Object obj2 = this.j;
        switch (i) {
            case 0:
                return new o3((lz) this.g, (gt0) this.h, (gt0) this.i, (gt0) obj2, tqVar, 0);
            case 1:
                o3 o3Var = new o3((h50) this.h, (w7) this.i, (zl0) obj2, tqVar, 1);
                o3Var.g = obj;
                return o3Var;
            case 2:
                return new o3(this.g, (va) obj2, (gt0) this.h, (gt0) this.i, tqVar);
            case 3:
                return new o3((jo) this.g, (ScrollCaptureSession) this.h, (Rect) this.i, (Consumer) obj2, tqVar, 3);
            case 4:
                o3 o3Var2 = new o3((e20) this.h, (nj1) this.i, (Float) obj2, tqVar, 4);
                o3Var2.g = obj;
                return o3Var2;
            case 5:
                return new o3((gj1) this.g, (e20) this.h, (nj1) this.i, (Float) obj2, tqVar, 5);
            case 6:
                return new o3((q90) this.g, (gt0) this.h, (gt0) this.i, (gt0) obj2, tqVar, 6);
            case 7:
                o3 o3Var3 = new o3((gt0) this.h, (od0) obj2, tqVar);
                o3Var3.i = obj;
                return o3Var3;
            case 8:
                return new o3((c31) this.i, (l50) obj2, tqVar);
            case 9:
                o3 o3Var4 = new o3((h50) this.h, (AtomicReference) this.i, (l50) obj2, tqVar, 9);
                o3Var4.g = obj;
                return o3Var4;
            case 10:
                o3 o3Var5 = new o3((x31) this.h, (m50) this.i, (h50) obj2, tqVar, 10);
                o3Var5.g = obj;
                return o3Var5;
            default:
                return new o3((Context) this.g, (ax1) this.i, (i01) obj2, (gt0) this.h, tqVar);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:234:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:237:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:90:0x01e9  */
    /* JADX WARN: Removed duplicated region for block: B:95:0x01ff  */
    /* JADX WARN: Removed duplicated region for block: B:98:0x0223  */
    /* JADX WARN: Type inference failed for: r2v0, types: [boolean] */
    /* JADX WARN: Type inference failed for: r2v23 */
    /* JADX WARN: Type inference failed for: r2v36 */
    /* JADX WARN: Type inference failed for: r2v37 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:94:0x01fd -> B:88:0x01c8). Please report as a decompilation issue!!! */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:96:0x0220 -> B:88:0x01c8). Please report as a decompilation issue!!! */
    @Override // defpackage.kf
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final java.lang.Object r(java.lang.Object r26) throws java.lang.Throwable {
        /*
            Method dump skipped, instruction units count: 1250
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.o3.r(java.lang.Object):java.lang.Object");
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public o3(c31 c31Var, l50 l50Var, tq tqVar) {
        super(2, tqVar);
        this.e = 8;
        this.i = c31Var;
        this.j = l50Var;
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public o3(gt0 gt0Var, od0 od0Var, tq tqVar) {
        super(2, tqVar);
        this.e = 7;
        this.h = gt0Var;
        this.j = od0Var;
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public o3(Object obj, va vaVar, gt0 gt0Var, gt0 gt0Var2, tq tqVar) {
        super(2, tqVar);
        this.e = 2;
        this.g = obj;
        this.j = vaVar;
        this.h = gt0Var;
        this.i = gt0Var2;
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ o3(Object obj, Object obj2, Object obj3, tq tqVar, int i) {
        super(2, tqVar);
        this.e = i;
        this.h = obj;
        this.i = obj2;
        this.j = obj3;
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ o3(Object obj, Object obj2, Object obj3, Object obj4, tq tqVar, int i) {
        super(2, tqVar);
        this.e = i;
        this.g = obj;
        this.h = obj2;
        this.i = obj3;
        this.j = obj4;
    }
}
