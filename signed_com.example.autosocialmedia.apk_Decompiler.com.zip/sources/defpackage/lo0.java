package defpackage;

import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public class lo0 {
    public static final /* synthetic */ AtomicReferenceFieldUpdater a = AtomicReferenceFieldUpdater.newUpdater(lo0.class, Object.class, "_cur$volatile");
    public static final /* synthetic */ long b = yi.a.objectFieldOffset(lo0.class.getDeclaredField("_cur$volatile"));
    private volatile /* synthetic */ Object _cur$volatile = new no0(8, false);

    public final boolean a(Runnable runnable) {
        while (true) {
            AtomicReferenceFieldUpdater atomicReferenceFieldUpdater = a;
            atomicReferenceFieldUpdater.getClass();
            no0 no0Var = (no0) yi.a.getObjectVolatile(this, b);
            int iA = no0Var.a(runnable);
            if (iA == 0) {
                return true;
            }
            if (iA == 1) {
                f0.B(atomicReferenceFieldUpdater, this, no0Var, no0Var.d());
            } else if (iA == 2) {
                return false;
            }
        }
    }

    public final void b() {
        while (true) {
            AtomicReferenceFieldUpdater atomicReferenceFieldUpdater = a;
            atomicReferenceFieldUpdater.getClass();
            no0 no0Var = (no0) yi.a.getObjectVolatile(this, b);
            if (no0Var.c()) {
                return;
            } else {
                f0.B(atomicReferenceFieldUpdater, this, no0Var, no0Var.d());
            }
        }
    }

    public final int c() {
        a.getClass();
        no0 no0Var = (no0) yi.a.getObjectVolatile(this, b);
        no0Var.getClass();
        long j = no0.f.get(no0Var);
        return 1073741823 & (((int) ((j & 1152921503533105152L) >> 30)) - ((int) (1073741823 & j)));
    }

    public final Object d() {
        while (true) {
            AtomicReferenceFieldUpdater atomicReferenceFieldUpdater = a;
            atomicReferenceFieldUpdater.getClass();
            no0 no0Var = (no0) yi.a.getObjectVolatile(this, b);
            Object objE = no0Var.e();
            if (objE != no0.g) {
                return objE;
            }
            f0.B(atomicReferenceFieldUpdater, this, no0Var, no0Var.d());
        }
    }
}
