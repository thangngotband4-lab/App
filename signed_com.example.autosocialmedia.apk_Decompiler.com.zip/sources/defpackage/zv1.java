package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class zv1 {
    public final String a;
    public final String b;
    public final Long c;
    public final x1 d;
    public final ht1 e;

    public zv1(String str, String str2, Long l, x1 x1Var, ht1 ht1Var) {
        str.getClass();
        str2.getClass();
        this.a = str;
        this.b = str2;
        this.c = l;
        this.d = x1Var;
        this.e = ht1Var;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof zv1)) {
            return false;
        }
        zv1 zv1Var = (zv1) obj;
        return ng0.o(this.a, zv1Var.a) && ng0.o(this.b, zv1Var.b) && ng0.o(this.c, zv1Var.c) && this.d == zv1Var.d && this.e == zv1Var.e;
    }

    public final int hashCode() {
        int iE = f0.e(this.a.hashCode() * 31, 31, this.b);
        Long l = this.c;
        int iHashCode = (this.d.hashCode() + ((iE + (l == null ? 0 : l.hashCode())) * 31)) * 31;
        ht1 ht1Var = this.e;
        return iHashCode + (ht1Var != null ? ht1Var.hashCode() : 0);
    }

    public final String toString() {
        return "UnifiedAccount(username=" + this.a + ", displayName=" + this.b + ", goLikeId=" + this.c + ", status=" + this.d + ", tiktokVariant=" + this.e + ")";
    }
}
