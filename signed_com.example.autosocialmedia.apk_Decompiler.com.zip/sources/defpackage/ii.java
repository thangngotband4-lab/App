package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class ii implements l50 {
    public final /* synthetic */ int d;
    public final /* synthetic */ long e;
    public final /* synthetic */ Object f;
    public final /* synthetic */ t50 g;

    public /* synthetic */ ii(long j, Object obj, t50 t50Var, int i) {
        this.d = i;
        this.e = j;
        this.f = obj;
        this.g = t50Var;
    }

    @Override // defpackage.l50
    public final Object f(Object obj, Object obj2) {
        int i = this.d;
        bw1 bw1Var = bw1.a;
        t50 t50Var = this.g;
        Object obj3 = this.f;
        switch (i) {
            case 0:
                xo xoVar = (xo) obj;
                int iIntValue = ((Number) obj2).intValue();
                if (!xoVar.O(iIntValue & 1, (iIntValue & 3) != 2)) {
                    xoVar.R();
                } else {
                    rm.h(this.e, ((nv1) xoVar.j(pv1.a)).m, jl.C(417635459, new hi((uz0) obj3, (m50) t50Var), xoVar), xoVar, 384);
                }
                break;
            default:
                xo xoVar2 = (xo) obj;
                int iIntValue2 = ((Number) obj2).intValue();
                if (!xoVar2.O(iIntValue2 & 1, (iIntValue2 & 3) != 2)) {
                    xoVar2.R();
                } else {
                    yj1.b(this.e, (dq1) obj3, (l50) t50Var, xoVar2, 0);
                }
                break;
        }
        return bw1Var;
    }
}
