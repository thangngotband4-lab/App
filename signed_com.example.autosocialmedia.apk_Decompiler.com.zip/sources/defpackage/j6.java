package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class j6 extends uq {
    public th d;
    public /* synthetic */ Object e;
    public final /* synthetic */ k6 f;
    public int g;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public j6(k6 k6Var, uq uqVar) {
        super(uqVar);
        this.f = k6Var;
    }

    @Override // defpackage.kf
    public final Object r(Object obj) {
        this.e = obj;
        this.g |= Integer.MIN_VALUE;
        return this.f.d(this);
    }
}
