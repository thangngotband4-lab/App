package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class mv implements lr0 {
    public static final mv e = new mv(0);
    public final /* synthetic */ int d;

    public /* synthetic */ mv(int i) {
        this.d = i;
    }

    @Override // defpackage.ur
    public final ur i(ur urVar) {
        switch (this.d) {
        }
        return hl.O(this, urVar);
    }

    @Override // defpackage.ur
    public final sr k(tr trVar) {
        switch (this.d) {
        }
        return hl.v(this, trVar);
    }

    @Override // defpackage.ur
    public final Object p(l50 l50Var, Object obj) {
        switch (this.d) {
        }
        return l50Var.f(obj, this);
    }

    @Override // defpackage.ur
    public final ur t(tr trVar) {
        switch (this.d) {
        }
        return hl.H(this, trVar);
    }

    @Override // defpackage.lr0
    public final float u() {
        switch (this.d) {
            case 0:
                return 0.0f;
            default:
                return 1.0f;
        }
    }
}
