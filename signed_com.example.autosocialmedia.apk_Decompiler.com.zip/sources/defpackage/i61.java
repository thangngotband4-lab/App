package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class i61 extends ph1 {
    public final h50 e;
    public int f;

    public i61(long j, vh1 vh1Var, h50 h50Var) {
        super(j, vh1Var);
        this.e = h50Var;
        this.f = 1;
    }

    @Override // defpackage.ph1
    public final void c() {
        if (this.c) {
            return;
        }
        l();
        this.c = true;
        synchronized (yh1.c) {
            o();
        }
    }

    @Override // defpackage.ph1
    public final h50 e() {
        return this.e;
    }

    @Override // defpackage.ph1
    public final boolean f() {
        return true;
    }

    @Override // defpackage.ph1
    public final h50 i() {
        return null;
    }

    @Override // defpackage.ph1
    public final void k() {
        this.f++;
    }

    @Override // defpackage.ph1
    public final void l() {
        int i = this.f - 1;
        this.f = i;
        if (i == 0) {
            a();
        }
    }

    @Override // defpackage.ph1
    public final void n(rj1 rj1Var) {
        sa1 sa1Var = yh1.a;
        throw new IllegalStateException("Cannot modify a state object in a read-only snapshot");
    }

    @Override // defpackage.ph1
    public final ph1 u(h50 h50Var) {
        yh1.c(this);
        return new zt0(this.b, this.a, yh1.k(h50Var, this.e, true), this);
    }

    @Override // defpackage.ph1
    public final void m() {
    }
}
