package defpackage;

import kotlin.Metadata;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u000e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0081\b\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001¨\u0006\u0003"}, d2 = {"Log;", "Ljr0;", "Lng;", "foundation"}, k = 1, mv = {2, 0, 0}, xi = 48)
public final /* data */ class og extends jr0 {
    public final float a;
    public final oh b;
    public final qf1 c;

    public og(float f, oh ohVar, qf1 qf1Var) {
        this.a = f;
        this.b = ohVar;
        this.c = qf1Var;
    }

    @Override // defpackage.jr0
    public final er0 e() {
        return new ng(this.a, this.b, this.c);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof og)) {
            return false;
        }
        og ogVar = (og) obj;
        return hw.b(this.a, ogVar.a) && this.b.equals(ogVar.b) && ng0.o(this.c, ogVar.c);
    }

    @Override // defpackage.jr0
    public final void f(er0 er0Var) {
        ng ngVar = (ng) er0Var;
        float f = ngVar.u;
        ji jiVar = ngVar.x;
        float f2 = this.a;
        if (!hw.b(f, f2)) {
            ngVar.u = f2;
            jiVar.M0();
        }
        oh ohVar = ngVar.v;
        oh ohVar2 = this.b;
        if (!ng0.o(ohVar, ohVar2)) {
            ngVar.v = ohVar2;
            jiVar.M0();
        }
        qf1 qf1Var = ngVar.w;
        qf1 qf1Var2 = this.c;
        if (ng0.o(qf1Var, qf1Var2)) {
            return;
        }
        ngVar.w = qf1Var2;
        jiVar.M0();
        bm.E(ngVar);
    }

    public final int hashCode() {
        return this.c.hashCode() + ((this.b.hashCode() + (Float.hashCode(this.a) * 31)) * 31);
    }

    public final String toString() {
        return "BorderModifierNodeElement(width=" + ((Object) hw.c(this.a)) + ", brush=" + this.b + ", shape=" + this.c + ')';
    }
}
