package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class i81 implements wu {
    public int d;
    public float e = 1.0f;
    public float f = 1.0f;
    public float g = 1.0f;
    public float h;
    public long i;
    public long j;
    public float k;
    public long l;
    public qf1 m;
    public boolean n;
    public long o;
    public wu p;
    public ri0 q;
    public int r;
    public hl s;

    public i81() {
        long j = ca0.a;
        this.i = j;
        this.j = j;
        this.k = 8.0f;
        this.l = wt1.b;
        this.m = eq0.G;
        this.o = 9205357640488583168L;
        this.p = rm.d();
        this.q = ri0.d;
        this.r = 3;
    }

    public final void a() {
        h(1.0f);
        i(1.0f);
        d(1.0f);
        j(0.0f);
        long j = ca0.a;
        e(j);
        m(j);
        if (this.k != 8.0f) {
            this.d |= 2048;
            this.k = 8.0f;
        }
        n(wt1.b);
        l(eq0.G);
        f(false);
        if (this.r != 3) {
            this.d |= 524288;
            this.r = 3;
        }
        this.o = 9205357640488583168L;
        this.s = null;
        this.d = 0;
    }

    @Override // defpackage.wu
    public final float b() {
        return this.p.b();
    }

    public final void d(float f) {
        if (this.g == f) {
            return;
        }
        this.d |= 4;
        this.g = f;
    }

    public final void e(long j) {
        if (ql.c(this.i, j)) {
            return;
        }
        this.d |= 64;
        this.i = j;
    }

    public final void f(boolean z) {
        if (this.n != z) {
            this.d |= 16384;
            this.n = z;
        }
    }

    public final void h(float f) {
        if (this.e == f) {
            return;
        }
        this.d |= 1;
        this.e = f;
    }

    public final void i(float f) {
        if (this.f == f) {
            return;
        }
        this.d |= 2;
        this.f = f;
    }

    public final void j(float f) {
        if (this.h == f) {
            return;
        }
        this.d |= 32;
        this.h = f;
    }

    @Override // defpackage.wu
    public final float k() {
        return this.p.k();
    }

    public final void l(qf1 qf1Var) {
        if (ng0.o(this.m, qf1Var)) {
            return;
        }
        this.d |= 8192;
        this.m = qf1Var;
    }

    public final void m(long j) {
        if (ql.c(this.j, j)) {
            return;
        }
        this.d |= 128;
        this.j = j;
    }

    public final void n(long j) {
        if (wt1.a(this.l, j)) {
            return;
        }
        this.d |= 4096;
        this.l = j;
    }
}
