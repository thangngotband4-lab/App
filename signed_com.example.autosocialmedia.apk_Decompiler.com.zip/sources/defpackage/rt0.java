package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class rt0 implements vi, gz1 {
    public final xi d;
    public final /* synthetic */ st0 e;

    public rt0(st0 st0Var, xi xiVar) {
        this.e = st0Var;
        this.d = xiVar;
    }

    @Override // defpackage.gz1
    public final void a(rc1 rc1Var, int i) {
        this.d.a(rc1Var, i);
    }

    @Override // defpackage.tq
    public final ur e() {
        return this.d.h;
    }

    @Override // defpackage.tq
    public final void h(Object obj) {
        this.d.h(obj);
    }

    @Override // defpackage.vi
    public final lz j(Object obj, m50 m50Var) {
        st0 st0Var = this.e;
        wi wiVar = new wi(st0Var, this);
        lz lzVarJ = this.d.J((bw1) obj, wiVar);
        if (lzVarJ != null) {
            st0.i.set(st0Var, null);
        }
        return lzVarJ;
    }

    @Override // defpackage.vi
    public final boolean l(Throwable th) {
        return this.d.l(th);
    }

    @Override // defpackage.vi
    public final void z(Object obj) {
        this.d.z(obj);
    }
}
