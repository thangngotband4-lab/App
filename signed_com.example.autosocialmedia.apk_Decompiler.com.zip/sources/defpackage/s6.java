package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public abstract class s6 {
    public static final float a = (25.0f * 2.0f) / 2.4142137f;

    public static final void a(nw0 nw0Var, fr0 fr0Var, final long j, xo xoVar, int i) {
        int i2;
        xoVar.X(1776202187);
        int i3 = (xoVar.f(nw0Var) ? 4 : 2) | i | (xoVar.f(fr0Var) ? 32 : 16) | 128;
        if (xoVar.O(i3 & 1, (i3 & 147) != 146)) {
            xoVar.T();
            if ((i & 1) == 0 || xoVar.y()) {
                i2 = i3 & (-897);
                j = 9205357640488583168L;
            } else {
                xoVar.R();
                i2 = i3 & (-897);
            }
            xoVar.q();
            int i4 = i2 & 14;
            boolean z = i4 == 4;
            Object objL = xoVar.L();
            if (z || objL == ro.a) {
                objL = new l(3, nw0Var);
                xoVar.g0(objL);
            }
            final fr0 fr0VarA = md1.a(fr0Var, false, (h50) objL);
            ng0.b(nw0Var, a4.f, jl.C(-1653527038, new l50() { // from class: q6
                @Override // defpackage.l50
                public final Object f(Object obj, Object obj2) {
                    xo xoVar2 = (xo) obj;
                    int iIntValue = ((Integer) obj2).intValue();
                    if (xoVar2.O(iIntValue & 1, (iIntValue & 3) != 2)) {
                        long j2 = j;
                        fr0 fr0Var2 = fr0VarA;
                        if (j2 != 9205357640488583168L) {
                            xoVar2.W(-1244013944);
                            fr0 fr0VarE = ig1.e(fr0Var2, kw.b(j2), kw.a(j2), 0.0f, 0.0f, 12);
                            lq0 lq0VarD = tg.d(a4.f, false);
                            int iHashCode = Long.hashCode(xoVar2.T);
                            t11 t11VarL = xoVar2.l();
                            fr0 fr0VarM = om.M(xoVar2, fr0VarE);
                            oo.b.getClass();
                            kp kpVar = no.b;
                            xoVar2.Z();
                            if (xoVar2.S) {
                                xoVar2.k(kpVar);
                            } else {
                                xoVar2.j0();
                            }
                            ak1.o(xoVar2, no.e, lq0VarD);
                            ak1.o(xoVar2, no.d, t11VarL);
                            ak1.j(xoVar2, Integer.valueOf(iHashCode), no.f);
                            ak1.n(xoVar2, no.g);
                            ak1.o(xoVar2, no.c, fr0VarM);
                            s6.b(null, xoVar2, 0, 1);
                            xoVar2.p(true);
                            xoVar2.p(false);
                        } else {
                            xoVar2.W(-1243644858);
                            s6.b(fr0Var2, xoVar2, 0, 0);
                            xoVar2.p(false);
                        }
                    } else {
                        xoVar2.R();
                    }
                    return bw1.a;
                }
            }, xoVar), xoVar, i4 | 432);
        } else {
            xoVar.R();
        }
        long j2 = j;
        l61 l61VarR = xoVar.r();
        if (l61VarR != null) {
            l61VarR.d = new r6(nw0Var, fr0Var, j2, i);
        }
    }

    public static final void b(fr0 fr0Var, xo xoVar, int i, int i2) {
        int i3;
        xoVar.X(694251107);
        int i4 = i2 & 1;
        if (i4 != 0) {
            i3 = i | 6;
        } else {
            i3 = (xoVar.f(fr0Var) ? 4 : 2) | i;
        }
        if (xoVar.O(i3 & 1, (i3 & 3) != 2)) {
            if (i4 != 0) {
                fr0Var = cr0.a;
            }
            om.d(xoVar, om.q(ig1.g(fr0Var, a, 25.0f), new un(8)));
        } else {
            xoVar.R();
        }
        l61 l61VarR = xoVar.r();
        if (l61VarR != null) {
            l61VarR.d = new n6(fr0Var, i, i2);
        }
    }
}
