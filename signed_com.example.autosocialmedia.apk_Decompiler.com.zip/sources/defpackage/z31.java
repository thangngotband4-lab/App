package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class z31 implements dr0 {
    public ga a;
    public nh b;
    public boolean c;
    public final l4 d;

    public z31() {
        l4 l4Var = new l4();
        l4Var.d = this;
        l4Var.b = y31.d;
        this.d = l4Var;
    }

    public final h50 e() {
        ga gaVar = this.a;
        if (gaVar != null) {
            return gaVar;
        }
        ng0.N("onTouchEvent");
        throw null;
    }
}
