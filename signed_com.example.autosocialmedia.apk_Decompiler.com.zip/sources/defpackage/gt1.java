package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class gt1 {
    public static ht1 a(String str) {
        ht1 ht1Var;
        ht1[] ht1VarArrValues = ht1.values();
        int length = ht1VarArrValues.length;
        int i = 0;
        while (true) {
            if (i >= length) {
                ht1Var = null;
                break;
            }
            ht1Var = ht1VarArrValues[i];
            if (ng0.o(ht1Var.name(), str)) {
                break;
            }
            i++;
        }
        return ht1Var == null ? ht1.NORMAL : ht1Var;
    }
}
