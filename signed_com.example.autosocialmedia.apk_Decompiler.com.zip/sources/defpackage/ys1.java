package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class ys1 implements h50 {
    public final /* synthetic */ int d;
    public final /* synthetic */ gt0 e;

    public /* synthetic */ ys1(gt0 gt0Var, int i) {
        this.d = i;
        this.e = gt0Var;
    }

    @Override // defpackage.h50
    public final Object g(Object obj) {
        int i = this.d;
        bw1 bw1Var = bw1.a;
        gt0 gt0Var = this.e;
        switch (i) {
            case 0:
                Boolean bool = (Boolean) obj;
                bool.booleanValue();
                gt0Var.setValue(bool);
                break;
            case 1:
                Boolean bool2 = (Boolean) obj;
                bool2.booleanValue();
                gt0Var.setValue(bool2);
                break;
            case 2:
                Boolean bool3 = (Boolean) obj;
                bool3.booleanValue();
                gt0Var.setValue(bool3);
                break;
            case 3:
                String str = (String) obj;
                str.getClass();
                gt0Var.setValue(str);
                break;
            default:
                String str2 = (String) obj;
                str2.getClass();
                gt0Var.setValue(str2);
                break;
        }
        return bw1Var;
    }
}
