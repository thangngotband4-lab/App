package defpackage;

import android.util.Log;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.nio.charset.Charset;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class ye1 {
    public static final hl a(ye1 ye1Var, String str, String str2) {
        HttpURLConnection httpURLConnection;
        ye1Var.getClass();
        HttpURLConnection httpURLConnection2 = null;
        String strK = null;
        HttpURLConnection httpURLConnection3 = null;
        try {
            try {
                URLConnection uRLConnectionOpenConnection = new URL(im0.SERVER_BASE_URL.concat(str)).openConnection();
                uRLConnectionOpenConnection.getClass();
                httpURLConnection = (HttpURLConnection) uRLConnectionOpenConnection;
                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.setDoOutput(true);
                httpURLConnection.setRequestProperty("content-type", "application/json");
                httpURLConnection.setRequestProperty("accept", "application/json");
                httpURLConnection.setConnectTimeout(im0.HTTP_TIMEOUT_MS);
                httpURLConnection.setReadTimeout(im0.HTTP_TIMEOUT_MS);
            } catch (Throwable th) {
                th = th;
            }
        } catch (Exception e) {
            e = e;
        }
        try {
            OutputStream outputStream = httpURLConnection.getOutputStream();
            try {
                Charset charset = ak.a;
                byte[] bytes = str2.getBytes(charset);
                bytes.getClass();
                outputStream.write(bytes);
                outputStream.close();
                int responseCode = httpURLConnection.getResponseCode();
                if (200 > responseCode || responseCode >= 300) {
                    InputStream errorStream = httpURLConnection.getErrorStream();
                    if (errorStream != null) {
                        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(errorStream, charset), 8192);
                        try {
                            strK = uj1.k(bufferedReader);
                            bufferedReader.close();
                        } finally {
                            try {
                                throw th;
                            } finally {
                            }
                        }
                    }
                    Log.w("ServerLicense", "HTTP " + responseCode + " at " + str + ": " + bk1.z(strK == null ? "" : strK, dv0.MAX_VIDEOS));
                    StringBuilder sb = new StringBuilder("Server trả lỗi HTTP ");
                    sb.append(responseCode);
                    re1 re1Var = new re1(responseCode, sb.toString(), strK);
                    httpURLConnection.disconnect();
                    return re1Var;
                }
                InputStream inputStream = httpURLConnection.getInputStream();
                inputStream.getClass();
                BufferedReader bufferedReader2 = new BufferedReader(new InputStreamReader(inputStream, charset), 8192);
                try {
                    String strK2 = uj1.k(bufferedReader2);
                    bufferedReader2.close();
                    te1 te1Var = new te1(strK2);
                    httpURLConnection.disconnect();
                    return te1Var;
                } finally {
                }
            } finally {
            }
        } catch (Exception e2) {
            e = e2;
            httpURLConnection2 = httpURLConnection;
            Log.w("ServerLicense", "request error at " + str + ": " + e.getMessage());
            String message = e.getMessage();
            if (message == null) {
                message = "Lỗi kết nối";
            }
            se1 se1Var = new se1(message);
            if (httpURLConnection2 != null) {
                httpURLConnection2.disconnect();
            }
            return se1Var;
        } catch (Throwable th2) {
            th = th2;
            httpURLConnection3 = httpURLConnection;
            if (httpURLConnection3 != null) {
                httpURLConnection3.disconnect();
            }
            throw th;
        }
    }
}
