package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class ur0 {
    public final long a;
    public final long b;
    public final boolean c;

    public ur0(long j, long j2, boolean z) {
        this.a = j;
        this.b = j2;
        this.c = z;
    }

    public final ur0 a(ur0 ur0Var) {
        return new ur0(jw0.e(this.a, ur0Var.a), Math.max(this.b, ur0Var.b), this.c);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof ur0)) {
            return false;
        }
        ur0 ur0Var = (ur0) obj;
        return jw0.b(this.a, ur0Var.a) && this.b == ur0Var.b && this.c == ur0Var.c;
    }

    public final int hashCode() {
        return Boolean.hashCode(this.c) + f0.c(Long.hashCode(this.a) * 31, 31, this.b);
    }

    public final String toString() {
        return "MouseWheelScrollDelta(value=" + ((Object) jw0.g(this.a)) + ", timeMillis=" + this.b + ", shouldApplyImmediately=" + this.c + ')';
    }
}
