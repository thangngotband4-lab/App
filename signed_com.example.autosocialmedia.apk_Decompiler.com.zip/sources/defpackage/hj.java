package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class hj {
    public final long a;
    public final long b;
    public final long c;
    public final long d;

    public hj(long j, long j2, long j3, long j4) {
        this.a = j;
        this.b = j2;
        this.c = j3;
        this.d = j4;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || !(obj instanceof hj)) {
            return false;
        }
        hj hjVar = (hj) obj;
        return ql.c(this.a, hjVar.a) && ql.c(this.b, hjVar.b) && ql.c(this.c, hjVar.c) && ql.c(this.d, hjVar.d);
    }

    public final int hashCode() {
        int i = ql.h;
        return Long.hashCode(this.d) + f0.c(f0.c(Long.hashCode(this.a) * 31, 31, this.b), 31, this.c);
    }
}
