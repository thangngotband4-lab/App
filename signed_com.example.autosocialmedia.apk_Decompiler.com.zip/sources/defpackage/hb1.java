package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class hb1 extends ib1 {
    public static final hb1 d = new hb1("tiktok", "TikTok", fl.p());

    public final boolean equals(Object obj) {
        return this == obj || (obj instanceof hb1);
    }

    public final int hashCode() {
        return -1485906247;
    }

    public final String toString() {
        return "TikTok";
    }
}
