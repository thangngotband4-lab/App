package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class jb0 extends ki0 implements l50 {
    public final /* synthetic */ int e;
    public final /* synthetic */ kb0[] f;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ jb0(kb0[] kb0VarArr, int i) {
        super(2);
        this.e = i;
        this.f = kb0VarArr;
    }

    @Override // defpackage.l50
    public final Object f(Object obj, Object obj2) {
        int i = this.e;
        kb0[] kb0VarArr = this.f;
        switch (i) {
            case 0:
                return Float.valueOf(jl.f((j21) obj, true, kb0VarArr, ((Number) obj2).floatValue()));
            default:
                return Float.valueOf(jl.f((j21) obj, false, kb0VarArr, ((Number) obj2).floatValue()));
        }
    }
}
