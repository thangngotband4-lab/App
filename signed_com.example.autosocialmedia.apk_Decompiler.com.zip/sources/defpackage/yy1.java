package defpackage;

import java.util.Iterator;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public abstract class yy1 {
    public final zy1 a = new zy1();

    public final void a() {
        zy1 zy1Var = this.a;
        if (zy1Var != null && !zy1Var.d) {
            zy1Var.d = true;
            synchronized (zy1Var.a) {
                try {
                    Iterator it = zy1Var.b.values().iterator();
                    while (it.hasNext()) {
                        zy1.a((AutoCloseable) it.next());
                    }
                    Iterator it2 = zy1Var.c.iterator();
                    while (it2.hasNext()) {
                        zy1.a((AutoCloseable) it2.next());
                    }
                    zy1Var.c.clear();
                } catch (Throwable th) {
                    throw th;
                }
            }
        }
        b();
    }

    public void b() {
    }
}
