package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class hm1 extends c81 implements l50 {
    public Object e;
    public Object f;
    public int g;
    public /* synthetic */ Object h;
    public final /* synthetic */ ds i;
    public final /* synthetic */ m50 j;
    public final /* synthetic */ h50 k;
    public final /* synthetic */ w41 l;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public hm1(ds dsVar, m50 m50Var, h50 h50Var, w41 w41Var, tq tqVar) {
        super(tqVar);
        this.i = dsVar;
        this.j = m50Var;
        this.k = h50Var;
        this.l = w41Var;
    }

    @Override // defpackage.l50
    public final Object f(Object obj, Object obj2) {
        return ((hm1) o((tq) obj2, (ol1) obj)).r(bw1.a);
    }

    @Override // defpackage.kf
    public final tq o(tq tqVar, Object obj) {
        hm1 hm1Var = new hm1(this.i, this.j, this.k, this.l, tqVar);
        hm1Var.h = obj;
        return hm1Var;
    }

    /* JADX WARN: Removed duplicated region for block: B:33:0x00c2  */
    /* JADX WARN: Removed duplicated region for block: B:35:0x00d5  */
    /* JADX WARN: Removed duplicated region for block: B:58:0x015d  */
    /* JADX WARN: Removed duplicated region for block: B:62:0x0173  */
    /* JADX WARN: Removed duplicated region for block: B:65:0x0179  */
    /* JADX WARN: Removed duplicated region for block: B:66:0x0182  */
    /* JADX WARN: Removed duplicated region for block: B:68:0x0190  */
    @Override // defpackage.kf
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final java.lang.Object r(java.lang.Object r19) {
        /*
            Method dump skipped, instruction units count: 434
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.hm1.r(java.lang.Object):java.lang.Object");
    }
}
