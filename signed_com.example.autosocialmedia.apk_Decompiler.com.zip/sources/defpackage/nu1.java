package defpackage;

import kotlin.Metadata;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u000e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0083\b\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001¨\u0006\u0003"}, d2 = {"Lnu1;", "Ljr0;", "Lou1;", "foundation"}, k = 1, mv = {2, 0, 0}, xi = 48)
final /* data */ class nu1 extends jr0 {
    public final xk0 a;

    public nu1(xk0 xk0Var) {
        this.a = xk0Var;
    }

    @Override // defpackage.jr0
    public final er0 e() {
        ou1 ou1Var = new ou1();
        ou1Var.r = this.a;
        return ou1Var;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        return (obj instanceof nu1) && ng0.o(this.a, ((nu1) obj).a);
    }

    @Override // defpackage.jr0
    public final void f(er0 er0Var) {
        ((ou1) er0Var).r = this.a;
    }

    public final int hashCode() {
        return this.a.hashCode();
    }

    public final String toString() {
        return "TraversablePrefetchStateModifierElement(prefetchState=" + this.a + ')';
    }
}
