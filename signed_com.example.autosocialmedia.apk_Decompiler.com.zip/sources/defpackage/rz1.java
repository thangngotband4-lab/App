package defpackage;

import android.animation.ValueAnimator;
import android.view.View;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class rz1 implements Runnable {
    public final /* synthetic */ View d;
    public final /* synthetic */ xz1 e;
    public final /* synthetic */ ae0 f;
    public final /* synthetic */ ValueAnimator g;

    public rz1(View view, xz1 xz1Var, ae0 ae0Var, ValueAnimator valueAnimator) {
        this.d = view;
        this.e = xz1Var;
        this.f = ae0Var;
        this.g = valueAnimator;
    }

    @Override // java.lang.Runnable
    public final void run() {
        tz1.i(this.d, this.e, this.f);
        this.g.start();
    }
}
