package defpackage;

import com.example.autosocialmedia.MainActivity;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class po extends o {
    public final m01 l;
    public boolean m;

    public po(MainActivity mainActivity) {
        super(mainActivity);
        this.l = hl.I(null);
    }

    @Override // defpackage.o
    public final void a(int i, xo xoVar) {
        xoVar.X(420213850);
        int i2 = (xoVar.h(this) ? 4 : 2) | i;
        if (xoVar.O(i2 & 1, (i2 & 3) != 2)) {
            l50 l50Var = (l50) this.l.getValue();
            if (l50Var == null) {
                xoVar.W(-1238823553);
            } else {
                xoVar.W(98585282);
                l50Var.f(xoVar, 0);
            }
            xoVar.p(false);
        } else {
            xoVar.R();
        }
        l61 l61VarR = xoVar.r();
        if (l61VarR != null) {
            l61VarR.d = new n(this, i, 3);
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public CharSequence getAccessibilityClassName() {
        return po.class.getName();
    }

    @Override // defpackage.o
    public boolean getShouldCreateCompositionOnAttachedToWindow() {
        return this.m;
    }

    public final void setContent(l50 l50Var) {
        this.m = true;
        this.l.setValue(l50Var);
        if (isAttachedToWindow()) {
            if (this.g != null || isAttachedToWindow()) {
                d();
            } else {
                zi.f("createComposition requires either a parent reference or the View to be attachedto a window. Attach the View or call setParentCompositionReference.");
            }
        }
    }

    public static /* synthetic */ void getShouldCreateCompositionOnAttachedToWindow$annotations() {
    }
}
