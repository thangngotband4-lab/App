package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class gf1 implements vy {
    public final int a;
    public final int b;

    public gf1(int i, int i2) {
        this.a = i;
        this.b = i2;
    }

    @Override // defpackage.vy
    public final void a(wy wyVar) {
        int iO = tl.o(this.a, 0, wyVar.a.b());
        int iO2 = tl.o(this.b, 0, wyVar.a.b());
        if (iO < iO2) {
            wyVar.f(iO, iO2);
        } else {
            wyVar.f(iO2, iO);
        }
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof gf1)) {
            return false;
        }
        gf1 gf1Var = (gf1) obj;
        return this.a == gf1Var.a && this.b == gf1Var.b;
    }

    public final int hashCode() {
        return (this.a * 31) + this.b;
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder("SetSelectionCommand(start=");
        sb.append(this.a);
        sb.append(", end=");
        return f0.p(sb, this.b, ')');
    }
}
