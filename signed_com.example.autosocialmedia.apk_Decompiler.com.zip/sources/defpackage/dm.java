package defpackage;

import android.graphics.ColorSpace;
import android.os.Build;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.autofill.AutofillId;
import java.util.function.DoubleUnaryOperator;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public abstract class dm {
    public static final ColorSpace a(am amVar) {
        if (ng0.o(amVar, em.e)) {
            ColorSpace colorSpace = ColorSpace.get(ColorSpace.Named.SRGB);
            zi.d(colorSpace);
            return colorSpace;
        }
        if (ng0.o(amVar, em.q)) {
            ColorSpace colorSpace2 = ColorSpace.get(ColorSpace.Named.ACES);
            zi.d(colorSpace2);
            return colorSpace2;
        }
        if (ng0.o(amVar, em.r)) {
            ColorSpace colorSpace3 = ColorSpace.get(ColorSpace.Named.ACESCG);
            zi.d(colorSpace3);
            return colorSpace3;
        }
        if (ng0.o(amVar, em.o)) {
            ColorSpace colorSpace4 = ColorSpace.get(ColorSpace.Named.ADOBE_RGB);
            zi.d(colorSpace4);
            return colorSpace4;
        }
        if (ng0.o(amVar, em.j)) {
            ColorSpace colorSpace5 = ColorSpace.get(ColorSpace.Named.BT2020);
            zi.d(colorSpace5);
            return colorSpace5;
        }
        if (ng0.o(amVar, em.i)) {
            ColorSpace colorSpace6 = ColorSpace.get(ColorSpace.Named.BT709);
            zi.d(colorSpace6);
            return colorSpace6;
        }
        if (ng0.o(amVar, em.t)) {
            ColorSpace colorSpace7 = ColorSpace.get(ColorSpace.Named.CIE_LAB);
            zi.d(colorSpace7);
            return colorSpace7;
        }
        if (ng0.o(amVar, em.s)) {
            ColorSpace colorSpace8 = ColorSpace.get(ColorSpace.Named.CIE_XYZ);
            zi.d(colorSpace8);
            return colorSpace8;
        }
        if (ng0.o(amVar, em.k)) {
            ColorSpace colorSpace9 = ColorSpace.get(ColorSpace.Named.DCI_P3);
            zi.d(colorSpace9);
            return colorSpace9;
        }
        if (ng0.o(amVar, em.l)) {
            ColorSpace colorSpace10 = ColorSpace.get(ColorSpace.Named.DISPLAY_P3);
            zi.d(colorSpace10);
            return colorSpace10;
        }
        if (ng0.o(amVar, em.g)) {
            ColorSpace colorSpace11 = ColorSpace.get(ColorSpace.Named.EXTENDED_SRGB);
            zi.d(colorSpace11);
            return colorSpace11;
        }
        if (ng0.o(amVar, em.h)) {
            ColorSpace colorSpace12 = ColorSpace.get(ColorSpace.Named.LINEAR_EXTENDED_SRGB);
            zi.d(colorSpace12);
            return colorSpace12;
        }
        if (ng0.o(amVar, em.f)) {
            ColorSpace colorSpace13 = ColorSpace.get(ColorSpace.Named.LINEAR_SRGB);
            zi.d(colorSpace13);
            return colorSpace13;
        }
        if (ng0.o(amVar, em.m)) {
            ColorSpace colorSpace14 = ColorSpace.get(ColorSpace.Named.NTSC_1953);
            zi.d(colorSpace14);
            return colorSpace14;
        }
        if (ng0.o(amVar, em.p)) {
            ColorSpace colorSpace15 = ColorSpace.get(ColorSpace.Named.PRO_PHOTO_RGB);
            zi.d(colorSpace15);
            return colorSpace15;
        }
        if (ng0.o(amVar, em.n)) {
            ColorSpace colorSpace16 = ColorSpace.get(ColorSpace.Named.SMPTE_C);
            zi.d(colorSpace16);
            return colorSpace16;
        }
        if (Build.VERSION.SDK_INT >= 34) {
            ColorSpace colorSpace17 = ng0.o(amVar, em.v) ? ColorSpace.get(ColorSpace.Named.BT2020_HLG) : ng0.o(amVar, em.w) ? ColorSpace.get(ColorSpace.Named.BT2020_PQ) : null;
            if (colorSpace17 != null) {
                zi.d(colorSpace17);
                return colorSpace17;
            }
        }
        if (!(amVar instanceof q81)) {
            ColorSpace colorSpace18 = ColorSpace.get(ColorSpace.Named.SRGB);
            zi.d(colorSpace18);
            return colorSpace18;
        }
        String str = amVar.a;
        q81 q81Var = (q81) amVar;
        float[] fArrA = q81Var.d.a();
        vt1 vt1Var = q81Var.g;
        ColorSpace.Rgb.TransferParameters transferParameters = vt1Var != null ? new ColorSpace.Rgb.TransferParameters(vt1Var.b, vt1Var.c, vt1Var.d, vt1Var.e, vt1Var.f, vt1Var.g, vt1Var.a) : null;
        if (transferParameters != null) {
            return zi.d(new ColorSpace.Rgb(str, q81Var.h, fArrA, transferParameters));
        }
        float[] fArr = q81Var.h;
        final p81 p81Var = q81Var.l;
        final int i = 0;
        DoubleUnaryOperator doubleUnaryOperator = new DoubleUnaryOperator() { // from class: cm
            @Override // java.util.function.DoubleUnaryOperator
            public final double applyAsDouble(double d) {
                int i2 = i;
                h50 h50Var = p81Var;
                switch (i2) {
                }
                return ((Number) h50Var.g(Double.valueOf(d))).doubleValue();
            }
        };
        final p81 p81Var2 = q81Var.o;
        final int i2 = 1;
        return zi.d(new ColorSpace.Rgb(str, fArr, fArrA, doubleUnaryOperator, new DoubleUnaryOperator() { // from class: cm
            @Override // java.util.function.DoubleUnaryOperator
            public final double applyAsDouble(double d) {
                int i22 = i2;
                h50 h50Var = p81Var2;
                switch (i22) {
                }
                return ((Number) h50Var.g(Double.valueOf(d))).doubleValue();
            }
        }, q81Var.e, q81Var.f));
    }

    public static AutofillId b(View view) {
        return view.getAutofillId();
    }

    public static float c(ViewConfiguration viewConfiguration) {
        return viewConfiguration.getScaledHorizontalScrollFactor();
    }

    public static float d(ViewConfiguration viewConfiguration) {
        return viewConfiguration.getScaledHorizontalScrollFactor();
    }

    public static float e(ViewConfiguration viewConfiguration) {
        return viewConfiguration.getScaledVerticalScrollFactor();
    }

    public static float f(ViewConfiguration viewConfiguration) {
        return viewConfiguration.getScaledVerticalScrollFactor();
    }

    public static /* bridge */ /* synthetic */ AutofillId h(Object obj) {
        return (AutofillId) obj;
    }
}
