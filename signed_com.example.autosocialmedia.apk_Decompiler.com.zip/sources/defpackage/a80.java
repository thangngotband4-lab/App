package defpackage;

import android.webkit.WebChromeClient;
import android.webkit.WebView;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class a80 extends WebChromeClient {
    public final /* synthetic */ int a;
    public final /* synthetic */ gt0 b;

    public /* synthetic */ a80(gt0 gt0Var, int i) {
        this.a = i;
        this.b = gt0Var;
    }

    @Override // android.webkit.WebChromeClient
    public final void onProgressChanged(WebView webView, int i) {
        int i2 = this.a;
        gt0 gt0Var = this.b;
        switch (i2) {
            case 0:
                gt0Var.setValue(Integer.valueOf(i));
                break;
            case 1:
                gt0Var.setValue(Integer.valueOf(i));
                break;
            case 2:
                gt0Var.setValue(Integer.valueOf(i));
                break;
            case 3:
                gt0Var.setValue(Integer.valueOf(i));
                break;
            default:
                gt0Var.setValue(Integer.valueOf(i));
                break;
        }
    }
}
