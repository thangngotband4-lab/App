package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class nm implements fr0 {
    public final fr0 a;
    public final fr0 b;

    public nm(fr0 fr0Var, fr0 fr0Var2) {
        this.a = fr0Var;
        this.b = fr0Var2;
    }

    @Override // defpackage.fr0
    public final Object a(l50 l50Var, Object obj) {
        return this.b.a(l50Var, this.a.a(l50Var, obj));
    }

    @Override // defpackage.fr0
    public final boolean b(h50 h50Var) {
        return this.a.b(h50Var) && this.b.b(h50Var);
    }

    public final boolean equals(Object obj) {
        if (!(obj instanceof nm)) {
            return false;
        }
        nm nmVar = (nm) obj;
        return this.a.equals(nmVar.a) && ng0.o(this.b, nmVar.b);
    }

    public final int hashCode() {
        return (this.b.hashCode() * 31) + this.a.hashCode();
    }

    public final String toString() {
        return "[" + ((String) a(oa.o, "")) + ']';
    }
}
