package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class cx extends uq {
    public l50 d;
    public ol1 e;
    public d71 f;
    public st1 g;
    public t31 h;
    public float i;
    public /* synthetic */ Object j;
    public int k;

    @Override // defpackage.kf
    public final Object r(Object obj) {
        this.j = obj;
        this.k |= Integer.MIN_VALUE;
        return fx.c(null, 0L, null, this);
    }
}
