package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class i30 {
    public static final i30 b = new i30();
    public static final i30 c = new i30();
    public static final i30 d = new i30();
    public final it0 a = new it0(new k30[16]);

    /* JADX WARN: Code restructure failed: missing block: B:69:0x004b, code lost:
    
        continue;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static void a(defpackage.i30 r12) {
        /*
            r12.getClass()
            i30 r0 = defpackage.i30.b
            java.lang.String r1 = "\n    Please check whether the focusRequester is FocusRequester.Cancel or FocusRequester.Default\n    before invoking any functions on the focusRequester.\n"
            if (r12 == r0) goto Lc3
            i30 r0 = defpackage.i30.c
            if (r12 == r0) goto Lbf
            it0 r12 = r12.a
            int r0 = r12.f
            if (r0 != 0) goto L1b
            java.lang.String r12 = "FocusRelatedWarning: \n   FocusRequester is not initialized. Here are some possible fixes:\n\n   1. Remember the FocusRequester: val focusRequester = remember { FocusRequester() }\n   2. Did you forget to add a Modifier.focusRequester() ?\n   3. Are you attempting to request focus during composition? Focus requests should be made in\n   response to some event. Eg Modifier.clickable { focusRequester.requestFocus() }\n"
            java.io.PrintStream r0 = java.lang.System.out
            r0.println(r12)
            return
        L1b:
            java.lang.Object[] r12 = r12.d
            r1 = 0
            r2 = r1
        L1f:
            if (r2 >= r0) goto Lbe
            r3 = r12[r2]
            k30 r3 = (defpackage.k30) r3
            r4 = r3
            er0 r4 = (defpackage.er0) r4
            er0 r4 = r4.d
            boolean r4 = r4.q
            if (r4 != 0) goto L33
            java.lang.String r4 = "visitChildren called on an unattached node"
            defpackage.sd0.b(r4)
        L33:
            it0 r4 = new it0
            r5 = 16
            er0[] r6 = new defpackage.er0[r5]
            r4.<init>(r6)
            er0 r3 = (defpackage.er0) r3
            er0 r3 = r3.d
            er0 r6 = r3.i
            if (r6 != 0) goto L48
            defpackage.tl.j(r4, r3)
            goto L4b
        L48:
            r4.b(r6)
        L4b:
            int r3 = r4.f
            if (r3 == 0) goto Lba
            int r3 = r3 + (-1)
            java.lang.Object r3 = r4.k(r3)
            er0 r3 = (defpackage.er0) r3
            int r6 = r3.g
            r6 = r6 & 1024(0x400, float:1.435E-42)
            if (r6 != 0) goto L61
            defpackage.tl.j(r4, r3)
            goto L4b
        L61:
            if (r3 == 0) goto L4b
            int r6 = r3.f
            r6 = r6 & 1024(0x400, float:1.435E-42)
            if (r6 == 0) goto Lb7
            r6 = 0
            r7 = r6
        L6b:
            if (r3 == 0) goto L4b
            boolean r8 = r3 instanceof defpackage.r30
            if (r8 == 0) goto L7b
            r30 r3 = (defpackage.r30) r3
            r8 = 7
            boolean r3 = r3.T0(r8)
            if (r3 == 0) goto Lb2
            goto Lba
        L7b:
            int r8 = r3.f
            r8 = r8 & 1024(0x400, float:1.435E-42)
            if (r8 == 0) goto Lb2
            boolean r8 = r3 instanceof defpackage.lu
            if (r8 == 0) goto Lb2
            r8 = r3
            lu r8 = (defpackage.lu) r8
            er0 r8 = r8.s
            r9 = r1
        L8b:
            r10 = 1
            if (r8 == 0) goto Laf
            int r11 = r8.f
            r11 = r11 & 1024(0x400, float:1.435E-42)
            if (r11 == 0) goto Lac
            int r9 = r9 + 1
            if (r9 != r10) goto L9a
            r3 = r8
            goto Lac
        L9a:
            if (r7 != 0) goto La3
            it0 r7 = new it0
            er0[] r10 = new defpackage.er0[r5]
            r7.<init>(r10)
        La3:
            if (r3 == 0) goto La9
            r7.b(r3)
            r3 = r6
        La9:
            r7.b(r8)
        Lac:
            er0 r8 = r8.i
            goto L8b
        Laf:
            if (r9 != r10) goto Lb2
            goto L6b
        Lb2:
            er0 r3 = defpackage.tl.k(r7)
            goto L6b
        Lb7:
            er0 r3 = r3.i
            goto L61
        Lba:
            int r2 = r2 + 1
            goto L1f
        Lbe:
            return
        Lbf:
            defpackage.zi.f(r1)
            return
        Lc3:
            defpackage.zi.f(r1)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.i30.a(i30):void");
    }
}
