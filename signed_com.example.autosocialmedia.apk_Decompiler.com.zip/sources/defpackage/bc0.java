package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public abstract class bc0 {
    public static final fr0 a = ig1.f(cr0.a, ct.v);

    public static final void a(hc0 hc0Var, String str, fr0 fr0Var, long j, xo xoVar, int i, int i2) {
        int i3;
        fr0 fr0Var2;
        long j2;
        xoVar.X(-126890956);
        if ((i & 6) == 0) {
            i3 = (xoVar.f(hc0Var) ? 4 : 2) | i;
        } else {
            i3 = i;
        }
        if ((i & 48) == 0) {
            i3 |= xoVar.f(str) ? 32 : 16;
        }
        int i4 = i2 & 4;
        if (i4 != 0) {
            i3 |= 384;
        } else if ((i & 384) == 0) {
            i3 |= xoVar.f(fr0Var) ? 256 : 128;
        }
        if ((i & 3072) == 0) {
            i3 |= ((i2 & 8) == 0 && xoVar.e(j)) ? 2048 : 1024;
        }
        if (xoVar.O(i3 & 1, (i3 & 1171) != 1170)) {
            xoVar.T();
            if ((i & 1) == 0 || xoVar.y()) {
                if (i4 != 0) {
                    fr0Var = cr0.a;
                }
                if ((i2 & 8) != 0) {
                    j = ((ql) xoVar.j(dq.a)).a;
                    i3 &= -7169;
                }
                fr0 fr0Var3 = fr0Var;
                long j3 = j;
                xoVar.q();
                b(cj1.l(hc0Var, xoVar), str, fr0Var3, j3, xoVar, (i3 & 112) | 8 | (i3 & 896) | (i3 & 7168));
                j2 = j3;
                fr0Var2 = fr0Var3;
            } else {
                xoVar.R();
                if ((i2 & 8) != 0) {
                    i3 &= -7169;
                }
                fr0 fr0Var32 = fr0Var;
                long j32 = j;
                xoVar.q();
                b(cj1.l(hc0Var, xoVar), str, fr0Var32, j32, xoVar, (i3 & 112) | 8 | (i3 & 896) | (i3 & 7168));
                j2 = j32;
                fr0Var2 = fr0Var32;
            }
        } else {
            xoVar.R();
            fr0Var2 = fr0Var;
            j2 = j;
        }
        l61 l61VarR = xoVar.r();
        if (l61VarR != null) {
            l61VarR.d = new zb0(hc0Var, str, fr0Var2, j2, i, i2, 0);
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:78:0x0117  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static final void b(defpackage.xz0 r16, java.lang.String r17, defpackage.fr0 r18, long r19, defpackage.xo r21, int r22) {
        /*
            Method dump skipped, instruction units count: 314
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.bc0.b(xz0, java.lang.String, fr0, long, xo, int):void");
    }
}
