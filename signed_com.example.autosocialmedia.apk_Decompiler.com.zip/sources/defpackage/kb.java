package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class kb extends ki0 implements h50 {
    public final /* synthetic */ int e;
    public final /* synthetic */ lb f;
    public final /* synthetic */ long g;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ kb(lb lbVar, long j, int i) {
        super(1);
        this.e = i;
        this.f = lbVar;
        this.g = j;
    }

    @Override // defpackage.h50
    public final Object g(Object obj) {
        j10 j10Var;
        int i = this.e;
        long j = this.g;
        lb lbVar = this.f;
        switch (i) {
            case 0:
                bu1 bu1Var = (bu1) obj;
                if (!ng0.o(bu1Var.b(), lbVar.t.b())) {
                    kj1 kj1Var = (kj1) lbVar.t.c.g(bu1Var.b());
                    j = kj1Var != null ? ((yf0) kj1Var.getValue()).a : 0L;
                } else if (!yf0.a(lbVar.u, -9223372034707292160L)) {
                    j = lbVar.u;
                }
                kj1 kj1Var2 = (kj1) lbVar.t.c.g(bu1Var.c());
                j = kj1Var2 != null ? ((yf0) kj1Var2.getValue()).a : 0L;
                kg1 kg1Var = (kg1) lbVar.s.getValue();
                return (kg1Var == null || (j10Var = (j10) kg1Var.a.f(new yf0(j), new yf0(j))) == null) ? y5.F(0.0f, 400.0f, null, 5) : j10Var;
            default:
                if (ng0.o(obj, lbVar.t.b())) {
                    j = yf0.a(lbVar.u, -9223372034707292160L) ? j : lbVar.u;
                } else {
                    kj1 kj1Var3 = (kj1) lbVar.t.c.g(obj);
                    if (kj1Var3 != null) {
                        j = ((yf0) kj1Var3.getValue()).a;
                    }
                }
                return new yf0(j);
        }
    }
}
