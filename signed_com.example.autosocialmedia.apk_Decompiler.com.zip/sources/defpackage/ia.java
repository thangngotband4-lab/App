package defpackage;

import android.graphics.Canvas;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class ia extends ki0 implements h50 {
    public final /* synthetic */ int e;
    public final /* synthetic */ Object f;
    public final /* synthetic */ Object g;
    public final /* synthetic */ Object h;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public ia(ty1 ty1Var, ij0 ij0Var, ty1 ty1Var2) {
        super(1);
        this.e = 0;
        this.f = ty1Var;
        this.h = ij0Var;
        this.g = ty1Var2;
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // defpackage.h50
    public final Object g(Object obj) {
        int i = this.e;
        bw1 bw1Var = bw1.a;
        boolean zBooleanValue = false;
        Object[] objArr = 0;
        wt1Var = null;
        wt1 wt1Var = null;
        Object obj2 = this.g;
        Object obj3 = this.h;
        Object obj4 = this.f;
        switch (i) {
            case 0:
                ty1 ty1Var = (ty1) obj4;
                ij0 ij0Var = (ij0) obj3;
                ty1 ty1Var2 = (ty1) obj2;
                dj djVarF = ((ay) obj).C().f();
                if (ty1Var.getView().getVisibility() != 8) {
                    ty1Var.B = true;
                    nz0 nz0Var = ij0Var.r;
                    k5 k5Var = nz0Var instanceof k5 ? (k5) nz0Var : null;
                    if (k5Var != null) {
                        Canvas canvasA = q4.a(djVarF);
                        k5Var.getAndroidViewsHandler$ui().getClass();
                        ty1Var2.draw(canvasA);
                    }
                    ty1Var.B = false;
                }
                return bw1Var;
            case 1:
                return new ab((ji1) obj4, obj2, (mb) obj3, objArr == true ? 1 : 0);
            case 2:
                mu1 mu1Var = (mu1) obj;
                ow owVar = (ow) mu1Var;
                if (!((b7) ((k5) tl.N((ow) obj2)).m8getDragAndDropManager()).b.contains(owVar) || !bm.c(owVar, om.B((l1) obj3))) {
                    return lu1.d;
                }
                ((e71) obj4).d = mu1Var;
                return lu1.f;
            case 3:
                i81 i81Var = (i81) obj;
                kj1 kj1Var = (kj1) obj2;
                kj1 kj1Var2 = (kj1) obj4;
                i81Var.d(kj1Var2 != null ? ((Number) kj1Var2.getValue()).floatValue() : 1.0f);
                i81Var.h(kj1Var != null ? ((Number) kj1Var.getValue()).floatValue() : 1.0f);
                i81Var.i(kj1Var != null ? ((Number) kj1Var.getValue()).floatValue() : 1.0f);
                kj1 kj1Var3 = (kj1) obj3;
                i81Var.n(kj1Var3 != null ? ((wt1) kj1Var3.getValue()).a : wt1.b);
                return bw1Var;
            case 4:
                w00 w00Var = (w00) obj3;
                int iOrdinal = ((zz) obj).ordinal();
                if (iOrdinal == 0) {
                    gu1 gu1Var = w00Var.a;
                } else if (iOrdinal == 1) {
                    wt1Var = (wt1) obj4;
                } else {
                    if (iOrdinal != 2) {
                        tz.c();
                        return null;
                    }
                    gu1 gu1Var2 = w00Var.a;
                }
                return new wt1(wt1Var != null ? wt1Var.a : wt1.b);
            default:
                r30 r30Var = (r30) obj;
                if (!ng0.o(r30Var, (r30) obj4)) {
                    if (ng0.o(r30Var, ((d30) obj2).c)) {
                        zi.f("Focus search landed at the root.");
                        return null;
                    }
                    zBooleanValue = ((Boolean) ((h50) obj3).g(r30Var)).booleanValue();
                }
                return Boolean.valueOf(zBooleanValue);
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ ia(Object obj, Object obj2, Object obj3, int i) {
        super(1);
        this.e = i;
        this.f = obj;
        this.g = obj2;
        this.h = obj3;
    }
}
