package defpackage;

import android.os.Build;
import android.view.View;
import android.view.WindowInsets;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class iy1 implements View.OnApplyWindowInsetsListener {
    public m02 a = null;
    public final /* synthetic */ View b;
    public final /* synthetic */ pw0 c;

    public iy1(View view, pw0 pw0Var) {
        this.b = view;
        this.c = pw0Var;
    }

    @Override // android.view.View.OnApplyWindowInsetsListener
    public WindowInsets onApplyWindowInsets(View view, WindowInsets windowInsets) {
        m02 m02VarC = m02.c(windowInsets, view);
        int i = Build.VERSION.SDK_INT;
        pw0 pw0Var = this.c;
        if (i < 30) {
            jy1.a(windowInsets, this.b);
            if (m02VarC.equals(this.a)) {
                return pw0Var.b(view, m02VarC).b();
            }
        }
        this.a = m02VarC;
        m02 m02VarB = pw0Var.b(view, m02VarC);
        if (i >= 30) {
            return m02VarB.b();
        }
        int i2 = oy1.a;
        hy1.a(view);
        return m02VarB.b();
    }
}
