package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class j70 {
    public final long a;
    public final int b;
    public final int c;

    public j70(int i, int i2, long j) {
        this.a = j;
        this.b = i;
        this.c = i2;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof j70)) {
            return false;
        }
        j70 j70Var = (j70) obj;
        return this.a == j70Var.a && this.b == j70Var.b && this.c == j70Var.c;
    }

    public final int hashCode() {
        return Integer.hashCode(this.c) + f0.b(this.b, Long.hashCode(this.a) * 31, 31);
    }

    public final String toString() {
        return "Stats(totalEarned=" + this.a + ", totalJobsDone=" + this.b + ", failStreak=" + this.c + ")";
    }
}
