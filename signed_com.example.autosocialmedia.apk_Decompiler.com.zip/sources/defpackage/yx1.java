package defpackage;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class yx1 {
    public static final yx1 d;
    public static final yx1 e;
    public static final /* synthetic */ yx1[] f;

    static {
        yx1 yx1Var = new yx1("Lsq2", 0);
        d = yx1Var;
        yx1 yx1Var2 = new yx1("Impulse", 1);
        e = yx1Var2;
        f = new yx1[]{yx1Var, yx1Var2};
    }

    public static yx1 valueOf(String str) {
        return (yx1) Enum.valueOf(yx1.class, str);
    }

    public static yx1[] values() {
        return (yx1[]) f.clone();
    }
}
