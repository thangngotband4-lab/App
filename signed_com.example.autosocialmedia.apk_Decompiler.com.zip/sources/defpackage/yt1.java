package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class yt1 implements w40 {
    public final /* synthetic */ int d;
    public final /* synthetic */ fu1 e;

    public /* synthetic */ yt1(fu1 fu1Var, int i) {
        this.d = i;
        this.e = fu1Var;
    }

    @Override // defpackage.w40
    public final Object a() {
        int i = this.d;
        fu1 fu1Var = this.e;
        switch (i) {
            case 0:
                return Boolean.valueOf((ng0.o(fu1Var.d.getValue(), fu1Var.c()) && fu1Var.g.g() == Long.MIN_VALUE && !((Boolean) fu1Var.h.getValue()).booleanValue()) ? false : true);
            default:
                return Long.valueOf(fu1Var.b());
        }
    }
}
