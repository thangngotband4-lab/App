package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class wf1 implements xv {
    public final yf1 d;
    public final long e;
    public final Object f;
    public final xi g;

    public wf1(yf1 yf1Var, long j, Object obj, xi xiVar) {
        this.d = yf1Var;
        this.e = j;
        this.f = obj;
        this.g = xiVar;
    }

    @Override // defpackage.xv
    public final void a() {
        yf1 yf1Var = this.d;
        synchronized (yf1Var) {
            if (this.e < yf1Var.o()) {
                return;
            }
            Object[] objArr = yf1Var.k;
            objArr.getClass();
            long j = this.e;
            if (objArr[((int) j) & (objArr.length - 1)] != this) {
                return;
            }
            zu1.d(objArr, j, zu1.i0);
            yf1Var.i();
        }
    }
}
