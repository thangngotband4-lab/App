package defpackage;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class kt0 {
    public static final kt0 d;
    public static final kt0 e;
    public static final /* synthetic */ kt0[] f;

    static {
        kt0 kt0Var = new kt0("Default", 0);
        d = kt0Var;
        kt0 kt0Var2 = new kt0("UserInput", 1);
        e = kt0Var2;
        f = new kt0[]{kt0Var, kt0Var2, new kt0("PreventUserInput", 2)};
    }

    public static kt0 valueOf(String str) {
        return (kt0) Enum.valueOf(kt0.class, str);
    }

    public static kt0[] values() {
        return (kt0[]) f.clone();
    }
}
