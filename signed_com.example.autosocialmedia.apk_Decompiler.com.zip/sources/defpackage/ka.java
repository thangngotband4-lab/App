package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class ka extends jl1 implements l50 {
    public final /* synthetic */ int e;
    public int f;
    public final /* synthetic */ long g;
    public final /* synthetic */ Object h;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public ka(long j, ol1 ol1Var, tq tqVar) {
        super(2, tqVar);
        this.e = 2;
        this.g = j;
        this.h = ol1Var;
    }

    @Override // defpackage.l50
    public final Object f(Object obj, Object obj2) {
        int i = this.e;
        bw1 bw1Var = bw1.a;
        ds dsVar = (ds) obj;
        tq tqVar = (tq) obj2;
        switch (i) {
        }
        return ((ka) o(tqVar, dsVar)).r(bw1Var);
    }

    @Override // defpackage.kf
    public final tq o(tq tqVar, Object obj) {
        int i = this.e;
        Object obj2 = this.h;
        switch (i) {
            case 0:
                return new ka((ma) obj2, this.g, tqVar, 0);
            case 1:
                return new ka((va) obj2, this.g, tqVar, 1);
            default:
                return new ka(this.g, (ol1) obj2, tqVar);
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:15:0x003d, code lost:
    
        if (defpackage.jl.l(8, r13) == r7) goto L16;
     */
    @Override // defpackage.kf
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final java.lang.Object r(java.lang.Object r14) {
        /*
            r13 = this;
            int r0 = r13.e
            bw1 r6 = defpackage.bw1.a
            java.lang.Object r1 = r13.h
            r2 = 0
            java.lang.String r3 = "call to 'resume' before 'invoke' with coroutine"
            es r7 = defpackage.es.d
            r5 = 1
            long r8 = r13.g
            switch(r0) {
                case 0: goto L7f;
                case 1: goto L55;
                default: goto L11;
            }
        L11:
            int r0 = r13.f
            r10 = 8
            r12 = 2
            if (r0 == 0) goto L29
            if (r0 == r5) goto L25
            if (r0 != r12) goto L20
            defpackage.vl.Q(r14)
            goto L41
        L20:
            defpackage.zi.f(r3)
            r6 = r2
            goto L54
        L25:
            defpackage.vl.Q(r14)
            goto L37
        L29:
            defpackage.vl.Q(r14)
            long r2 = r8 - r10
            r13.f = r5
            java.lang.Object r0 = defpackage.jl.l(r2, r13)
            if (r0 != r7) goto L37
            goto L3f
        L37:
            r13.f = r12
            java.lang.Object r0 = defpackage.jl.l(r10, r13)
            if (r0 != r7) goto L41
        L3f:
            r6 = r7
            goto L54
        L41:
            ol1 r1 = (defpackage.ol1) r1
            xi r0 = r1.f
            if (r0 == 0) goto L54
            o31 r1 = new o31
            r1.<init>(r8)
            d81 r2 = new d81
            r2.<init>(r1)
            r0.h(r2)
        L54:
            return r6
        L55:
            int r0 = r13.f
            if (r0 == 0) goto L64
            if (r0 != r5) goto L5f
            defpackage.vl.Q(r14)
            goto L7e
        L5f:
            defpackage.zi.f(r3)
            r6 = r2
            goto L7e
        L64:
            defpackage.vl.Q(r14)
            r0 = r1
            va r0 = (defpackage.va) r0
            jw0 r1 = new jw0
            r1.<init>(r8)
            yi1 r2 = defpackage.id1.d
            r13.f = r5
            r3 = 0
            r5 = 12
            r4 = r13
            java.lang.Object r0 = defpackage.va.c(r0, r1, r2, r3, r4, r5)
            if (r0 != r7) goto L7e
            r6 = r7
        L7e:
            return r6
        L7f:
            int r0 = r13.f
            if (r0 == 0) goto L8e
            if (r0 != r5) goto L89
            defpackage.vl.Q(r14)
            goto L9e
        L89:
            defpackage.zi.f(r3)
            r6 = r2
            goto L9e
        L8e:
            defpackage.vl.Q(r14)
            ma r1 = (defpackage.ma) r1
            du0 r0 = r1.d
            r13.f = r5
            java.lang.Object r0 = r0.b(r8, r13)
            if (r0 != r7) goto L9e
            r6 = r7
        L9e:
            return r6
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.ka.r(java.lang.Object):java.lang.Object");
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ ka(Object obj, long j, tq tqVar, int i) {
        super(2, tqVar);
        this.e = i;
        this.h = obj;
        this.g = j;
    }
}
