package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class v60 extends uq {
    public /* synthetic */ Object d;
    public final /* synthetic */ lz e;
    public int f;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public v60(lz lzVar, uq uqVar) {
        super(uqVar);
        this.e = lzVar;
    }

    @Override // defpackage.kf
    public final Object r(Object obj) {
        this.d = obj;
        this.f |= Integer.MIN_VALUE;
        return this.e.f(this);
    }
}
