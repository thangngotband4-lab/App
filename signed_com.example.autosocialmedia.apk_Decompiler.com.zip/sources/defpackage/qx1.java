package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public abstract class qx1 {
    public static final int[] a = new int[0];
    public static final float[] b = new float[0];
    public static final l1 c = new l1(new int[2], new float[2], new float[][]{new float[2], new float[2]});
}
