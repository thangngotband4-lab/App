package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class ue0 implements l50 {
    public final /* synthetic */ int d;
    public final /* synthetic */ w40 e;
    public final /* synthetic */ h50 f;

    public /* synthetic */ ue0(w40 w40Var, h50 h50Var, int i, int i2) {
        this.d = i2;
        this.e = w40Var;
        this.f = h50Var;
    }

    @Override // defpackage.l50
    public final Object f(Object obj, Object obj2) {
        int i = this.d;
        bw1 bw1Var = bw1.a;
        h50 h50Var = this.f;
        w40 w40Var = this.e;
        xo xoVar = (xo) obj;
        ((Integer) obj2).getClass();
        switch (i) {
            case 0:
                ct.t(w40Var, h50Var, xoVar, bm.T(7));
                break;
            case 1:
                ng0.j(w40Var, h50Var, xoVar, bm.T(7));
                break;
            case 2:
                vh0.o(w40Var, h50Var, xoVar, bm.T(7));
                break;
            default:
                j22.e(w40Var, h50Var, xoVar, bm.T(7));
                break;
        }
        return bw1Var;
    }
}
