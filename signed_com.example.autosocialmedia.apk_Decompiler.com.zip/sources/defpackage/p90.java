package defpackage;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import org.json.JSONException;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class p90 extends jl1 implements l50 {
    public final /* synthetic */ gt0 A;
    public final /* synthetic */ gt0 B;
    public final /* synthetic */ gt0 C;
    public final /* synthetic */ gt0 D;
    public final /* synthetic */ gt0 E;
    public final /* synthetic */ gt0 F;
    public final /* synthetic */ gt0 G;
    public final /* synthetic */ gt0 H;
    public final /* synthetic */ gt0 I;
    public int e;
    public final /* synthetic */ g80 f;
    public final /* synthetic */ gt0 g;
    public final /* synthetic */ gt0 h;
    public final /* synthetic */ kj1 i;
    public final /* synthetic */ gt0 j;
    public final /* synthetic */ gt0 k;
    public final /* synthetic */ gt0 l;
    public final /* synthetic */ gt0 m;
    public final /* synthetic */ gt0 n;
    public final /* synthetic */ gt0 o;
    public final /* synthetic */ gt0 p;
    public final /* synthetic */ gt0 q;
    public final /* synthetic */ gt0 r;
    public final /* synthetic */ gt0 s;
    public final /* synthetic */ gt0 t;
    public final /* synthetic */ gt0 u;
    public final /* synthetic */ gt0 v;
    public final /* synthetic */ gt0 w;
    public final /* synthetic */ gt0 x;
    public final /* synthetic */ gt0 y;
    public final /* synthetic */ gt0 z;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public p90(g80 g80Var, gt0 gt0Var, gt0 gt0Var2, kj1 kj1Var, gt0 gt0Var3, gt0 gt0Var4, gt0 gt0Var5, gt0 gt0Var6, gt0 gt0Var7, gt0 gt0Var8, gt0 gt0Var9, gt0 gt0Var10, gt0 gt0Var11, gt0 gt0Var12, gt0 gt0Var13, gt0 gt0Var14, gt0 gt0Var15, gt0 gt0Var16, gt0 gt0Var17, gt0 gt0Var18, gt0 gt0Var19, gt0 gt0Var20, gt0 gt0Var21, gt0 gt0Var22, gt0 gt0Var23, gt0 gt0Var24, gt0 gt0Var25, gt0 gt0Var26, gt0 gt0Var27, gt0 gt0Var28, tq tqVar) {
        super(2, tqVar);
        this.f = g80Var;
        this.g = gt0Var;
        this.h = gt0Var2;
        this.i = kj1Var;
        this.j = gt0Var3;
        this.k = gt0Var4;
        this.l = gt0Var5;
        this.m = gt0Var6;
        this.n = gt0Var7;
        this.o = gt0Var8;
        this.p = gt0Var9;
        this.q = gt0Var10;
        this.r = gt0Var11;
        this.s = gt0Var12;
        this.t = gt0Var13;
        this.u = gt0Var14;
        this.v = gt0Var15;
        this.w = gt0Var16;
        this.x = gt0Var17;
        this.y = gt0Var18;
        this.z = gt0Var19;
        this.A = gt0Var20;
        this.B = gt0Var21;
        this.C = gt0Var22;
        this.D = gt0Var23;
        this.E = gt0Var24;
        this.F = gt0Var25;
        this.G = gt0Var26;
        this.H = gt0Var27;
        this.I = gt0Var28;
    }

    @Override // defpackage.l50
    public final Object f(Object obj, Object obj2) {
        return ((p90) o((tq) obj2, (ds) obj)).r(bw1.a);
    }

    @Override // defpackage.kf
    public final tq o(tq tqVar, Object obj) {
        return new p90(this.f, this.g, this.h, this.i, this.j, this.k, this.l, this.m, this.n, this.o, this.p, this.q, this.r, this.s, this.t, this.u, this.v, this.w, this.x, this.y, this.z, this.A, this.B, this.C, this.D, this.E, this.F, this.G, this.H, this.I, tqVar);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r1v10 */
    /* JADX WARN: Type inference failed for: r1v88, types: [java.util.ArrayList] */
    /* JADX WARN: Type inference failed for: r1v9, types: [java.util.List] */
    /* JADX WARN: Type inference failed for: r5v12, types: [java.util.ArrayList] */
    /* JADX WARN: Type inference failed for: r5v13, types: [java.util.ArrayList] */
    /* JADX WARN: Type inference failed for: r5v2, types: [java.util.List] */
    /* JADX WARN: Type inference failed for: r5v3 */
    /* JADX WARN: Type inference failed for: r5v6, types: [java.util.List] */
    /* JADX WARN: Type inference failed for: r5v7 */
    /* JADX WARN: Type inference failed for: r7v0, types: [java.util.List] */
    /* JADX WARN: Type inference failed for: r8v0, types: [java.util.List] */
    /* JADX WARN: Type inference failed for: r9v0, types: [java.util.List] */
    @Override // defpackage.kf
    public final Object r(Object obj) throws JSONException {
        ?? Y;
        ?? Z;
        ?? A;
        int i = this.e;
        if (i == 0) {
            vl.Q(obj);
            this.e = 1;
            Object objL = jl.l(400L, this);
            es esVar = es.d;
            if (objL == esVar) {
                return esVar;
            }
        } else {
            if (i != 1) {
                zi.f("call to 'resume' before 'invoke' with coroutine");
                return null;
            }
            vl.Q(obj);
        }
        gt0 gt0Var = this.g;
        List list = (List) gt0Var.getValue();
        ArrayList arrayList = new ArrayList();
        for (Object obj2 : list) {
            if (((Set) this.h.getValue()).contains(new Long(((o60) obj2).a))) {
                arrayList.add(obj2);
            }
        }
        boolean zIsEmpty = ((List) gt0Var.getValue()).isEmpty();
        kj1 kj1Var = this.i;
        int i2 = 0;
        if (zIsEmpty) {
            Y = ((e80) kj1Var.getValue()).y();
        } else {
            Y = new ArrayList(ll.R(arrayList));
            int size = arrayList.size();
            int i3 = 0;
            while (i3 < size) {
                Object obj3 = arrayList.get(i3);
                i3++;
                Y.add(new Long(((o60) obj3).a));
            }
        }
        ?? r7 = Y;
        if (zIsEmpty) {
            Z = ((e80) kj1Var.getValue()).z();
        } else {
            Z = new ArrayList(ll.R(arrayList));
            int size2 = arrayList.size();
            int i4 = 0;
            while (i4 < size2) {
                Object obj4 = arrayList.get(i4);
                i4++;
                o60 o60Var = (o60) obj4;
                String str = o60Var.b;
                if (bk1.s(str)) {
                    str = o60Var.c;
                }
                Z.add(str);
            }
        }
        ?? r8 = Z;
        if (zIsEmpty) {
            A = ((e80) kj1Var.getValue()).A();
        } else {
            A = new ArrayList(ll.R(arrayList));
            int size3 = arrayList.size();
            while (i2 < size3) {
                Object obj5 = arrayList.get(i2);
                i2++;
                A.add(bk1.v(((o60) obj5).c));
            }
        }
        this.f.d(new e80(r7, r8, A, ((Number) this.j.getValue()).intValue(), ((Number) this.k.getValue()).intValue(), ((Number) this.l.getValue()).intValue(), ((Boolean) this.m.getValue()).booleanValue(), ((Number) this.n.getValue()).intValue(), ((Number) this.o.getValue()).intValue(), ((Boolean) this.p.getValue()).booleanValue(), ((Number) this.q.getValue()).intValue(), ((Number) this.r.getValue()).intValue(), ((Boolean) this.s.getValue()).booleanValue(), ((Boolean) this.t.getValue()).booleanValue(), ((Boolean) this.u.getValue()).booleanValue(), ((Boolean) this.v.getValue()).booleanValue(), ((Number) this.w.getValue()).intValue(), ((Number) this.x.getValue()).intValue(), ((Number) this.y.getValue()).intValue(), ((Number) this.z.getValue()).intValue(), ((Number) this.A.getValue()).intValue(), ((Number) this.B.getValue()).intValue(), ((Boolean) this.C.getValue()).booleanValue(), ((Boolean) this.D.getValue()).booleanValue(), ((Number) this.E.getValue()).intValue(), ((Number) this.F.getValue()).intValue(), ((Number) this.G.getValue()).intValue(), ((Boolean) this.H.getValue()).booleanValue(), (ht1) this.I.getValue()));
        return bw1.a;
    }
}
