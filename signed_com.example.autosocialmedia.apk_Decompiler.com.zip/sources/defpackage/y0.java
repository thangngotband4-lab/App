package defpackage;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.graphics.Rect;
import android.util.Log;
import android.view.accessibility.AccessibilityNodeInfo;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class y0 {
    public static final y0 a = new y0();
    public static final List b = kl.N("được tài trợ", "sponsored");

    public static Object a(AccessibilityService accessibilityService, AccessibilityNodeInfo accessibilityNodeInfo, uq uqVar) {
        AccessibilityNodeInfo parent = accessibilityNodeInfo;
        while (true) {
            if (parent == null) {
                break;
            }
            if (!parent.isClickable()) {
                parent = parent.getParent();
            } else if (parent.performAction(16)) {
                Log.d("AutoAccessibility", "click via ACTION_CLICK on node desc='" + ((Object) parent.getContentDescription()) + "'");
                return Boolean.TRUE;
            }
        }
        Rect rect = new Rect();
        accessibilityNodeInfo.getBoundsInScreen(rect);
        if (!rect.isEmpty()) {
            return i(accessibilityService, rect.exactCenterX(), rect.exactCenterY(), 80L, uqVar);
        }
        Log.w("AutoAccessibility", "click failed - empty bounds");
        return Boolean.FALSE;
    }

    public static String b(AccessibilityService accessibilityService) {
        accessibilityService.getClass();
        AccessibilityNodeInfo rootInActiveWindow = accessibilityService.getRootInActiveWindow();
        if (rootInActiveWindow == null) {
            return null;
        }
        StringBuilder sb = new StringBuilder(512);
        c(new c71(), sb, rootInActiveWindow);
        if (sb.length() == 0) {
            return null;
        }
        return String.valueOf(sb.toString().hashCode());
    }

    public static final void c(c71 c71Var, StringBuilder sb, AccessibilityNodeInfo accessibilityNodeInfo) {
        if (c71Var.d >= 80) {
            return;
        }
        CharSequence text = accessibilityNodeInfo.getText();
        String string = text != null ? text.toString() : null;
        if (string == null) {
            string = "";
        }
        CharSequence contentDescription = accessibilityNodeInfo.getContentDescription();
        String string2 = contentDescription != null ? contentDescription.toString() : null;
        String str = string2 != null ? string2 : "";
        if (!bk1.s(string) || !bk1.s(str)) {
            sb.append(string);
            sb.append('|');
            sb.append(str);
            sb.append('\n');
            c71Var.d++;
        }
        int childCount = accessibilityNodeInfo.getChildCount();
        for (int i = 0; i < childCount && c71Var.d < 80; i++) {
            AccessibilityNodeInfo child = accessibilityNodeInfo.getChild(i);
            if (child != null) {
                c(c71Var, sb, child);
            }
        }
    }

    public static Object d(AccessibilityService accessibilityService, GestureDescription gestureDescription, uq uqVar) {
        xi xiVar = new xi(1, rm.H(uqVar));
        xiVar.v();
        if (!accessibilityService.dispatchGesture(gestureDescription, new s0(xiVar), null) && (xiVar.u() instanceof yu0)) {
            xiVar.h(Boolean.FALSE);
        }
        return xiVar.t();
    }

    public static ArrayList e(AccessibilityNodeInfo accessibilityNodeInfo, h50 h50Var) {
        h50Var.getClass();
        ArrayList arrayList = new ArrayList();
        l(accessibilityNodeInfo, new c(h50Var, 1, arrayList));
        return arrayList;
    }

    public static final void f(a71 a71Var, c71 c71Var, AccessibilityNodeInfo accessibilityNodeInfo) {
        int i;
        String lowerCase;
        String str;
        String string;
        String string2;
        if (a71Var.d || (i = c71Var.d) >= 120) {
            return;
        }
        c71Var.d = i + 1;
        CharSequence text = accessibilityNodeInfo.getText();
        String lowerCase2 = null;
        if (text == null || (string2 = text.toString()) == null) {
            lowerCase = null;
        } else {
            lowerCase = string2.toLowerCase(Locale.ROOT);
            lowerCase.getClass();
        }
        if (lowerCase == null) {
            lowerCase = "";
        }
        CharSequence contentDescription = accessibilityNodeInfo.getContentDescription();
        if (contentDescription != null && (string = contentDescription.toString()) != null) {
            lowerCase2 = string.toLowerCase(Locale.ROOT);
            lowerCase2.getClass();
        }
        String str2 = lowerCase2 != null ? lowerCase2 : "";
        Iterator it = b.iterator();
        do {
            if (!it.hasNext()) {
                int childCount = accessibilityNodeInfo.getChildCount();
                for (int i2 = 0; i2 < childCount && !a71Var.d; i2++) {
                    AccessibilityNodeInfo child = accessibilityNodeInfo.getChild(i2);
                    if (child != null) {
                        f(a71Var, c71Var, child);
                    }
                }
                return;
            }
            str = (String) it.next();
            if (bk1.n(lowerCase, str, false)) {
                break;
            }
        } while (!bk1.n(str2, str, false));
        a71Var.d = true;
    }

    public static Object g(AccessibilityService accessibilityService, float f, float f2, float f3, float f4, long j, uq uqVar) {
        Path path = new Path();
        path.moveTo(f, f2);
        path.lineTo(f3, f4);
        GestureDescription gestureDescriptionBuild = new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(path, 0L, j)).build();
        gestureDescriptionBuild.getClass();
        return d(accessibilityService, gestureDescriptionBuild, uqVar);
    }

    public static Object i(AccessibilityService accessibilityService, float f, float f2, long j, uq uqVar) {
        Path path = new Path();
        path.moveTo(f, f2);
        GestureDescription gestureDescriptionBuild = new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(path, 0L, j)).build();
        gestureDescriptionBuild.getClass();
        return d(accessibilityService, gestureDescriptionBuild, uqVar);
    }

    public static void l(AccessibilityNodeInfo accessibilityNodeInfo, c cVar) {
        cVar.g(accessibilityNodeInfo);
        int childCount = accessibilityNodeInfo.getChildCount();
        for (int i = 0; i < childCount; i++) {
            AccessibilityNodeInfo child = accessibilityNodeInfo.getChild(i);
            if (child != null) {
                l(child, cVar);
            }
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:39:0x011a  */
    /* JADX WARN: Removed duplicated region for block: B:48:0x017c  */
    /* JADX WARN: Removed duplicated region for block: B:50:0x0181  */
    /* JADX WARN: Removed duplicated region for block: B:56:0x01b0  */
    /* JADX WARN: Removed duplicated region for block: B:69:0x01db  */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0015  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:56:0x01b0 -> B:57:0x01b6). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final java.lang.Object h(android.accessibilityservice.AccessibilityService r29, boolean r30, defpackage.uq r31) {
        /*
            Method dump skipped, instruction units count: 478
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.y0.h(android.accessibilityservice.AccessibilityService, boolean, uq):java.lang.Object");
    }

    /* JADX WARN: Code restructure failed: missing block: B:29:0x0081, code lost:
    
        if (defpackage.jl.l(200, r0) == r3) goto L30;
     */
    /* JADX WARN: Removed duplicated region for block: B:20:0x0055  */
    /* JADX WARN: Removed duplicated region for block: B:26:0x0070  */
    /* JADX WARN: Removed duplicated region for block: B:28:0x0073  */
    /* JADX WARN: Removed duplicated region for block: B:31:0x0084  */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0013  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:29:0x0081 -> B:13:0x002f). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final java.lang.Object j(long r11, defpackage.h50 r13, defpackage.uq r14) {
        /*
            r10 = this;
            boolean r0 = r14 instanceof defpackage.u0
            if (r0 == 0) goto L13
            r0 = r14
            u0 r0 = (defpackage.u0) r0
            int r1 = r0.i
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L13
            int r1 = r1 - r2
            r0.i = r1
            goto L18
        L13:
            u0 r0 = new u0
            r0.<init>(r10, r14)
        L18:
            java.lang.Object r10 = r0.g
            int r14 = r0.i
            r1 = 2
            r2 = 1
            es r3 = defpackage.es.d
            if (r14 == 0) goto L45
            if (r14 == r2) goto L3b
            if (r14 != r1) goto L34
            long r11 = r0.e
            long r13 = r0.d
            h50 r4 = r0.f
            defpackage.vl.Q(r10)
        L2f:
            r8 = r13
            r13 = r4
            r4 = r11
            r11 = r8
            goto L4d
        L34:
            java.lang.String r10 = "call to 'resume' before 'invoke' with coroutine"
            defpackage.zi.f(r10)
            r10 = 0
            return r10
        L3b:
            long r11 = r0.e
            long r13 = r0.d
            h50 r4 = r0.f
            defpackage.vl.Q(r10)
            goto L68
        L45:
            defpackage.vl.Q(r10)
            long r4 = android.os.SystemClock.elapsedRealtime()
            long r4 = r4 + r11
        L4d:
            long r6 = android.os.SystemClock.elapsedRealtime()
            int r10 = (r6 > r4 ? 1 : (r6 == r4 ? 0 : -1))
            if (r10 >= 0) goto L84
            r0.f = r13
            r0.d = r11
            r0.e = r4
            r0.i = r2
            java.lang.Object r10 = r13.g(r0)
            if (r10 != r3) goto L64
            goto L83
        L64:
            r8 = r4
            r4 = r13
            r13 = r11
            r11 = r8
        L68:
            java.lang.Boolean r10 = (java.lang.Boolean) r10
            boolean r10 = r10.booleanValue()
            if (r10 == 0) goto L73
            java.lang.Boolean r10 = java.lang.Boolean.TRUE
            return r10
        L73:
            r0.f = r4
            r0.d = r13
            r0.e = r11
            r0.i = r1
            r5 = 200(0xc8, double:9.9E-322)
            java.lang.Object r10 = defpackage.jl.l(r5, r0)
            if (r10 != r3) goto L2f
        L83:
            return r3
        L84:
            java.lang.Boolean r10 = java.lang.Boolean.FALSE
            return r10
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.y0.j(long, h50, uq):java.lang.Object");
    }

    /* JADX WARN: Removed duplicated region for block: B:7:0x0013  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final java.lang.Object k(android.accessibilityservice.AccessibilityService r5, long r6, defpackage.h50 r8, defpackage.uq r9) {
        /*
            r4 = this;
            boolean r0 = r9 instanceof defpackage.v0
            if (r0 == 0) goto L13
            r0 = r9
            v0 r0 = (defpackage.v0) r0
            int r1 = r0.g
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L13
            int r1 = r1 - r2
            r0.g = r1
            goto L18
        L13:
            v0 r0 = new v0
            r0.<init>(r4, r9)
        L18:
            java.lang.Object r9 = r0.e
            int r1 = r0.g
            r2 = 1
            r3 = 0
            if (r1 == 0) goto L2e
            if (r1 != r2) goto L28
            e71 r4 = r0.d
            defpackage.vl.Q(r9)
            goto L49
        L28:
            java.lang.String r4 = "call to 'resume' before 'invoke' with coroutine"
            defpackage.zi.f(r4)
            return r3
        L2e:
            defpackage.vl.Q(r9)
            e71 r9 = new e71
            r9.<init>()
            w0 r1 = new w0
            r1.<init>(r5, r9, r8, r3)
            r0.d = r9
            r0.g = r2
            java.lang.Object r4 = r4.j(r6, r1, r0)
            es r5 = defpackage.es.d
            if (r4 != r5) goto L48
            return r5
        L48:
            r4 = r9
        L49:
            java.lang.Object r4 = r4.d
            return r4
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.y0.k(android.accessibilityservice.AccessibilityService, long, h50, uq):java.lang.Object");
    }
}
