package defpackage;

import java.util.Iterator;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class md implements Iterator, lh0 {
    public int d;
    public int e;
    public boolean f;
    public final /* synthetic */ int g;
    public final /* synthetic */ Object h;

    /* JADX WARN: 'this' call moved to the top of the method (can break code semantics) */
    public md(qd qdVar, int i) {
        this(qdVar.f);
        this.g = i;
        switch (i) {
            case 1:
                this.h = qdVar;
                this(qdVar.f);
                break;
            default:
                this.h = qdVar;
                break;
        }
    }

    @Override // java.util.Iterator
    public final boolean hasNext() {
        return this.e < this.d;
    }

    @Override // java.util.Iterator
    public final Object next() {
        Object objE;
        if (!hasNext()) {
            tz.j();
            return null;
        }
        int i = this.e;
        int i2 = this.g;
        Object obj = this.h;
        switch (i2) {
            case 0:
                objE = ((qd) obj).e(i);
                break;
            case 1:
                objE = ((qd) obj).h(i);
                break;
            default:
                objE = ((rd) obj).e[i];
                break;
        }
        this.e++;
        this.f = true;
        return objE;
    }

    @Override // java.util.Iterator
    public final void remove() {
        if (!this.f) {
            zi.f("Call next() before removing an element.");
            return;
        }
        int i = this.e - 1;
        this.e = i;
        int i2 = this.g;
        Object obj = this.h;
        switch (i2) {
            case 0:
                ((qd) obj).f(i);
                break;
            case 1:
                ((qd) obj).f(i);
                break;
            default:
                ((rd) obj).a(i);
                break;
        }
        this.d--;
        this.f = false;
    }

    /* JADX WARN: 'this' call moved to the top of the method (can break code semantics) */
    public md(rd rdVar) {
        this(rdVar.f);
        this.g = 2;
        this.h = rdVar;
    }

    public md(int i) {
        this.d = i;
    }
}
