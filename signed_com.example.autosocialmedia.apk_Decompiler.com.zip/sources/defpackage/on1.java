package defpackage;

import java.util.List;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class on1 {
    public final kc a;
    public final dq1 b;
    public final boolean e;
    public final wu g;
    public final z30 h;
    public ef j;
    public ri0 k;
    public final int c = Integer.MAX_VALUE;
    public final int d = 1;
    public final int f = 1;
    public final List i = uz.d;

    public on1(kc kcVar, dq1 dq1Var, boolean z, wu wuVar, z30 z30Var, int i) {
        this.a = kcVar;
        this.b = dq1Var;
        this.e = z;
        this.g = wuVar;
        this.h = z30Var;
    }

    public final void a(ri0 ri0Var) {
        ef efVar = this.j;
        if (efVar == null || ri0Var != this.k || efVar.b()) {
            this.k = ri0Var;
            efVar = new ef(this.a, yj1.i(this.b, ri0Var), this.i, this.g, this.h);
        }
        this.j = efVar;
    }
}
