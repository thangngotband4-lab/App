package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class ya extends ki0 implements l50 {
    public final /* synthetic */ Object e;
    public final /* synthetic */ fr0 f;
    public final /* synthetic */ h50 g;
    public final /* synthetic */ b4 h;
    public final /* synthetic */ String i;
    public final /* synthetic */ h50 j;
    public final /* synthetic */ qn k;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public ya(Object obj, fr0 fr0Var, h50 h50Var, b4 b4Var, String str, h50 h50Var2, qn qnVar, int i) {
        super(2);
        this.e = obj;
        this.f = fr0Var;
        this.g = h50Var;
        this.h = b4Var;
        this.i = str;
        this.j = h50Var2;
        this.k = qnVar;
    }

    @Override // defpackage.l50
    public final Object f(Object obj, Object obj2) {
        ((Number) obj2).intValue();
        int iT = bm.T(1597873);
        m22.d(this.e, this.f, this.g, this.h, this.i, this.j, this.k, (xo) obj, iT);
        return bw1.a;
    }
}
