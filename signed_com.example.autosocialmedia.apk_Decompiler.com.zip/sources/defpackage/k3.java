package defpackage;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class k3 extends jl1 implements l50 {
    public final /* synthetic */ int e;
    public int f;
    public final /* synthetic */ lz g;
    public final /* synthetic */ gt0 h;
    public final /* synthetic */ gt0 i;
    public final /* synthetic */ gt0 j;
    public final /* synthetic */ gt0 k;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ k3(lz lzVar, gt0 gt0Var, gt0 gt0Var2, gt0 gt0Var3, gt0 gt0Var4, tq tqVar, int i) {
        super(2, tqVar);
        this.e = i;
        this.g = lzVar;
        this.h = gt0Var;
        this.i = gt0Var2;
        this.j = gt0Var3;
        this.k = gt0Var4;
    }

    @Override // defpackage.l50
    public final Object f(Object obj, Object obj2) {
        int i = this.e;
        bw1 bw1Var = bw1.a;
        ds dsVar = (ds) obj;
        tq tqVar = (tq) obj2;
        switch (i) {
        }
        return ((k3) o(tqVar, dsVar)).r(bw1Var);
    }

    @Override // defpackage.kf
    public final tq o(tq tqVar, Object obj) {
        switch (this.e) {
            case 0:
                return new k3(this.g, this.h, this.i, this.j, this.k, tqVar, 0);
            default:
                return new k3(this.g, this.h, this.i, this.j, this.k, tqVar, 1);
        }
    }

    @Override // defpackage.kf
    public final Object r(Object obj) throws JSONException {
        int i = this.e;
        bw1 bw1Var = bw1.a;
        gt0 gt0Var = this.k;
        gt0 gt0Var2 = this.j;
        lz lzVar = this.g;
        es esVar = es.d;
        gt0 gt0Var3 = this.h;
        gt0 gt0Var4 = this.i;
        tq tqVar = null;
        switch (i) {
            case 0:
                int i2 = this.f;
                if (i2 == 0) {
                    vl.Q(obj);
                    mg0.Q(gt0Var3, true);
                    gt0Var4.setValue(null);
                    this.f = 1;
                    obj = lzVar.e(this);
                    if (obj == esVar) {
                    }
                } else if (i2 != 1) {
                    zi.f("call to 'resume' before 'invoke' with coroutine");
                } else {
                    vl.Q(obj);
                }
                r60 r60Var = (r60) obj;
                if (r60Var instanceof q60) {
                    gt0Var2.setValue((String) ((q60) r60Var).a);
                    mg0.Q(gt0Var3, false);
                } else if (!(r60Var instanceof p60)) {
                    tz.c();
                } else {
                    gt0Var4.setValue(((p60) r60Var).a);
                    mg0.Q(gt0Var3, false);
                    mg0.g(gt0Var, false);
                }
                break;
            default:
                int i3 = this.f;
                if (i3 == 0) {
                    vl.Q(obj);
                    gt0Var3.setValue(Boolean.TRUE);
                    gt0Var4.setValue(null);
                    String str = (String) gt0Var2.getValue();
                    this.f = 1;
                    JSONObject jSONObject = new JSONObject();
                    jSONObject.put("unique_id", str);
                    au auVar = rv.a;
                    obj = m22.H(vt.f, new m3(lzVar, jSONObject, tqVar, 3), this);
                    if (obj == esVar) {
                    }
                } else if (i3 != 1) {
                    zi.f("call to 'resume' before 'invoke' with coroutine");
                } else {
                    vl.Q(obj);
                }
                r60 r60Var2 = (r60) obj;
                if (r60Var2 instanceof q60) {
                    JSONObject jSONObject2 = (JSONObject) ((q60) r60Var2).a;
                    if (jSONObject2.optBoolean("success", false)) {
                        gt0Var.setValue(Boolean.TRUE);
                    } else {
                        JSONArray jSONArrayOptJSONArray = jSONObject2.optJSONArray("error");
                        gt0Var4.setValue((jSONArrayOptJSONArray == null || jSONArrayOptJSONArray.length() <= 0) ? jSONObject2.optString("message", "Thêm tài khoản thất bại") : jSONArrayOptJSONArray.optString(0));
                    }
                    gt0Var3.setValue(Boolean.FALSE);
                } else if (!(r60Var2 instanceof p60)) {
                    tz.c();
                } else {
                    gt0Var4.setValue(((p60) r60Var2).a);
                    gt0Var3.setValue(Boolean.FALSE);
                }
                break;
        }
        return null;
    }
}
