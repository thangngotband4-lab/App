package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class gl1 implements w40 {
    public final /* synthetic */ int d;
    public final /* synthetic */ ac e;

    public /* synthetic */ gl1(ac acVar, int i) {
        this.d = i;
        this.e = acVar;
    }

    @Override // defpackage.w40
    public final Object a() {
        int i = this.d;
        bw1 bw1Var = bw1.a;
        ac acVar = this.e;
        switch (i) {
            case 0:
                acVar.i = false;
                break;
            default:
                acVar.i = false;
                break;
        }
        return bw1Var;
    }
}
