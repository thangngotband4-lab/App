package defpackage;

import kotlin.Metadata;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u000e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001¨\u0006\u0003"}, d2 = {"Lsb1;", "Ljr0;", "Ltb1;", "foundation"}, k = 1, mv = {2, 0, 0}, xi = 48)
final class sb1 extends jr0 {
    public final hc1 a;
    public final ry0 b;
    public final boolean c;
    public final pt d;
    public final ks0 e;
    public final boolean f;
    public final e7 g;

    public sb1(e7 e7Var, pt ptVar, ks0 ks0Var, ry0 ry0Var, hc1 hc1Var, boolean z, boolean z2) {
        this.a = hc1Var;
        this.b = ry0Var;
        this.c = z;
        this.d = ptVar;
        this.e = ks0Var;
        this.f = z2;
        this.g = e7Var;
    }

    @Override // defpackage.jr0
    public final er0 e() {
        tb1 tb1Var = new tb1();
        tb1Var.t = this.a;
        tb1Var.u = this.b;
        tb1Var.v = this.c;
        tb1Var.w = this.d;
        tb1Var.x = this.e;
        tb1Var.y = this.f;
        tb1Var.z = this.g;
        return tb1Var;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || sb1.class != obj.getClass()) {
            return false;
        }
        sb1 sb1Var = (sb1) obj;
        return ng0.o(this.a, sb1Var.a) && this.b == sb1Var.b && this.c == sb1Var.c && ng0.o(this.d, sb1Var.d) && ng0.o(this.e, sb1Var.e) && this.f == sb1Var.f && ng0.o(this.g, sb1Var.g);
    }

    @Override // defpackage.jr0
    public final void f(er0 er0Var) {
        ((tb1) er0Var).R0(this.g, this.d, this.e, this.b, this.a, this.f, this.c);
    }

    public final int hashCode() {
        int iF = f0.f(f0.f((this.b.hashCode() + (this.a.hashCode() * 31)) * 31, 31, this.c), 31, false);
        pt ptVar = this.d;
        int iHashCode = (iF + (ptVar != null ? ptVar.hashCode() : 0)) * 31;
        ks0 ks0Var = this.e;
        int iF2 = f0.f((iHashCode + (ks0Var != null ? ks0Var.hashCode() : 0)) * 961, 31, this.f);
        e7 e7Var = this.g;
        return iF2 + (e7Var != null ? e7Var.hashCode() : 0);
    }
}
