package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public interface au0 {
    default long K(int i, long j, long j2) {
        return 0L;
    }

    default Object f0(long j, tq tqVar) {
        return new xx1(0L);
    }

    default Object j0(long j, long j2, tq tqVar) {
        return new xx1(0L);
    }

    default long q0(int i, long j) {
        return 0L;
    }
}
