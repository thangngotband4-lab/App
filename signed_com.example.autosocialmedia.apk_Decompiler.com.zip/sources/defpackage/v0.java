package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class v0 extends uq {
    public e71 d;
    public /* synthetic */ Object e;
    public final /* synthetic */ y0 f;
    public int g;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public v0(y0 y0Var, uq uqVar) {
        super(uqVar);
        this.f = y0Var;
    }

    @Override // defpackage.kf
    public final Object r(Object obj) {
        this.e = obj;
        this.g |= Integer.MIN_VALUE;
        return this.f.k(null, 0L, null, this);
    }
}
