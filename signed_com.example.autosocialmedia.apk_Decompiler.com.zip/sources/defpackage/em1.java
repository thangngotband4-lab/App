package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class em1 extends jl1 implements l50 {
    public final /* synthetic */ int e;
    public final /* synthetic */ w41 f;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ em1(w41 w41Var, tq tqVar, int i) {
        super(2, tqVar);
        this.e = i;
        this.f = w41Var;
    }

    @Override // defpackage.l50
    public final Object f(Object obj, Object obj2) {
        int i = this.e;
        bw1 bw1Var = bw1.a;
        ds dsVar = (ds) obj;
        tq tqVar = (tq) obj2;
        switch (i) {
            case 0:
                ((em1) o(tqVar, dsVar)).r(bw1Var);
                break;
            case 1:
                ((em1) o(tqVar, dsVar)).r(bw1Var);
                break;
            case 2:
                ((em1) o(tqVar, dsVar)).r(bw1Var);
                break;
            case 3:
                ((em1) o(tqVar, dsVar)).r(bw1Var);
                break;
            case 4:
                ((em1) o(tqVar, dsVar)).r(bw1Var);
                break;
            case 5:
                ((em1) o(tqVar, dsVar)).r(bw1Var);
                break;
            case 6:
                ((em1) o(tqVar, dsVar)).r(bw1Var);
                break;
            default:
                ((em1) o(tqVar, dsVar)).r(bw1Var);
                break;
        }
        return bw1Var;
    }

    @Override // defpackage.kf
    public final tq o(tq tqVar, Object obj) {
        int i = this.e;
        w41 w41Var = this.f;
        switch (i) {
            case 0:
                return new em1(w41Var, tqVar, 0);
            case 1:
                return new em1(w41Var, tqVar, 1);
            case 2:
                return new em1(w41Var, tqVar, 2);
            case 3:
                return new em1(w41Var, tqVar, 3);
            case 4:
                return new em1(w41Var, tqVar, 4);
            case 5:
                return new em1(w41Var, tqVar, 5);
            case 6:
                return new em1(w41Var, tqVar, 6);
            default:
                return new em1(w41Var, tqVar, 7);
        }
    }

    @Override // defpackage.kf
    public final Object r(Object obj) {
        int i = this.e;
        bw1 bw1Var = bw1.a;
        w41 w41Var = this.f;
        switch (i) {
            case 0:
                vl.Q(obj);
                w41Var.f = true;
                st0 st0Var = w41Var.g;
                if (st0Var.d()) {
                    st0Var.h(null);
                }
                break;
            case 1:
                vl.Q(obj);
                w41Var.a();
                break;
            case 2:
                vl.Q(obj);
                w41Var.a();
                break;
            case 3:
                vl.Q(obj);
                w41Var.f = true;
                st0 st0Var2 = w41Var.g;
                if (st0Var2.d()) {
                    st0Var2.h(null);
                }
                break;
            case 4:
                vl.Q(obj);
                w41Var.a();
                break;
            case 5:
                vl.Q(obj);
                w41Var.a();
                break;
            case 6:
                vl.Q(obj);
                w41Var.f = true;
                st0 st0Var3 = w41Var.g;
                if (st0Var3.d()) {
                    st0Var3.h(null);
                }
                break;
            default:
                vl.Q(obj);
                w41Var.a();
                break;
        }
        return bw1Var;
    }
}
