package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class mb implements bu1 {
    public final fu1 a;
    public final m01 b = hl.I(new yf0(0));
    public final at0 c;

    public mb(fu1 fu1Var) {
        this.a = fu1Var;
        long[] jArr = za1.a;
        this.c = new at0();
    }

    @Override // defpackage.bu1
    public final Object b() {
        return this.a.f().b();
    }

    @Override // defpackage.bu1
    public final Object c() {
        return this.a.f().c();
    }
}
