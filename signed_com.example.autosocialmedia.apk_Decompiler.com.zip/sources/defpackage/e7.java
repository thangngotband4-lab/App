package defpackage;

import android.content.Context;
import android.os.Build;
import android.widget.EdgeEffect;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class e7 {
    public final wu a;
    public long b = 9205357640488583168L;
    public final py c;
    public final m01 d;
    public final boolean e;
    public boolean f;
    public long g;
    public long h;
    public final lu i;

    public e7(Context context, wu wuVar, long j, uz0 uz0Var) {
        this.a = wuVar;
        py pyVar = new py(context, tl.Q(j));
        this.c = pyVar;
        this.d = new m01(bw1.a, a4.N);
        this.e = true;
        this.g = 0L;
        this.h = -1L;
        d7 d7Var = new d7(0, this);
        m31 m31Var = ll1.a;
        pl1 pl1Var = new pl1(null, null, d7Var);
        this.i = Build.VERSION.SDK_INT >= 31 ? new n60(pl1Var, this, pyVar) : new n60(pl1Var, this, pyVar, uz0Var);
    }

    public final void a() {
        boolean z;
        py pyVar = this.c;
        EdgeEffect edgeEffect = pyVar.d;
        boolean z2 = true;
        if (edgeEffect != null) {
            edgeEffect.onRelease();
            z = !edgeEffect.isFinished();
        } else {
            z = false;
        }
        EdgeEffect edgeEffect2 = pyVar.e;
        if (edgeEffect2 != null) {
            edgeEffect2.onRelease();
            z = !edgeEffect2.isFinished() || z;
        }
        EdgeEffect edgeEffect3 = pyVar.f;
        if (edgeEffect3 != null) {
            edgeEffect3.onRelease();
            z = !edgeEffect3.isFinished() || z;
        }
        EdgeEffect edgeEffect4 = pyVar.g;
        if (edgeEffect4 != null) {
            edgeEffect4.onRelease();
            if (edgeEffect4.isFinished() && !z) {
                z2 = false;
            }
            z = z2;
        }
        if (z) {
            d();
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:50:0x0137, code lost:
    
        if (r4 == r6) goto L51;
     */
    /* JADX WARN: Removed duplicated region for block: B:7:0x001b  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final java.lang.Object b(long r19, defpackage.nc1 r21, defpackage.uq r22) {
        /*
            Method dump skipped, instruction units count: 483
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.e7.b(long, nc1, uq):java.lang.Object");
    }

    public final long c() {
        long jV = this.b;
        if ((9223372034707292159L & jV) == 9205357640488583168L) {
            jV = jl.v(this.g);
        }
        float fIntBitsToFloat = Float.intBitsToFloat((int) (jV >> 32)) / Float.intBitsToFloat((int) (this.g >> 32));
        return (((long) Float.floatToRawIntBits(Float.intBitsToFloat((int) (jV & 4294967295L)) / Float.intBitsToFloat((int) (this.g & 4294967295L)))) & 4294967295L) | (Float.floatToRawIntBits(fIntBitsToFloat) << 32);
    }

    public final void d() {
        if (this.e) {
            this.d.setValue(bw1.a);
        }
    }

    public final float e(long j) {
        float fIntBitsToFloat = Float.intBitsToFloat((int) (c() >> 32));
        int i = (int) (j & 4294967295L);
        float fIntBitsToFloat2 = Float.intBitsToFloat(i) / Float.intBitsToFloat((int) (this.g & 4294967295L));
        EdgeEffect edgeEffectB = this.c.b();
        float fU = -fIntBitsToFloat2;
        float f = 1.0f - fIntBitsToFloat;
        int i2 = Build.VERSION.SDK_INT;
        if (i2 >= 31) {
            fU = sc.u(edgeEffectB, fU, f);
        } else {
            edgeEffectB.onPull(fU, f);
        }
        return (i2 >= 31 ? sc.c(edgeEffectB) : 0.0f) == 0.0f ? Float.intBitsToFloat((int) (4294967295L & this.g)) * (-fU) : Float.intBitsToFloat(i);
    }

    public final float f(long j) {
        float fIntBitsToFloat = Float.intBitsToFloat((int) (c() & 4294967295L));
        int i = (int) (j >> 32);
        float fIntBitsToFloat2 = Float.intBitsToFloat(i) / Float.intBitsToFloat((int) (this.g >> 32));
        EdgeEffect edgeEffectC = this.c.c();
        float f = 1.0f - fIntBitsToFloat;
        int i2 = Build.VERSION.SDK_INT;
        if (i2 >= 31) {
            fIntBitsToFloat2 = sc.u(edgeEffectC, fIntBitsToFloat2, f);
        } else {
            edgeEffectC.onPull(fIntBitsToFloat2, f);
        }
        return (i2 >= 31 ? sc.c(edgeEffectC) : 0.0f) == 0.0f ? Float.intBitsToFloat((int) (this.g >> 32)) * fIntBitsToFloat2 : Float.intBitsToFloat(i);
    }

    public final float g(long j) {
        float fIntBitsToFloat = Float.intBitsToFloat((int) (c() & 4294967295L));
        int i = (int) (j >> 32);
        float fIntBitsToFloat2 = Float.intBitsToFloat(i) / Float.intBitsToFloat((int) (this.g >> 32));
        EdgeEffect edgeEffectD = this.c.d();
        float fU = -fIntBitsToFloat2;
        int i2 = Build.VERSION.SDK_INT;
        if (i2 >= 31) {
            fU = sc.u(edgeEffectD, fU, fIntBitsToFloat);
        } else {
            edgeEffectD.onPull(fU, fIntBitsToFloat);
        }
        return (i2 >= 31 ? sc.c(edgeEffectD) : 0.0f) == 0.0f ? Float.intBitsToFloat((int) (this.g >> 32)) * (-fU) : Float.intBitsToFloat(i);
    }

    public final float h(long j) {
        float fIntBitsToFloat = Float.intBitsToFloat((int) (c() >> 32));
        int i = (int) (j & 4294967295L);
        float fIntBitsToFloat2 = Float.intBitsToFloat(i) / Float.intBitsToFloat((int) (this.g & 4294967295L));
        EdgeEffect edgeEffectE = this.c.e();
        int i2 = Build.VERSION.SDK_INT;
        if (i2 >= 31) {
            fIntBitsToFloat2 = sc.u(edgeEffectE, fIntBitsToFloat2, fIntBitsToFloat);
        } else {
            edgeEffectE.onPull(fIntBitsToFloat2, fIntBitsToFloat);
        }
        return (i2 >= 31 ? sc.c(edgeEffectE) : 0.0f) == 0.0f ? Float.intBitsToFloat((int) (this.g & 4294967295L)) * fIntBitsToFloat2 : Float.intBitsToFloat(i);
    }

    public final void i(long j) {
        boolean zA = gg1.a(this.g, 0L);
        boolean zA2 = gg1.a(j, this.g);
        this.g = j;
        if (!zA2) {
            int iD = eq0.D(Float.intBitsToFloat((int) (j >> 32)));
            long jD = (((long) eq0.D(Float.intBitsToFloat((int) (j & 4294967295L)))) & 4294967295L) | (((long) iD) << 32);
            py pyVar = this.c;
            pyVar.c = jD;
            EdgeEffect edgeEffect = pyVar.d;
            if (edgeEffect != null) {
                edgeEffect.setSize((int) (jD >> 32), (int) (jD & 4294967295L));
            }
            EdgeEffect edgeEffect2 = pyVar.e;
            if (edgeEffect2 != null) {
                edgeEffect2.setSize((int) (jD >> 32), (int) (jD & 4294967295L));
            }
            EdgeEffect edgeEffect3 = pyVar.f;
            if (edgeEffect3 != null) {
                edgeEffect3.setSize((int) (jD & 4294967295L), (int) (jD >> 32));
            }
            EdgeEffect edgeEffect4 = pyVar.g;
            if (edgeEffect4 != null) {
                edgeEffect4.setSize((int) (jD & 4294967295L), (int) (jD >> 32));
            }
            EdgeEffect edgeEffect5 = pyVar.h;
            if (edgeEffect5 != null) {
                edgeEffect5.setSize((int) (jD >> 32), (int) (jD & 4294967295L));
            }
            EdgeEffect edgeEffect6 = pyVar.i;
            if (edgeEffect6 != null) {
                edgeEffect6.setSize((int) (jD >> 32), (int) (jD & 4294967295L));
            }
            EdgeEffect edgeEffect7 = pyVar.j;
            if (edgeEffect7 != null) {
                edgeEffect7.setSize((int) (jD & 4294967295L), (int) (jD >> 32));
            }
            EdgeEffect edgeEffect8 = pyVar.k;
            if (edgeEffect8 != null) {
                edgeEffect8.setSize((int) (4294967295L & jD), (int) (jD >> 32));
            }
        }
        if (zA || zA2) {
            return;
        }
        a();
    }
}
