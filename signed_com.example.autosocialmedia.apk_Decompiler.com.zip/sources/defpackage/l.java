package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class l implements h50 {
    public final /* synthetic */ int d;
    public final /* synthetic */ Object e;

    public /* synthetic */ l(int i, Object obj) {
        this.d = i;
        this.e = obj;
    }

    /* JADX WARN: Removed duplicated region for block: B:113:0x0264  */
    /* JADX WARN: Removed duplicated region for block: B:114:0x0277  */
    /* JADX WARN: Removed duplicated region for block: B:173:0x03ab  */
    /* JADX WARN: Removed duplicated region for block: B:234:0x055c  */
    /* JADX WARN: Removed duplicated region for block: B:244:0x0599  */
    @Override // defpackage.h50
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final java.lang.Object g(java.lang.Object r43) {
        /*
            Method dump skipped, instruction units count: 2156
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.l.g(java.lang.Object):java.lang.Object");
    }

    public /* synthetic */ l(Object obj, int i, Object obj2) {
        this.d = i;
        this.e = obj;
    }
}
