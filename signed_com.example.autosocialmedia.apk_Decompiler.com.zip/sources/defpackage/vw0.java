package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class vw0 implements cn0 {
    public final zm0 d;
    public final xw0 e;
    public ae0 f;
    public final /* synthetic */ ww0 g;

    public vw0(ww0 ww0Var, zm0 zm0Var, xw0 xw0Var) {
        this.g = ww0Var;
        this.d = zm0Var;
        this.e = xw0Var;
        zm0Var.a(this);
    }

    @Override // defpackage.cn0
    public final void e(en0 en0Var, xm0 xm0Var) {
        xm0 xm0Var2 = xm0.ON_START;
        xw0 xw0Var = this.e;
        if (xm0Var == xm0Var2) {
            ww0 ww0Var = this.g;
            ww0Var.b.addLast(xw0Var);
            ae0 ae0Var = new ae0(ww0Var, 14, xw0Var);
            xw0Var.a.add(ae0Var);
            ww0Var.c();
            xw0Var.b = new z4(0, ww0Var, ww0.class, "updateEnabledCallbacks", "updateEnabledCallbacks()V", 0, 0, 5);
            this.f = ae0Var;
            return;
        }
        if (xm0Var == xm0.ON_STOP) {
            ae0 ae0Var2 = this.f;
            if (ae0Var2 != null) {
                ae0Var2.cancel();
                return;
            }
            return;
        }
        if (xm0Var == xm0.ON_DESTROY) {
            this.d.b(this);
            xw0Var.a.remove(this);
            ae0 ae0Var3 = this.f;
            if (ae0Var3 != null) {
                ae0Var3.cancel();
            }
            this.f = null;
        }
    }
}
