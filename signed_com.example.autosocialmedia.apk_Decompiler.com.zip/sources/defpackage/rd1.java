package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class rd1 {
    public final pd1 a;
    public final vf0 b;

    public rd1(pd1 pd1Var, vf0 vf0Var) {
        this.a = pd1Var;
        this.b = vf0Var;
    }
}
