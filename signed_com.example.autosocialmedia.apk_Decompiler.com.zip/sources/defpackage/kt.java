package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class kt implements xc0 {
    public static final kt a = new kt();

    @Override // defpackage.xc0
    public final ku a(ks0 ks0Var) {
        return new jt(ks0Var);
    }

    public final boolean equals(Object obj) {
        return obj == this;
    }

    @Override // defpackage.xc0
    public final int hashCode() {
        return -1;
    }
}
