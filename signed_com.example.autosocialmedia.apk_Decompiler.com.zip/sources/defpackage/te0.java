package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class te0 implements l50 {
    public final /* synthetic */ int d;
    public final /* synthetic */ gt0 e;

    public /* synthetic */ te0(gt0 gt0Var, int i) {
        this.d = i;
        this.e = gt0Var;
    }

    @Override // defpackage.l50
    public final Object f(Object obj, Object obj2) {
        int i = this.d;
        cr0 cr0Var = cr0.a;
        bw1 bw1Var = bw1.a;
        dp1 dp1Var = ro.a;
        gt0 gt0Var = this.e;
        switch (i) {
            case 0:
                xo xoVar = (xo) obj;
                int iIntValue = ((Integer) obj2).intValue();
                if (!xoVar.O(iIntValue & 1, (iIntValue & 3) != 2)) {
                    xoVar.R();
                } else {
                    km kmVarA = im.a(ng0.g, a4.q, xoVar, 0);
                    int iHashCode = Long.hashCode(xoVar.T);
                    t11 t11VarL = xoVar.l();
                    fr0 fr0VarM = om.M(xoVar, cr0Var);
                    oo.b.getClass();
                    kp kpVar = no.b;
                    xoVar.Z();
                    if (xoVar.S) {
                        xoVar.k(kpVar);
                    } else {
                        xoVar.j0();
                    }
                    ak1.o(xoVar, no.e, kmVarA);
                    ak1.o(xoVar, no.d, t11VarL);
                    ak1.j(xoVar, Integer.valueOf(iHashCode), no.f);
                    ak1.n(xoVar, no.g);
                    ak1.o(xoVar, no.c, fr0VarM);
                    mp1.b("Dán chuỗi cookies (phải chứa sessionid và csrftoken).", null, sl.m(), ak1.h(13), null, null, 0L, null, 0L, 0, false, 0, 0, null, xoVar, 24582, 0, 262122);
                    om.d(xoVar, ig1.b(cr0Var, 8.0f));
                    String str = (String) gt0Var.getValue();
                    Object objL = xoVar.L();
                    if (objL == dp1Var) {
                        objL = new h3(gt0Var, 29);
                        xoVar.g0(objL);
                    }
                    tl.g(str, (h50) objL, ig1.d(ig1.a, 100.0f, 0.0f, 2), false, null, null, m22.n, false, null, new ei0(1, 123), null, false, 0, 0, null, null, xoVar, 12583344, 196608, 8355704);
                    xoVar.p(true);
                }
                break;
            case 1:
                xo xoVar2 = (xo) obj;
                int iIntValue2 = ((Integer) obj2).intValue();
                if (!xoVar2.O(iIntValue2 & 1, (iIntValue2 & 3) != 2)) {
                    xoVar2.R();
                } else {
                    km kmVarA2 = im.a(ng0.g, a4.q, xoVar2, 0);
                    int iHashCode2 = Long.hashCode(xoVar2.T);
                    t11 t11VarL2 = xoVar2.l();
                    fr0 fr0VarM2 = om.M(xoVar2, cr0Var);
                    oo.b.getClass();
                    kp kpVar2 = no.b;
                    xoVar2.Z();
                    if (xoVar2.S) {
                        xoVar2.k(kpVar2);
                    } else {
                        xoVar2.j0();
                    }
                    ak1.o(xoVar2, no.e, kmVarA2);
                    ak1.o(xoVar2, no.d, t11VarL2);
                    ak1.j(xoVar2, Integer.valueOf(iHashCode2), no.f);
                    ak1.n(xoVar2, no.g);
                    ak1.o(xoVar2, no.c, fr0VarM2);
                    mp1.b("Dán chuỗi cookies (phải chứa sessionid và csrftoken).", null, sl.m(), ak1.h(13), null, null, 0L, null, 0L, 0, false, 0, 0, null, xoVar2, 24582, 0, 262122);
                    om.d(xoVar2, ig1.b(cr0Var, 8.0f));
                    String str2 = (String) gt0Var.getValue();
                    Object objL2 = xoVar2.L();
                    if (objL2 == dp1Var) {
                        objL2 = new qp0(gt0Var, 25);
                        xoVar2.g0(objL2);
                    }
                    tl.g(str2, (h50) objL2, ig1.d(ig1.a, 100.0f, 0.0f, 2), false, null, null, zu1.r, false, null, new ei0(1, 123), null, false, 0, 0, null, null, xoVar2, 12583344, 196608, 8355704);
                    xoVar2.p(true);
                }
                break;
            case 2:
                xo xoVar3 = (xo) obj;
                int iIntValue3 = ((Integer) obj2).intValue();
                if (!xoVar3.O(iIntValue3 & 1, (iIntValue3 & 3) != 2)) {
                    xoVar3.R();
                } else {
                    km kmVarA3 = im.a(ng0.g, a4.q, xoVar3, 0);
                    int iHashCode3 = Long.hashCode(xoVar3.T);
                    t11 t11VarL3 = xoVar3.l();
                    fr0 fr0VarM3 = om.M(xoVar3, cr0Var);
                    oo.b.getClass();
                    kp kpVar3 = no.b;
                    xoVar3.Z();
                    if (xoVar3.S) {
                        xoVar3.k(kpVar3);
                    } else {
                        xoVar3.j0();
                    }
                    ak1.o(xoVar3, no.e, kmVarA3);
                    ak1.o(xoVar3, no.d, t11VarL3);
                    ak1.j(xoVar3, Integer.valueOf(iHashCode3), no.f);
                    ak1.n(xoVar3, no.g);
                    ak1.o(xoVar3, no.c, fr0VarM3);
                    mp1.b("Dán chuỗi cookies (phải chứa auth_token và ct0).", null, sl.m(), ak1.h(13), null, null, 0L, null, 0L, 0, false, 0, 0, null, xoVar3, 24582, 0, 262122);
                    om.d(xoVar3, ig1.b(cr0Var, 8.0f));
                    String str3 = (String) gt0Var.getValue();
                    Object objL3 = xoVar3.L();
                    if (objL3 == dp1Var) {
                        objL3 = new ys1(gt0Var, 3);
                        xoVar3.g0(objL3);
                    }
                    tl.g(str3, (h50) objL3, ig1.d(ig1.a, 100.0f, 0.0f, 2), false, null, null, mg0.N, false, null, new ei0(1, 123), null, false, 0, 0, null, null, xoVar3, 12583344, 196608, 8355704);
                    xoVar3.p(true);
                }
                break;
            case 3:
                xo xoVar4 = (xo) obj;
                int iIntValue4 = ((Integer) obj2).intValue();
                if (!xoVar4.O(iIntValue4 & 1, (iIntValue4 & 3) != 2)) {
                    xoVar4.R();
                } else {
                    km kmVarA4 = im.a(ng0.g, a4.q, xoVar4, 0);
                    int iHashCode4 = Long.hashCode(xoVar4.T);
                    t11 t11VarL4 = xoVar4.l();
                    fr0 fr0VarM4 = om.M(xoVar4, cr0Var);
                    oo.b.getClass();
                    kp kpVar4 = no.b;
                    xoVar4.Z();
                    if (xoVar4.S) {
                        xoVar4.k(kpVar4);
                    } else {
                        xoVar4.j0();
                    }
                    ak1.o(xoVar4, no.e, kmVarA4);
                    ak1.o(xoVar4, no.d, t11VarL4);
                    ak1.j(xoVar4, Integer.valueOf(iHashCode4), no.f);
                    ak1.n(xoVar4, no.g);
                    ak1.o(xoVar4, no.c, fr0VarM4);
                    mp1.b("Dán chuỗi cookies (phải chứa SAPISID hoặc __Secure-3PAPISID).", null, sl.m(), ak1.h(13), null, null, 0L, null, 0L, 0, false, 0, 0, null, xoVar4, 24582, 0, 262122);
                    om.d(xoVar4, ig1.b(cr0Var, 8.0f));
                    String str4 = (String) gt0Var.getValue();
                    Object objL4 = xoVar4.L();
                    if (objL4 == dp1Var) {
                        objL4 = new ys1(gt0Var, 4);
                        xoVar4.g0(objL4);
                    }
                    tl.g(str4, (h50) objL4, ig1.d(ig1.a, 100.0f, 0.0f, 2), false, null, null, vh0.s, false, null, new ei0(1, 123), null, false, 0, 0, null, null, xoVar4, 12583344, 196608, 8355704);
                    xoVar4.p(true);
                }
                break;
            case 4:
                xo xoVar5 = (xo) obj;
                int iIntValue5 = ((Integer) obj2).intValue();
                if (!xoVar5.O(iIntValue5 & 1, (iIntValue5 & 3) != 2)) {
                    xoVar5.R();
                } else {
                    Object objL5 = xoVar5.L();
                    if (objL5 == dp1Var) {
                        objL5 = new ev0(gt0Var, 6);
                        xoVar5.g0(objL5);
                    }
                    ct.v((w40) objL5, null, false, null, null, null, mg0.A, xoVar5, 805306374, 510);
                }
                break;
            case 5:
                xo xoVar6 = (xo) obj;
                int iIntValue6 = ((Integer) obj2).intValue();
                if (!xoVar6.O(iIntValue6 & 1, (iIntValue6 & 3) != 2)) {
                    xoVar6.R();
                } else {
                    Object objL6 = xoVar6.L();
                    if (objL6 == dp1Var) {
                        objL6 = new ev0(gt0Var, 20);
                        xoVar6.g0(objL6);
                    }
                    ct.v((w40) objL6, null, false, null, null, null, m22.t, xoVar6, 805306374, 510);
                }
                break;
            default:
                xo xoVar7 = (xo) obj;
                int iIntValue7 = ((Integer) obj2).intValue();
                if (!xoVar7.O(iIntValue7 & 1, (iIntValue7 & 3) != 2)) {
                    xoVar7.R();
                } else {
                    Object objL7 = xoVar7.L();
                    if (objL7 == dp1Var) {
                        objL7 = new ev0(gt0Var, 19);
                        xoVar7.g0(objL7);
                    }
                    ct.v((w40) objL7, null, false, null, null, null, m22.x, xoVar7, 805306374, 510);
                }
                break;
        }
        return bw1Var;
    }
}
