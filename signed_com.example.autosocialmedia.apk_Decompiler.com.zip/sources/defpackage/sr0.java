package defpackage;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class sr0 {
    public static final sr0 d;
    public static final sr0 e;
    public static final sr0 f;
    public static final sr0 g;
    public static final sr0 h;
    public static final /* synthetic */ sr0[] i;

    static {
        sr0 sr0Var = new sr0("DefaultSpatial", 0);
        d = sr0Var;
        sr0 sr0Var2 = new sr0("FastSpatial", 1);
        e = sr0Var2;
        sr0 sr0Var3 = new sr0("SlowSpatial", 2);
        sr0 sr0Var4 = new sr0("DefaultEffects", 3);
        f = sr0Var4;
        sr0 sr0Var5 = new sr0("FastEffects", 4);
        g = sr0Var5;
        sr0 sr0Var6 = new sr0("SlowEffects", 5);
        h = sr0Var6;
        i = new sr0[]{sr0Var, sr0Var2, sr0Var3, sr0Var4, sr0Var5, sr0Var6};
    }

    public static sr0 valueOf(String str) {
        return (sr0) Enum.valueOf(sr0.class, str);
    }

    public static sr0[] values() {
        return (sr0[]) i.clone();
    }
}
