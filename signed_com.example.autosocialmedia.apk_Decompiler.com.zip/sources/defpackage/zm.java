package defpackage;

import java.util.Arrays;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class zm {
    public int a;
    public Object b;

    public /* synthetic */ zm(int i, Object obj) {
        this.b = obj;
        this.a = i;
    }

    /* JADX WARN: Code restructure failed: missing block: B:101:0x01e9, code lost:
    
        if (r8.size() <= 0) goto L103;
     */
    /* JADX WARN: Code restructure failed: missing block: B:102:0x01eb, code lost:
    
        r0 = new defpackage.mi(r8, r7);
     */
    /* JADX WARN: Code restructure failed: missing block: B:103:0x01f1, code lost:
    
        r0 = null;
     */
    /* JADX WARN: Code restructure failed: missing block: B:104:0x01f2, code lost:
    
        if (r0 == null) goto L106;
     */
    /* JADX WARN: Code restructure failed: missing block: B:106:0x01f6, code lost:
    
        if (r20 == false) goto L108;
     */
    /* JADX WARN: Code restructure failed: missing block: B:107:0x01f8, code lost:
    
        r0 = new defpackage.mi(r6, r11, r25);
     */
    /* JADX WARN: Code restructure failed: missing block: B:108:0x0200, code lost:
    
        r0 = new defpackage.mi(r6, r25);
     */
    /* JADX WARN: Code restructure failed: missing block: B:109:0x0208, code lost:
    
        if (r12 == 1) goto L121;
     */
    /* JADX WARN: Code restructure failed: missing block: B:111:0x020b, code lost:
    
        if (r12 == 2) goto L120;
     */
    /* JADX WARN: Code restructure failed: missing block: B:112:0x020d, code lost:
    
        r1 = r0.a;
        r0 = r0.b;
     */
    /* JADX WARN: Code restructure failed: missing block: B:113:0x0213, code lost:
    
        if (r4 == 1) goto L118;
     */
    /* JADX WARN: Code restructure failed: missing block: B:114:0x0215, code lost:
    
        if (r4 == 2) goto L117;
     */
    /* JADX WARN: Code restructure failed: missing block: B:115:0x0217, code lost:
    
        r2 = android.graphics.Shader.TileMode.CLAMP;
     */
    /* JADX WARN: Code restructure failed: missing block: B:117:0x0224, code lost:
    
        r2 = android.graphics.Shader.TileMode.MIRROR;
     */
    /* JADX WARN: Code restructure failed: missing block: B:118:0x0227, code lost:
    
        r2 = android.graphics.Shader.TileMode.REPEAT;
     */
    /* JADX WARN: Code restructure failed: missing block: B:119:0x022a, code lost:
    
        r12 = new android.graphics.LinearGradient(r26, r27, r15, r16, r1, r0, r2);
     */
    /* JADX WARN: Code restructure failed: missing block: B:120:0x022e, code lost:
    
        r12 = new android.graphics.SweepGradient(r10, r9, r0.a, r0.b);
     */
    /* JADX WARN: Code restructure failed: missing block: B:122:0x023c, code lost:
    
        if (r23 <= 0.0f) goto L134;
     */
    /* JADX WARN: Code restructure failed: missing block: B:123:0x023e, code lost:
    
        r1 = r0.a;
        r0 = r0.b;
     */
    /* JADX WARN: Code restructure failed: missing block: B:124:0x0245, code lost:
    
        if (r4 == 1) goto L130;
     */
    /* JADX WARN: Code restructure failed: missing block: B:126:0x0248, code lost:
    
        if (r4 == 2) goto L129;
     */
    /* JADX WARN: Code restructure failed: missing block: B:127:0x024a, code lost:
    
        r2 = android.graphics.Shader.TileMode.CLAMP;
     */
    /* JADX WARN: Code restructure failed: missing block: B:129:0x0259, code lost:
    
        r2 = android.graphics.Shader.TileMode.MIRROR;
     */
    /* JADX WARN: Code restructure failed: missing block: B:130:0x025c, code lost:
    
        r2 = android.graphics.Shader.TileMode.REPEAT;
     */
    /* JADX WARN: Code restructure failed: missing block: B:131:0x025f, code lost:
    
        r12 = new android.graphics.RadialGradient(r10, r9, r23, r1, r0, r2);
     */
    /* JADX WARN: Code restructure failed: missing block: B:133:0x026a, code lost:
    
        return new defpackage.zm(0, r12);
     */
    /* JADX WARN: Code restructure failed: missing block: B:135:0x0272, code lost:
    
        throw new org.xmlpull.v1.XmlPullParserException("<gradient> tag requires 'gradientRadius' attribute with radial type");
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static defpackage.zm c(android.content.res.Resources r30, int r31, android.content.res.Resources.Theme r32) throws org.xmlpull.v1.XmlPullParserException, java.io.IOException {
        /*
            Method dump skipped, instruction units count: 667
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.zm.c(android.content.res.Resources, int, android.content.res.Resources$Theme):zm");
    }

    public void a(long j) {
        if (b(j)) {
            return;
        }
        int i = this.a;
        long[] jArrCopyOf = (long[]) this.b;
        if (i >= jArrCopyOf.length) {
            jArrCopyOf = Arrays.copyOf(jArrCopyOf, Math.max(i + 1, jArrCopyOf.length * 2));
            this.b = jArrCopyOf;
        }
        jArrCopyOf[i] = j;
        if (i >= this.a) {
            this.a = i + 1;
        }
    }

    public boolean b(long j) {
        int i = this.a;
        for (int i2 = 0; i2 < i; i2++) {
            if (((long[]) this.b)[i2] == j) {
                return true;
            }
        }
        return false;
    }

    public void d(long j) {
        int i = this.a;
        int i2 = 0;
        while (i2 < i) {
            if (j == ((long[]) this.b)[i2]) {
                int i3 = this.a - 1;
                while (i2 < i3) {
                    long[] jArr = (long[]) this.b;
                    int i4 = i2 + 1;
                    jArr[i2] = jArr[i4];
                    i2 = i4;
                }
                this.a--;
                return;
            }
            i2++;
        }
    }
}
