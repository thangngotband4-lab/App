package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class ef1 implements vy {
    public final int a;
    public final int b;

    public ef1(int i, int i2) {
        this.a = i;
        this.b = i2;
    }

    @Override // defpackage.vy
    public final void a(wy wyVar) {
        boolean z = wyVar.d != -1;
        o01 o01Var = wyVar.a;
        if (z) {
            wyVar.d = -1;
            wyVar.e = -1;
        }
        int iO = tl.o(this.a, 0, o01Var.b());
        int iO2 = tl.o(this.b, 0, o01Var.b());
        if (iO != iO2) {
            if (iO < iO2) {
                wyVar.e(iO, iO2);
            } else {
                wyVar.e(iO2, iO);
            }
        }
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof ef1)) {
            return false;
        }
        ef1 ef1Var = (ef1) obj;
        return this.a == ef1Var.a && this.b == ef1Var.b;
    }

    public final int hashCode() {
        return (this.a * 31) + this.b;
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder("SetComposingRegionCommand(start=");
        sb.append(this.a);
        sb.append(", end=");
        return f0.p(sb, this.b, ')');
    }
}
