package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class j61 implements lj1, e20, x50 {
    public final /* synthetic */ nj1 d;

    public j61(nj1 nj1Var) {
        this.d = nj1Var;
    }

    @Override // defpackage.e20
    public final Object b(f20 f20Var, tq tqVar) throws Throwable {
        this.d.b(f20Var, tqVar);
        return es.d;
    }

    @Override // defpackage.x50
    public final e20 c(ur urVar, int i, sh shVar) {
        return ((((i < 0 || i >= 2) && i != -2) || shVar != sh.e) && !((i == 0 || i == -3) && shVar == sh.d)) ? new rj(this, urVar, i, shVar) : this;
    }

    @Override // defpackage.lj1
    public final Object getValue() {
        return this.d.getValue();
    }
}
