package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public interface iu {
    xv c(long j, jt1 jt1Var, ur urVar);

    void d(long j, xi xiVar);
}
