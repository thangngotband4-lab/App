package defpackage;

import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Outline;
import android.graphics.Paint;
import android.graphics.PorterDuffXfermode;
import android.os.Build;
import android.view.DisplayListCanvas;
import android.view.RenderNode;
import java.util.concurrent.atomic.AtomicBoolean;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class da0 implements aa0 {
    public static final AtomicBoolean w = new AtomicBoolean(true);
    public final gj b;
    public final fj c;
    public final RenderNode d;
    public long e;
    public Paint f;
    public Matrix g;
    public boolean h;
    public long i;
    public int j;
    public int k;
    public float l;
    public boolean m;
    public float n;
    public float o;
    public float p;
    public long q;
    public long r;
    public float s;
    public boolean t;
    public boolean u;
    public boolean v;

    public da0(k5 k5Var, gj gjVar, fj fjVar) {
        this.b = gjVar;
        this.c = fjVar;
        RenderNode renderNodeCreate = RenderNode.create("Compose", k5Var);
        this.d = renderNodeCreate;
        this.e = 0L;
        this.i = 0L;
        if (w.getAndSet(false)) {
            renderNodeCreate.setScaleX(renderNodeCreate.getScaleX());
            renderNodeCreate.setScaleY(renderNodeCreate.getScaleY());
            renderNodeCreate.setTranslationX(renderNodeCreate.getTranslationX());
            renderNodeCreate.setTranslationY(renderNodeCreate.getTranslationY());
            renderNodeCreate.setElevation(renderNodeCreate.getElevation());
            renderNodeCreate.setRotation(renderNodeCreate.getRotation());
            renderNodeCreate.setRotationX(renderNodeCreate.getRotationX());
            renderNodeCreate.setRotationY(renderNodeCreate.getRotationY());
            renderNodeCreate.setCameraDistance(renderNodeCreate.getCameraDistance());
            renderNodeCreate.setPivotX(renderNodeCreate.getPivotX());
            renderNodeCreate.setPivotY(renderNodeCreate.getPivotY());
            renderNodeCreate.setClipToOutline(renderNodeCreate.getClipToOutline());
            renderNodeCreate.setClipToBounds(false);
            renderNodeCreate.setAlpha(renderNodeCreate.getAlpha());
            renderNodeCreate.isValid();
            renderNodeCreate.setLeftTopRightBottom(0, 0, 0, 0);
            renderNodeCreate.offsetLeftAndRight(0);
            renderNodeCreate.offsetTopAndBottom(0);
            if (Build.VERSION.SDK_INT >= 28) {
                s71.c(renderNodeCreate, s71.a(renderNodeCreate));
                s71.d(renderNodeCreate, s71.b(renderNodeCreate));
            }
            r71.a(renderNodeCreate);
            renderNodeCreate.setLayerType(0);
            renderNodeCreate.setHasOverlappingRendering(renderNodeCreate.hasOverlappingRendering());
        }
        renderNodeCreate.setClipToBounds(false);
        O(0);
        this.j = 0;
        this.k = 3;
        this.l = 1.0f;
        this.n = 1.0f;
        this.o = 1.0f;
        long j = ql.b;
        this.q = j;
        this.r = j;
        this.s = 8.0f;
    }

    @Override // defpackage.aa0
    public final void A(long j) {
        if (Build.VERSION.SDK_INT >= 28) {
            this.r = j;
            s71.d(this.d, tl.Q(j));
        }
    }

    @Override // defpackage.aa0
    public final void B(float f) {
        this.o = f;
        this.d.setScaleY(f);
    }

    @Override // defpackage.aa0
    public final Matrix C() {
        Matrix matrix = this.g;
        if (matrix == null) {
            matrix = new Matrix();
            this.g = matrix;
        }
        this.d.getMatrix(matrix);
        return matrix;
    }

    @Override // defpackage.aa0
    public final void D(int i, int i2, long j) {
        int i3 = (int) (j >> 32);
        int i4 = (int) (4294967295L & j);
        this.d.setLeftTopRightBottom(i, i2, i + i3, i2 + i4);
        if (yf0.a(this.e, j)) {
            return;
        }
        if (this.m) {
            this.d.setPivotX(i3 / 2.0f);
            this.d.setPivotY(i4 / 2.0f);
        }
        this.e = j;
    }

    @Override // defpackage.aa0
    public final float E() {
        return 0.0f;
    }

    @Override // defpackage.aa0
    public final void F(float f) {
        this.s = f;
        this.d.setCameraDistance(-f);
    }

    @Override // defpackage.aa0
    public final float G() {
        return this.p;
    }

    @Override // defpackage.aa0
    public final boolean H() {
        return this.d.isValid();
    }

    @Override // defpackage.aa0
    public final float I() {
        return this.o;
    }

    @Override // defpackage.aa0
    public final float J() {
        return 0.0f;
    }

    @Override // defpackage.aa0
    public final int K() {
        return this.k;
    }

    @Override // defpackage.aa0
    public final void L(long j) {
        if ((9223372034707292159L & j) == 9205357640488583168L) {
            this.m = true;
            this.d.setPivotX(((int) (this.e >> 32)) / 2.0f);
            this.d.setPivotY(((int) (4294967295L & this.e)) / 2.0f);
        } else {
            this.m = false;
            this.d.setPivotX(Float.intBitsToFloat((int) (j >> 32)));
            this.d.setPivotY(Float.intBitsToFloat((int) (j & 4294967295L)));
        }
    }

    @Override // defpackage.aa0
    public final long M() {
        return this.q;
    }

    public final void N() {
        boolean z = this.t;
        boolean z2 = false;
        boolean z3 = z && !this.h;
        if (z && this.h) {
            z2 = true;
        }
        if (z3 != this.u) {
            this.u = z3;
            this.d.setClipToBounds(z3);
        }
        if (z2 != this.v) {
            this.v = z2;
            this.d.setClipToOutline(z2);
        }
    }

    public final void O(int i) {
        RenderNode renderNode = this.d;
        if (i == 1) {
            renderNode.setLayerType(2);
            renderNode.setLayerPaint(this.f);
            renderNode.setHasOverlappingRendering(true);
        } else if (i == 2) {
            renderNode.setLayerType(0);
            renderNode.setLayerPaint(this.f);
            renderNode.setHasOverlappingRendering(false);
        } else {
            renderNode.setLayerType(0);
            renderNode.setLayerPaint(this.f);
            renderNode.setHasOverlappingRendering(true);
        }
    }

    public final void P() {
        int i = this.j;
        if (i != 1 && this.k == 3) {
            O(i);
        } else {
            O(1);
        }
    }

    @Override // defpackage.aa0
    public final float a() {
        return this.l;
    }

    @Override // defpackage.aa0
    public final void b() {
        this.d.setRotationX(0.0f);
    }

    @Override // defpackage.aa0
    public final void c(float f) {
        this.l = f;
        this.d.setAlpha(f);
    }

    @Override // defpackage.aa0
    public final float d() {
        return this.n;
    }

    @Override // defpackage.aa0
    public final void e(float f) {
        this.p = f;
        this.d.setElevation(f);
    }

    @Override // defpackage.aa0
    public final float f() {
        return 0.0f;
    }

    @Override // defpackage.aa0
    public final void g() {
        this.d.setTranslationY(0.0f);
    }

    @Override // defpackage.aa0
    public final void h() {
        this.d.setRotationY(0.0f);
    }

    @Override // defpackage.aa0
    public final long i() {
        return this.r;
    }

    @Override // defpackage.aa0
    public final void j(long j) {
        if (Build.VERSION.SDK_INT >= 28) {
            this.q = j;
            s71.c(this.d, tl.Q(j));
        }
    }

    @Override // defpackage.aa0
    public final void k(Outline outline, long j) {
        this.i = j;
        this.d.setOutline(outline);
        this.h = outline != null;
        N();
    }

    @Override // defpackage.aa0
    public final void l() {
        P();
    }

    @Override // defpackage.aa0
    public final void m(float f) {
        this.n = f;
        this.d.setScaleX(f);
    }

    @Override // defpackage.aa0
    public final void n(int i) {
        if (this.k == i) {
            return;
        }
        this.k = i;
        Paint paint = this.f;
        if (paint == null) {
            paint = new Paint();
            this.f = paint;
        }
        paint.setXfermode(new PorterDuffXfermode(zu1.x(i)));
        P();
    }

    @Override // defpackage.aa0
    public final float o() {
        return this.s;
    }

    @Override // defpackage.aa0
    public final void p() {
        r71.a(this.d);
    }

    @Override // defpackage.aa0
    public final float q() {
        return 0.0f;
    }

    @Override // defpackage.aa0
    public final void r() {
        this.d.setTranslationX(0.0f);
    }

    @Override // defpackage.aa0
    public final void s(dj djVar) {
        Canvas canvas = q4.a;
        DisplayListCanvas displayListCanvas = ((p4) djVar).a;
        displayListCanvas.getClass();
        displayListCanvas.drawRenderNode(this.d);
    }

    @Override // defpackage.aa0
    public final void t(boolean z) {
        this.t = z;
        N();
    }

    @Override // defpackage.aa0
    public final int u() {
        return this.j;
    }

    @Override // defpackage.aa0
    public final float v() {
        return 0.0f;
    }

    @Override // defpackage.aa0
    public final void w(wu wuVar, ri0 ri0Var, y90 y90Var, g4 g4Var) {
        Canvas canvasStart = this.d.start(Math.max((int) (this.e >> 32), (int) (this.i >> 32)), Math.max((int) (this.e & 4294967295L), (int) (this.i & 4294967295L)));
        try {
            p4 p4Var = this.b.a;
            Canvas canvas = p4Var.a;
            p4Var.a = canvasStart;
            fj fjVar = this.c;
            yc ycVar = fjVar.e;
            long jR = bm.R(this.e);
            ej ejVar = ((fj) ycVar.c).d;
            wu wuVar2 = ejVar.a;
            ri0 ri0Var2 = ejVar.b;
            dj djVarF = ycVar.f();
            long jI = ycVar.i();
            y90 y90Var2 = (y90) ycVar.b;
            ycVar.p(wuVar);
            ycVar.q(ri0Var);
            ycVar.o(p4Var);
            ycVar.r(jR);
            ycVar.b = y90Var;
            p4Var.l();
            try {
                g4Var.g(fjVar);
                p4Var.i();
                ycVar.p(wuVar2);
                ycVar.q(ri0Var2);
                ycVar.o(djVarF);
                ycVar.r(jI);
                ycVar.b = y90Var2;
                p4Var.a = canvas;
            } catch (Throwable th) {
                p4Var.i();
                yc ycVar2 = fjVar.e;
                ycVar2.p(wuVar2);
                ycVar2.q(ri0Var2);
                ycVar2.o(djVarF);
                ycVar2.r(jI);
                ycVar2.b = y90Var2;
                throw th;
            }
        } finally {
            this.d.end(canvasStart);
        }
    }

    @Override // defpackage.aa0
    public final dg x() {
        return null;
    }

    @Override // defpackage.aa0
    public final void y(int i) {
        this.j = i;
        P();
    }

    @Override // defpackage.aa0
    public final void z() {
        this.d.setRotation(0.0f);
    }
}
