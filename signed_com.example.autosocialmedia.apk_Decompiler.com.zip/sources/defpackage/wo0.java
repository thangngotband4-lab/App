package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class wo0 implements w40 {
    public final /* synthetic */ int d;
    public final /* synthetic */ qn1 e;

    public /* synthetic */ wo0(qn1 qn1Var, int i) {
        this.d = i;
        this.e = qn1Var;
    }

    @Override // defpackage.w40
    public final Object a() {
        int i = this.d;
        bw1 bw1Var = bw1.a;
        qn1 qn1Var = this.e;
        switch (i) {
            case 0:
                qn1Var.b();
                break;
            default:
                qn1Var.onCancel();
                break;
        }
        return bw1Var;
    }
}
