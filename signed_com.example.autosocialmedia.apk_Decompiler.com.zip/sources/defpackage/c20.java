package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class c20 implements l50 {
    public final /* synthetic */ long d;
    public final /* synthetic */ dq1 e;
    public final /* synthetic */ float f;
    public final /* synthetic */ qn g;

    public c20(long j, dq1 dq1Var, float f, qn qnVar) {
        this.d = j;
        this.e = dq1Var;
        this.f = f;
        this.g = qnVar;
    }

    @Override // defpackage.l50
    public final Object f(Object obj, Object obj2) {
        xo xoVar = (xo) obj;
        int iIntValue = ((Number) obj2).intValue();
        if (xoVar.O(iIntValue & 1, (iIntValue & 3) != 2)) {
            rm.h(this.d, this.e, jl.C(-1767363041, new b20(this.f, this.g), xoVar), xoVar, 384);
        } else {
            xoVar.R();
        }
        return bw1.a;
    }
}
