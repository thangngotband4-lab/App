package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class b6 extends ki0 implements l50 {
    public final /* synthetic */ int e;
    public final /* synthetic */ Object f;
    public final /* synthetic */ l50 g;
    public final /* synthetic */ Object h;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public b6(k5 k5Var, ba baVar, l50 l50Var) {
        super(2);
        this.e = 0;
        this.h = k5Var;
        this.f = baVar;
        this.g = l50Var;
    }

    @Override // defpackage.l50
    public final Object f(Object obj, Object obj2) {
        int i = this.e;
        bw1 bw1Var = bw1.a;
        l50 l50Var = this.g;
        Object obj3 = this.f;
        Object obj4 = this.h;
        switch (i) {
            case 0:
                xo xoVar = (xo) obj;
                int iIntValue = ((Number) obj2).intValue();
                if (!xoVar.O(iIntValue & 1, (iIntValue & 3) != 2)) {
                    xoVar.R();
                } else {
                    lp.a((k5) obj4, (ba) obj3, l50Var, xoVar, 0);
                }
                break;
            case 1:
                ((Number) obj2).intValue();
                lp.a((nz0) obj4, (ba) obj3, l50Var, (xo) obj, bm.T(1));
                break;
            default:
                ((Number) obj2).intValue();
                m22.o((vk1) obj4, (fr0) obj3, l50Var, (xo) obj, bm.T(9));
                break;
        }
        return bw1Var;
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ b6(Object obj, Object obj2, l50 l50Var, int i, int i2) {
        super(2);
        this.e = i2;
        this.h = obj;
        this.f = obj2;
        this.g = l50Var;
    }
}
