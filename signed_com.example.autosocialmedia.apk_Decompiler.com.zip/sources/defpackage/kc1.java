package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class kc1 implements pb1 {
    public final /* synthetic */ oc1 a;
    public final /* synthetic */ mc1 b;

    public kc1(oc1 oc1Var, mc1 mc1Var) {
        this.a = oc1Var;
        this.b = mc1Var;
    }

    @Override // defpackage.pb1
    public final float a(float f) {
        float fAbs = Math.abs(f);
        oc1 oc1Var = this.a;
        if (fAbs != 0.0f && !((Boolean) oc1Var.h.a()).booleanValue()) {
            throw new q10("The fling animation was cancelled", 0);
        }
        return oc1Var.d(oc1Var.g(this.b.a(2, oc1Var.e(oc1Var.h(f)))));
    }
}
