package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class au1 {
    public final yu1 a;
    public final m01 b = hl.I(null);
    public final /* synthetic */ fu1 c;

    public au1(fu1 fu1Var, yu1 yu1Var, String str) {
        this.c = fu1Var;
        this.a = yu1Var;
    }

    public final zt1 a(h50 h50Var, h50 h50Var2) {
        m01 m01Var = this.b;
        zt1 zt1Var = (zt1) m01Var.getValue();
        fu1 fu1Var = this.c;
        if (zt1Var == null) {
            Object objG = h50Var2.g(fu1Var.c());
            Object objG2 = h50Var2.g(fu1Var.c());
            yu1 yu1Var = this.a;
            fc fcVar = (fc) yu1Var.a.g(objG2);
            fcVar.d();
            du1 du1Var = new du1(fu1Var, objG, fcVar, yu1Var);
            zt1Var = new zt1(this, du1Var, h50Var, h50Var2);
            m01Var.setValue(zt1Var);
            fu1Var.i.add(du1Var);
        }
        zt1Var.f = h50Var2;
        zt1Var.e = h50Var;
        zt1Var.a(fu1Var.f());
        return zt1Var;
    }
}
