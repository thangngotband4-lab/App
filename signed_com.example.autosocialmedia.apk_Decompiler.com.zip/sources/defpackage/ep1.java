package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class ep1 {
    public static final ep1 c = new ep1(ak1.h(0), ak1.h(0));
    public final long a;
    public final long b;

    public ep1(long j, long j2) {
        this.a = j;
        this.b = j2;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof ep1)) {
            return false;
        }
        ep1 ep1Var = (ep1) obj;
        return gq1.a(this.a, ep1Var.a) && gq1.a(this.b, ep1Var.b);
    }

    public final int hashCode() {
        hq1[] hq1VarArr = gq1.b;
        return Long.hashCode(this.b) + (Long.hashCode(this.a) * 31);
    }

    public final String toString() {
        return "TextIndent(firstLine=" + ((Object) gq1.d(this.a)) + ", restLine=" + ((Object) gq1.d(this.b)) + ')';
    }
}
