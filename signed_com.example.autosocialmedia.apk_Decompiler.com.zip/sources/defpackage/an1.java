package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class an1 extends lu implements hp, h60 {
    public ko1 t;
    public final m01 u = new m01(null, a4.N);

    public an1(ko1 ko1Var) {
        this.t = ko1Var;
        d7 d7Var = new d7(5, this);
        m31 m31Var = ll1.a;
        M0(new pl1(null, null, d7Var));
    }

    @Override // defpackage.h60
    public final void u(pu0 pu0Var) {
        this.u.setValue(pu0Var);
    }
}
