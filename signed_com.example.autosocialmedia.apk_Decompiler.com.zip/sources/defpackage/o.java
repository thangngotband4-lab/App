package defpackage;

import android.content.Context;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import com.example.autosocialmedia.R;
import java.lang.ref.WeakReference;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public abstract class o extends ViewGroup {
    public WeakReference d;
    public IBinder e;
    public k12 f;
    public ap g;
    public py1 h;
    public boolean i;
    public boolean j;
    public boolean k;

    public o(Context context) {
        super(context, null, 0);
        setClipChildren(false);
        setClipToPadding(false);
        setImportantForAccessibility(1);
        m7 m7Var = new m7(1, this);
        addOnAttachStateChangeListener(m7Var);
        tz tzVar = new tz(19);
        fl.r(this).a.add(tzVar);
        this.h = new py1(this, m7Var, tzVar);
    }

    private final void setParentContext(ap apVar) {
        if (this.g != apVar) {
            this.g = apVar;
            if (apVar != null) {
                this.d = null;
            }
            k12 k12Var = this.f;
            if (k12Var != null) {
                k12Var.d();
                this.f = null;
                if (isAttachedToWindow()) {
                    d();
                }
            }
        }
    }

    private final void setPreviousAttachedWindowToken(IBinder iBinder) {
        if (this.e != iBinder) {
            this.e = iBinder;
            this.d = null;
        }
    }

    public abstract void a(int i, xo xoVar);

    @Override // android.view.ViewGroup
    public final void addView(View view) {
        c();
        super.addView(view);
    }

    @Override // android.view.ViewGroup
    public final boolean addViewInLayout(View view, int i, ViewGroup.LayoutParams layoutParams) {
        c();
        return super.addViewInLayout(view, i, layoutParams);
    }

    public final void c() {
        if (this.j) {
            return;
        }
        throw new UnsupportedOperationException("Cannot add views to " + getClass().getSimpleName() + "; only Compose content is supported");
    }

    /* JADX WARN: Multi-variable type inference failed */
    public final void d() {
        if (this.f == null) {
            boolean z = false;
            Object[] objArr = 0;
            try {
                this.j = true;
                this.f = m12.a(this, g(), new qn(-656146368, true, new n(objArr == true ? 1 : 0, this)));
            } finally {
                this.j = false;
            }
        }
    }

    public void e(boolean z, int i, int i2, int i3, int i4) {
        View childAt = getChildAt(0);
        if (childAt != null) {
            childAt.layout(getPaddingLeft(), getPaddingTop(), (i3 - i) - getPaddingRight(), (i4 - i2) - getPaddingBottom());
        }
    }

    public void f(int i, int i2) {
        View childAt = getChildAt(0);
        if (childAt == null) {
            super.onMeasure(i, i2);
            return;
        }
        childAt.measure(View.MeasureSpec.makeMeasureSpec(Math.max(0, (View.MeasureSpec.getSize(i) - getPaddingLeft()) - getPaddingRight()), View.MeasureSpec.getMode(i)), View.MeasureSpec.makeMeasureSpec(Math.max(0, (View.MeasureSpec.getSize(i2) - getPaddingTop()) - getPaddingBottom()), View.MeasureSpec.getMode(i2)));
        setMeasuredDimension(getPaddingRight() + getPaddingLeft() + childAt.getMeasuredWidth(), getPaddingBottom() + getPaddingTop() + childAt.getMeasuredHeight());
    }

    public final ap g() {
        r61 r61Var;
        ur urVar;
        aa aaVar;
        ap apVarB = this.g;
        if (apVarB == null) {
            apVarB = c12.b(this);
            if (apVarB == null) {
                Object parent = getParent();
                while (apVarB == null && (parent instanceof View)) {
                    View view = (View) parent;
                    apVarB = c12.b(view);
                    parent = ck1.d(view);
                }
            }
            boolean z = false;
            if (apVarB != null) {
                ap apVar = (!(apVarB instanceof r61) || ((n61) ((r61) apVarB).u.getValue()).compareTo(n61.e) > 0) ? apVarB : null;
                if (apVar != null) {
                    this.d = new WeakReference(apVar);
                }
            } else {
                apVarB = null;
            }
            if (apVarB == null) {
                WeakReference weakReference = this.d;
                if (weakReference == null || (apVarB = (ap) weakReference.get()) == null || ((apVarB instanceof r61) && ((n61) ((r61) apVarB).u.getValue()).compareTo(n61.e) <= 0)) {
                    apVarB = null;
                }
                if (apVarB == null) {
                    if (!isAttachedToWindow()) {
                        sd0.b("Cannot locate windowRecomposer; View " + this + " is not attached to a window");
                    }
                    View view2 = this;
                    Object parent2 = getParent();
                    while (parent2 instanceof View) {
                        View view3 = (View) parent2;
                        if (view3.getId() == 16908290) {
                            break;
                        }
                        view2 = view3;
                        parent2 = view3.getParent();
                    }
                    ap apVarB2 = c12.b(view2);
                    if (apVarB2 == null) {
                        ((w02) x02.a.get()).getClass();
                        ur urVar2 = rz.d;
                        ul1 ul1Var = y9.p;
                        if (Looper.myLooper() == Looper.getMainLooper()) {
                            urVar = (ur) y9.p.getValue();
                        } else {
                            urVar = (ur) y9.q.get();
                            if (urVar == null) {
                                zi.f("no AndroidUiDispatcher for this thread");
                                return null;
                            }
                        }
                        ur urVarI = urVar.i(urVar2);
                        aa aaVar2 = (aa) urVarI.k(a4.K);
                        if (aaVar2 != null) {
                            aaVar = new aa(aaVar2);
                            li0 li0Var = (li0) aaVar.f;
                            synchronized (li0Var.b) {
                                li0Var.a = false;
                            }
                        } else {
                            aaVar = null;
                        }
                        e71 e71Var = new e71();
                        ur mr0Var = (lr0) urVarI.k(a4.L);
                        if (mr0Var == null) {
                            mr0Var = new mr0();
                            e71Var.d = mr0Var;
                        }
                        if (aaVar != null) {
                            urVar2 = aaVar;
                        }
                        ur urVarI2 = urVarI.i(urVar2).i(mr0Var);
                        r61Var = new r61(urVarI2);
                        synchronized (r61Var.c) {
                            r61Var.t = true;
                        }
                        sq sqVarA = bm.a(urVarI2);
                        en0 en0VarG = ui1.g(view2);
                        zm0 lifecycle = en0VarG != null ? en0VarG.getLifecycle() : null;
                        if (lifecycle == null) {
                            sd0.c("ViewTreeLifecycleOwner not found from " + view2);
                            zi.h();
                            return null;
                        }
                        view2.addOnAttachStateChangeListener(new y02(view2, r61Var));
                        lifecycle.a(new a12(sqVarA, aaVar, r61Var, e71Var, view2));
                        view2.setTag(R.id.androidx_compose_ui_view_composition_context, r61Var);
                        Handler handler = view2.getHandler();
                        int i = ra0.a;
                        ur urVar3 = new qa0(handler, "windowRecomposer cleanup", false).i;
                        d dVar = new d(r61Var, view2, z ? 1 : 0, 26);
                        gs gsVar = gs.g;
                        if ((2 & 1) != 0) {
                            urVar3 = rz.d;
                        }
                        int i2 = 2;
                        if ((2 & 2) != 0) {
                            gsVar = gs.d;
                        }
                        ur urVarS = jl.s(rz.d, urVar3, true);
                        au auVar = rv.a;
                        if (urVarS != auVar && urVarS.k(a4.w) == null) {
                            urVarS = urVarS.i(auVar);
                        }
                        p ul0Var = gsVar == gs.e ? new ul0(urVarS, dVar) : new bj1(urVarS, true);
                        ul0Var.h0(gsVar, ul0Var, dVar);
                        view2.addOnAttachStateChangeListener(new m7(i2, ul0Var));
                    } else {
                        if (!(apVarB2 instanceof r61)) {
                            zi.f("root viewTreeParentCompositionContext is not a Recomposer");
                            return null;
                        }
                        r61Var = (r61) apVarB2;
                    }
                    r61 r61Var2 = ((n61) r61Var.u.getValue()).compareTo(n61.e) > 0 ? r61Var : null;
                    if (r61Var2 != null) {
                        this.d = new WeakReference(r61Var2);
                    }
                    return r61Var;
                }
            }
        }
        return apVarB;
    }

    /* JADX INFO: renamed from: getAutoClearFocusBehavior-4UtRPd4, reason: not valid java name */
    public final int m11getAutoClearFocusBehavior4UtRPd4() {
        Object tag = getTag(R.id.auto_clear_focus_behavior_tag);
        vd vdVar = tag instanceof vd ? (vd) tag : null;
        if (vdVar != null) {
            return vdVar.a;
        }
        return 1;
    }

    public final boolean getHasComposition() {
        return this.f != null;
    }

    public boolean getShouldCreateCompositionOnAttachedToWindow() {
        return true;
    }

    public final boolean getShowLayoutBounds() {
        return this.i;
    }

    @Override // android.view.ViewGroup
    public final boolean isTransitionGroup() {
        return !this.k || super.isTransitionGroup();
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        setPreviousAttachedWindowToken(getWindowToken());
        if (getShouldCreateCompositionOnAttachedToWindow()) {
            d();
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z, int i, int i2, int i3, int i4) {
        e(z, i, i2, i3, i4);
    }

    @Override // android.view.View
    public final void onMeasure(int i, int i2) {
        d();
        f(i, i2);
    }

    @Override // android.view.View
    public final void onRtlPropertiesChanged(int i) {
        View childAt = getChildAt(0);
        if (childAt != null) {
            childAt.setLayoutDirection(i);
        }
    }

    /* JADX INFO: renamed from: setAutoClearFocusBehavior-17tfJxM, reason: not valid java name */
    public final void m12setAutoClearFocusBehavior17tfJxM(int i) {
        setTag(R.id.auto_clear_focus_behavior_tag, new vd(i));
    }

    public final void setParentCompositionContext(ap apVar) {
        setParentContext(apVar);
    }

    public final void setShowLayoutBounds(boolean z) {
        this.i = z;
        KeyEvent.Callback childAt = getChildAt(0);
        if (childAt != null) {
            ((k5) ((nz0) childAt)).setShowLayoutBounds(z);
        }
    }

    @Override // android.view.ViewGroup
    public void setTransitionGroup(boolean z) {
        super.setTransitionGroup(z);
        this.k = true;
    }

    public final void setViewCompositionStrategy(qy1 qy1Var) {
        py1 py1Var = this.h;
        if (py1Var != null) {
            py1Var.a();
        }
        ((cd) qy1Var).getClass();
        m7 m7Var = new m7(1, this);
        addOnAttachStateChangeListener(m7Var);
        tz tzVar = new tz(19);
        fl.r(this).a.add(tzVar);
        this.h = new py1(this, m7Var, tzVar);
    }

    @Override // android.view.ViewGroup
    public final boolean shouldDelayChildPressedState() {
        return false;
    }

    @Override // android.view.ViewGroup
    public final void addView(View view, int i) {
        c();
        super.addView(view, i);
    }

    @Override // android.view.ViewGroup
    public final boolean addViewInLayout(View view, int i, ViewGroup.LayoutParams layoutParams, boolean z) {
        c();
        return super.addViewInLayout(view, i, layoutParams, z);
    }

    @Override // android.view.ViewGroup
    public final void addView(View view, int i, int i2) {
        c();
        super.addView(view, i, i2);
    }

    @Override // android.view.ViewGroup, android.view.ViewManager
    public final void addView(View view, ViewGroup.LayoutParams layoutParams) {
        c();
        super.addView(view, layoutParams);
    }

    @Override // android.view.ViewGroup
    public final void addView(View view, int i, ViewGroup.LayoutParams layoutParams) {
        c();
        super.addView(view, i, layoutParams);
    }

    private static /* synthetic */ void getDisposeViewCompositionStrategy$annotations() {
    }

    public static /* synthetic */ void getShowLayoutBounds$annotations() {
    }
}
