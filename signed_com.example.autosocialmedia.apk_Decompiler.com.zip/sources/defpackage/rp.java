package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class rp extends uh {
    public final sh s;

    public rp(int i, sh shVar) {
        super(i);
        this.s = shVar;
        if (shVar == sh.d) {
            tz.h("This implementation does not support suspension for senders, use ", f71.a(uh.class).a(), " instead");
            throw null;
        }
        if (i >= 1) {
            return;
        }
        tz.e(f0.j(i, "Buffered channel capacity must be at least 1, but ", " was specified"));
        throw null;
    }

    public final Object M(Object obj, boolean z) {
        if (this.s != sh.f) {
            return I(obj);
        }
        Object objS = super.s(obj);
        return (!(objS instanceof xj) || (objS instanceof wj)) ? objS : bw1.a;
    }

    @Override // defpackage.uh, defpackage.ge1
    public final Object c(tq tqVar, Object obj) throws Throwable {
        if (M(obj, true) instanceof wj) {
            throw t();
        }
        return bw1.a;
    }

    @Override // defpackage.uh, defpackage.ge1
    public final Object s(Object obj) {
        return M(obj, false);
    }

    @Override // defpackage.uh
    public final boolean z() {
        return this.s == sh.e;
    }
}
