package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class y6 extends ki0 implements l50 {
    public final /* synthetic */ fr0 e;
    public final /* synthetic */ l50 f;
    public final /* synthetic */ int g;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public y6(fr0 fr0Var, l50 l50Var, int i) {
        super(2);
        this.e = fr0Var;
        this.f = l50Var;
        this.g = i;
    }

    @Override // defpackage.l50
    public final Object f(Object obj, Object obj2) {
        ((Number) obj2).intValue();
        int iT = bm.T(this.g | 1);
        vh0.r(this.e, this.f, (xo) obj, iT);
        return bw1.a;
    }
}
