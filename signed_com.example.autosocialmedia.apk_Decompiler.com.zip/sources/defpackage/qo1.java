package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class qo1 implements qn1 {
    public wp1 b;
    public final /* synthetic */ so1 d;
    public boolean a = true;
    public tz c = a4.V;

    public qo1(so1 so1Var) {
        this.d = so1Var;
    }

    @Override // defpackage.qn1
    public final void a(long j, tz tzVar) {
        long j2;
        qp1 qp1VarD;
        qp1 qp1VarD2;
        so1 so1Var = this.d;
        m01 m01Var = so1Var.q;
        if (so1Var.k() && ((la0) m01Var.getValue()) == null) {
            m01Var.setValue(la0.f);
            so1Var.s = -1;
            this.a = true;
            this.c = tzVar;
            so1Var.o();
            em0 em0Var = so1Var.d;
            if (em0Var == null || (qp1VarD2 = em0Var.d()) == null || !qp1VarD2.c(j)) {
                j2 = j;
                em0 em0Var2 = so1Var.d;
                if (em0Var2 != null && (qp1VarD = em0Var2.d()) != null) {
                    int iA = so1Var.b.a(qp1VarD.b(j2, true));
                    zo1 zo1VarE = so1.e(so1Var.n().a, jj1.b(iA, iA));
                    so1Var.h(false);
                    ua0 ua0Var = so1Var.j;
                    if (ua0Var != null) {
                        ua0Var.a();
                    }
                    so1Var.c.g(zo1VarE);
                    so1Var.v = new wp1(zo1VarE.b);
                }
                this.a = false;
            } else {
                if (so1Var.n().a.e.length() == 0) {
                    return;
                }
                so1Var.h(false);
                long jC = so1.c(so1Var, zo1.a(so1Var.n(), null, wp1.b, 5), j, true, false, this.c, true);
                j2 = j;
                so1Var.o = new wp1(jC);
                this.b = new wp1(jC);
            }
            so1Var.q(na0.d);
            so1Var.n = j2;
            so1Var.r.setValue(new jw0(j2));
            so1Var.p = 0L;
        }
    }

    @Override // defpackage.qn1
    public final void b() {
        f();
    }

    /* JADX WARN: Removed duplicated region for block: B:21:0x008e  */
    @Override // defpackage.qn1
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void e(long r9) {
        /*
            Method dump skipped, instruction units count: 222
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.qo1.e(long):void");
    }

    public final void f() {
        so1 so1Var = this.d;
        so1Var.q.setValue(null);
        so1Var.r.setValue(null);
        this.c = a4.V;
        so1Var.t(true);
        wp1 wp1Var = this.b;
        boolean zC = wp1.c(wp1Var != null ? wp1Var.a : so1Var.n().b);
        so1Var.q(zC ? na0.f : na0.e);
        em0 em0Var = so1Var.d;
        if (em0Var != null) {
            em0Var.m.setValue(Boolean.valueOf(!zC && ck1.e(so1Var, true)));
        }
        em0 em0Var2 = so1Var.d;
        if (em0Var2 != null) {
            em0Var2.n.setValue(Boolean.valueOf(!zC && ck1.e(so1Var, false)));
        }
        em0 em0Var3 = so1Var.d;
        if (em0Var3 != null) {
            em0Var3.o.setValue(Boolean.valueOf(zC && ck1.e(so1Var, true)));
        }
        if (this.a) {
            so1.b(so1Var, so1Var.o);
        }
        so1Var.o = null;
    }

    @Override // defpackage.qn1
    public final void onCancel() {
        f();
    }

    @Override // defpackage.qn1
    public final void c() {
    }

    @Override // defpackage.qn1
    public final void d() {
    }
}
