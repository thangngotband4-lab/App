package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class pc0 implements qc0 {
    public final ru0 d;

    public pc0(ru0 ru0Var) {
        this.d = ru0Var;
    }

    @Override // defpackage.qc0
    public final boolean b() {
        return false;
    }

    @Override // defpackage.qc0
    public final ru0 d() {
        return this.d;
    }
}
