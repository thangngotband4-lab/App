package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class uu1 extends tu1 {
    public final /* synthetic */ int g;

    @Override // java.util.Iterator
    public final Object next() {
        switch (this.g) {
            case 0:
                int i = this.f;
                this.f = i + 2;
                Object[] objArr = this.d;
                return new bq0(objArr[i], 0, objArr[i + 1]);
            case 1:
                int i2 = this.f;
                this.f = i2 + 2;
                return this.d[i2];
            default:
                int i3 = this.f;
                this.f = i3 + 2;
                return this.d[i3 + 1];
        }
    }
}
