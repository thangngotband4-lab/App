package defpackage;

import android.view.ActionMode;
import android.view.View;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class q9 implements fn1 {
    public final View a;
    public final h50 b;
    public final w40 c;
    public final pt0 d = new pt0();
    public final li1 e = new li1(new k9(this, 0));
    public final k9 f = new k9(this, 1);
    public final k9 g = new k9(this, 2);
    public ActionMode h;
    public o9 i;
    public l5 j;

    public q9(View view, h50 h50Var, w40 w40Var) {
        this.a = view;
        this.b = h50Var;
        this.c = w40Var;
    }

    @Override // defpackage.fn1
    public final Object a(wm1 wm1Var, jl1 jl1Var) {
        tq tqVar = null;
        p9 p9Var = new p9(this, wm1Var, tqVar, 0);
        pt0 pt0Var = this.d;
        pt0Var.getClass();
        Object objT = bm.t(new wa(pt0Var, p9Var, tqVar, 2), jl1Var);
        return objT == es.d ? objT : bw1.a;
    }
}
