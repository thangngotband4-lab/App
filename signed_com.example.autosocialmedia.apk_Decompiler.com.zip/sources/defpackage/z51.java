package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public abstract class z51 extends pi implements qh0 {
    public final boolean j;

    public z51(Object obj, Class cls, String str, String str2, int i) {
        super(obj, cls, str, str2, (i & 1) == 1);
        this.j = false;
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (obj instanceof z51) {
            z51 z51Var = (z51) obj;
            return e().equals(z51Var.e()) && this.g.equals(z51Var.g) && this.h.equals(z51Var.h) && ng0.o(this.e, z51Var.e);
        }
        if (obj instanceof qh0) {
            return obj.equals(h());
        }
        return false;
    }

    public final kh0 h() {
        if (this.j) {
            return this;
        }
        kh0 kh0Var = this.d;
        if (kh0Var != null) {
            return kh0Var;
        }
        kh0 kh0VarD = d();
        this.d = kh0VarD;
        return kh0VarD;
    }

    public final int hashCode() {
        return this.h.hashCode() + f0.e(e().hashCode() * 31, 31, this.g);
    }

    public final String toString() {
        kh0 kh0VarH = h();
        if (kh0VarH != this) {
            return kh0VarH.toString();
        }
        return "property " + this.g + " (Kotlin reflection is not available)";
    }
}
