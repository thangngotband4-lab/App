package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class cc extends fc {
    public float a;
    public float b;

    public cc(float f, float f2) {
        this.a = f;
        this.b = f2;
    }

    @Override // defpackage.fc
    public final float a(int i) {
        if (i == 0) {
            return this.a;
        }
        if (i != 1) {
            return 0.0f;
        }
        return this.b;
    }

    @Override // defpackage.fc
    public final int b() {
        return 2;
    }

    @Override // defpackage.fc
    public final fc c() {
        return new cc(0.0f, 0.0f);
    }

    @Override // defpackage.fc
    public final void d() {
        this.a = 0.0f;
        this.b = 0.0f;
    }

    @Override // defpackage.fc
    public final void e(float f, int i) {
        if (i == 0) {
            this.a = f;
        } else {
            if (i != 1) {
                return;
            }
            this.b = f;
        }
    }

    public final boolean equals(Object obj) {
        if (!(obj instanceof cc)) {
            return false;
        }
        cc ccVar = (cc) obj;
        return ccVar.a == this.a && ccVar.b == this.b;
    }

    public final int hashCode() {
        return Float.hashCode(this.b) + (Float.hashCode(this.a) * 31);
    }

    public final String toString() {
        return "AnimationVector2D: v1 = " + this.a + ", v2 = " + this.b;
    }
}
