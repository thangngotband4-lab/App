package defpackage;

import java.util.concurrent.atomic.AtomicReference;
import java.util.concurrent.atomic.AtomicReferenceArray;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public abstract /* synthetic */ class f0 {
    public static /* synthetic */ boolean A(AtomicReferenceArray atomicReferenceArray, int i, Object obj, Object obj2) {
        while (!atomicReferenceArray.compareAndSet(i, obj, obj2)) {
            if (atomicReferenceArray.get(i) != obj) {
                return false;
            }
        }
        return true;
    }

    public static /* synthetic */ boolean B(AtomicReferenceFieldUpdater atomicReferenceFieldUpdater, Object obj, Object obj2, Object obj3) {
        while (!atomicReferenceFieldUpdater.compareAndSet(obj, obj2, obj3)) {
            if (atomicReferenceFieldUpdater.get(obj) != obj2) {
                return false;
            }
        }
        return true;
    }

    public static long C(cr0 cr0Var, float f, xo xoVar) {
        om.d(xoVar, ig1.f(cr0Var, f));
        return sl.l();
    }

    public static int a(float f, int i, int i2) {
        return (Float.hashCode(f) + i) * i2;
    }

    public static int b(int i, int i2, int i3) {
        return (Integer.hashCode(i) + i2) * i3;
    }

    public static int c(int i, int i2, long j) {
        return (Long.hashCode(j) + i) * i2;
    }

    public static int d(int i, int i2, dq1 dq1Var) {
        return (dq1Var.hashCode() + i) * i2;
    }

    public static int e(int i, int i2, String str) {
        return (str.hashCode() + i) * i2;
    }

    public static int f(int i, int i2, boolean z) {
        return (Boolean.hashCode(z) + i) * i2;
    }

    public static long g(cr0 cr0Var, float f, xo xoVar) {
        om.d(xoVar, ig1.b(cr0Var, f));
        return sl.m();
    }

    public static l1 h(float f, float f2) {
        l1 l1Var = new l1(16);
        l1Var.v(f, f2);
        return l1Var;
    }

    public static ym i(String str) {
        sd0.c(str);
        return new ym();
    }

    public static String j(int i, String str, String str2) {
        return str + i + str2;
    }

    public static String k(String str, int i) {
        return str + i;
    }

    public static String l(String str, int i, String str2, int i2) {
        return str + i + str2 + i2;
    }

    public static String m(String str, String str2) {
        return str + str2;
    }

    public static String n(String str, String str2, String str3) {
        return str + str2 + str3;
    }

    public static String o(StringBuilder sb, float f, char c) {
        sb.append(f);
        sb.append(c);
        return sb.toString();
    }

    public static String p(StringBuilder sb, int i, char c) {
        sb.append(i);
        sb.append(c);
        return sb.toString();
    }

    public static StringBuilder q(int i, String str, String str2) {
        StringBuilder sb = new StringBuilder(str);
        sb.append(i);
        sb.append(str2);
        return sb;
    }

    public static void r(int i, int i2, int i3, int i4, int i5) {
        rm.f(i);
        rm.f(i2);
        rm.f(i3);
        rm.f(i4);
        rm.f(i5);
    }

    public static void s(int i, xo xoVar, int i2, oa oaVar) {
        xoVar.g0(Integer.valueOf(i));
        xoVar.b(oaVar, Integer.valueOf(i2));
    }

    public static void t(int i, xo xoVar, oa oaVar, xo xoVar2, c5 c5Var) {
        ak1.j(xoVar, Integer.valueOf(i), oaVar);
        ak1.n(xoVar2, c5Var);
    }

    public static void u(long j, StringBuilder sb, String str) {
        sb.append((Object) ql.i(j));
        sb.append(str);
    }

    public static void v(yc ycVar, long j) {
        ycVar.f().i();
        ycVar.r(j);
    }

    public static void w(xo xoVar, boolean z, cr0 cr0Var, float f, xo xoVar2) {
        xoVar.p(z);
        om.d(xoVar2, ig1.b(cr0Var, f));
    }

    public static /* synthetic */ void x(Object obj) {
        if (obj == null) {
            return;
        }
        zi.e();
    }

    public static void y(StringBuilder sb, int i, String str, int i2, String str2) {
        sb.append(i);
        sb.append(str);
        sb.append(i2);
        sb.append(str2);
    }

    public static /* synthetic */ boolean z(AtomicReference atomicReference, Object obj, Object obj2) {
        while (!atomicReference.compareAndSet(obj, obj2)) {
            if (atomicReference.get() != obj) {
                return false;
            }
        }
        return true;
    }
}
