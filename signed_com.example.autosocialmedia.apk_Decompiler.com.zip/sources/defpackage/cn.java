package defpackage;

import com.example.autosocialmedia.MainActivity;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class cn implements yw0 {
    public final /* synthetic */ MainActivity a;

    public /* synthetic */ cn(MainActivity mainActivity) {
        this.a = mainActivity;
    }
}
