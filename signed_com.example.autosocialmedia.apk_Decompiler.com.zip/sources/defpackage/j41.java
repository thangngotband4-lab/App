package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class j41 {
    public final int a;
    public final boolean b;
    public final boolean c;
    public final boolean d;
    public final boolean e;

    public j41(boolean z, pc1 pc1Var, boolean z2) {
        mp mpVar = u8.a;
        int i = !z ? 262152 : 262144;
        i = pc1Var == pc1.e ? i | 8192 : i;
        i = z2 ? i : i | 512;
        boolean z3 = pc1Var == pc1.d;
        this.a = i;
        this.b = z3;
        this.c = true;
        this.d = true;
        this.e = true;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof j41)) {
            return false;
        }
        j41 j41Var = (j41) obj;
        return this.a == j41Var.a && this.b == j41Var.b && this.c == j41Var.c && this.d == j41Var.d && this.e == j41Var.e;
    }

    public final int hashCode() {
        return Boolean.hashCode(false) + f0.f(f0.f(f0.f(f0.f(this.a * 31, 31, this.b), 31, this.c), 31, this.d), 31, this.e);
    }
}
