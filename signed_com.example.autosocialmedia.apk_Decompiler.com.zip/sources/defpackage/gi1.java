package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class gi1 implements f20 {
    public final /* synthetic */ int d;
    public final /* synthetic */ i51 e;

    public /* synthetic */ gi1(i51 i51Var, int i) {
        this.d = i;
        this.e = i51Var;
    }

    @Override // defpackage.f20
    public final Object k(Object obj, tq tqVar) {
        int i = this.d;
        bw1 bw1Var = bw1.a;
        i51 i51Var = this.e;
        switch (i) {
            case 0:
                i51Var.setValue(obj);
                break;
            default:
                i51Var.setValue(obj);
                break;
        }
        return bw1Var;
    }
}
