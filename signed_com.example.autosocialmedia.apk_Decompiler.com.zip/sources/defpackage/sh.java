package defpackage;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class sh {
    public static final sh d;
    public static final sh e;
    public static final sh f;
    public static final /* synthetic */ sh[] g;

    static {
        sh shVar = new sh("SUSPEND", 0);
        d = shVar;
        sh shVar2 = new sh("DROP_OLDEST", 1);
        e = shVar2;
        sh shVar3 = new sh("DROP_LATEST", 2);
        f = shVar3;
        g = new sh[]{shVar, shVar2, shVar3};
    }

    public static sh valueOf(String str) {
        return (sh) Enum.valueOf(sh.class, str);
    }

    public static sh[] values() {
        return (sh[]) g.clone();
    }
}
