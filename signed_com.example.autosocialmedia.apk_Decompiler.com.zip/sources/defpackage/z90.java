package defpackage;

import kotlin.Metadata;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u000e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0082\b\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001¨\u0006\u0003"}, d2 = {"Lz90;", "Ljr0;", "Leg1;", "ui"}, k = 1, mv = {2, 0, 0}, xi = 48)
final /* data */ class z90 extends jr0 {
    public final float a;
    public final float b;
    public final float c;
    public final float d;
    public final long e;
    public final qf1 f;
    public final boolean g;
    public final long h;
    public final long i;

    public z90(float f, float f2, float f3, float f4, long j, qf1 qf1Var, boolean z, long j2, long j3) {
        this.a = f;
        this.b = f2;
        this.c = f3;
        this.d = f4;
        this.e = j;
        this.f = qf1Var;
        this.g = z;
        this.h = j2;
        this.i = j3;
    }

    @Override // defpackage.jr0
    public final er0 e() {
        eg1 eg1Var = new eg1();
        eg1Var.r = this.a;
        eg1Var.s = this.b;
        eg1Var.t = this.c;
        eg1Var.u = this.d;
        eg1Var.v = 8.0f;
        eg1Var.w = this.e;
        eg1Var.x = this.f;
        eg1Var.y = this.g;
        eg1Var.z = this.h;
        eg1Var.A = this.i;
        eg1Var.B = 3;
        eg1Var.C = new g4(24, eg1Var);
        return eg1Var;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof z90)) {
            return false;
        }
        z90 z90Var = (z90) obj;
        return Float.compare(this.a, z90Var.a) == 0 && Float.compare(this.b, z90Var.b) == 0 && Float.compare(this.c, z90Var.c) == 0 && Float.compare(0.0f, 0.0f) == 0 && Float.compare(0.0f, 0.0f) == 0 && Float.compare(this.d, z90Var.d) == 0 && Float.compare(0.0f, 0.0f) == 0 && Float.compare(0.0f, 0.0f) == 0 && Float.compare(0.0f, 0.0f) == 0 && Float.compare(8.0f, 8.0f) == 0 && wt1.a(this.e, z90Var.e) && ng0.o(this.f, z90Var.f) && this.g == z90Var.g && ql.c(this.h, z90Var.h) && ql.c(this.i, z90Var.i);
    }

    @Override // defpackage.jr0
    public final void f(er0 er0Var) {
        pu0 pu0Var;
        eg1 eg1Var = (eg1) er0Var;
        eg1Var.r = this.a;
        eg1Var.s = this.b;
        eg1Var.t = this.c;
        eg1Var.u = this.d;
        eg1Var.v = 8.0f;
        eg1Var.w = this.e;
        eg1Var.x = this.f;
        eg1Var.y = this.g;
        eg1Var.z = this.h;
        eg1Var.A = this.i;
        eg1Var.B = 3;
        g4 g4Var = eg1Var.C;
        if (eg1Var.d.q && (pu0Var = tl.K(eg1Var, 2).s) != null) {
            pu0Var.s1(g4Var, true);
        }
    }

    public final int hashCode() {
        int iA = f0.a(8.0f, f0.a(0.0f, f0.a(0.0f, f0.a(0.0f, f0.a(this.d, f0.a(0.0f, f0.a(0.0f, f0.a(this.c, f0.a(this.b, Float.hashCode(this.a) * 31, 31), 31), 31), 31), 31), 31), 31), 31), 31);
        int i = wt1.c;
        int iF = f0.f((this.f.hashCode() + f0.c(iA, 31, this.e)) * 31, 961, this.g);
        int i2 = ql.h;
        return f0.b(3, f0.b(0, f0.c(f0.c(iF, 31, this.h), 31, this.i), 31), 31);
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder("GraphicsLayerElement(scaleX=");
        sb.append(this.a);
        sb.append(", scaleY=");
        sb.append(this.b);
        sb.append(", alpha=");
        sb.append(this.c);
        sb.append(", translationX=0.0, translationY=0.0, shadowElevation=");
        sb.append(this.d);
        sb.append(", rotationX=0.0, rotationY=0.0, rotationZ=0.0, cameraDistance=8.0, transformOrigin=");
        sb.append((Object) wt1.b(this.e));
        sb.append(", shape=");
        sb.append(this.f);
        sb.append(", clip=");
        sb.append(this.g);
        sb.append(", renderEffect=null, ambientShadowColor=");
        f0.u(this.h, sb, ", spotShadowColor=");
        sb.append((Object) ql.i(this.i));
        sb.append(", compositingStrategy=CompositingStrategy(value=0), blendMode=");
        sb.append((Object) ct.M(3));
        sb.append(", colorFilter=null)");
        return sb.toString();
    }
}
