package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class ru0 extends ko0 implements qc0 {
    @Override // defpackage.qc0
    public final boolean b() {
        return true;
    }

    @Override // defpackage.ko0
    public final boolean n() {
        return false;
    }

    @Override // defpackage.qc0
    public final ru0 d() {
        return this;
    }
}
