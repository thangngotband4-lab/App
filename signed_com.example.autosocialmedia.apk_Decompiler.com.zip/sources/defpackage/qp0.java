package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class qp0 implements h50 {
    public final /* synthetic */ int d;
    public final /* synthetic */ gt0 e;

    public /* synthetic */ qp0(gt0 gt0Var, int i) {
        this.d = i;
        this.e = gt0Var;
    }

    @Override // defpackage.h50
    public final Object g(Object obj) {
        int i = this.d;
        bw1 bw1Var = bw1.a;
        gt0 gt0Var = this.e;
        switch (i) {
            case 0:
                ib1 ib1Var = (ib1) obj;
                ib1Var.getClass();
                gt0Var.setValue(ib1Var);
                break;
            case 1:
                Boolean bool = (Boolean) obj;
                bool.booleanValue();
                gt0Var.setValue(bool);
                break;
            case 2:
                Float f = (Float) obj;
                f.floatValue();
                gt0Var.setValue(f);
                break;
            case 3:
                Float f2 = (Float) obj;
                f2.floatValue();
                gt0Var.setValue(f2);
                break;
            case 4:
                Boolean bool2 = (Boolean) obj;
                bool2.booleanValue();
                gt0Var.setValue(bool2);
                break;
            case 5:
                Boolean bool3 = (Boolean) obj;
                bool3.booleanValue();
                gt0Var.setValue(bool3);
                break;
            case 6:
                Float f3 = (Float) obj;
                f3.floatValue();
                gt0Var.setValue(f3);
                break;
            case 7:
                Float f4 = (Float) obj;
                f4.floatValue();
                gt0Var.setValue(f4);
                break;
            case 8:
                Boolean bool4 = (Boolean) obj;
                bool4.booleanValue();
                gt0Var.setValue(bool4);
                break;
            case 9:
                Float f5 = (Float) obj;
                f5.floatValue();
                gt0Var.setValue(f5);
                break;
            case 10:
                Float f6 = (Float) obj;
                f6.floatValue();
                gt0Var.setValue(f6);
                break;
            case 11:
                Boolean bool5 = (Boolean) obj;
                bool5.getClass();
                gt0Var.setValue(bool5);
                break;
            case 12:
                Float f7 = (Float) obj;
                f7.getClass();
                gt0Var.setValue(f7);
                break;
            case 13:
                Float f8 = (Float) obj;
                f8.getClass();
                gt0Var.setValue(f8);
                break;
            case 14:
                String str = (String) obj;
                str.getClass();
                gt0Var.setValue(str);
                break;
            case 15:
                Float f9 = (Float) obj;
                f9.floatValue();
                gt0Var.setValue(f9);
                break;
            case 16:
                Float f10 = (Float) obj;
                f10.floatValue();
                gt0Var.setValue(f10);
                break;
            case 17:
                Float f11 = (Float) obj;
                f11.floatValue();
                gt0Var.setValue(f11);
                break;
            case 18:
                Boolean bool6 = (Boolean) obj;
                bool6.booleanValue();
                gt0Var.setValue(bool6);
                break;
            case 19:
                Float f12 = (Float) obj;
                f12.floatValue();
                gt0Var.setValue(f12);
                break;
            case e80.MAX_VERIFY /* 20 */:
                gt0Var.setValue((qi0) obj);
                break;
            case 21:
                Float f13 = (Float) obj;
                f13.getClass();
                break;
            case 22:
                Boolean bool7 = (Boolean) obj;
                bool7.booleanValue();
                gt0Var.setValue(bool7);
                break;
            case 23:
                Boolean bool8 = (Boolean) obj;
                bool8.booleanValue();
                gt0Var.setValue(bool8);
                break;
            case 24:
                ((h50) gt0Var.getValue()).g((jw0) obj);
                break;
            case 25:
                String str2 = (String) obj;
                str2.getClass();
                gt0Var.setValue(str2);
                break;
            case 26:
                Boolean bool9 = (Boolean) obj;
                bool9.booleanValue();
                gt0Var.setValue(bool9);
                break;
            case 27:
                Boolean bool10 = (Boolean) obj;
                bool10.booleanValue();
                gt0Var.setValue(bool10);
                break;
            case 28:
                Boolean bool11 = (Boolean) obj;
                bool11.booleanValue();
                gt0Var.setValue(bool11);
                break;
            default:
                Boolean bool12 = (Boolean) obj;
                bool12.booleanValue();
                gt0Var.setValue(bool12);
                break;
        }
        return bw1Var;
    }
}
