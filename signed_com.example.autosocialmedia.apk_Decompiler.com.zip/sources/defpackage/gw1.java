package defpackage;

import java.io.Serializable;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class gw1 implements zj0, Serializable {
    public w40 d;
    public Object e;

    @Override // defpackage.zj0
    public final Object getValue() {
        if (this.e == dp1.h) {
            w40 w40Var = this.d;
            w40Var.getClass();
            this.e = w40Var.a();
            this.d = null;
        }
        return this.e;
    }

    public final String toString() {
        return this.e != dp1.h ? String.valueOf(getValue()) : "Lazy value not initialized yet.";
    }
}
