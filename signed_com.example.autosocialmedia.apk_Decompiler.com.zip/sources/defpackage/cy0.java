package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class cy0 extends ny0 {
    public static final cy0 c = new cy0(0, 0, 3);

    @Override // defpackage.ny0
    public final void a(y50 y50Var, ad adVar, mh1 mh1Var, l71 l71Var, oy0 oy0Var) {
        mh1Var.n(mh1Var.t, new a8(2, l71Var));
        mh1Var.H();
    }
}
