package defpackage;

import android.view.DragEvent;
import android.view.View;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class b7 implements View.OnDragListener, mw {
    public final ow a;
    public final rd b;
    public final a7 c;

    public b7() {
        ow owVar = new ow();
        owVar.t = 0L;
        this.a = owVar;
        this.b = new rd();
        this.c = new a7(this);
    }

    @Override // android.view.View.OnDragListener
    public final boolean onDrag(View view, DragEvent dragEvent) {
        l1 l1Var = new l1(8, dragEvent);
        int action = dragEvent.getAction();
        lu1 lu1Var = lu1.d;
        rd rdVar = this.b;
        ow owVar = this.a;
        switch (action) {
            case 1:
                a71 a71Var = new a71();
                nw nwVar = new nw(l1Var, owVar, a71Var);
                if (nwVar.g(owVar) == lu1Var) {
                    cd.m(owVar, nwVar);
                }
                boolean z = a71Var.d;
                rdVar.getClass();
                md mdVar = new md(rdVar);
                while (mdVar.hasNext()) {
                    ((ow) mdVar.next()).Q0();
                }
                break;
            case 2:
                owVar.P0(l1Var);
                break;
            case 4:
                g4 g4Var = new g4(12, l1Var);
                if (g4Var.g(owVar) == lu1Var) {
                    cd.m(owVar, g4Var);
                }
                rdVar.clear();
                break;
            case 5:
                owVar.N0();
                break;
            case 6:
                owVar.O0();
                break;
        }
        return false;
    }
}
