package defpackage;

import kotlin.Metadata;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\n\u0018\u00002\f\u0012\b\u0012\u00060\u0002R\u00020\u00030\u0001¨\u0006\u0004"}, d2 = {"Li5;", "Ljr0;", "Lw4;", "Lk5;", "ui"}, k = 1, mv = {2, 0, 0}, xi = 48)
public final class i5 extends jr0 {
    public final /* synthetic */ k5 a;

    public i5(k5 k5Var) {
        this.a = k5Var;
    }

    @Override // defpackage.jr0
    public final er0 e() {
        return new w4(this.a);
    }

    public final boolean equals(Object obj) {
        return obj == this;
    }

    @Override // defpackage.jr0
    public final /* bridge */ /* synthetic */ void f(er0 er0Var) {
    }

    public final int hashCode() {
        return this.a.hashCode();
    }
}
