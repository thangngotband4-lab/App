package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class b1 extends z0 {
    public static b1 e;
    public static final z71 f = z71.e;
    public static final z71 g = z71.d;
    public pp1 c;
    public pd1 d;

    @Override // defpackage.z0
    public final int[] a(int i) {
        int iE;
        if (c().length() > 0 && i < c().length()) {
            try {
                pd1 pd1Var = this.d;
                if (pd1Var == null) {
                    ng0.N("node");
                    throw null;
                }
                x61 x61VarG = pd1Var.g();
                int iRound = Math.round(x61VarG.d - x61VarG.b);
                if (i <= 0) {
                    i = 0;
                }
                pp1 pp1Var = this.c;
                if (pp1Var == null) {
                    ng0.N("layoutResult");
                    throw null;
                }
                int iD = pp1Var.b.d(i);
                pp1 pp1Var2 = this.c;
                if (pp1Var2 == null) {
                    ng0.N("layoutResult");
                    throw null;
                }
                float f2 = pp1Var2.b.f(iD) + iRound;
                pp1 pp1Var3 = this.c;
                if (pp1Var3 == null) {
                    ng0.N("layoutResult");
                    throw null;
                }
                float f3 = pp1Var3.b.f(r0.f - 1);
                pp1 pp1Var4 = this.c;
                if (f2 < f3) {
                    if (pp1Var4 == null) {
                        ng0.N("layoutResult");
                        throw null;
                    }
                    iE = pp1Var4.b.e(f2);
                } else {
                    if (pp1Var4 == null) {
                        ng0.N("layoutResult");
                        throw null;
                    }
                    iE = pp1Var4.b.f;
                }
                return b(i, e(iE - 1, g) + 1);
            } catch (IllegalStateException unused) {
            }
        }
        return null;
    }

    @Override // defpackage.z0
    public final int[] d(int i) {
        int iE;
        if (c().length() > 0 && i > 0) {
            try {
                pd1 pd1Var = this.d;
                if (pd1Var == null) {
                    ng0.N("node");
                    throw null;
                }
                x61 x61VarG = pd1Var.g();
                int iRound = Math.round(x61VarG.d - x61VarG.b);
                int length = c().length();
                if (length <= i) {
                    i = length;
                }
                pp1 pp1Var = this.c;
                if (pp1Var == null) {
                    ng0.N("layoutResult");
                    throw null;
                }
                int iD = pp1Var.b.d(i);
                pp1 pp1Var2 = this.c;
                if (pp1Var2 == null) {
                    ng0.N("layoutResult");
                    throw null;
                }
                float f2 = pp1Var2.b.f(iD) - iRound;
                if (f2 > 0.0f) {
                    pp1 pp1Var3 = this.c;
                    if (pp1Var3 == null) {
                        ng0.N("layoutResult");
                        throw null;
                    }
                    iE = pp1Var3.b.e(f2);
                } else {
                    iE = 0;
                }
                if (i == c().length() && iE < iD) {
                    iE++;
                }
                return b(e(iE, f), i);
            } catch (IllegalStateException unused) {
            }
        }
        return null;
    }

    public final int e(int i, z71 z71Var) {
        pp1 pp1Var = this.c;
        if (pp1Var == null) {
            ng0.N("layoutResult");
            throw null;
        }
        int iF = pp1Var.f(i);
        pp1 pp1Var2 = this.c;
        if (pp1Var2 == null) {
            ng0.N("layoutResult");
            throw null;
        }
        z71 z71VarG = pp1Var2.g(iF);
        pp1 pp1Var3 = this.c;
        if (z71Var != z71VarG) {
            if (pp1Var3 != null) {
                return pp1Var3.f(i);
            }
            ng0.N("layoutResult");
            throw null;
        }
        if (pp1Var3 != null) {
            return pp1Var3.b.c(i, false) - 1;
        }
        ng0.N("layoutResult");
        throw null;
    }
}
