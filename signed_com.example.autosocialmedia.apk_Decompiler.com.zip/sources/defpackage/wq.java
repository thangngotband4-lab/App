package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class wq extends er0 implements nd1 {
    public boolean r;
    public h50 s;

    @Override // defpackage.nd1
    public final void k0(yd1 yd1Var) {
        this.s.g(yd1Var);
    }

    @Override // defpackage.nd1
    public final boolean m0() {
        return false;
    }

    @Override // defpackage.nd1
    public final boolean n0() {
        return this.r;
    }
}
