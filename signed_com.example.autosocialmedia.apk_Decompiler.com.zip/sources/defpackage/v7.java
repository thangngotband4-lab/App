package defpackage;

import android.content.Context;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class v7 extends jl1 implements l50 {
    public final /* synthetic */ int e;
    public int f;
    public /* synthetic */ Object g;
    public Object h;
    public final /* synthetic */ Object i;
    public final /* synthetic */ Object j;
    public final /* synthetic */ Object k;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ v7(Object obj, Object obj2, Object obj3, Object obj4, Object obj5, tq tqVar, int i) {
        super(2, tqVar);
        this.e = i;
        this.g = obj;
        this.h = obj2;
        this.i = obj3;
        this.j = obj4;
        this.k = obj5;
    }

    @Override // defpackage.l50
    public final Object f(Object obj, Object obj2) throws Throwable {
        int i = this.e;
        bw1 bw1Var = bw1.a;
        ds dsVar = (ds) obj;
        tq tqVar = (tq) obj2;
        switch (i) {
            case 0:
                ((v7) o(tqVar, dsVar)).r(bw1Var);
                break;
        }
        return ((v7) o(tqVar, dsVar)).r(bw1Var);
    }

    @Override // defpackage.kf
    public final tq o(tq tqVar, Object obj) {
        int i = this.e;
        Object obj2 = this.k;
        Object obj3 = this.i;
        Object obj4 = this.j;
        switch (i) {
            case 0:
                v7 v7Var = new v7((l8) this.h, (h50) obj3, (w7) obj4, (zl0) obj2, tqVar);
                v7Var.g = obj;
                return v7Var;
            case 1:
                return new v7((em0) this.g, (gt0) this.h, (fp1) obj3, (so1) obj4, (mc0) obj2, tqVar, 1);
            case 2:
                return new v7((dh) this.g, (zo1) this.h, (em0) obj3, (qp1) obj4, (mw0) obj2, tqVar, 2);
            case 3:
                return new v7((um0) this.g, (Context) this.h, (gt0) obj3, (gt0) obj4, (gt0) obj2, tqVar, 3);
            case 4:
                v7 v7Var2 = new v7((r61) obj3, (q61) obj4, (aa) obj2, tqVar);
                v7Var2.g = obj;
                return v7Var2;
            case 5:
                return new v7((Context) this.g, (gt0) this.h, (gt0) obj3, (gt0) obj4, (gt0) obj2, tqVar, 5);
            default:
                v7 v7Var3 = new v7((x31) this.h, (m50) obj4, (h50) obj3, (w41) obj2, tqVar);
                v7Var3.g = obj;
                return v7Var3;
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:199:0x01ed A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:203:0x01a8 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:208:0x0218 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    @Override // defpackage.kf
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final java.lang.Object r(java.lang.Object r14) throws java.lang.Throwable {
        /*
            Method dump skipped, instruction units count: 1024
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.v7.r(java.lang.Object):java.lang.Object");
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public v7(x31 x31Var, m50 m50Var, h50 h50Var, w41 w41Var, tq tqVar) {
        super(2, tqVar);
        this.e = 6;
        this.h = x31Var;
        this.j = m50Var;
        this.i = h50Var;
        this.k = w41Var;
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public v7(r61 r61Var, q61 q61Var, aa aaVar, tq tqVar) {
        super(2, tqVar);
        this.e = 4;
        this.i = r61Var;
        this.j = q61Var;
        this.k = aaVar;
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public v7(l8 l8Var, h50 h50Var, w7 w7Var, zl0 zl0Var, tq tqVar) {
        super(2, tqVar);
        this.e = 0;
        this.h = l8Var;
        this.i = h50Var;
        this.j = w7Var;
        this.k = zl0Var;
    }
}
