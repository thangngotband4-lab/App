package defpackage;

import java.util.List;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class ql0 implements hc1 {
    public static final ae0 x;
    public final xt a;
    public boolean b;
    public ll0 c;
    public boolean d;
    public final nk e;
    public final m01 f;
    public final ks0 g;
    public float h;
    public final cu i;
    public final boolean j;
    public ij0 k;
    public final ol0 l;
    public final cf m;
    public final kk0 n;
    public final ah o;
    public final xk0 p;
    public final l1 q;
    public final uk0 r;
    public final gt0 s;
    public final m01 t;
    public final m01 u;
    public final gt0 v;
    public final ae0 w;

    static {
        bo boVar = new bo(15);
        g70 g70Var = new g70(13);
        a8 a8Var = new a8(8, boVar);
        zu1.g(1, g70Var);
        x = new ae0(20, a8Var, g70Var, false);
    }

    public ql0(int i, int i2) {
        xt xtVar = new xt();
        xtVar.a = -1;
        xtVar.d = -1;
        this.a = xtVar;
        nk nkVar = new nk();
        nkVar.b = new j01(i);
        nkVar.c = new j01(i2);
        nkVar.e = new rk0(i);
        this.e = nkVar;
        ll0 ll0Var = sl0.a;
        a4 a4Var = a4.N;
        this.f = new m01(ll0Var, a4Var);
        this.g = new ks0();
        this.i = new cu(new l(14, this));
        this.j = true;
        this.l = new ol0(this);
        this.m = new cf();
        this.n = new kk0();
        this.o = new ah(1);
        this.p = new xk0(new nl0(this, i));
        this.q = new l1(12, this);
        this.r = new uk0();
        bw1 bw1Var = bw1.a;
        this.s = new m01(bw1Var, a4Var);
        Boolean bool = Boolean.FALSE;
        this.t = hl.I(bool);
        this.u = hl.I(bool);
        this.v = new m01(bw1Var, a4Var);
        ae0 ae0Var = new ae0(8, false);
        yu1 yu1Var = m22.I;
        Float fValueOf = Float.valueOf(0.0f);
        ae0Var.f = new ac(yu1Var, fValueOf, (fc) yu1Var.a.g(fValueOf), Long.MIN_VALUE, Long.MIN_VALUE, false);
        this.w = ae0Var;
    }

    @Override // defpackage.hc1
    public final boolean a() {
        return ((Boolean) this.u.getValue()).booleanValue();
    }

    @Override // defpackage.hc1
    public final boolean b() {
        return this.i.b();
    }

    @Override // defpackage.hc1
    public final boolean c() {
        return ((Boolean) this.t.getValue()).booleanValue();
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0013  */
    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:593)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    @Override // defpackage.hc1
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final java.lang.Object d(defpackage.kt0 r9, defpackage.l50 r10, defpackage.uq r11) throws java.lang.Throwable {
        /*
            r8 = this;
            boolean r0 = r11 instanceof defpackage.pl0
            if (r0 == 0) goto L13
            r0 = r11
            pl0 r0 = (defpackage.pl0) r0
            int r1 = r0.h
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L13
            int r1 = r1 - r2
            r0.h = r1
            goto L18
        L13:
            pl0 r0 = new pl0
            r0.<init>(r8, r11)
        L18:
            java.lang.Object r11 = r0.f
            int r1 = r0.h
            es r2 = defpackage.es.d
            bw1 r3 = defpackage.bw1.a
            r4 = 2
            r5 = 0
            r6 = 1
            if (r1 == 0) goto L3f
            if (r1 == r6) goto L33
            if (r1 != r4) goto L2d
            defpackage.vl.Q(r11)
            return r3
        L2d:
            java.lang.String r8 = "call to 'resume' before 'invoke' with coroutine"
            defpackage.zi.f(r8)
            return r5
        L33:
            jl1 r9 = r0.e
            r10 = r9
            l50 r10 = (defpackage.l50) r10
            kt0 r9 = r0.d
            defpackage.vl.Q(r11)
            goto Lb4
        L3f:
            defpackage.vl.Q(r11)
            m01 r11 = r8.f
            java.lang.Object r11 = r11.getValue()
            ll0 r1 = defpackage.sl0.a
            if (r11 != r1) goto Lb4
            r0.d = r9
            r11 = r10
            jl1 r11 = (defpackage.jl1) r11
            r0.e = r11
            r0.h = r6
            cf r11 = r8.m
            tm r1 = r11.b
            if (r1 != 0) goto L70
            tm r1 = new tm
            r1.<init>(r6)
            r1.Q(r5)
            r11.b = r1
            bf r11 = r11.a
            if (r11 == 0) goto L70
            boolean r7 = r11.q
            if (r7 == 0) goto L70
            r11.M0()
        L70:
            java.lang.Object r11 = r1.N()
            boolean r7 = r11 instanceof defpackage.qc0
            if (r7 != 0) goto L86
            boolean r1 = r11 instanceof defpackage.xm
            if (r1 != 0) goto L81
            java.lang.Object r11 = defpackage.ng0.O(r11)
            goto Lad
        L81:
            xm r11 = (defpackage.xm) r11
            java.lang.Throwable r8 = r11.a
            throw r8
        L86:
            int r11 = r1.b0(r11)
            if (r11 < 0) goto L70
            fh0 r11 = new fh0
            tq r7 = defpackage.rm.H(r0)
            r11.<init>(r7, r1)
            r11.v()
            f81 r7 = new f81
            r7.<init>(r11)
            xv r1 = defpackage.hl.B(r1, r6, r7)
            si r7 = new si
            r7.<init>(r6, r1)
            r11.y(r7)
            java.lang.Object r11 = r11.t()
        Lad:
            if (r11 != r2) goto Lb0
            goto Lb1
        Lb0:
            r11 = r3
        Lb1:
            if (r11 != r2) goto Lb4
            goto Lc2
        Lb4:
            r0.d = r5
            r0.e = r5
            r0.h = r4
            cu r8 = r8.i
            java.lang.Object r8 = r8.d(r9, r10, r0)
            if (r8 != r2) goto Lc3
        Lc2:
            return r2
        Lc3:
            return r3
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.ql0.d(kt0, l50, uq):java.lang.Object");
    }

    @Override // defpackage.hc1
    public final float e(float f) {
        return this.i.e(f);
    }

    public final void f(ll0 ll0Var, boolean z, boolean z2) {
        String str;
        long j;
        ph1 ph1VarX;
        h50 h50VarE;
        ph1 ph1VarJ;
        yu1 yu1Var = m22.I;
        List list = ll0Var.k;
        int i = ll0Var.n;
        int i2 = ll0Var.b;
        ml0 ml0Var = ll0Var.a;
        this.p.e = list.size();
        ae0 ae0Var = this.w;
        nk nkVar = this.e;
        tq tqVar = null;
        if (!z && this.b) {
            this.c = ll0Var;
            ph1VarX = om.x();
            h50VarE = ph1VarX != null ? ph1VarX.e() : null;
            ph1VarJ = om.J(ph1VarX);
            try {
                if (((Number) ((ac) ae0Var.f).e.getValue()).floatValue() != 0.0f && ml0Var != null && ml0Var.a == ((j01) nkVar.b).g() && i2 == ((j01) nkVar.c).g()) {
                    bj1 bj1Var = (bj1) ae0Var.e;
                    if (bj1Var != null) {
                        bj1Var.a(null);
                    }
                    ae0Var.f = new ac(yu1Var, Float.valueOf(0.0f), null, 60);
                }
                return;
            } finally {
                om.S(ph1VarX, ph1VarJ, h50VarE);
            }
        }
        if (z) {
            this.b = true;
        }
        this.u.setValue(Boolean.valueOf(((ml0Var != null ? ml0Var.a : 0) == 0 && i2 == 0) ? false : true));
        this.t.setValue(Boolean.valueOf(ll0Var.c));
        this.h -= ll0Var.d;
        this.f.setValue(ll0Var);
        if (z2) {
            nkVar.getClass();
            if (i2 < 0.0f) {
                vd0.c("scrollOffset should be non-negative");
            }
            ((j01) nkVar.c).h(i2);
        } else {
            ml0 ml0Var2 = (ml0) il.X(list);
            ml0 ml0Var3 = (ml0) il.c0(list);
            if (ml0Var2 != null) {
                str = "scrollOffset should be non-negative";
                j = ml0Var2.a;
            } else {
                str = "scrollOffset should be non-negative";
                j = -1;
            }
            m22.G(j, "firstVisibleItem:index");
            m22.G(ml0Var3 != null ? ml0Var3.a : -1L, "lastVisibleItem:index");
            nkVar.getClass();
            nkVar.d = ml0Var != null ? ml0Var.g : null;
            if (nkVar.a || i > 0) {
                nkVar.a = true;
                if (i2 < 0.0f) {
                    vd0.c(str);
                }
                nkVar.b(ml0Var != null ? ml0Var.a : 0, i2);
            }
            if (this.j) {
                xt xtVar = this.a;
                int i3 = xtVar.a;
                boolean z3 = xtVar.c;
                if (i3 != -1 && !list.isEmpty() && i3 != xt.a(ll0Var, z3)) {
                    xtVar.a = -1;
                    wk0 wk0Var = xtVar.b;
                    if (wk0Var != null) {
                        wk0Var.cancel();
                    }
                    xtVar.b = null;
                }
                int i4 = xtVar.d;
                if (i4 != -1 && xtVar.e != 0.0f && i4 != i && !list.isEmpty()) {
                    int iA = xt.a(ll0Var, xtVar.e < 0.0f);
                    if (iA >= 0 && iA < i) {
                        xtVar.a = iA;
                        xtVar.b = l1.E(this.q, iA);
                    }
                }
                xtVar.d = i;
            }
        }
        if (z) {
            float f = ll0Var.f;
            wu wuVar = ll0Var.i;
            ds dsVar = ll0Var.h;
            ae0Var.getClass();
            if (f <= wuVar.y(1.0f)) {
                return;
            }
            ph1VarX = om.x();
            h50VarE = ph1VarX != null ? ph1VarX.e() : null;
            ph1VarJ = om.J(ph1VarX);
            try {
                float fFloatValue = ((Number) ((ac) ae0Var.f).e.getValue()).floatValue();
                bj1 bj1Var2 = (bj1) ae0Var.e;
                if (bj1Var2 != null) {
                    bj1Var2.a(null);
                }
                ac acVar = (ac) ae0Var.f;
                if (acVar.i) {
                    ae0Var.f = ct.A(acVar, fFloatValue - f);
                } else {
                    ae0Var.f = new ac(yu1Var, Float.valueOf(-f), null, 60);
                }
                ae0Var.e = m22.y(dsVar, null, new i3(ae0Var, tqVar, 9), 3);
            } finally {
            }
        }
    }

    public final ll0 g() {
        return (ll0) this.f.getValue();
    }

    public final void h(float f, ll0 ll0Var) {
        wk0 wk0Var;
        wk0 wk0Var2;
        if (this.j) {
            boolean zIsEmpty = ll0Var.k.isEmpty();
            xt xtVar = this.a;
            if (!zIsEmpty) {
                boolean z = f < 0.0f;
                int iA = xt.a(ll0Var, z);
                if (iA >= 0 && iA < ll0Var.n) {
                    if (iA != xtVar.a) {
                        if (xtVar.c != z) {
                            xtVar.a = -1;
                            wk0 wk0Var3 = xtVar.b;
                            if (wk0Var3 != null) {
                                wk0Var3.cancel();
                            }
                            xtVar.b = null;
                        }
                        xtVar.c = z;
                        xtVar.a = iA;
                        xtVar.b = l1.E(this.q, iA);
                    }
                    List list = ll0Var.k;
                    if (z) {
                        ml0 ml0Var = (ml0) il.b0(list);
                        if (((ml0Var.j + ml0Var.k) + ll0Var.q) - ll0Var.m < (-f) && (wk0Var2 = xtVar.b) != null) {
                            wk0Var2.a();
                        }
                    } else if (ll0Var.l - ((ml0) il.W(list)).j < f && (wk0Var = xtVar.b) != null) {
                        wk0Var.a();
                    }
                }
            }
            xtVar.e = f;
        }
    }
}
