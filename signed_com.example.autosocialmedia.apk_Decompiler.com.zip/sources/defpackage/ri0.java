package defpackage;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class ri0 {
    public static final ri0 d;
    public static final ri0 e;
    public static final /* synthetic */ ri0[] f;

    static {
        ri0 ri0Var = new ri0("Ltr", 0);
        d = ri0Var;
        ri0 ri0Var2 = new ri0("Rtl", 1);
        e = ri0Var2;
        f = new ri0[]{ri0Var, ri0Var2};
    }

    public static ri0 valueOf(String str) {
        return (ri0) Enum.valueOf(ri0.class, str);
    }

    public static ri0[] values() {
        return (ri0[]) f.clone();
    }
}
