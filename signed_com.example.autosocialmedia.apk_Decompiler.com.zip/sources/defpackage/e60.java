package defpackage;

import android.content.Context;
import android.os.Build;
import android.text.TextUtils;
import android.view.textclassifier.TextClassification;
import java.util.Arrays;
import java.util.List;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class e60 implements l50 {
    public final /* synthetic */ int d;
    public final /* synthetic */ Object e;
    public final /* synthetic */ Object f;

    public /* synthetic */ e60(Object obj, int i, Object obj2) {
        this.d = i;
        this.e = obj;
        this.f = obj2;
    }

    private final Object d(Object obj, Object obj2) {
        wp1 wp1Var;
        so1 so1Var = (so1) this.e;
        ds dsVar = (ds) this.f;
        tm1 tm1Var = (tm1) obj;
        Context context = (Context) obj2;
        boolean zJ = so1Var.j();
        kc kcVarM = so1Var.m();
        TextClassification textClassification = null;
        String str = kcVarM != null ? kcVarM.e : null;
        wp1 wp1Var2 = so1Var.v;
        if (wp1Var2 != null) {
            long j = wp1Var2.a;
            mw0 mw0Var = so1Var.b;
            wp1Var = new wp1(jj1.b(mw0Var.b((int) (j >> 32)), mw0Var.b((int) (j & 4294967295L))));
        } else {
            wp1Var = null;
        }
        c31 c31Var = so1Var.i;
        rf rfVar = new rf(so1Var, dsVar, context, 12);
        vj1 vj1Var = e31.a;
        if (Build.VERSION.SDK_INT < 28 || str == null || wp1Var == null || c31Var == null || !(c31Var instanceof c31)) {
            rfVar.g(tm1Var);
            if (str != null && wp1Var != null) {
                bm.e(tm1Var, context, zJ, str, wp1Var.a);
            }
        } else {
            long j2 = wp1Var.a;
            Object obj3 = c31Var.h;
            st0 st0Var = c31Var.e;
            if (st0Var.f()) {
                sm1 sm1Var = (sm1) c31Var.g.getValue();
                TextClassification textClassification2 = (sm1Var != null && wp1.b(j2, sm1Var.b) && ng0.o(str, sm1Var.a)) ? sm1Var.c : null;
                st0Var.h(null);
                textClassification = textClassification2;
            }
            if (textClassification == null) {
                rfVar.g(tm1Var);
            } else {
                if (!textClassification.getActions().isEmpty()) {
                    tm1Var.a.a(new jn1(obj3, textClassification, 0));
                } else if ((textClassification.getIcon() != null || !TextUtils.isEmpty(textClassification.getLabel())) && (textClassification.getIntent() != null || textClassification.getOnClickListener() != null)) {
                    tm1Var.a.a(new jn1(obj3, textClassification, -1));
                }
                rfVar.g(tm1Var);
                List actions = textClassification.getActions();
                int size = actions.size();
                for (int i = 0; i < size; i++) {
                    oc.d(actions.get(i));
                    if (i > 0) {
                        tm1Var.a.a(new jn1(obj3, textClassification, i));
                    }
                }
            }
            bm.e(tm1Var, context, zJ, str, wp1Var.a);
        }
        return bw1.a;
    }

    private final Object e(Object obj, Object obj2) {
        i01 i01Var = (i01) this.e;
        gt0 gt0Var = (gt0) this.f;
        long jLongValue = ((Long) obj).longValue();
        long jLongValue2 = ((Long) obj2).longValue();
        if (jLongValue2 > 0) {
            i01Var.h(tl.n(jLongValue / jLongValue2, 0.0f, 1.0f));
            gt0Var.setValue(String.format("Đã tải %.1f / %.1f MB", Arrays.copyOf(new Object[]{Double.valueOf(jLongValue / 1048576.0d), Double.valueOf(jLongValue2 / 1048576.0d)}, 2)));
        } else {
            gt0Var.setValue(String.format("Đã tải %.1f MB", Arrays.copyOf(new Object[]{Double.valueOf(jLongValue / 1048576.0d)}, 1)));
        }
        return bw1.a;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:419:0x0992  */
    /* JADX WARN: Removed duplicated region for block: B:428:0x09ae  */
    /* JADX WARN: Removed duplicated region for block: B:433:0x09c6  */
    /* JADX WARN: Removed duplicated region for block: B:441:0x09df  */
    /* JADX WARN: Removed duplicated region for block: B:444:0x0a02  */
    /* JADX WARN: Removed duplicated region for block: B:445:0x0a07  */
    /* JADX WARN: Removed duplicated region for block: B:447:0x0a0a  */
    /* JADX WARN: Removed duplicated region for block: B:448:0x0a0f  */
    /* JADX WARN: Removed duplicated region for block: B:452:0x0a17  */
    @Override // defpackage.l50
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final java.lang.Object f(java.lang.Object r56, java.lang.Object r57) {
        /*
            Method dump skipped, instruction units count: 3400
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.e60.f(java.lang.Object, java.lang.Object):java.lang.Object");
    }

    public /* synthetic */ e60(Object obj, Object obj2, int i, int i2) {
        this.d = i2;
        this.e = obj;
        this.f = obj2;
    }
}
