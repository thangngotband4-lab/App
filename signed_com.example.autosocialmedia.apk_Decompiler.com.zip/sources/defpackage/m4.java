package defpackage;

import android.graphics.Rect;
import android.view.autofill.AutofillManager;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class m4 extends ki0 implements n50 {
    public final /* synthetic */ o4 e;
    public final /* synthetic */ int f;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public m4(o4 o4Var, int i) {
        super(4);
        this.e = o4Var;
        this.f = i;
    }

    @Override // defpackage.n50
    public final Object m(Object obj, Object obj2, Object obj3, Object obj4) {
        int iIntValue = ((Number) obj).intValue();
        int iIntValue2 = ((Number) obj2).intValue();
        int iIntValue3 = ((Number) obj3).intValue();
        int iIntValue4 = ((Number) obj4).intValue();
        o4 o4Var = this.e;
        l1 l1Var = o4Var.d;
        ((AutofillManager) l1Var.e).notifyViewEntered(o4Var.f, this.f, new Rect(iIntValue, iIntValue2, iIntValue3, iIntValue4));
        return bw1.a;
    }
}
