package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class n6 implements l50 {
    public final /* synthetic */ int d;
    public final /* synthetic */ Object e;
    public final /* synthetic */ int f;

    public /* synthetic */ n6(fr0 fr0Var, int i, int i2) {
        this.d = 0;
        this.e = fr0Var;
        this.f = i2;
    }

    @Override // defpackage.l50
    public final Object f(Object obj, Object obj2) {
        int i = this.d;
        bw1 bw1Var = bw1.a;
        int i2 = this.f;
        Object obj3 = this.e;
        switch (i) {
            case 0:
                ((Integer) obj2).getClass();
                s6.b((fr0) obj3, (xo) obj, bm.T(1), i2);
                break;
            case 1:
                ((Integer) obj2).getClass();
                tg.a((fr0) obj3, (xo) obj, bm.T(i2 | 1));
                break;
            default:
                hl0 hl0Var = (hl0) obj3;
                xo xoVar = (xo) obj;
                int iIntValue = ((Integer) obj2).intValue();
                if (!xoVar.O(iIntValue & 1, (iIntValue & 3) != 2)) {
                    xoVar.R();
                } else {
                    fg0 fg0VarB = hl0Var.b.a.b(i2);
                    ((qn) fg0VarB.c.c).m(hl0Var.c, Integer.valueOf(i2 - fg0VarB.a), xoVar, 0);
                }
                break;
        }
        return bw1Var;
    }

    public /* synthetic */ n6(int i, int i2, Object obj) {
        this.d = i2;
        this.e = obj;
        this.f = i;
    }
}
