package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public abstract class av1 {
    public static final nv1 a;

    static {
        p40 p40Var = p40.j;
        dq1 dq1Var = new dq1(0L, ak1.h(57), p40Var, ak1.g(-1.0d), 0, ak1.h(64), 16645977);
        dq1 dq1Var2 = new dq1(0L, ak1.h(45), p40Var, ak1.g(-0.75d), 0, ak1.h(52), 16645977);
        p40 p40Var2 = p40.i;
        dq1 dq1Var3 = new dq1(0L, ak1.h(36), p40Var2, ak1.g(-0.5d), 0, ak1.h(44), 16645977);
        dq1 dq1Var4 = new dq1(0L, ak1.h(32), p40Var2, ak1.g(-0.5d), 0, ak1.h(40), 16645977);
        dq1 dq1Var5 = new dq1(0L, ak1.h(28), p40Var2, ak1.g(-0.4d), 0, ak1.h(36), 16645977);
        p40 p40Var3 = p40.h;
        dq1 dq1Var6 = new dq1(0L, ak1.h(24), p40Var3, ak1.g(-0.3d), 0, ak1.h(32), 16645977);
        dq1 dq1Var7 = new dq1(0L, ak1.h(22), p40Var3, ak1.g(-0.2d), 0, ak1.h(28), 16645977);
        dq1 dq1Var8 = new dq1(0L, ak1.h(16), p40Var3, ak1.g(0.1d), 0, ak1.h(24), 16645977);
        p40 p40Var4 = p40.g;
        dq1 dq1Var9 = new dq1(0L, ak1.h(14), p40Var4, ak1.g(0.1d), 0, ak1.h(20), 16645977);
        p40 p40Var5 = p40.f;
        a = new nv1(dq1Var, dq1Var2, dq1Var3, dq1Var4, dq1Var5, dq1Var6, dq1Var7, dq1Var8, dq1Var9, new dq1(0L, ak1.h(16), p40Var5, ak1.g(0.15d), 0, ak1.h(24), 16645977), new dq1(0L, ak1.h(14), p40Var5, ak1.g(0.15d), 0, ak1.h(20), 16645977), new dq1(0L, ak1.h(12), p40Var5, ak1.g(0.25d), 0, ak1.h(16), 16645977), new dq1(0L, ak1.h(14), p40Var3, ak1.g(0.5d), 0, ak1.h(20), 16645977), new dq1(0L, ak1.h(12), p40Var3, ak1.g(0.5d), 0, ak1.h(16), 16645977), new dq1(0L, ak1.h(11), p40Var4, ak1.g(0.5d), 0, ak1.h(16), 16645977));
    }
}
