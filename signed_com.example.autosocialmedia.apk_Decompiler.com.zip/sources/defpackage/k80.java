package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class k80 implements m50 {
    public final /* synthetic */ int d;
    public final /* synthetic */ gt0 e;
    public final /* synthetic */ gt0 f;
    public final /* synthetic */ gt0 g;
    public final /* synthetic */ gt0 h;
    public final /* synthetic */ gt0 i;
    public final /* synthetic */ gt0 j;
    public final /* synthetic */ gt0 k;
    public final /* synthetic */ gt0 l;
    public final /* synthetic */ gt0 m;

    public /* synthetic */ k80(gt0 gt0Var, gt0 gt0Var2, gt0 gt0Var3, gt0 gt0Var4, gt0 gt0Var5, gt0 gt0Var6, gt0 gt0Var7, gt0 gt0Var8, gt0 gt0Var9, int i) {
        this.d = i;
        this.e = gt0Var;
        this.f = gt0Var2;
        this.g = gt0Var3;
        this.h = gt0Var4;
        this.i = gt0Var5;
        this.j = gt0Var6;
        this.k = gt0Var7;
        this.l = gt0Var8;
        this.m = gt0Var9;
    }

    @Override // defpackage.m50
    public final Object c(Object obj, Object obj2, Object obj3) {
        int i;
        mb0 mb0Var;
        xo xoVar;
        int i2 = this.d;
        bw1 bw1Var = bw1.a;
        switch (i2) {
            case 0:
                xo xoVar2 = (xo) obj2;
                int iIntValue = ((Integer) obj3).intValue();
                ((bk0) obj).getClass();
                if (!xoVar2.O(iIntValue & 1, (iIntValue & 17) != 16)) {
                    xoVar2.R();
                } else {
                    om.d(xoVar2, ig1.b(cr0.a, 20.0f));
                    rm.e(ig1.a, null, 0L, 0, jl.C(1900469286, new k80(this.e, this.f, this.g, this.h, this.i, this.j, this.k, this.l, this.m, 1), xoVar2), xoVar2, 24582, 14);
                }
                break;
            default:
                xo xoVar3 = (xo) obj2;
                int iIntValue2 = ((Integer) obj3).intValue();
                ((lm) obj).getClass();
                if (!xoVar3.O(iIntValue2 & 1, (iIntValue2 & 17) != 16)) {
                    xoVar3.R();
                } else {
                    k91 k91VarA = j91.a(ng0.e, a4.o, xoVar3, 48);
                    int iHashCode = Long.hashCode(xoVar3.T);
                    t11 t11VarL = xoVar3.l();
                    cr0 cr0Var = cr0.a;
                    fr0 fr0VarM = om.M(xoVar3, cr0Var);
                    oo.b.getClass();
                    kp kpVar = no.b;
                    xoVar3.Z();
                    if (xoVar3.S) {
                        xoVar3.k(kpVar);
                    } else {
                        xoVar3.j0();
                    }
                    ak1.o(xoVar3, no.e, k91VarA);
                    ak1.o(xoVar3, no.d, t11VarL);
                    ak1.j(xoVar3, Integer.valueOf(iHashCode), no.f);
                    ak1.n(xoVar3, no.g);
                    ak1.o(xoVar3, no.c, fr0VarM);
                    bc0.a(cj1.i(), null, ig1.f(cr0Var, 20.0f), sl.b(), xoVar3, 432, 0);
                    mp1.b("Cấu hình chạy", null, f0.C(cr0Var, 8.0f, xoVar3), ak1.h(16), p40.i, null, 0L, null, 0L, 0, false, 0, 0, null, xoVar3, 1597446, 0, 262058);
                    f0.w(xoVar3, true, cr0Var, 12.0f, xoVar3);
                    gt0 gt0Var = this.e;
                    int iIntValue3 = ((Number) gt0Var.getValue()).intValue();
                    Object objL = xoVar3.L();
                    dp1 dp1Var = ro.a;
                    if (objL == dp1Var) {
                        objL = new h3(gt0Var, 6);
                        xoVar3.g0(objL);
                    }
                    mg0.j("Đợi trước khi follow", iIntValue3, "s", 0, 60, (h50) objL, xoVar3, 224646);
                    gt0 gt0Var2 = this.f;
                    int iIntValue4 = ((Number) gt0Var2.getValue()).intValue();
                    gt0 gt0Var3 = this.g;
                    int iIntValue5 = ((Number) gt0Var3.getValue()).intValue();
                    Object objL2 = xoVar3.L();
                    if (objL2 == dp1Var) {
                        objL2 = new h3(gt0Var2, 7);
                        xoVar3.g0(objL2);
                    }
                    mg0.j("Đợi sau follow (min)", iIntValue4, "s", 5, iIntValue5, (h50) objL2, xoVar3, 200070);
                    int iIntValue6 = ((Number) gt0Var3.getValue()).intValue();
                    int iIntValue7 = ((Number) gt0Var2.getValue()).intValue();
                    Object objL3 = xoVar3.L();
                    if (objL3 == dp1Var) {
                        objL3 = new h3(gt0Var3, 8);
                        xoVar3.g0(objL3);
                    }
                    mg0.j("Đợi sau follow (max)", iIntValue6, "s", iIntValue7, e80.MAX_DELAY, (h50) objL3, xoVar3, 221574);
                    gt0 gt0Var4 = this.h;
                    int iIntValue8 = ((Number) gt0Var4.getValue()).intValue();
                    Object objL4 = xoVar3.L();
                    if (objL4 == dp1Var) {
                        objL4 = new h3(gt0Var4, 9);
                        xoVar3.g0(objL4);
                    }
                    mg0.j("Dừng sau số job lỗi", iIntValue8, "", 0, 50, (h50) objL4, xoVar3, 224646);
                    gt0 gt0Var5 = this.i;
                    int iIntValue9 = ((Number) gt0Var5.getValue()).intValue();
                    Object objL5 = xoVar3.L();
                    if (objL5 == dp1Var) {
                        objL5 = new h3(gt0Var5, 12);
                        xoVar3.g0(objL5);
                    }
                    mg0.j("Đợi khi hết nhiệm vụ", iIntValue9, "s", 0, e80.MAX_NO_JOBS_WAIT, (h50) objL5, xoVar3, 224646);
                    om.d(xoVar3, ig1.b(cr0Var, 8.0f));
                    f10 f10Var = ig1.a;
                    fr0 fr0VarB = ig1.b(f10Var, 1.0f);
                    long jB = ql.b(0.08f, sl.n());
                    mb0 mb0Var2 = eq0.G;
                    tg.a(eq0.q(fr0VarB, jB, mb0Var2), xoVar3, 0);
                    om.d(xoVar3, ig1.b(cr0Var, 4.0f));
                    gt0 gt0Var6 = this.j;
                    boolean zBooleanValue = ((Boolean) gt0Var6.getValue()).booleanValue();
                    Object objL6 = xoVar3.L();
                    if (objL6 == dp1Var) {
                        objL6 = new h3(gt0Var6, 19);
                        xoVar3.g0(objL6);
                    }
                    mg0.k("Tự đổi tài khoản", "Sau N job sẽ chuyển sang acc tiếp theo", zBooleanValue, (h50) objL6, xoVar3, 3126);
                    if (((Boolean) gt0Var6.getValue()).booleanValue()) {
                        xoVar3.W(623483227);
                        gt0 gt0Var7 = this.k;
                        int iIntValue10 = ((Number) gt0Var7.getValue()).intValue();
                        Object objL7 = xoVar3.L();
                        if (objL7 == dp1Var) {
                            objL7 = new h3(gt0Var7, 20);
                            xoVar3.g0(objL7);
                        }
                        mb0Var = mb0Var2;
                        i = 563854076;
                        xoVar = xoVar3;
                        mg0.j("Đổi acc sau số job", iIntValue10, "", 1, 9999, (h50) objL7, xoVar, 224646);
                    } else {
                        i = 563854076;
                        mb0Var = mb0Var2;
                        xoVar = xoVar3;
                        xoVar.W(563854076);
                    }
                    xoVar.p(false);
                    om.d(xoVar, ig1.b(cr0Var, 4.0f));
                    tg.a(eq0.q(ig1.b(f10Var, 1.0f), ql.b(0.08f, sl.n()), mb0Var), xoVar, 0);
                    om.d(xoVar, ig1.b(cr0Var, 4.0f));
                    gt0 gt0Var8 = this.l;
                    boolean zBooleanValue2 = ((Boolean) gt0Var8.getValue()).booleanValue();
                    Object objL8 = xoVar.L();
                    if (objL8 == dp1Var) {
                        objL8 = new h3(gt0Var8, 24);
                        xoVar.g0(objL8);
                    }
                    mg0.k("Kiểm tra bị nhả follow", "Mở lại profile sau follow, phát hiện acc bị nhả", zBooleanValue2, (h50) objL8, xoVar, 3126);
                    if (((Boolean) gt0Var8.getValue()).booleanValue()) {
                        xoVar.W(624324970);
                        gt0 gt0Var9 = this.m;
                        int iIntValue11 = ((Number) gt0Var9.getValue()).intValue();
                        Object objL9 = xoVar.L();
                        if (objL9 == dp1Var) {
                            objL9 = new h3(gt0Var9, 28);
                            xoVar.g0(objL9);
                        }
                        mg0.j("Dừng sau số lần nhả liên tiếp", iIntValue11, "", 1, 20, (h50) objL9, xoVar, 224646);
                    } else {
                        xoVar.W(i);
                    }
                    xoVar.p(false);
                    om.d(xoVar, ig1.b(cr0Var, 8.0f));
                    mp1.b("Mẹo: \"Đợi trước khi follow\" giả lập người xem profile, giảm rủi ro bị anti-bot. \"Kiểm tra nhả follow\" tốn thêm ~3-5s/job nhưng phát hiện sớm nếu acc bị flag.", y5.D(cr0Var, 0.0f, 4.0f, 0.0f, 0.0f, 13), sl.n(), ak1.h(11), null, null, 0L, null, ak1.h(15), 0, false, 0, 0, null, xoVar, 24624, 48, 260072);
                }
                break;
        }
        return bw1Var;
    }
}
