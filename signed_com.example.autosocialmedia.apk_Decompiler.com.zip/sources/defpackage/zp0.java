package defpackage;

import java.util.Collection;
import java.util.Iterator;
import java.util.Map;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class zp0 extends y {
    public final /* synthetic */ int d;
    public final yp0 e;

    public /* synthetic */ zp0(yp0 yp0Var, int i) {
        this.d = i;
        this.e = yp0Var;
    }

    @Override // defpackage.y
    public final int a() {
        switch (this.d) {
        }
        return this.e.l;
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.Set
    public final boolean add(Object obj) {
        switch (this.d) {
            case 0:
                ((Map.Entry) obj).getClass();
                throw new UnsupportedOperationException();
            default:
                throw new UnsupportedOperationException();
        }
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.Set
    public final boolean addAll(Collection collection) {
        int i = this.d;
        collection.getClass();
        switch (i) {
            case 0:
                throw new UnsupportedOperationException();
            default:
                throw new UnsupportedOperationException();
        }
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.Set
    public final void clear() {
        switch (this.d) {
            case 0:
                this.e.clear();
                break;
            default:
                this.e.clear();
                break;
        }
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.Set
    public final boolean contains(Object obj) {
        int i = this.d;
        yp0 yp0Var = this.e;
        switch (i) {
            case 0:
                if (!(obj instanceof Map.Entry)) {
                    return false;
                }
                Map.Entry entry = (Map.Entry) obj;
                yp0Var.getClass();
                int iF = yp0Var.f(entry.getKey());
                if (iF < 0) {
                    return false;
                }
                Object[] objArr = yp0Var.e;
                objArr.getClass();
                return ng0.o(objArr[iF], entry.getValue());
            default:
                return yp0Var.containsKey(obj);
        }
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.Set
    public boolean containsAll(Collection collection) {
        switch (this.d) {
            case 0:
                collection.getClass();
                return this.e.d(collection);
            default:
                return super.containsAll(collection);
        }
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.Set
    public final boolean isEmpty() {
        switch (this.d) {
        }
        return this.e.isEmpty();
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.lang.Iterable, java.util.Set
    public final Iterator iterator() {
        int i = this.d;
        yp0 yp0Var = this.e;
        switch (i) {
            case 0:
                yp0Var.getClass();
                return new vp0(yp0Var, 0);
            default:
                yp0Var.getClass();
                return new vp0(yp0Var, 1);
        }
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.Set
    public final boolean remove(Object obj) {
        int i = this.d;
        yp0 yp0Var = this.e;
        switch (i) {
            case 0:
                if (obj instanceof Map.Entry) {
                    Map.Entry entry = (Map.Entry) obj;
                    yp0Var.getClass();
                    yp0Var.b();
                    int iF = yp0Var.f(entry.getKey());
                    if (iF >= 0) {
                        Object[] objArr = yp0Var.e;
                        objArr.getClass();
                        if (ng0.o(objArr[iF], entry.getValue())) {
                            yp0Var.j(iF);
                        }
                    }
                }
                break;
            default:
                yp0Var.b();
                int iF2 = yp0Var.f(obj);
                if (iF2 >= 0) {
                    yp0Var.j(iF2);
                }
                break;
        }
        return true;
    }

    @Override // java.util.AbstractSet, java.util.AbstractCollection, java.util.Collection, java.util.Set
    public final boolean removeAll(Collection collection) {
        int i = this.d;
        yp0 yp0Var = this.e;
        collection.getClass();
        switch (i) {
            case 0:
                yp0Var.b();
                break;
            default:
                yp0Var.b();
                break;
        }
        return super.removeAll(collection);
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.Set
    public final boolean retainAll(Collection collection) {
        int i = this.d;
        yp0 yp0Var = this.e;
        collection.getClass();
        switch (i) {
            case 0:
                yp0Var.b();
                break;
            default:
                yp0Var.b();
                break;
        }
        return super.retainAll(collection);
    }
}
