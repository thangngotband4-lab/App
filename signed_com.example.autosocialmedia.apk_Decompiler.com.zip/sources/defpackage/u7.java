package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class u7 extends w50 implements h50 {
    public final /* synthetic */ zl0 l;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public u7(zl0 zl0Var) {
        super(1, mg0.class, "localToScreen", "startInput$localToScreen(Landroidx/compose/foundation/text/input/internal/LegacyPlatformTextInputServiceAdapter$LegacyPlatformTextInputNode;[F)V", 0);
        this.l = zl0Var;
    }

    @Override // defpackage.h50
    public final Object g(Object obj) {
        float[] fArr = ((fq0) obj).a;
        qi0 qi0Var = (qi0) this.l.u.getValue();
        if (qi0Var != null) {
            if (!qi0Var.B()) {
                qi0Var = null;
            }
            if (qi0Var != null) {
                qi0Var.D(fArr);
            }
        }
        return bw1.a;
    }
}
