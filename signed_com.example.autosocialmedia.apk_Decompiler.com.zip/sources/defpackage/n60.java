package defpackage;

import android.graphics.Canvas;
import android.graphics.RenderNode;
import android.widget.EdgeEffect;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class n60 extends lu implements zx {
    public final /* synthetic */ int t = 1;
    public final e7 u;
    public final py v;
    public Object w;

    public n60(pl1 pl1Var, e7 e7Var, py pyVar, uz0 uz0Var) {
        this.u = e7Var;
        this.v = pyVar;
        this.w = uz0Var;
        M0(pl1Var);
    }

    public static boolean P0(float f, EdgeEffect edgeEffect, Canvas canvas) {
        if (f == 0.0f) {
            return edgeEffect.draw(canvas);
        }
        int iSave = canvas.save();
        canvas.rotate(f);
        boolean zDraw = edgeEffect.draw(canvas);
        canvas.restoreToCount(iSave);
        return zDraw;
    }

    public static boolean Q0(float f, long j, EdgeEffect edgeEffect, Canvas canvas) {
        int iSave = canvas.save();
        canvas.rotate(f);
        canvas.translate(Float.intBitsToFloat((int) (j >> 32)), Float.intBitsToFloat((int) (j & 4294967295L)));
        boolean zDraw = edgeEffect.draw(canvas);
        canvas.restoreToCount(iSave);
        return zDraw;
    }

    /* JADX WARN: Removed duplicated region for block: B:113:0x01ef A[PHI: r22
      0x01ef: PHI (r22v2 boolean) = (r22v1 boolean), (r22v11 boolean) binds: [B:94:0x01a7, B:102:0x01c2] A[DONT_GENERATE, DONT_INLINE]] */
    @Override // defpackage.zx
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void L(defpackage.kj0 r26) {
        /*
            Method dump skipped, instruction units count: 1208
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.n60.L(kj0):void");
    }

    public RenderNode R0() {
        RenderNode renderNode = (RenderNode) this.w;
        if (renderNode != null) {
            return renderNode;
        }
        RenderNode renderNodeE = eg.E();
        this.w = renderNodeE;
        return renderNodeE;
    }

    public n60(pl1 pl1Var, e7 e7Var, py pyVar) {
        this.u = e7Var;
        this.v = pyVar;
        M0(pl1Var);
    }
}
