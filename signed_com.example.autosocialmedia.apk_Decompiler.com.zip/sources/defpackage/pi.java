package defpackage;

import java.io.Serializable;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public abstract class pi implements kh0, Serializable {
    public transient kh0 d;
    public final Object e;
    public final Class f;
    public final String g;
    public final String h;
    public final boolean i;

    public pi(Object obj, Class cls, String str, String str2, boolean z) {
        this.e = obj;
        this.f = cls;
        this.g = str;
        this.h = str2;
        this.i = z;
    }

    public abstract kh0 d();

    public final qk e() {
        boolean z = this.i;
        Class cls = this.f;
        if (!z) {
            return f71.a(cls);
        }
        f71.a.getClass();
        return new qz0(cls);
    }
}
