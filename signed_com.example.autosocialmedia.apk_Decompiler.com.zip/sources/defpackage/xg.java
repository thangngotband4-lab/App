package defpackage;

import kotlin.Metadata;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u000e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001¨\u0006\u0003"}, d2 = {"Lxg;", "Ljr0;", "Lzg;", "ui"}, k = 1, mv = {2, 0, 0}, xi = 48)
final class xg extends jr0 {
    public final ga a;

    public xg(ga gaVar) {
        this.a = gaVar;
    }

    @Override // defpackage.jr0
    public final er0 e() {
        return new zg(this.a);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof xg) {
            return this.a == ((xg) obj).a;
        }
        return false;
    }

    @Override // defpackage.jr0
    public final void f(er0 er0Var) {
        zg zgVar = (zg) er0Var;
        ga gaVar = this.a;
        zgVar.r = gaVar;
        if (zgVar.q) {
            gaVar.g(zgVar.s);
        }
    }

    public final int hashCode() {
        return this.a.hashCode();
    }
}
