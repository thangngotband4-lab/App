package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class tx extends lx {
    public hh1 L;
    public ry0 M;
    public boolean N;
    public m50 O;
    public m50 P;
    public boolean Q;

    @Override // defpackage.lx
    public final Object T0(kx kxVar, kx kxVar2) {
        hh1 hh1Var = this.L;
        tq tqVar = null;
        f fVar = new f(kxVar, this, tqVar, 6);
        hh1Var.getClass();
        Object objT = bm.t(new d(hh1Var, fVar, tqVar, 21), kxVar2);
        bw1 bw1Var = bw1.a;
        es esVar = es.d;
        if (objT != esVar) {
            objT = bw1Var;
        }
        return objT == esVar ? objT : bw1Var;
    }

    @Override // defpackage.lx
    public final void Y0(long j) {
        if (!this.q || ng0.o(this.O, rx.a)) {
            return;
        }
        m22.y(A0(), null, new sx(this, j, null), 1);
    }

    @Override // defpackage.lx
    public final void Z0(xw xwVar) {
        if (!this.q || ng0.o(this.P, rx.b)) {
            return;
        }
        m22.y(A0(), null, new f(this, xwVar, null, 7), 1);
    }

    @Override // defpackage.lx
    public final boolean e1() {
        return this.N;
    }
}
