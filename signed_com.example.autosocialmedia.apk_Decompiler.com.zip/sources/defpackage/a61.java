package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public abstract class a61 {
    public final wl0 a;

    public a61(w40 w40Var) {
        this.a = new wl0(w40Var);
    }

    public abstract c61 a(Object obj);

    public ex1 b() {
        return this.a;
    }

    public final ex1 c(c61 c61Var, ex1 ex1Var) {
        ex1 ex1Var2 = null;
        ex1Var2 = null;
        ex1Var2 = null;
        ex1Var2 = null;
        ex1Var2 = null;
        ex1Var2 = null;
        if (ex1Var instanceof ly) {
            if (c61Var.d) {
                ly lyVar = (ly) ex1Var;
                lyVar.a.setValue(c61Var.a());
                ex1Var2 = lyVar;
            }
        } else if (ex1Var instanceof wj1) {
            if ((c61Var.b || c61Var.e != null) && !c61Var.d) {
                wj1 wj1Var = (wj1) ex1Var;
                if (ng0.o(c61Var.a(), wj1Var.a)) {
                    ex1Var2 = wj1Var;
                }
            }
        } else if (ex1Var instanceof np) {
            c61Var.getClass();
        }
        if (ex1Var2 != null) {
            return ex1Var2;
        }
        if (!c61Var.d) {
            return new wj1(c61Var.a());
        }
        Object obj = c61Var.e;
        a4 a4Var = c61Var.c;
        if (a4Var == null) {
            a4Var = a4.Z;
        }
        return new ly(new m01(obj, a4Var));
    }
}
