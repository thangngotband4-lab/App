package defpackage;

import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import java.util.concurrent.locks.LockSupport;
import sun.misc.Unsafe;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public abstract class u00 extends p00 implements iu {
    public static final /* synthetic */ AtomicReferenceFieldUpdater j = AtomicReferenceFieldUpdater.newUpdater(u00.class, Object.class, "_queue$volatile");
    public static final /* synthetic */ AtomicReferenceFieldUpdater k;
    public static final /* synthetic */ AtomicIntegerFieldUpdater l;
    public static final /* synthetic */ long m;
    public static final /* synthetic */ long n;
    private volatile /* synthetic */ Object _delayed$volatile;
    private volatile /* synthetic */ int _isCompleted$volatile = 0;
    private volatile /* synthetic */ Object _queue$volatile;

    static {
        Unsafe unsafe = yi.a;
        n = unsafe.objectFieldOffset(u00.class.getDeclaredField("_queue$volatile"));
        k = AtomicReferenceFieldUpdater.newUpdater(u00.class, Object.class, "_delayed$volatile");
        m = unsafe.objectFieldOffset(u00.class.getDeclaredField("_delayed$volatile"));
        l = AtomicIntegerFieldUpdater.newUpdater(u00.class, "_isCompleted$volatile");
    }

    public final void A() {
        s00 s00VarB;
        k.getClass();
        t00 t00Var = (t00) yi.a.getObjectVolatile(this, m);
        if (t00Var == null || lq1.b.get(t00Var) == 0) {
            return;
        }
        long jNanoTime = System.nanoTime();
        do {
            synchronized (t00Var) {
                try {
                    s00[] s00VarArr = t00Var.a;
                    s00 s00Var = s00VarArr != null ? s00VarArr[0] : null;
                    if (s00Var != null) {
                        s00VarB = ((jNanoTime - s00Var.d) > 0L ? 1 : ((jNanoTime - s00Var.d) == 0L ? 0 : -1)) >= 0 ? B(s00Var) : false ? t00Var.b(0) : null;
                    }
                } catch (Throwable th) {
                    throw th;
                }
            }
        } while (s00VarB != null);
    }

    /* JADX WARN: Code restructure failed: missing block: B:21:0x0041, code lost:
    
        return false;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final boolean B(java.lang.Runnable r7) {
        /*
            r6 = this;
        L0:
            java.util.concurrent.atomic.AtomicReferenceFieldUpdater r0 = defpackage.u00.j
            r0.getClass()
            sun.misc.Unsafe r1 = defpackage.yi.a
            long r2 = defpackage.u00.n
            java.lang.Object r1 = r1.getObjectVolatile(r6, r2)
            java.util.concurrent.atomic.AtomicIntegerFieldUpdater r2 = defpackage.u00.l
            int r2 = r2.get(r6)
            r3 = 0
            if (r2 == 0) goto L17
            return r3
        L17:
            r2 = 1
            if (r1 != 0) goto L22
            r1 = 0
            boolean r0 = defpackage.f0.B(r0, r6, r1, r7)
            if (r0 == 0) goto L0
            goto L58
        L22:
            boolean r4 = r1 instanceof defpackage.no0
            if (r4 == 0) goto L3d
            r4 = r1
            no0 r4 = (defpackage.no0) r4
            int r5 = r4.a(r7)
            if (r5 == 0) goto L58
            if (r5 == r2) goto L35
            r0 = 2
            if (r5 == r0) goto L41
            goto L0
        L35:
            no0 r2 = r4.d()
            defpackage.f0.B(r0, r6, r1, r2)
            goto L0
        L3d:
            lz r4 = defpackage.ng0.x
            if (r1 != r4) goto L42
        L41:
            return r3
        L42:
            no0 r3 = new no0
            r4 = 8
            r3.<init>(r4, r2)
            r4 = r1
            java.lang.Runnable r4 = (java.lang.Runnable) r4
            r3.a(r4)
            r3.a(r7)
            boolean r0 = defpackage.f0.B(r0, r6, r1, r3)
            if (r0 == 0) goto L0
        L58:
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.u00.B(java.lang.Runnable):boolean");
    }

    public final long C() {
        s00 s00Var;
        kd kdVar = this.h;
        if (((kdVar == null || kdVar.isEmpty()) ? Long.MAX_VALUE : 0L) != 0) {
            j.getClass();
            Unsafe unsafe = yi.a;
            Object objectVolatile = unsafe.getObjectVolatile(this, n);
            if (objectVolatile != null) {
                if (objectVolatile instanceof no0) {
                    long j2 = no0.f.get((no0) objectVolatile);
                    if (((int) (1073741823 & j2)) != ((int) ((j2 & 1152921503533105152L) >> 30))) {
                        return 0L;
                    }
                } else if (objectVolatile == ng0.x) {
                    return Long.MAX_VALUE;
                }
            }
            k.getClass();
            t00 t00Var = (t00) unsafe.getObjectVolatile(this, m);
            if (t00Var != null) {
                synchronized (t00Var) {
                    s00[] s00VarArr = t00Var.a;
                    s00Var = s00VarArr != null ? s00VarArr[0] : null;
                }
                if (s00Var != null) {
                    long jNanoTime = s00Var.d - System.nanoTime();
                    if (jNanoTime >= 0) {
                        return jNanoTime;
                    }
                }
            }
            return Long.MAX_VALUE;
        }
        return 0L;
    }

    public abstract Thread D();

    public final boolean E() {
        kd kdVar = this.h;
        if (kdVar != null ? kdVar.isEmpty() : true) {
            k.getClass();
            Unsafe unsafe = yi.a;
            t00 t00Var = (t00) unsafe.getObjectVolatile(this, m);
            if (t00Var != null && lq1.b.get(t00Var) != 0) {
                return false;
            }
            j.getClass();
            Object objectVolatile = unsafe.getObjectVolatile(this, n);
            if (objectVolatile != null) {
                if (objectVolatile instanceof no0) {
                    long j2 = no0.f.get((no0) objectVolatile);
                    return ((int) (1073741823 & j2)) == ((int) ((j2 & 1152921503533105152L) >> 30));
                }
                if (objectVolatile == ng0.x) {
                }
            }
            return true;
        }
        return false;
    }

    public void F(long j2, s00 s00Var) {
        mt.o.I(j2, s00Var);
    }

    public final void G() {
        s00 s00VarB;
        long jNanoTime = System.nanoTime();
        while (true) {
            k.getClass();
            t00 t00Var = (t00) yi.a.getObjectVolatile(this, m);
            if (t00Var == null) {
                return;
            }
            synchronized (t00Var) {
                s00VarB = lq1.b.get(t00Var) > 0 ? t00Var.b(0) : null;
            }
            if (s00VarB == null) {
                return;
            } else {
                F(jNanoTime, s00VarB);
            }
        }
    }

    public final void H() {
        j.getClass();
        Unsafe unsafe = yi.a;
        unsafe.putObjectVolatile(this, n, (Object) null);
        k.getClass();
        unsafe.putObjectVolatile(this, m, (Object) null);
    }

    public final void I(long j2, s00 s00Var) {
        Thread threadD;
        int iJ = J(j2, s00Var);
        if (iJ == 0) {
            if (!K(s00Var) || Thread.currentThread() == (threadD = D())) {
                return;
            }
            LockSupport.unpark(threadD);
            return;
        }
        if (iJ == 1) {
            F(j2, s00Var);
        } else {
            if (iJ == 2) {
                return;
            }
            zi.f("unexpected result");
        }
    }

    public final int J(long j2, s00 s00Var) {
        if (l.get(this) != 0) {
            return 1;
        }
        AtomicReferenceFieldUpdater atomicReferenceFieldUpdater = k;
        atomicReferenceFieldUpdater.getClass();
        Unsafe unsafe = yi.a;
        long j3 = m;
        t00 t00Var = (t00) unsafe.getObjectVolatile(this, j3);
        if (t00Var == null) {
            t00 t00Var2 = new t00();
            t00Var2.c = j2;
            f0.B(atomicReferenceFieldUpdater, this, null, t00Var2);
            Object objectVolatile = unsafe.getObjectVolatile(this, j3);
            objectVolatile.getClass();
            t00Var = (t00) objectVolatile;
        }
        return s00Var.b(j2, t00Var, this);
    }

    public final boolean K(s00 s00Var) {
        k.getClass();
        t00 t00Var = (t00) yi.a.getObjectVolatile(this, m);
        if (t00Var != null) {
            synchronized (t00Var) {
                s00[] s00VarArr = t00Var.a;
                s00Var = s00VarArr != null ? s00VarArr[0] : null;
            }
        }
        return s00Var == s00Var;
    }

    public xv c(long j2, jt1 jt1Var, ur urVar) {
        return nt.a.c(j2, jt1Var, urVar);
    }

    @Override // defpackage.iu
    public final void d(long j2, xi xiVar) {
        long j3 = j2 > 0 ? j2 >= 9223372036854L ? Long.MAX_VALUE : 1000000 * j2 : 0L;
        if (j3 < 4611686018427387903L) {
            long jNanoTime = System.nanoTime();
            q00 q00Var = new q00(this, j3 + jNanoTime, xiVar);
            I(jNanoTime, q00Var);
            xiVar.y(new si(1, q00Var));
        }
    }

    @Override // defpackage.wr
    public final void e(ur urVar, Runnable runnable) {
        z(runnable);
    }

    @Override // defpackage.p00
    public final long q() {
        if (s()) {
            return 0L;
        }
        A();
        Runnable runnableY = y();
        if (runnableY == null) {
            return C();
        }
        runnableY.run();
        return 0L;
    }

    @Override // defpackage.p00
    public void shutdown() {
        jq1.a.set(null);
        l.set(this, 1);
        x();
        while (q() <= 0) {
        }
        G();
    }

    public final void x() {
        lz lzVar = ng0.x;
        while (true) {
            AtomicReferenceFieldUpdater atomicReferenceFieldUpdater = j;
            atomicReferenceFieldUpdater.getClass();
            Object objectVolatile = yi.a.getObjectVolatile(this, n);
            if (objectVolatile == null) {
                if (f0.B(atomicReferenceFieldUpdater, this, null, lzVar)) {
                    return;
                }
            } else if (objectVolatile instanceof no0) {
                ((no0) objectVolatile).c();
                return;
            } else {
                if (objectVolatile == lzVar) {
                    return;
                }
                no0 no0Var = new no0(8, true);
                no0Var.a((Runnable) objectVolatile);
                if (f0.B(atomicReferenceFieldUpdater, this, objectVolatile, no0Var)) {
                    return;
                }
            }
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:14:0x002f, code lost:
    
        return null;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final java.lang.Runnable y() {
        /*
            r5 = this;
        L0:
            java.util.concurrent.atomic.AtomicReferenceFieldUpdater r0 = defpackage.u00.j
            r0.getClass()
            sun.misc.Unsafe r1 = defpackage.yi.a
            long r2 = defpackage.u00.n
            java.lang.Object r1 = r1.getObjectVolatile(r5, r2)
            r2 = 0
            if (r1 != 0) goto L11
            goto L2f
        L11:
            boolean r3 = r1 instanceof defpackage.no0
            if (r3 == 0) goto L2b
            r2 = r1
            no0 r2 = (defpackage.no0) r2
            java.lang.Object r3 = r2.e()
            lz r4 = defpackage.no0.g
            if (r3 == r4) goto L23
            java.lang.Runnable r3 = (java.lang.Runnable) r3
            return r3
        L23:
            no0 r2 = r2.d()
            defpackage.f0.B(r0, r5, r1, r2)
            goto L0
        L2b:
            lz r3 = defpackage.ng0.x
            if (r1 != r3) goto L30
        L2f:
            return r2
        L30:
            boolean r0 = defpackage.f0.B(r0, r5, r1, r2)
            if (r0 == 0) goto L0
            java.lang.Runnable r1 = (java.lang.Runnable) r1
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.u00.y():java.lang.Runnable");
    }

    public void z(Runnable runnable) {
        A();
        if (!B(runnable)) {
            mt.o.z(runnable);
            return;
        }
        Thread threadD = D();
        if (Thread.currentThread() != threadD) {
            LockSupport.unpark(threadD);
        }
    }
}
