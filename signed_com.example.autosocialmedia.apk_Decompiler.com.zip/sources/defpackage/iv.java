package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class iv {
    public final boolean a;
    public final boolean b;
    public final boolean d;
    public final pc1 c = pc1.d;
    public final boolean e = true;
    public final String f = "";

    public iv(boolean z, boolean z2, boolean z3) {
        this.a = z;
        this.b = z2;
        this.d = z3;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof iv)) {
            return false;
        }
        iv ivVar = (iv) obj;
        return this.a == ivVar.a && this.b == ivVar.b && this.c == ivVar.c && this.d == ivVar.d && this.e == ivVar.e;
    }

    public final int hashCode() {
        return Boolean.hashCode(this.e) + f0.f((this.c.hashCode() + f0.f(Boolean.hashCode(this.a) * 31, 31, this.b)) * 31, 31, this.d);
    }
}
