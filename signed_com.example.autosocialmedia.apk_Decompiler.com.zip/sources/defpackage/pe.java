package defpackage;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class pe {
    public static final pe d;
    public static final pe e;
    public static final pe f;
    public static final pe g;
    public static final pe h;
    public static final pe i;
    public static final pe j;
    public static final pe k;
    public static final /* synthetic */ pe[] l;

    static {
        pe peVar = new pe("NONE", 0);
        d = peVar;
        pe peVar2 = new pe("SCRAPE_TIKTOK", 1);
        e = peVar2;
        pe peVar3 = new pe("NURTURE_TIKTOK", 2);
        f = peVar3;
        pe peVar4 = new pe("GOLIKE_RUN", 3);
        g = peVar4;
        pe peVar5 = new pe("INSTAGRAM_RUN", 4);
        h = peVar5;
        pe peVar6 = new pe("X_RUN", 5);
        i = peVar6;
        pe peVar7 = new pe("THREADS_RUN", 6);
        j = peVar7;
        pe peVar8 = new pe("YOUTUBE_RUN", 7);
        k = peVar8;
        l = new pe[]{peVar, peVar2, peVar3, peVar4, peVar5, peVar6, peVar7, peVar8};
    }

    public static pe valueOf(String str) {
        return (pe) Enum.valueOf(pe.class, str);
    }

    public static pe[] values() {
        return (pe[]) l.clone();
    }
}
