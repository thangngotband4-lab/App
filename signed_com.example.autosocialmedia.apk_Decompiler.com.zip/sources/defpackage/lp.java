package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public abstract class lp {
    public static final vj1 a = new vj1(z5.s);
    public static final vj1 b = new vj1(z5.t);
    public static final vj1 c = new vj1(z5.v);
    public static final vj1 d = new vj1(z5.u);
    public static final vj1 e = new vj1(z5.x);
    public static final vj1 f = new vj1(z5.w);
    public static final vj1 g = new vj1(z5.D);
    public static final vj1 h = new vj1(z5.z);
    public static final vj1 i = new vj1(z5.A);
    public static final vj1 j = new vj1(z5.C);
    public static final vj1 k = new vj1(z5.B);
    public static final vj1 l = new vj1(z5.E);
    public static final vj1 m = new vj1(z5.F);
    public static final vj1 n = new vj1(z5.G);
    public static final vj1 o = new vj1(kp.g);
    public static final vj1 p = new vj1(kp.f);
    public static final vj1 q = new vj1(kp.h);
    public static final vj1 r = new vj1(kp.i);
    public static final vj1 s = new vj1(kp.j);
    public static final vj1 t = new vj1(kp.k);
    public static final vj1 u = new vj1(z5.H);
    public static final mp v = new mp(z5.I);
    public static final vj1 w = new vj1(z5.y);

    public static final void a(nz0 nz0Var, ba baVar, l50 l50Var, xo xoVar, int i2) {
        xoVar.X(1925803616);
        int i3 = i2 | (xoVar.f(nz0Var) ? 4 : 2) | (xoVar.f(baVar) ? 32 : 16) | (xoVar.h(l50Var) ? 256 : 128);
        if (xoVar.O(i3 & 1, (i3 & 147) != 146)) {
            k5 k5Var = (k5) nz0Var;
            c61 c61VarA = a.a(k5Var.getAccessibilityManager());
            c61 c61VarA2 = b.a(k5Var.getAutofill());
            c61 c61VarA3 = d.a(k5Var.getAutofillManager());
            c61 c61VarA4 = c.a(k5Var.getAutofillTree());
            c61 c61VarA5 = e.a(k5Var.getClipboardManager());
            c61 c61VarA6 = f.a(k5Var.getClipboard());
            c61 c61VarA7 = h.a(k5Var.getDensity());
            c61 c61VarA8 = i.a(k5Var.getFocusOwner());
            c61 c61VarA9 = j.a(k5Var.getFontLoader());
            c61VarA9.f = false;
            c61 c61VarA10 = k.a(k5Var.getFontFamilyResolver());
            c61VarA10.f = false;
            fl.b(new c61[]{c61VarA, c61VarA2, c61VarA3, c61VarA4, c61VarA5, c61VarA6, c61VarA7, c61VarA8, c61VarA9, c61VarA10, l.a(k5Var.getHapticFeedBack()), m.a(k5Var.getInputModeManager()), n.a(k5Var.getLayoutDirection()), o.a(k5Var.getTextInputService()), p.a(k5Var.getSoftwareKeyboardController()), q.a(k5Var.getTextToolbar()), r.a(baVar), s.a(k5Var.getViewConfiguration()), t.a(k5Var.getWindowInfo()), u.a(k5Var.getPointerIconService()), g.a(k5Var.getGraphicsContext()), fo0.a.a(k5Var.getRetainedValuesStore())}, l50Var, xoVar, ((i3 >> 3) & 112) | 8);
        } else {
            xoVar.R();
        }
        l61 l61VarR = xoVar.r();
        if (l61VarR != null) {
            l61VarR.d = new b6(nz0Var, baVar, l50Var, i2, 1);
        }
    }

    public static final void b(String str) {
        throw new IllegalStateException(("CompositionLocal " + str + " not present").toString());
    }
}
