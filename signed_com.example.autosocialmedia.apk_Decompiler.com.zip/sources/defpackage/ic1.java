package defpackage;

import kotlin.Metadata;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u000e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0001\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001¨\u0006\u0003"}, d2 = {"Lic1;", "Ljr0;", "Lnb1;", "foundation"}, k = 1, mv = {2, 0, 0}, xi = 48)
public final class ic1 extends jr0 {
    public final rb1 a;
    public final boolean b;

    public ic1(rb1 rb1Var, boolean z) {
        this.a = rb1Var;
        this.b = z;
    }

    @Override // defpackage.jr0
    public final er0 e() {
        nb1 nb1Var = new nb1();
        nb1Var.r = this.a;
        nb1Var.s = this.b;
        return nb1Var;
    }

    public final boolean equals(Object obj) {
        if (!(obj instanceof ic1)) {
            return false;
        }
        ic1 ic1Var = (ic1) obj;
        return ng0.o(this.a, ic1Var.a) && this.b == ic1Var.b;
    }

    @Override // defpackage.jr0
    public final void f(er0 er0Var) {
        nb1 nb1Var = (nb1) er0Var;
        nb1Var.r = this.a;
        nb1Var.s = this.b;
    }

    public final int hashCode() {
        return Boolean.hashCode(this.b) + f0.f(this.a.hashCode() * 31, 31, false);
    }
}
