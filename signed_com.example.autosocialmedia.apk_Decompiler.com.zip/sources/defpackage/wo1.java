package defpackage;

import android.os.Build;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class wo1 implements h50 {
    public final /* synthetic */ int d;
    public final /* synthetic */ wu e;
    public final /* synthetic */ gt0 f;

    public /* synthetic */ wo1(wu wuVar, gt0 gt0Var, int i) {
        this.d = i;
        this.e = wuVar;
        this.f = gt0Var;
    }

    @Override // defpackage.h50
    public final Object g(Object obj) {
        int i = this.d;
        gt0 gt0Var = this.f;
        wu wuVar = this.e;
        switch (i) {
            case 0:
                r51 r51Var = new r51((w40) obj, 1);
                wo1 wo1Var = new wo1(wuVar, gt0Var, 1);
                if (op0.a()) {
                    return op0.a() ? new lp0(r51Var, wo1Var, Build.VERSION.SDK_INT == 28 ? t21.b : t21.c) : cr0.a;
                }
                throw new UnsupportedOperationException("Magnifier is only supported on API level 28 and higher.");
            default:
                kw kwVar = (kw) obj;
                gt0Var.setValue(new yf0((((long) wuVar.P(kw.a(kwVar.a))) & 4294967295L) | (((long) wuVar.P(kw.b(kwVar.a))) << 32)));
                return bw1.a;
        }
    }
}
