package defpackage;

import android.view.View;
import com.example.autosocialmedia.R;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public abstract class fl {
    public static hc0 a;
    public static hc0 b;
    public static hc0 c;
    public static hc0 d;
    public static hc0 e;
    public static hc0 f;
    public static hc0 g;
    public static hc0 h;
    public static hc0 i;
    public static hc0 j;
    public static hc0 k;

    public static je1 A(l50 l50Var) {
        je1 je1Var = new je1();
        je1Var.f = rm.w(je1Var, je1Var, l50Var);
        return je1Var;
    }

    /* JADX WARN: Code restructure failed: missing block: B:82:0x0166, code lost:
    
        if (r3 == r13) goto L83;
     */
    /* JADX WARN: Removed duplicated region for block: B:46:0x00bd A[Catch: all -> 0x0053, TryCatch #1 {all -> 0x0053, blocks: (B:21:0x004f, B:44:0x00b5, B:46:0x00bd, B:48:0x00c9, B:50:0x00d5, B:41:0x009b), top: B:99:0x002b }] */
    /* JADX WARN: Removed duplicated region for block: B:8:0x001e  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static final java.lang.Object B(defpackage.ol1 r17, defpackage.eg0 r18, defpackage.p7 r19, defpackage.m31 r20, defpackage.kf r21) {
        /*
            Method dump skipped, instruction units count: 414
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.fl.B(ol1, eg0, p7, m31, kf):java.lang.Object");
    }

    public static final void C(xi xiVar, tq tqVar, boolean z) {
        Object objU = xiVar.u();
        Throwable thF = xiVar.f(objU);
        Object d81Var = thF != null ? new d81(thF) : xiVar.g(objU);
        if (!z) {
            tqVar.h(d81Var);
            return;
        }
        tqVar.getClass();
        nv nvVar = (nv) tqVar;
        uq uqVar = nvVar.h;
        Object obj = nvVar.j;
        ur urVarE = uqVar.e();
        Object objN = ct.N(urVarE, obj);
        xv1 xv1VarJ = objN != ct.W ? jl.J(uqVar, urVarE, objN) : null;
        try {
            uqVar.h(d81Var);
            if (xv1VarJ == null || xv1VarJ.i0()) {
                ct.J(urVarE, objN);
            }
        } catch (Throwable th) {
            if (xv1VarJ == null || xv1VarJ.i0()) {
                ct.J(urVarE, objN);
            }
            throw th;
        }
    }

    public static String D(long j2) {
        int i2 = (int) (j2 >> 32);
        int i3 = (int) (j2 & 4294967295L);
        if (Float.intBitsToFloat(i2) == Float.intBitsToFloat(i3)) {
            return "CornerRadius.circular(" + om.V(Float.intBitsToFloat(i2)) + ')';
        }
        return "CornerRadius.elliptical(" + om.V(Float.intBitsToFloat(i2)) + ", " + om.V(Float.intBitsToFloat(i3)) + ')';
    }

    /* JADX WARN: Code restructure failed: missing block: B:34:0x009e, code lost:
    
        if (r15 == r6) goto L35;
     */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0013  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static final java.lang.Object E(defpackage.ol1 r12, defpackage.qn1 r13, defpackage.m31 r14, defpackage.kf r15) {
        /*
            Method dump skipped, instruction units count: 213
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.fl.E(ol1, qn1, m31, kf):java.lang.Object");
    }

    /* JADX WARN: Removed duplicated region for block: B:45:0x00b9  */
    /* JADX WARN: Removed duplicated region for block: B:48:0x00c4  */
    /* JADX WARN: Removed duplicated region for block: B:50:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:593)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static final void a(defpackage.c61 r11, defpackage.l50 r12, defpackage.xo r13, int r14) {
        /*
            Method dump skipped, instruction units count: 204
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.fl.a(c61, l50, xo, int):void");
    }

    /* JADX WARN: Removed duplicated region for block: B:26:0x00a3  */
    /* JADX WARN: Removed duplicated region for block: B:29:0x00af  */
    /* JADX WARN: Removed duplicated region for block: B:31:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:593)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static final void b(defpackage.c61[] r8, defpackage.l50 r9, defpackage.xo r10, int r11) {
        /*
            r0 = 415205898(0x18bf8a0a, float:4.9511727E-24)
            r10.X(r0)
            zf0 r0 = r10.x
            t11 r1 = r10.l()
            r2 = 201(0xc9, float:2.82E-43)
            gx0 r3 = defpackage.yo.b
            r10.U(r2, r3)
            boolean r2 = r10.S
            r3 = 1
            r4 = 0
            if (r2 == 0) goto L27
            t11 r2 = defpackage.t11.g
            t11 r2 = defpackage.hl.b0(r8, r1, r2)
            t11 r1 = r10.f0(r1, r2)
            r10.J = r3
        L25:
            r2 = r4
            goto L72
        L27:
            ih1 r2 = r10.G
            int r5 = r2.g
            java.lang.Object r2 = r2.h(r5, r4)
            r2.getClass()
            t11 r2 = (defpackage.t11) r2
            ih1 r5 = r10.G
            int r6 = r5.g
            java.lang.Object r5 = r5.h(r6, r3)
            r5.getClass()
            t11 r5 = (defpackage.t11) r5
            t11 r6 = defpackage.hl.b0(r8, r1, r5)
            boolean r7 = r10.A()
            if (r7 == 0) goto L63
            boolean r7 = r10.y
            if (r7 != 0) goto L63
            boolean r5 = r5.equals(r6)
            if (r5 != 0) goto L56
            goto L63
        L56:
            int r1 = r10.l
            ih1 r5 = r10.G
            int r5 = r5.s()
            int r5 = r5 + r1
            r10.l = r5
            r1 = r2
            goto L25
        L63:
            t11 r1 = r10.f0(r1, r6)
            boolean r5 = r10.y
            if (r5 != 0) goto L71
            boolean r2 = defpackage.ng0.o(r1, r2)
            if (r2 != 0) goto L25
        L71:
            r2 = r3
        L72:
            if (r2 == 0) goto L7b
            boolean r5 = r10.S
            if (r5 != 0) goto L7b
            r10.J(r1)
        L7b:
            boolean r5 = r10.w
            r0.c(r5)
            r10.w = r2
            r10.K = r1
            r2 = 202(0xca, float:2.83E-43)
            gx0 r5 = defpackage.yo.c
            r10.S(r5, r2, r1, r4)
            int r1 = r11 >> 3
            r1 = r1 & 14
            java.lang.Integer r1 = java.lang.Integer.valueOf(r1)
            r9.f(r10, r1)
            r10.p(r4)
            r10.p(r4)
            int r0 = r0.b()
            if (r0 == 0) goto La3
            goto La4
        La3:
            r3 = r4
        La4:
            r10.w = r3
            r0 = 0
            r10.K = r0
            l61 r10 = r10.r()
            if (r10 == 0) goto Lb7
            on r0 = new on
            r1 = 2
            r0.<init>(r8, r9, r11, r1)
            r10.d = r0
        Lb7:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.fl.b(c61[], l50, xo, int):void");
    }

    public static final void c(final Object obj, final int i2, final uk0 uk0Var, final qn qnVar, xo xoVar, final int i3) {
        int i4;
        xoVar.X(872548579);
        if ((i3 & 6) == 0) {
            i4 = (xoVar.h(obj) ? 4 : 2) | i3;
        } else {
            i4 = i3;
        }
        if ((i3 & 48) == 0) {
            i4 |= xoVar.d(i2) ? 32 : 16;
        }
        if ((i3 & 384) == 0) {
            i4 |= xoVar.h(uk0Var) ? 256 : 128;
        }
        if ((i3 & 3072) == 0) {
            i4 |= xoVar.h(qnVar) ? 2048 : 1024;
        }
        if (xoVar.O(i4 & 1, (i4 & 1171) != 1170)) {
            boolean zF = xoVar.f(obj) | xoVar.f(uk0Var);
            Object objL = xoVar.L();
            Object obj2 = ro.a;
            if (zF || objL == obj2) {
                objL = new sk0(obj, uk0Var);
                xoVar.g0(objL);
            }
            sk0 sk0Var = (sk0) objL;
            sk0Var.c = i2;
            m01 m01Var = sk0Var.g;
            a61 a61Var = i21.a;
            sk0 sk0Var2 = (sk0) xoVar.j(a61Var);
            ph1 ph1VarX = om.x();
            h50 h50VarE = ph1VarX != null ? ph1VarX.e() : null;
            ph1 ph1VarJ = om.J(ph1VarX);
            try {
                if (sk0Var2 != ((sk0) m01Var.getValue())) {
                    m01Var.setValue(sk0Var2);
                    if (sk0Var.d > 0) {
                        sk0 sk0Var3 = sk0Var.e;
                        if (sk0Var3 != null) {
                            sk0Var3.b();
                        }
                        if (sk0Var2 != null) {
                            sk0Var2.a();
                        } else {
                            sk0Var2 = null;
                        }
                        sk0Var.e = sk0Var2;
                    }
                }
                om.S(ph1VarX, ph1VarJ, h50VarE);
                boolean zF2 = xoVar.f(sk0Var);
                Object objL2 = xoVar.L();
                if (zF2 || objL2 == obj2) {
                    objL2 = new l(13, sk0Var);
                    xoVar.g0(objL2);
                }
                ct.h(sk0Var, (h50) objL2, xoVar);
                a(a61Var.a(sk0Var), qnVar, xoVar, ((i4 >> 6) & 112) | 8);
            } catch (Throwable th) {
                om.S(ph1VarX, ph1VarJ, h50VarE);
                throw th;
            }
        } else {
            xoVar.R();
        }
        l61 l61VarR = xoVar.r();
        if (l61VarR != null) {
            l61VarR.d = new l50() { // from class: tk0
                @Override // defpackage.l50
                public final Object f(Object obj3, Object obj4) {
                    ((Integer) obj4).getClass();
                    fl.c(obj, i2, uk0Var, qnVar, (xo) obj3, bm.T(i3 | 1));
                    return bw1.a;
                }
            };
        }
    }

    public static final x61 d(long j2, long j3) {
        int i2 = (int) (j2 >> 32);
        int i3 = (int) (j2 & 4294967295L);
        return new x61(Float.intBitsToFloat(i2), Float.intBitsToFloat(i3), Float.intBitsToFloat((int) (j3 >> 32)) + Float.intBitsToFloat(i2), Float.intBitsToFloat((int) (j3 & 4294967295L)) + Float.intBitsToFloat(i3));
    }

    /* JADX WARN: Removed duplicated region for block: B:17:0x003f A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:20:0x004b  */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0013  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:16:0x003d -> B:18:0x0040). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static final java.lang.Object e(defpackage.ol1 r6, defpackage.kf r7) {
        /*
            boolean r0 = r7 instanceof defpackage.yc1
            if (r0 == 0) goto L13
            r0 = r7
            yc1 r0 = (defpackage.yc1) r0
            int r1 = r0.f
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L13
            int r1 = r1 - r2
            r0.f = r1
            goto L18
        L13:
            yc1 r0 = new yc1
            r0.<init>(r7)
        L18:
            java.lang.Object r7 = r0.e
            int r1 = r0.f
            r2 = 1
            if (r1 == 0) goto L2e
            if (r1 != r2) goto L27
            ol1 r6 = r0.d
            defpackage.vl.Q(r7)
            goto L40
        L27:
            java.lang.String r6 = "call to 'resume' before 'invoke' with coroutine"
            defpackage.zi.f(r6)
            r6 = 0
            return r6
        L2e:
            defpackage.vl.Q(r7)
        L31:
            r0.d = r6
            r0.f = r2
            n31 r7 = defpackage.n31.e
            java.lang.Object r7 = r6.a(r7, r0)
            es r1 = defpackage.es.d
            if (r7 != r1) goto L40
            return r1
        L40:
            m31 r7 = (defpackage.m31) r7
            java.util.List r1 = r7.a
            int r3 = r1.size()
            r4 = 0
        L49:
            if (r4 >= r3) goto L5b
            java.lang.Object r5 = r1.get(r4)
            t31 r5 = (defpackage.t31) r5
            boolean r5 = defpackage.bm.m(r5)
            if (r5 != 0) goto L58
            goto L31
        L58:
            int r4 = r4 + 1
            goto L49
        L5b:
            return r7
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.fl.e(ol1, kf):java.lang.Object");
    }

    public static final String f() {
        String str = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
        str.getClass();
        return str;
    }

    /* JADX WARN: Code restructure failed: missing block: B:47:0x00c1, code lost:
    
        if (r15 == r6) goto L48;
     */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0013  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static final java.lang.Object g(defpackage.ol1 r11, defpackage.qn1 r12, defpackage.m31 r13, int r14, defpackage.kf r15) {
        /*
            Method dump skipped, instruction units count: 247
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.fl.g(ol1, qn1, m31, int, kf):java.lang.Object");
    }

    public static final int h(long[] jArr, long j2) {
        int length = jArr.length - 1;
        int i2 = 0;
        while (i2 <= length) {
            int i3 = (i2 + length) >>> 1;
            long j3 = jArr[i3];
            if (j2 > j3) {
                i2 = i3 + 1;
            } else {
                if (j2 >= j3) {
                    return i3;
                }
                length = i3 - 1;
            }
        }
        return -(i2 + 1);
    }

    public static final gt0 i(ks0 ks0Var, xo xoVar, int i2) {
        Object objL = xoVar.L();
        dp1 dp1Var = ro.a;
        if (objL == dp1Var) {
            objL = hl.I(Boolean.FALSE);
            xoVar.g0(objL);
        }
        gt0 gt0Var = (gt0) objL;
        int i3 = 0;
        boolean z = (((i2 & 14) ^ 6) > 4 && xoVar.f(ks0Var)) || (i2 & 6) == 4;
        Object objL2 = xoVar.L();
        if (z || objL2 == dp1Var) {
            objL2 = new w20(ks0Var, gt0Var, null, i3);
            xoVar.g0(objL2);
        }
        ct.o(xoVar, (l50) objL2, ks0Var);
        return gt0Var;
    }

    public static int j(Comparable comparable, Comparable comparable2) {
        if (comparable == comparable2) {
            return 0;
        }
        if (comparable == null) {
            return -1;
        }
        if (comparable2 == null) {
            return 1;
        }
        return comparable.compareTo(comparable2);
    }

    public static final boolean k(long j2, long j3) {
        return j2 == j3;
    }

    public static final hc0 l() {
        hc0 hc0Var = d;
        if (hc0Var != null) {
            return hc0Var;
        }
        gc0 gc0Var = new gc0("Rounded.History", 24.0f, 24.0f, 24.0f, 24.0f, 0L, 0, false, 96);
        int i2 = lx1.a;
        pi1 pi1Var = new pi1(ql.b);
        l1 l1VarH = f0.h(13.26f, 3.0f);
        l1VarH.l(8.17f, 2.86f, 4.0f, 6.95f, 4.0f, 12.0f);
        l1VarH.t(2.21f, 12.0f);
        l1VarH.m(-0.45f, 0.0f, -0.67f, 0.54f, -0.35f, 0.85f);
        l1VarH.u(2.79f, 2.8f);
        l1VarH.m(0.2f, 0.2f, 0.51f, 0.2f, 0.71f, 0.0f);
        l1VarH.u(2.79f, -2.8f);
        l1VarH.m(0.31f, -0.31f, 0.09f, -0.85f, -0.36f, -0.85f);
        l1VarH.t(6.0f, 12.0f);
        l1VarH.m(0.0f, -3.9f, 3.18f, -7.05f, 7.1f, -7.0f);
        l1VarH.m(3.72f, 0.05f, 6.85f, 3.18f, 6.9f, 6.9f);
        l1VarH.m(0.05f, 3.91f, -3.1f, 7.1f, -7.0f, 7.1f);
        l1VarH.m(-1.61f, 0.0f, -3.1f, -0.55f, -4.28f, -1.48f);
        l1VarH.m(-0.4f, -0.31f, -0.96f, -0.28f, -1.32f, 0.08f);
        l1VarH.m(-0.42f, 0.42f, -0.39f, 1.13f, 0.08f, 1.49f);
        l1VarH.l(9.0f, 20.29f, 10.91f, 21.0f, 13.0f, 21.0f);
        l1VarH.m(5.05f, 0.0f, 9.14f, -4.17f, 9.0f, -9.26f);
        l1VarH.m(-0.13f, -4.69f, -4.05f, -8.61f, -8.74f, -8.74f);
        l1VarH.i();
        l1VarH.v(12.75f, 8.0f);
        l1VarH.m(-0.41f, 0.0f, -0.75f, 0.34f, -0.75f, 0.75f);
        l1VarH.I(3.68f);
        l1VarH.m(0.0f, 0.35f, 0.19f, 0.68f, 0.49f, 0.86f);
        l1VarH.u(3.12f, 1.85f);
        l1VarH.m(0.36f, 0.21f, 0.82f, 0.09f, 1.03f, -0.26f);
        l1VarH.m(0.21f, -0.36f, 0.09f, -0.82f, -0.26f, -1.03f);
        l1VarH.u(-2.88f, -1.71f);
        l1VarH.I(-3.4f);
        l1VarH.m(0.0f, -0.4f, -0.34f, -0.74f, -0.75f, -0.74f);
        l1VarH.i();
        gc0.a(gc0Var, (ArrayList) l1VarH.e, pi1Var);
        hc0 hc0VarB = gc0Var.b();
        d = hc0VarB;
        return hc0VarB;
    }

    public static final hc0 m() {
        hc0 hc0Var = e;
        if (hc0Var != null) {
            return hc0Var;
        }
        gc0 gc0Var = new gc0("Rounded.Info", 24.0f, 24.0f, 24.0f, 24.0f, 0L, 0, false, 96);
        int i2 = lx1.a;
        pi1 pi1Var = new pi1(ql.b);
        l1 l1VarH = f0.h(12.0f, 2.0f);
        l1VarH.l(6.48f, 2.0f, 2.0f, 6.48f, 2.0f, 12.0f);
        l1VarH.A(4.48f, 10.0f, 10.0f, 10.0f);
        l1VarH.A(10.0f, -4.48f, 10.0f, -10.0f);
        l1VarH.z(17.52f, 2.0f, 12.0f, 2.0f);
        l1VarH.i();
        l1VarH.v(12.0f, 17.0f);
        l1VarH.m(-0.55f, 0.0f, -1.0f, -0.45f, -1.0f, -1.0f);
        l1VarH.I(-4.0f);
        l1VarH.m(0.0f, -0.55f, 0.45f, -1.0f, 1.0f, -1.0f);
        l1VarH.A(1.0f, 0.45f, 1.0f, 1.0f);
        l1VarH.I(4.0f);
        l1VarH.m(0.0f, 0.55f, -0.45f, 1.0f, -1.0f, 1.0f);
        l1VarH.i();
        l1VarH.v(13.0f, 9.0f);
        l1VarH.r(-2.0f);
        l1VarH.t(11.0f, 7.0f);
        l1VarH.r(2.0f);
        l1VarH.I(2.0f);
        l1VarH.i();
        gc0.a(gc0Var, (ArrayList) l1VarH.e, pi1Var);
        hc0 hc0VarB = gc0Var.b();
        e = hc0VarB;
        return hc0VarB;
    }

    public static final hc0 n() {
        hc0 hc0Var = f;
        if (hc0Var != null) {
            return hc0Var;
        }
        gc0 gc0Var = new gc0("Rounded.KeyboardArrowRight", 24.0f, 24.0f, 24.0f, 24.0f, 0L, 0, false, 96);
        int i2 = lx1.a;
        pi1 pi1Var = new pi1(ql.b);
        l1 l1Var = new l1(16);
        l1Var.v(9.29f, 15.88f);
        l1Var.t(13.17f, 12.0f);
        l1Var.t(9.29f, 8.12f);
        l1Var.m(-0.39f, -0.39f, -0.39f, -1.02f, 0.0f, -1.41f);
        l1Var.m(0.39f, -0.39f, 1.02f, -0.39f, 1.41f, 0.0f);
        l1Var.u(4.59f, 4.59f);
        l1Var.m(0.39f, 0.39f, 0.39f, 1.02f, 0.0f, 1.41f);
        l1Var.t(10.7f, 17.3f);
        l1Var.m(-0.39f, 0.39f, -1.02f, 0.39f, -1.41f, 0.0f);
        l1Var.m(-0.38f, -0.39f, -0.39f, -1.03f, 0.0f, -1.42f);
        l1Var.i();
        gc0.a(gc0Var, (ArrayList) l1Var.e, pi1Var);
        hc0 hc0VarB = gc0Var.b();
        f = hc0VarB;
        return hc0VarB;
    }

    public static final hc0 o() {
        hc0 hc0Var = g;
        if (hc0Var != null) {
            return hc0Var;
        }
        gc0 gc0Var = new gc0("Rounded.Lock", 24.0f, 24.0f, 24.0f, 24.0f, 0L, 0, false, 96);
        int i2 = lx1.a;
        pi1 pi1Var = new pi1(ql.b);
        l1 l1Var = new l1(16);
        l1Var.v(18.0f, 8.0f);
        l1Var.r(-1.0f);
        l1Var.t(17.0f, 6.0f);
        l1Var.m(0.0f, -2.76f, -2.24f, -5.0f, -5.0f, -5.0f);
        l1Var.z(7.0f, 3.24f, 7.0f, 6.0f);
        l1Var.I(2.0f);
        l1Var.t(6.0f, 8.0f);
        l1Var.m(-1.1f, 0.0f, -2.0f, 0.9f, -2.0f, 2.0f);
        l1Var.I(10.0f);
        l1Var.m(0.0f, 1.1f, 0.9f, 2.0f, 2.0f, 2.0f);
        l1Var.r(12.0f);
        l1Var.m(1.1f, 0.0f, 2.0f, -0.9f, 2.0f, -2.0f);
        l1Var.t(20.0f, 10.0f);
        l1Var.m(0.0f, -1.1f, -0.9f, -2.0f, -2.0f, -2.0f);
        l1Var.i();
        l1Var.v(12.0f, 17.0f);
        l1Var.m(-1.1f, 0.0f, -2.0f, -0.9f, -2.0f, -2.0f);
        l1Var.A(0.9f, -2.0f, 2.0f, -2.0f);
        l1Var.A(2.0f, 0.9f, 2.0f, 2.0f);
        l1Var.A(-0.9f, 2.0f, -2.0f, 2.0f);
        l1Var.i();
        l1Var.v(9.0f, 8.0f);
        l1Var.t(9.0f, 6.0f);
        l1Var.m(0.0f, -1.66f, 1.34f, -3.0f, 3.0f, -3.0f);
        l1Var.A(3.0f, 1.34f, 3.0f, 3.0f);
        l1Var.I(2.0f);
        l1Var.t(9.0f, 8.0f);
        l1Var.i();
        gc0.a(gc0Var, (ArrayList) l1Var.e, pi1Var);
        hc0 hc0VarB = gc0Var.b();
        g = hc0VarB;
        return hc0VarB;
    }

    public static final hc0 p() {
        hc0 hc0Var = h;
        if (hc0Var != null) {
            return hc0Var;
        }
        gc0 gc0Var = new gc0("Rounded.MusicNote", 24.0f, 24.0f, 24.0f, 24.0f, 0L, 0, false, 96);
        int i2 = lx1.a;
        pi1 pi1Var = new pi1(ql.b);
        l1 l1Var = new l1(16);
        l1Var.v(12.0f, 5.0f);
        l1Var.I(8.55f);
        l1Var.m(-0.94f, -0.54f, -2.1f, -0.75f, -3.33f, -0.32f);
        l1Var.m(-1.34f, 0.48f, -2.37f, 1.67f, -2.61f, 3.07f);
        l1Var.m(-0.46f, 2.74f, 1.86f, 5.08f, 4.59f, 4.65f);
        l1Var.m(1.96f, -0.31f, 3.35f, -2.11f, 3.35f, -4.1f);
        l1Var.H(7.0f);
        l1Var.r(2.0f);
        l1Var.m(1.1f, 0.0f, 2.0f, -0.9f, 2.0f, -2.0f);
        l1Var.A(-0.9f, -2.0f, -2.0f, -2.0f);
        l1Var.r(-2.0f);
        l1Var.m(-1.1f, 0.0f, -2.0f, 0.9f, -2.0f, 2.0f);
        l1Var.i();
        gc0.a(gc0Var, (ArrayList) l1Var.e, pi1Var);
        hc0 hc0VarB = gc0Var.b();
        h = hc0VarB;
        return hc0VarB;
    }

    public static final hc0 q() {
        hc0 hc0Var = i;
        if (hc0Var != null) {
            return hc0Var;
        }
        gc0 gc0Var = new gc0("Rounded.PersonAdd", 24.0f, 24.0f, 24.0f, 24.0f, 0L, 0, false, 96);
        int i2 = lx1.a;
        pi1 pi1Var = new pi1(ql.b);
        l1 l1VarH = f0.h(15.0f, 12.0f);
        l1VarH.m(2.21f, 0.0f, 4.0f, -1.79f, 4.0f, -4.0f);
        l1VarH.A(-1.79f, -4.0f, -4.0f, -4.0f);
        l1VarH.A(-4.0f, 1.79f, -4.0f, 4.0f);
        l1VarH.A(1.79f, 4.0f, 4.0f, 4.0f);
        l1VarH.i();
        l1VarH.v(6.0f, 10.0f);
        l1VarH.t(6.0f, 8.0f);
        l1VarH.m(0.0f, -0.55f, -0.45f, -1.0f, -1.0f, -1.0f);
        l1VarH.A(-1.0f, 0.45f, -1.0f, 1.0f);
        l1VarH.I(2.0f);
        l1VarH.t(2.0f, 10.0f);
        l1VarH.m(-0.55f, 0.0f, -1.0f, 0.45f, -1.0f, 1.0f);
        l1VarH.A(0.45f, 1.0f, 1.0f, 1.0f);
        l1VarH.r(2.0f);
        l1VarH.I(2.0f);
        l1VarH.m(0.0f, 0.55f, 0.45f, 1.0f, 1.0f, 1.0f);
        l1VarH.A(1.0f, -0.45f, 1.0f, -1.0f);
        l1VarH.I(-2.0f);
        l1VarH.r(2.0f);
        l1VarH.m(0.55f, 0.0f, 1.0f, -0.45f, 1.0f, -1.0f);
        l1VarH.A(-0.45f, -1.0f, -1.0f, -1.0f);
        l1VarH.t(6.0f, 10.0f);
        l1VarH.i();
        l1VarH.v(15.0f, 14.0f);
        l1VarH.m(-2.67f, 0.0f, -8.0f, 1.34f, -8.0f, 4.0f);
        l1VarH.I(1.0f);
        l1VarH.m(0.0f, 0.55f, 0.45f, 1.0f, 1.0f, 1.0f);
        l1VarH.r(14.0f);
        l1VarH.m(0.55f, 0.0f, 1.0f, -0.45f, 1.0f, -1.0f);
        l1VarH.I(-1.0f);
        l1VarH.m(0.0f, -2.66f, -5.33f, -4.0f, -8.0f, -4.0f);
        l1VarH.i();
        gc0.a(gc0Var, (ArrayList) l1VarH.e, pi1Var);
        hc0 hc0VarB = gc0Var.b();
        i = hc0VarB;
        return hc0VarB;
    }

    public static final c41 r(View view) {
        c41 c41Var = (c41) view.getTag(R.id.pooling_container_listener_holder_tag);
        if (c41Var != null) {
            return c41Var;
        }
        c41 c41Var2 = new c41();
        view.setTag(R.id.pooling_container_listener_holder_tag, c41Var2);
        return c41Var2;
    }

    public static final hc0 s() {
        hc0 hc0Var = j;
        if (hc0Var != null) {
            return hc0Var;
        }
        gc0 gc0Var = new gc0("Rounded.Public", 24.0f, 24.0f, 24.0f, 24.0f, 0L, 0, false, 96);
        int i2 = lx1.a;
        pi1 pi1Var = new pi1(ql.b);
        l1 l1VarH = f0.h(12.0f, 2.0f);
        l1VarH.l(6.48f, 2.0f, 2.0f, 6.48f, 2.0f, 12.0f);
        l1VarH.A(4.48f, 10.0f, 10.0f, 10.0f);
        l1VarH.A(10.0f, -4.48f, 10.0f, -10.0f);
        l1VarH.z(17.52f, 2.0f, 12.0f, 2.0f);
        l1VarH.i();
        l1VarH.v(11.0f, 19.93f);
        l1VarH.m(-3.95f, -0.49f, -7.0f, -3.85f, -7.0f, -7.93f);
        l1VarH.m(0.0f, -0.62f, 0.08f, -1.21f, 0.21f, -1.79f);
        l1VarH.t(9.0f, 15.0f);
        l1VarH.I(1.0f);
        l1VarH.m(0.0f, 1.1f, 0.9f, 2.0f, 2.0f, 2.0f);
        l1VarH.I(1.93f);
        l1VarH.i();
        l1VarH.v(17.9f, 17.39f);
        l1VarH.m(-0.26f, -0.81f, -1.0f, -1.39f, -1.9f, -1.39f);
        l1VarH.r(-1.0f);
        l1VarH.I(-3.0f);
        l1VarH.m(0.0f, -0.55f, -0.45f, -1.0f, -1.0f, -1.0f);
        l1VarH.t(8.0f, 12.0f);
        l1VarH.I(-2.0f);
        l1VarH.r(2.0f);
        l1VarH.m(0.55f, 0.0f, 1.0f, -0.45f, 1.0f, -1.0f);
        l1VarH.t(11.0f, 7.0f);
        l1VarH.r(2.0f);
        l1VarH.m(1.1f, 0.0f, 2.0f, -0.9f, 2.0f, -2.0f);
        l1VarH.I(-0.41f);
        l1VarH.m(2.93f, 1.19f, 5.0f, 4.06f, 5.0f, 7.41f);
        l1VarH.m(0.0f, 2.08f, -0.8f, 3.97f, -2.1f, 5.39f);
        l1VarH.i();
        gc0.a(gc0Var, (ArrayList) l1VarH.e, pi1Var);
        hc0 hc0VarB = gc0Var.b();
        j = hc0VarB;
        return hc0VarB;
    }

    public static final i91 t(gq0 gq0Var) {
        Object objJ = gq0Var.j();
        if (objJ instanceof i91) {
            return (i91) objJ;
        }
        return null;
    }

    public static final hc0 u() {
        hc0 hc0Var = k;
        if (hc0Var != null) {
            return hc0Var;
        }
        gc0 gc0Var = new gc0("Rounded.Schedule", 24.0f, 24.0f, 24.0f, 24.0f, 0L, 0, false, 96);
        int i2 = lx1.a;
        pi1 pi1Var = new pi1(ql.b);
        l1 l1VarH = f0.h(11.99f, 2.0f);
        l1VarH.l(6.47f, 2.0f, 2.0f, 6.48f, 2.0f, 12.0f);
        l1VarH.A(4.47f, 10.0f, 9.99f, 10.0f);
        l1VarH.l(17.52f, 22.0f, 22.0f, 17.52f, 22.0f, 12.0f);
        l1VarH.z(17.52f, 2.0f, 11.99f, 2.0f);
        l1VarH.i();
        l1VarH.v(12.0f, 20.0f);
        l1VarH.m(-4.42f, 0.0f, -8.0f, -3.58f, -8.0f, -8.0f);
        l1VarH.A(3.58f, -8.0f, 8.0f, -8.0f);
        l1VarH.A(8.0f, 3.58f, 8.0f, 8.0f);
        l1VarH.A(-3.58f, 8.0f, -8.0f, 8.0f);
        l1VarH.i();
        l1VarH.v(11.78f, 7.0f);
        l1VarH.r(-0.06f);
        l1VarH.m(-0.4f, 0.0f, -0.72f, 0.32f, -0.72f, 0.72f);
        l1VarH.I(4.72f);
        l1VarH.m(0.0f, 0.35f, 0.18f, 0.68f, 0.49f, 0.86f);
        l1VarH.u(4.15f, 2.49f);
        l1VarH.m(0.34f, 0.2f, 0.78f, 0.1f, 0.98f, -0.24f);
        l1VarH.m(0.21f, -0.34f, 0.1f, -0.79f, -0.25f, -0.99f);
        l1VarH.u(-3.87f, -2.3f);
        l1VarH.t(12.5f, 7.72f);
        l1VarH.m(0.0f, -0.4f, -0.32f, -0.72f, -0.72f, -0.72f);
        l1VarH.i();
        gc0.a(gc0Var, (ArrayList) l1VarH.e, pi1Var);
        hc0 hc0VarB = gc0Var.b();
        k = hc0VarB;
        return hc0VarB;
    }

    public static final float v(i91 i91Var) {
        if (i91Var != null) {
            return i91Var.a;
        }
        return 0.0f;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public static final void w(zx zxVar) {
        if (((er0) zxVar).d.q) {
            tl.K(zxVar, 1).b1();
        }
    }

    public static final boolean x(float[] fArr, float[] fArr2) {
        if (fArr.length < 16 || fArr2.length < 16) {
            return false;
        }
        float f2 = fArr[0];
        float f3 = fArr[1];
        float f4 = fArr[2];
        float f5 = fArr[3];
        float f6 = fArr[4];
        float f7 = fArr[5];
        float f8 = fArr[6];
        float f9 = fArr[7];
        float f10 = fArr[8];
        float f11 = fArr[9];
        float f12 = fArr[10];
        float f13 = fArr[11];
        float f14 = fArr[12];
        float f15 = fArr[13];
        float f16 = fArr[14];
        float f17 = fArr[15];
        float f18 = (f2 * f7) - (f3 * f6);
        float f19 = (f2 * f8) - (f4 * f6);
        float f20 = (f2 * f9) - (f5 * f6);
        float f21 = (f3 * f8) - (f4 * f7);
        float f22 = (f3 * f9) - (f5 * f7);
        float f23 = (f4 * f9) - (f5 * f8);
        float f24 = (f10 * f15) - (f11 * f14);
        float f25 = (f10 * f16) - (f12 * f14);
        float f26 = (f10 * f17) - (f13 * f14);
        float f27 = (f11 * f16) - (f12 * f15);
        float f28 = (f11 * f17) - (f13 * f15);
        float f29 = (f12 * f17) - (f13 * f16);
        float f30 = (f23 * f24) + (((f21 * f26) + ((f20 * f27) + ((f18 * f29) - (f19 * f28)))) - (f22 * f25));
        if (f30 != 0.0f) {
            float f31 = 1.0f / f30;
            fArr2[0] = ((f9 * f27) + ((f7 * f29) - (f8 * f28))) * f31;
            fArr2[1] = (((f4 * f28) + ((-f3) * f29)) - (f5 * f27)) * f31;
            fArr2[2] = ((f17 * f21) + ((f15 * f23) - (f16 * f22))) * f31;
            fArr2[3] = (((f12 * f22) + ((-f11) * f23)) - (f13 * f21)) * f31;
            float f32 = -f6;
            fArr2[4] = (((f8 * f26) + (f32 * f29)) - (f9 * f25)) * f31;
            fArr2[5] = ((f5 * f25) + ((f29 * f2) - (f4 * f26))) * f31;
            float f33 = -f14;
            fArr2[6] = (((f16 * f20) + (f33 * f23)) - (f17 * f19)) * f31;
            fArr2[7] = ((f13 * f19) + ((f23 * f10) - (f12 * f20))) * f31;
            fArr2[8] = ((f9 * f24) + ((f6 * f28) - (f7 * f26))) * f31;
            fArr2[9] = (((f26 * f3) + ((-f2) * f28)) - (f5 * f24)) * f31;
            fArr2[10] = ((f17 * f18) + ((f14 * f22) - (f15 * f20))) * f31;
            fArr2[11] = (((f20 * f11) + ((-f10) * f22)) - (f13 * f18)) * f31;
            fArr2[12] = (((f7 * f25) + (f32 * f27)) - (f8 * f24)) * f31;
            fArr2[13] = ((f4 * f24) + ((f2 * f27) - (f3 * f25))) * f31;
            fArr2[14] = (((f15 * f19) + (f33 * f21)) - (f16 * f18)) * f31;
            fArr2[15] = ((f12 * f18) + ((f10 * f21) - (f11 * f19))) * f31;
        }
        return !(f30 == 0.0f);
    }

    public static final boolean y(float[] fArr) {
        return fArr.length >= 16 && fArr[0] == 1.0f && fArr[1] == 0.0f && fArr[2] == 0.0f && fArr[3] == 0.0f && fArr[4] == 0.0f && fArr[5] == 1.0f && fArr[6] == 0.0f && fArr[7] == 0.0f && fArr[8] == 0.0f && fArr[9] == 0.0f && fArr[10] == 1.0f && fArr[11] == 0.0f && fArr[12] == 0.0f && fArr[13] == 0.0f && fArr[14] == 0.0f && fArr[15] == 1.0f;
    }

    public static final boolean z(ij0 ij0Var) {
        if (ij0Var.l == null) {
            return false;
        }
        ij0 ij0VarU = ij0Var.u();
        return (ij0VarU != null ? ij0VarU.l : null) == null || ij0Var.K.b;
    }
}
