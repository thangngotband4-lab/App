package defpackage;

import kotlin.Metadata;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u000e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\bÂ\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001¨\u0006\u0003"}, d2 = {"Ls30;", "Ljr0;", "Lt30;", "ui"}, k = 1, mv = {2, 0, 0}, xi = 48)
final class s30 extends jr0 {
    public static final s30 a = new s30();

    @Override // defpackage.jr0
    public final er0 e() {
        return new t30();
    }

    public final boolean equals(Object obj) {
        return obj == this;
    }

    @Override // defpackage.jr0
    public final /* bridge */ /* synthetic */ void f(er0 er0Var) {
    }

    public final int hashCode() {
        return -659549572;
    }
}
