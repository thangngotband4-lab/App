package defpackage;

import java.util.LinkedHashMap;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class me {
    public final LinkedHashMap a = new LinkedHashMap();
}
