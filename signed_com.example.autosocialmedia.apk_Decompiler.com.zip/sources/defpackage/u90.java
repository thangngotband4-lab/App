package defpackage;

import android.content.Context;
import java.util.LinkedHashMap;
import org.json.JSONException;
import org.json.JSONObject;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class u90 {
    public static final int $stable = 8;
    private static final String CONTEXT = "asm:golike-stats:v1";
    public static final t90 Companion = new t90();
    private static volatile u90 INSTANCE = null;
    private static final String K_COINS = "coins";
    private static final String K_DATE = "date";
    private static final String K_JOBS = "jobs";
    private static final String K_KEY = "daily_stats";
    private static final String PREFS_NAME = "asm_golike_stats_enc";
    private final ht0 _daily;
    private final lj1 daily;
    private final qc1 store;

    public u90(Context context) {
        Object d81Var;
        w60 w60Var;
        LinkedHashMap linkedHashMap = qc1.c;
        qc1 qc1VarQ = vl.q(context, PREFS_NAME);
        this.store = qc1VarQ;
        String strA = qc1VarQ.a(K_KEY, CONTEXT);
        if (strA == null) {
            w60Var = new w60();
        } else {
            try {
                JSONObject jSONObject = new JSONObject(strA);
                String strOptString = jSONObject.optString(K_DATE, fl.f());
                strOptString.getClass();
                d81Var = new w60(jSONObject.optLong(K_COINS, 0L), strOptString, jSONObject.optInt(K_JOBS, 0));
            } catch (Throwable th) {
                d81Var = new d81(th);
            }
            w60Var = (w60) (d81Var instanceof d81 ? new w60() : d81Var);
        }
        nj1 nj1VarF = eq0.f(w60Var);
        this._daily = nj1VarF;
        this.daily = nj1VarF;
    }

    public final lj1 c() {
        return this.daily;
    }

    public final void d(long j) throws JSONException {
        w60 w60Var = (w60) ((nj1) this._daily).getValue();
        String strF = fl.f();
        w60 w60Var2 = !ng0.o(w60Var.c(), strF) ? new w60(j, strF, 1) : w60.a(w60Var, w60Var.d() + 1, w60Var.b() + j);
        JSONObject jSONObject = new JSONObject();
        jSONObject.put(K_DATE, w60Var2.c());
        jSONObject.put(K_JOBS, w60Var2.d());
        jSONObject.put(K_COINS, w60Var2.b());
        qc1 qc1Var = this.store;
        String string = jSONObject.toString();
        string.getClass();
        qc1Var.b(K_KEY, CONTEXT, string);
        nj1 nj1Var = (nj1) this._daily;
        nj1Var.getClass();
        nj1Var.i(null, w60Var2);
    }
}
