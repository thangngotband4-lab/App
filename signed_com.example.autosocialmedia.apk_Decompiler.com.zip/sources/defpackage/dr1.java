package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class dr1 extends er0 implements zi0 {
    public ks0 r;
    public boolean s;
    public yi1 t;
    public boolean u;
    public va v;
    public va w;
    public float x;
    public float y;

    @Override // defpackage.er0
    public final boolean B0() {
        return false;
    }

    @Override // defpackage.er0
    public final void E0() {
        m22.y(A0(), null, new i3(this, (tq) null, 17), 3);
    }

    @Override // defpackage.zi0
    public final mq0 d(nq0 nq0Var, gq0 gq0Var, long j) {
        float f = ct.O;
        int i = 0;
        int i2 = 1;
        float fY = nq0Var.y(this.u ? ct.J : ((gq0Var.f(xp.h(j)) != 0 && gq0Var.Z(xp.g(j)) != 0) || this.s) ? tl1.a : tl1.b);
        va vaVar = this.w;
        int iFloatValue = (int) (vaVar != null ? ((Number) vaVar.d()).floatValue() : fY);
        if (!((iFloatValue >= 0) & (iFloatValue >= 0))) {
            ud0.a("width and height must be >= 0");
        }
        k21 k21VarE = gq0Var.e(yp.h(iFloatValue, iFloatValue, iFloatValue, iFloatValue));
        float fY2 = nq0Var.y((tl1.d - nq0Var.x0(fY)) / 2.0f);
        float fY3 = nq0Var.y((tl1.c - tl1.a) - tl1.e);
        boolean z = this.u;
        if (z && this.s) {
            fY2 = fY3 - nq0Var.y(f);
        } else if (z && !this.s) {
            fY2 = nq0Var.y(f);
        } else if (this.s) {
            fY2 = fY3;
        }
        va vaVar2 = this.w;
        tq tqVar = null;
        Float f2 = vaVar2 != null ? (Float) vaVar2.e.getValue() : null;
        if (f2 == null || f2.floatValue() != fY) {
            m22.y(A0(), null, new cr1(this, fY, tqVar, i), 3);
        }
        va vaVar3 = this.v;
        Float f3 = vaVar3 != null ? (Float) vaVar3.e.getValue() : null;
        if (f3 == null || f3.floatValue() != fY2) {
            m22.y(A0(), null, new cr1(this, fY2, tqVar, i2), 3);
        }
        if (Float.isNaN(this.y) && Float.isNaN(this.x)) {
            this.y = fY;
            this.x = fY2;
        }
        return nq0Var.i0(iFloatValue, iFloatValue, vz.d, new o6(k21VarE, this, fY2));
    }
}
