package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class kq {
    public static final /* synthetic */ kq a = new kq();
    public static final m6 b;
    public static final m6 c;
    public static final m6 d;

    static {
        vl.a("username");
        b = vl.a("password");
        c = vl.a("emailAddress");
        vl.a("newUsername");
        vl.a("newPassword");
        vl.a("postalAddress");
        vl.a("postalCode");
        vl.a("creditCardNumber");
        vl.a("creditCardSecurityCode");
        vl.a("creditCardExpirationDate");
        vl.a("creditCardExpirationMonth");
        vl.a("creditCardExpirationYear");
        vl.a("creditCardExpirationDay");
        vl.a("addressCountry");
        vl.a("addressRegion");
        vl.a("addressLocality");
        vl.a("streetAddress");
        vl.a("extendedAddress");
        vl.a("extendedPostalCode");
        vl.a("personName");
        vl.a("personGivenName");
        vl.a("personFamilyName");
        vl.a("personMiddleName");
        vl.a("personMiddleInitial");
        vl.a("personNamePrefix");
        vl.a("personNameSuffix");
        d = vl.a("phoneNumber");
        vl.a("phoneNumberDevice");
        vl.a("phoneCountryCode");
        vl.a("phoneNational");
        vl.a("gender");
        vl.a("birthDateFull");
        vl.a("birthDateDay");
        vl.a("birthDateMonth");
        vl.a("birthDateYear");
        vl.a("smsOTPCode");
    }
}
