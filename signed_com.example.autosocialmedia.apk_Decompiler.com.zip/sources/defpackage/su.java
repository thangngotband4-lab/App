package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class su implements vy {
    public final int a;
    public final int b;

    public su(int i, int i2) {
        this.a = i;
        this.b = i2;
        if (i >= 0 && i2 >= 0) {
            return;
        }
        td0.a("Expected lengthBeforeCursor and lengthAfterCursor to be non-negative, were " + i + " and " + i2 + " respectively.");
    }

    @Override // defpackage.vy
    public final void a(wy wyVar) {
        int i = 0;
        int i2 = 0;
        int i3 = 0;
        while (true) {
            if (i2 < this.a) {
                int i4 = i3 + 1;
                int i5 = wyVar.b;
                if (i5 <= i4) {
                    i3 = i5;
                    break;
                } else {
                    i3 = (Character.isHighSurrogate(wyVar.b((i5 - i4) + (-1))) && Character.isLowSurrogate(wyVar.b(wyVar.b - i4))) ? i3 + 2 : i4;
                    i2++;
                }
            } else {
                break;
            }
        }
        int iB = 0;
        while (true) {
            if (i >= this.b) {
                break;
            }
            int i6 = iB + 1;
            int i7 = wyVar.c;
            o01 o01Var = wyVar.a;
            if (i7 + i6 >= o01Var.b()) {
                iB = o01Var.b() - wyVar.c;
                break;
            } else {
                iB = (Character.isHighSurrogate(wyVar.b((wyVar.c + i6) + (-1))) && Character.isLowSurrogate(wyVar.b(wyVar.c + i6))) ? iB + 2 : i6;
                i++;
            }
        }
        int i8 = wyVar.c;
        wyVar.a(i8, iB + i8);
        int i9 = wyVar.b;
        wyVar.a(i9 - i3, i9);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof su)) {
            return false;
        }
        su suVar = (su) obj;
        return this.a == suVar.a && this.b == suVar.b;
    }

    public final int hashCode() {
        return (this.a * 31) + this.b;
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder("DeleteSurroundingTextInCodePointsCommand(lengthBeforeCursor=");
        sb.append(this.a);
        sb.append(", lengthAfterCursor=");
        return f0.p(sb, this.b, ')');
    }
}
