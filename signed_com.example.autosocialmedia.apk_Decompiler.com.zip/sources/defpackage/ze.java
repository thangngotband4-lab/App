package defpackage;

import android.accessibilityservice.AccessibilityService;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public abstract class ze {
    public static WindowManager b;
    public static LinearLayout c;
    public static TextView d;
    public static TextView e;
    public static TextView f;
    public static TextView g;
    public static TextView h;
    public static WindowManager.LayoutParams i;
    public static final Handler a = new Handler(Looper.getMainLooper());
    public static final kd j = new kd();
    public static final int k = 5;

    public static void a(String str) {
        at.INSTANCE.getClass();
        at.a(str);
        a.post(new ue(str, 2));
    }

    public static void b(AccessibilityService accessibilityService, String str, boolean z) {
        Object systemService = accessibilityService.getSystemService("window");
        systemService.getClass();
        b = (WindowManager) systemService;
        float f2 = accessibilityService.getResources().getDisplayMetrics().density;
        LinearLayout linearLayout = new LinearLayout(accessibilityService);
        linearLayout.setOrientation(1);
        linearLayout.setPadding(c(f2, 16), c(f2, 12), c(f2, 16), c(f2, 12));
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setCornerRadius(c(f2, 18));
        gradientDrawable.setColor(Color.parseColor("#F2151521"));
        gradientDrawable.setStroke(c(f2, 1), Color.parseColor("#33FFFFFF"));
        linearLayout.setBackground(gradientDrawable);
        LinearLayout linearLayout2 = new LinearLayout(accessibilityService);
        linearLayout2.setOrientation(0);
        linearLayout2.setGravity(16);
        TextView textView = new TextView(accessibilityService);
        textView.setText("●");
        textView.setTextColor(Color.parseColor("#FF2D55"));
        textView.setTextSize(12.0f);
        TextView textView2 = new TextView(accessibilityService);
        textView2.setText(str);
        textView2.setTextColor(-1);
        textView2.setTextSize(14.0f);
        textView2.setTypeface(textView2.getTypeface(), 1);
        textView2.setPadding(c(f2, 8), 0, c(f2, 8), 0);
        d = textView2;
        TextView textView3 = new TextView(accessibilityService);
        textView3.setText("Dừng");
        textView3.setTextColor(-1);
        textView3.setTextSize(13.0f);
        textView3.setTypeface(textView3.getTypeface(), 1);
        textView3.setPadding(c(f2, 14), c(f2, 6), c(f2, 14), c(f2, 6));
        GradientDrawable gradientDrawable2 = new GradientDrawable();
        gradientDrawable2.setCornerRadius(c(f2, 12));
        gradientDrawable2.setColor(Color.parseColor("#FF3B30"));
        textView3.setBackground(gradientDrawable2);
        textView3.setOnClickListener(new we());
        g = textView3;
        linearLayout2.addView(textView);
        linearLayout2.addView(d, new LinearLayout.LayoutParams(0, -2, 1.0f));
        linearLayout2.addView(g);
        TextView textView4 = new TextView(accessibilityService);
        textView4.setText("Đang khởi động…");
        textView4.setTextColor(Color.parseColor("#E8EAED"));
        textView4.setTextSize(13.0f);
        textView4.setPadding(0, c(f2, 8), 0, 0);
        e = textView4;
        TextView textView5 = new TextView(accessibilityService);
        textView5.setText("📹 0    ❤️ 0    ➕ 0");
        textView5.setTextColor(Color.parseColor("#A1A1AA"));
        textView5.setTextSize(13.0f);
        textView5.setPadding(0, c(f2, 6), 0, 0);
        textView5.setVisibility(z ? 0 : 8);
        f = textView5;
        TextView textView6 = new TextView(accessibilityService);
        textView6.setText("");
        textView6.setTextColor(Color.parseColor("#9CA3AF"));
        textView6.setTextSize(10.5f);
        textView6.setPadding(0, c(f2, 8), 0, 0);
        textView6.setTypeface(Typeface.MONOSPACE);
        textView6.setVisibility(8);
        h = textView6;
        linearLayout.addView(linearLayout2);
        linearLayout.addView(e);
        linearLayout.addView(f);
        linearLayout.addView(h);
        LinearLayout linearLayout3 = new LinearLayout(accessibilityService);
        linearLayout3.setOrientation(1);
        linearLayout3.addView(linearLayout, new LinearLayout.LayoutParams(c(f2, dv0.MAX_COOLDOWN), -2));
        c = linearLayout3;
        WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams(-2, -2, Build.VERSION.SDK_INT >= 26 ? 2038 : 2002, 8, -3);
        layoutParams.gravity = 8388659;
        layoutParams.x = c(f2, 12);
        layoutParams.y = c(f2, 60);
        i = layoutParams;
        final LinearLayout linearLayout4 = c;
        linearLayout4.getClass();
        final WindowManager.LayoutParams layoutParams2 = i;
        layoutParams2.getClass();
        final c71 c71Var = new c71();
        final c71 c71Var2 = new c71();
        final b71 b71Var = new b71();
        final b71 b71Var2 = new b71();
        linearLayout4.setOnTouchListener(new View.OnTouchListener() { // from class: xe
            @Override // android.view.View.OnTouchListener
            public final boolean onTouch(View view, MotionEvent motionEvent) {
                View view2 = linearLayout4;
                int action = motionEvent.getAction();
                c71 c71Var3 = c71Var;
                WindowManager.LayoutParams layoutParams3 = layoutParams2;
                c71 c71Var4 = c71Var2;
                b71 b71Var3 = b71Var;
                b71 b71Var4 = b71Var2;
                if (action == 0) {
                    c71Var3.d = layoutParams3.x;
                    c71Var4.d = layoutParams3.y;
                    b71Var3.d = motionEvent.getRawX();
                    b71Var4.d = motionEvent.getRawY();
                    return true;
                }
                if (action != 2) {
                    return false;
                }
                layoutParams3.x = eq0.D(motionEvent.getRawX() - b71Var3.d) + c71Var3.d;
                layoutParams3.y = eq0.D(motionEvent.getRawY() - b71Var4.d) + c71Var4.d;
                try {
                    WindowManager windowManager = ze.b;
                    if (windowManager != null) {
                        windowManager.updateViewLayout(view2, layoutParams3);
                    }
                } catch (Throwable unused) {
                }
                return true;
            }
        });
        WindowManager windowManager = b;
        if (windowManager != null) {
            windowManager.addView(c, i);
        }
    }

    public static final int c(float f2, int i2) {
        return eq0.D(i2 * f2);
    }

    public static void d(Context context) {
        context.getClass();
        Intent intentAddFlags = new Intent("android.settings.action.MANAGE_OVERLAY_PERMISSION", Uri.parse("package:" + context.getPackageName())).addFlags(268435456);
        intentAddFlags.getClass();
        try {
            context.startActivity(intentAddFlags);
        } catch (Throwable unused) {
        }
    }

    public static void e(final AccessibilityService accessibilityService, final String str, final boolean z) {
        if (!Settings.canDrawOverlays(accessibilityService)) {
            Log.w("AutoAccessibility", "Overlay permission chưa cấp - bỏ qua hiển thị overlay");
        } else {
            a.post(new Runnable() { // from class: ye
                @Override // java.lang.Runnable
                public final void run() {
                    Object d81Var;
                    AccessibilityService accessibilityService2 = accessibilityService;
                    LinearLayout linearLayout = ze.c;
                    String str2 = str;
                    boolean z2 = z;
                    if (linearLayout != null) {
                        TextView textView = ze.d;
                        if (textView != null) {
                            textView.setText(str2);
                        }
                        TextView textView2 = ze.f;
                        if (textView2 != null) {
                            textView2.setVisibility(z2 ? 0 : 8);
                            return;
                        }
                        return;
                    }
                    try {
                        ze.b(accessibilityService2, str2, z2);
                        d81Var = bw1.a;
                    } catch (Throwable th) {
                        d81Var = new d81(th);
                    }
                    Throwable thA = e81.a(d81Var);
                    if (thA != null) {
                        Log.e("AutoAccessibility", "show overlay failed", thA);
                    }
                }
            });
        }
    }

    public static void f(String str) {
        str.getClass();
        a.post(new ue(str, 0));
    }
}
