package defpackage;

import java.util.Iterator;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class xz implements ie1 {
    public static final xz a = new xz();

    @Override // defpackage.ie1
    public final Iterator iterator() {
        return sz.d;
    }
}
