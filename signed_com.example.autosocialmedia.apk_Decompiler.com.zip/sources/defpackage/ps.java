package defpackage;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class ps {
    public static final ps d;
    public static final ps e;
    public static final ps f;
    public static final /* synthetic */ ps[] g;

    static {
        ps psVar = new ps("None", 0);
        d = psVar;
        ps psVar2 = new ps("Cancelled", 1);
        e = psVar2;
        ps psVar3 = new ps("Redirected", 2);
        f = psVar3;
        g = new ps[]{psVar, psVar2, psVar3, new ps("RedirectCancelled", 3)};
    }

    public static ps valueOf(String str) {
        return (ps) Enum.valueOf(ps.class, str);
    }

    public static ps[] values() {
        return (ps[]) g.clone();
    }
}
