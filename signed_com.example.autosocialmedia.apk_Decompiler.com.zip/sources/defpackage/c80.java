package defpackage;

import com.example.autosocialmedia.security.NativeGoLike;
import com.example.autosocialmedia.security.NativeInstagram;
import com.example.autosocialmedia.security.NativeNurture;
import com.example.autosocialmedia.security.NativeThreads;
import com.example.autosocialmedia.security.NativeX;
import com.example.autosocialmedia.security.NativeYoutube;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class c80 implements AutoCloseable {
    public final /* synthetic */ int d;
    public long e;

    public String a(boolean z) {
        return NativeGoLike.INSTANCE.nativeReportFollowResult(this.e, z);
    }

    @Override // java.lang.AutoCloseable
    public final void close() {
        switch (this.d) {
            case 0:
                long j = this.e;
                if (j != 0) {
                    NativeGoLike.INSTANCE.nativeFreeRunner(j);
                    this.e = 0L;
                }
                break;
            case 1:
                long j2 = this.e;
                if (j2 != 0) {
                    NativeInstagram.a.nativeFreeRunner(j2);
                    this.e = 0L;
                }
                break;
            case 2:
                long j3 = this.e;
                if (j3 != 0) {
                    NativeNurture.a.nativeFreeNurture(j3);
                    this.e = 0L;
                }
                break;
            case 3:
                long j4 = this.e;
                if (j4 != 0) {
                    NativeThreads.a.nativeFreeRunner(j4);
                    this.e = 0L;
                }
                break;
            case 4:
                long j5 = this.e;
                if (j5 != 0) {
                    NativeX.a.nativeFreeRunner(j5);
                    this.e = 0L;
                }
                break;
            default:
                long j6 = this.e;
                if (j6 != 0) {
                    NativeYoutube.a.nativeFreeRunner(j6);
                    this.e = 0L;
                }
                break;
        }
    }
}
