package defpackage;

import java.util.ArrayList;
import java.util.List;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public interface lq0 {
    default int b(gg0 gg0Var, List list, int i) {
        ArrayList arrayList = new ArrayList(list.size());
        int size = list.size();
        int i2 = 0;
        for (int i3 = 0; i3 < size; i3++) {
            arrayList.add(new ut((gq0) list.get(i3), hg0.e, kg0.e, i2));
        }
        return g(new tg0(gg0Var, gg0Var.getLayoutDirection()), arrayList, yp.b(i, 0, 13)).c();
    }

    default int d(gg0 gg0Var, List list, int i) {
        ArrayList arrayList = new ArrayList(list.size());
        int size = list.size();
        int i2 = 0;
        for (int i3 = 0; i3 < size; i3++) {
            arrayList.add(new ut((gq0) list.get(i3), hg0.e, kg0.d, i2));
        }
        return g(new tg0(gg0Var, gg0Var.getLayoutDirection()), arrayList, yp.b(0, i, 7)).e();
    }

    mq0 g(nq0 nq0Var, List list, long j);

    default int h(gg0 gg0Var, List list, int i) {
        ArrayList arrayList = new ArrayList(list.size());
        int size = list.size();
        int i2 = 0;
        for (int i3 = 0; i3 < size; i3++) {
            arrayList.add(new ut((gq0) list.get(i3), hg0.d, kg0.e, i2));
        }
        return g(new tg0(gg0Var, gg0Var.getLayoutDirection()), arrayList, yp.b(i, 0, 13)).c();
    }

    default int j(gg0 gg0Var, List list, int i) {
        ArrayList arrayList = new ArrayList(list.size());
        int size = list.size();
        int i2 = 0;
        for (int i3 = 0; i3 < size; i3++) {
            arrayList.add(new ut((gq0) list.get(i3), hg0.d, kg0.d, i2));
        }
        return g(new tg0(gg0Var, gg0Var.getLayoutDirection()), arrayList, yp.b(0, i, 7)).e();
    }
}
