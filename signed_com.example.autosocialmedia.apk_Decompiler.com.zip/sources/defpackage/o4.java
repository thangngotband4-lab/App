package defpackage;

import android.graphics.Rect;
import android.view.autofill.AutofillId;
import android.view.autofill.AutofillManager;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class o4 extends le implements z20 {
    public final l1 d;
    public final sd1 e;
    public final k5 f;
    public final z61 g;
    public final String h;
    public final Rect i = new Rect();
    public final AutofillId j;
    public final js0 k;
    public boolean l;

    public o4(l1 l1Var, sd1 sd1Var, k5 k5Var, z61 z61Var, String str) {
        this.d = l1Var;
        this.e = sd1Var;
        this.f = k5Var;
        this.g = z61Var;
        this.h = str;
        k5Var.setImportantForAutofill(1);
        ke keVarF = ak1.f(k5Var);
        AutofillId autofillIdH = keVarF != null ? dm.h(keVarF.a) : null;
        if (autofillIdH == null) {
            throw f0.i("Required value was null.");
        }
        this.j = autofillIdH;
        this.k = new js0();
    }

    @Override // defpackage.z20
    public final void d(r30 r30Var, r30 r30Var2) {
        ij0 ij0VarM;
        ld1 ld1VarW;
        ij0 ij0VarM2;
        ld1 ld1VarW2;
        if (r30Var != null && (ij0VarM2 = tl.M(r30Var)) != null && (ld1VarW2 = ij0VarM2.w()) != null) {
            at0 at0Var = ld1VarW2.d;
            if (at0Var.b(kd1.g) || at0Var.b(kd1.h)) {
                ((AutofillManager) this.d.e).notifyViewExited(this.f, ij0VarM2.e);
            }
        }
        if (r30Var2 == null || (ij0VarM = tl.M(r30Var2)) == null || (ld1VarW = ij0VarM.w()) == null) {
            return;
        }
        at0 at0Var2 = ld1VarW.d;
        if (at0Var2.b(kd1.g) || at0Var2.b(kd1.h)) {
            int i = ij0VarM.e;
            this.g.a.h(i, new m4(this, i));
        }
    }
}
