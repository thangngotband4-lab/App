package defpackage;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class ht1 {
    private static final /* synthetic */ n00 $ENTRIES;
    private static final /* synthetic */ ht1[] $VALUES;
    public static final gt1 Companion;
    public static final ht1 LITE;
    public static final ht1 NORMAL;
    public static final ht1 STUDIO;

    static {
        ht1 ht1Var = new ht1("NORMAL", 0);
        NORMAL = ht1Var;
        ht1 ht1Var2 = new ht1("LITE", 1);
        LITE = ht1Var2;
        ht1 ht1Var3 = new ht1("STUDIO", 2);
        STUDIO = ht1Var3;
        ht1[] ht1VarArr = {ht1Var, ht1Var2, ht1Var3};
        $VALUES = ht1VarArr;
        $ENTRIES = new o00(ht1VarArr);
        Companion = new gt1();
    }

    public static ht1 valueOf(String str) {
        return (ht1) Enum.valueOf(ht1.class, str);
    }

    public static ht1[] values() {
        return (ht1[]) $VALUES.clone();
    }
}
