package defpackage;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class ng1 {
    public static final ng1 d;
    public static final ng1 e;
    public static final /* synthetic */ ng1[] f;

    static {
        ng1 ng1Var = new ng1("THUMB", 0);
        d = ng1Var;
        ng1 ng1Var2 = new ng1("TRACK", 1);
        e = ng1Var2;
        f = new ng1[]{ng1Var, ng1Var2};
    }

    public static ng1 valueOf(String str) {
        return (ng1) Enum.valueOf(ng1.class, str);
    }

    public static ng1[] values() {
        return (ng1[]) f.clone();
    }
}
