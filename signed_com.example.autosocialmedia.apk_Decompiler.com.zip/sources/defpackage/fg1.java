package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public abstract class fg1 {
    static {
        y5.F(0.0f, 0.0f, null, 7);
    }

    public static final kj1 a(long j, j10 j10Var, String str, xo xoVar, int i, int i2) {
        if ((i2 & 4) != 0) {
            str = "ColorAnimation";
        }
        String str2 = str;
        boolean zF = xoVar.f(ql.f(j));
        Object objL = xoVar.L();
        if (zF || objL == ro.a) {
            yu1 yu1Var = new yu1(c5.w, new g4(10, ql.f(j)));
            xoVar.g0(yu1Var);
            objL = yu1Var;
        }
        return xa.b(new ql(j), (yu1) objL, j10Var, null, str2, xoVar, ((i << 3) & 896) | ((i << 6) & 57344), 8);
    }
}
