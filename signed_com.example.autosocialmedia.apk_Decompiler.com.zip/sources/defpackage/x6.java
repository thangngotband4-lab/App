package defpackage;

import java.util.ArrayList;
import java.util.List;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class x6 implements lq0 {
    public static final x6 b = new x6(0);
    public static final x6 c = new x6(1);
    public static final x6 d = new x6(2);
    public static final x6 e = new x6(3);
    public static final n1 f = new n1(25);
    public static final x6 g = new x6(4);
    public static final x6 h = new x6(5);
    public final /* synthetic */ int a;

    public /* synthetic */ x6(int i) {
        this.a = i;
    }

    public static final void a(ArrayList arrayList, c71 c71Var, nq0 nq0Var, ArrayList arrayList2, ArrayList arrayList3, c71 c71Var2, ArrayList arrayList4, c71 c71Var3, c71 c71Var4) {
        if (!arrayList.isEmpty()) {
            c71Var.d = nq0Var.P(12.0f) + c71Var.d;
        }
        arrayList.add(0, il.j0(arrayList2));
        arrayList3.add(Integer.valueOf(c71Var2.d));
        arrayList4.add(Integer.valueOf(c71Var.d));
        c71Var.d += c71Var2.d;
        c71Var3.d = Math.max(c71Var3.d, c71Var4.d);
        arrayList2.clear();
        c71Var4.d = 0;
        c71Var2.d = 0;
    }

    @Override // defpackage.lq0
    public final mq0 g(nq0 nq0Var, List list, long j) {
        ArrayList arrayList;
        ArrayList arrayList2;
        int i = this.a;
        int i2 = 15;
        int i3 = 0;
        vz vzVar = vz.d;
        switch (i) {
            case 0:
                ArrayList arrayList3 = new ArrayList(list.size());
                int size = list.size();
                int iJ = 0;
                int i4 = 0;
                while (i3 < size) {
                    k21 k21VarE = ((gq0) list.get(i3)).e(j);
                    iJ = Math.max(iJ, k21VarE.d);
                    i4 = Math.max(i4, k21VarE.e);
                    arrayList3.add(k21VarE);
                    i3++;
                }
                if (list.isEmpty()) {
                    iJ = xp.j(j);
                    i4 = xp.i(j);
                }
                return nq0Var.i0(iJ, i4, vzVar, new w6(0, arrayList3));
            case 1:
                int size2 = list.size();
                if (size2 == 0) {
                    return nq0Var.i0(0, 0, vzVar, c5.n);
                }
                if (size2 == 1) {
                    k21 k21VarE2 = ((gq0) list.get(0)).e(j);
                    return nq0Var.i0(k21VarE2.d, k21VarE2.e, vzVar, new v4(k21VarE2, 1));
                }
                ArrayList arrayList4 = new ArrayList(list.size());
                int size3 = list.size();
                int iMax = 0;
                int iMax2 = 0;
                for (int i5 = 0; i5 < size3; i5++) {
                    k21 k21VarE3 = ((gq0) list.get(i5)).e(j);
                    iMax = Math.max(iMax, k21VarE3.d);
                    iMax2 = Math.max(iMax2, k21VarE3.e);
                    arrayList4.add(k21VarE3);
                }
                return nq0Var.i0(iMax, iMax2, vzVar, new w6(1, arrayList4));
            case 2:
                return nq0Var.i0(xp.j(j), xp.i(j), vzVar, new n1(15));
            case 3:
                return nq0Var.i0(xp.h(j), xp.g(j), vzVar, f);
            case 4:
                int iMax3 = 0;
                ArrayList arrayList5 = new ArrayList(list.size());
                int size4 = list.size();
                int iMax4 = 0;
                while (i3 < size4) {
                    k21 k21VarE4 = ((gq0) list.get(i3)).e(j);
                    iMax3 = Math.max(iMax3, k21VarE4.d);
                    iMax4 = Math.max(iMax4, k21VarE4.e);
                    arrayList5.add(k21VarE4);
                    i3++;
                }
                return nq0Var.i0(iMax3, iMax4, vzVar, new l(24, arrayList5));
            case 5:
                return nq0Var.i0(xp.f(j) ? xp.h(j) : 0, xp.e(j) ? xp.g(j) : 0, vzVar, new sa1(i2));
            default:
                ArrayList arrayList6 = new ArrayList();
                ArrayList arrayList7 = new ArrayList();
                ArrayList arrayList8 = new ArrayList();
                c71 c71Var = new c71();
                c71 c71Var2 = new c71();
                ArrayList arrayList9 = new ArrayList();
                c71 c71Var3 = new c71();
                int i6 = 0;
                c71 c71Var4 = new c71();
                int size5 = list.size();
                while (i6 < size5) {
                    k21 k21VarE5 = ((gq0) list.get(i6)).e(j);
                    int i7 = i6;
                    if (!arrayList9.isEmpty()) {
                        ArrayList arrayList10 = arrayList6;
                        if (nq0Var.P(8.0f) + c71Var3.d + k21VarE5.d <= xp.h(j)) {
                            arrayList6 = arrayList10;
                        } else {
                            arrayList6 = arrayList10;
                            a(arrayList6, c71Var2, nq0Var, arrayList9, arrayList7, c71Var4, arrayList8, c71Var, c71Var3);
                        }
                    }
                    if (arrayList9.isEmpty()) {
                        arrayList2 = arrayList6;
                    } else {
                        arrayList2 = arrayList6;
                        c71Var3.d = nq0Var.P(8.0f) + c71Var3.d;
                    }
                    arrayList9.add(k21VarE5);
                    c71Var3.d += k21VarE5.d;
                    c71Var4.d = Math.max(c71Var4.d, k21VarE5.e);
                    i6 = i7 + 1;
                    arrayList6 = arrayList2;
                }
                ArrayList arrayList11 = arrayList6;
                if (arrayList9.isEmpty()) {
                    arrayList = arrayList11;
                } else {
                    arrayList = arrayList11;
                    a(arrayList, c71Var2, nq0Var, arrayList9, arrayList7, c71Var4, arrayList8, c71Var, c71Var3);
                }
                int iMax5 = Math.max(c71Var.d, xp.j(j));
                return nq0Var.i0(iMax5, Math.max(c71Var2.d, xp.i(j)), vzVar, new w3(arrayList, nq0Var, iMax5, arrayList8));
        }
    }
}
