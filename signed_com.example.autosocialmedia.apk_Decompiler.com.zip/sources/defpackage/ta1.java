package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class ta1 implements l50 {
    public static final ta1 d = new ta1();

    @Override // defpackage.l50
    public final Object f(Object obj, Object obj2) {
        long j = ((ql) obj2).a;
        return j == 16 ? Boolean.FALSE : Integer.valueOf(tl.Q(j));
    }
}
