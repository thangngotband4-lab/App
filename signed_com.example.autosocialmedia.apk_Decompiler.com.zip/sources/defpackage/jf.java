package defpackage;

import android.os.SystemClock;
import android.view.MotionEvent;
import java.util.List;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class jf extends er0 implements zi0, zx, nd1, w31, hr0, n01, oi0, h60, p20, h30, k30, oz0, xh {
    public dr0 r;

    @Override // defpackage.zi0
    public final int B(dp0 dp0Var, gq0 gq0Var, int i) {
        dr0 dr0Var = this.r;
        dr0Var.getClass();
        return ((xi0) dr0Var).d(new tg0(dp0Var, dp0Var.getLayoutDirection()), new ut(gq0Var, oq0.d, pq0.e, 1), yp.b(i, 0, 13)).c();
    }

    @Override // defpackage.er0
    public final void E0() {
        M0(true);
    }

    @Override // defpackage.er0
    public final void F0() {
        if (!this.q) {
            sd0.b("unInitializeModifier called on unattached node");
        }
        if ((this.f & 8) != 0) {
            ((k5) tl.N(this)).C();
        }
    }

    @Override // defpackage.w31
    public final void G(m31 m31Var, n31 n31Var, long j) {
        boolean z;
        boolean z2;
        boolean z3;
        dr0 dr0Var = this.r;
        dr0Var.getClass();
        l4 l4Var = ((z31) dr0Var).d;
        z31 z31Var = (z31) l4Var.d;
        List list = m31Var.a;
        int size = list.size();
        for (int i = 0; i < size; i++) {
            t31 t31Var = (t31) list.get(i);
            if (bm.n(t31Var) || bm.p(t31Var)) {
                z = false;
                break;
            }
        }
        z = true;
        if (!z) {
            z2 = false;
            break;
        }
        int size2 = list.size();
        for (int i2 = 0; i2 < size2; i2++) {
            if (((t31) list.get(i2)).b()) {
                z2 = false;
                break;
            }
        }
        z2 = true;
        if (z31Var.c) {
            z3 = true;
        } else {
            int size3 = list.size();
            int i3 = 0;
            while (true) {
                if (i3 < size3) {
                    t31 t31Var2 = (t31) list.get(i3);
                    if (bm.n(t31Var2) || bm.p(t31Var2)) {
                        break;
                    } else {
                        i3++;
                    }
                } else if (z2) {
                    break;
                } else {
                    z3 = false;
                }
            }
            z3 = true;
        }
        y31 y31Var = (y31) l4Var.b;
        y31 y31Var2 = y31.f;
        n31 n31Var2 = n31.f;
        if (y31Var != y31Var2) {
            if (n31Var == n31.d && z3) {
                l4Var.c = m31Var;
                l4Var.c(m31Var, !z || z31Var.c);
            }
            if (n31Var == n31.e && z && m31Var == ((m31) l4Var.c) && z31Var.c) {
                int size4 = list.size();
                for (int i4 = 0; i4 < size4; i4++) {
                    ((t31) list.get(i4)).a();
                }
            }
            if (n31Var == n31Var2 && !z3 && m31Var != ((m31) l4Var.c)) {
                l4Var.c(m31Var, true);
            }
        }
        if (n31Var == n31Var2) {
            int size5 = list.size();
            int i5 = 0;
            while (true) {
                if (i5 >= size5) {
                    l4Var.b = y31.d;
                    ((z31) l4Var.d).c = false;
                    l4Var.c = null;
                    break;
                } else if (!bm.p((t31) list.get(i5))) {
                    break;
                } else {
                    i5++;
                }
            }
            if (m31Var == ((m31) l4Var.c) && z) {
                int size6 = list.size();
                int i6 = 0;
                while (true) {
                    if (i6 >= size6) {
                        break;
                    }
                    if (!((t31) list.get(i6)).b()) {
                        i6++;
                    } else if (!z31Var.c) {
                        l4Var.f(m31Var);
                        return;
                    }
                }
                int size7 = list.size();
                for (int i7 = 0; i7 < size7; i7++) {
                    ((t31) list.get(i7)).a();
                }
            }
        }
    }

    @Override // defpackage.zx
    public final void L(kj0 kj0Var) {
        dr0 dr0Var = this.r;
        dr0Var.getClass();
        kj0Var.a();
    }

    public final void M0(boolean z) {
        if (!this.q) {
            sd0.b("initializeModifier called on unattached node");
        }
        dr0 dr0Var = this.r;
        if ((this.f & 4) != 0 && !z) {
            tl.K(this, 2).b1();
        }
        if ((this.f & 2) != 0) {
            bm1 bm1Var = tl.M(this).J.e;
            bm1Var.getClass();
            if (bm1Var.r) {
                pu0 pu0Var = this.k;
                pu0Var.getClass();
                ((bj0) pu0Var).v1(this);
                mz0 mz0Var = pu0Var.O;
                if (mz0Var != null) {
                    ((ba0) mz0Var).c();
                }
            }
            if (!z) {
                tl.K(this, 2).b1();
                tl.M(this).E();
            }
        }
        if (dr0Var instanceof ol0) {
            ((ol0) dr0Var).a.k = tl.M(this);
        }
        int i = this.f;
        if ((i & 16) != 0 && (dr0Var instanceof z31)) {
            ((z31) dr0Var).d.a = this.k;
        }
        if ((i & 8) != 0) {
            ((k5) tl.N(this)).C();
        }
    }

    @Override // defpackage.zi0
    public final int Q(dp0 dp0Var, gq0 gq0Var, int i) {
        dr0 dr0Var = this.r;
        dr0Var.getClass();
        return ((xi0) dr0Var).d(new tg0(dp0Var, dp0Var.getLayoutDirection()), new ut(gq0Var, oq0.d, pq0.d, 1), yp.b(0, i, 7)).e();
    }

    @Override // defpackage.h30
    public final void S(e30 e30Var) {
        dr0 dr0Var = this.r;
        sd0.b("applyFocusProperties called on wrong node");
        dr0Var.getClass();
        throw new ClassCastException();
    }

    @Override // defpackage.p20
    public final void W(m30 m30Var) {
        dr0 dr0Var = this.r;
        sd0.b("onFocusEvent called on wrong node");
        dr0Var.getClass();
        throw new ClassCastException();
    }

    @Override // defpackage.w31
    public final boolean Z() {
        dr0 dr0Var = this.r;
        dr0Var.getClass();
        ((z31) dr0Var).d.getClass();
        return true;
    }

    @Override // defpackage.ku, defpackage.w31
    public final void a() {
        if (this.r instanceof z31) {
            l0();
        }
    }

    @Override // defpackage.xh
    public final wu b() {
        return tl.M(this).C;
    }

    @Override // defpackage.xh
    public final long c() {
        return bm.R(tl.K(this, 128).f);
    }

    @Override // defpackage.zi0
    public final mq0 d(nq0 nq0Var, gq0 gq0Var, long j) {
        dr0 dr0Var = this.r;
        dr0Var.getClass();
        return ((xi0) dr0Var).d(nq0Var, gq0Var, j);
    }

    @Override // defpackage.zi0
    public final int e(dp0 dp0Var, gq0 gq0Var, int i) {
        dr0 dr0Var = this.r;
        dr0Var.getClass();
        return ((xi0) dr0Var).d(new tg0(dp0Var, dp0Var.getLayoutDirection()), new ut(gq0Var, oq0.e, pq0.d, 1), yp.b(0, i, 7)).e();
    }

    @Override // defpackage.xh
    public final ri0 getLayoutDirection() {
        return tl.M(this).D;
    }

    @Override // defpackage.hr0
    public final a4 i() {
        return a4.D;
    }

    @Override // defpackage.nd1
    public final void k0(yd1 yd1Var) {
        dr0 dr0Var = this.r;
        dr0Var.getClass();
        zc zcVar = (zc) dr0Var;
        ld1 ld1Var = new ld1();
        ld1Var.f = zcVar.a;
        zcVar.b.g(ld1Var);
        yd1Var.getClass();
        ld1 ld1Var2 = (ld1) yd1Var;
        at0 at0Var = ld1Var2.d;
        if (ld1Var.f) {
            ld1Var2.f = true;
        }
        if (ld1Var.g) {
            ld1Var2.g = true;
        }
        at0 at0Var2 = ld1Var.d;
        Object[] objArr = at0Var2.b;
        Object[] objArr2 = at0Var2.c;
        long[] jArr = at0Var2.a;
        int length = jArr.length - 2;
        if (length < 0) {
            return;
        }
        int i = 0;
        while (true) {
            long j = jArr[i];
            if ((((~j) << 7) & j & (-9187201950435737472L)) != -9187201950435737472L) {
                int i2 = 8 - ((~(i - length)) >>> 31);
                for (int i3 = 0; i3 < i2; i3++) {
                    if ((255 & j) < 128) {
                        int i4 = (i << 3) + i3;
                        Object obj = objArr[i4];
                        Object obj2 = objArr2[i4];
                        xd1 xd1Var = (xd1) obj;
                        if (!at0Var.b(xd1Var)) {
                            at0Var.m(xd1Var, obj2);
                        } else if (obj2 instanceof n0) {
                            Object objG = at0Var.g(xd1Var);
                            objG.getClass();
                            n0 n0Var = (n0) objG;
                            String str = n0Var.a;
                            if (str == null) {
                                str = ((n0) obj2).a;
                            }
                            t50 t50Var = n0Var.b;
                            if (t50Var == null) {
                                t50Var = ((n0) obj2).b;
                            }
                            at0Var.m(xd1Var, new n0(str, t50Var));
                        }
                    }
                    j >>= 8;
                }
                if (i2 != 8) {
                    return;
                }
            }
            if (i == length) {
                return;
            } else {
                i++;
            }
        }
    }

    @Override // defpackage.w31
    public final void l0() {
        dr0 dr0Var = this.r;
        dr0Var.getClass();
        l4 l4Var = ((z31) dr0Var).d;
        y31 y31Var = (y31) l4Var.b;
        z31 z31Var = (z31) l4Var.d;
        if (y31Var == y31.e) {
            long jUptimeMillis = SystemClock.uptimeMillis();
            MotionEvent motionEventObtain = MotionEvent.obtain(jUptimeMillis, jUptimeMillis, 3, 0.0f, 0.0f, 0);
            motionEventObtain.setSource(0);
            ((ga) z31Var.e()).g(motionEventObtain);
            motionEventObtain.recycle();
            l4Var.b = y31.d;
            z31Var.c = false;
            l4Var.c = null;
        }
    }

    @Override // defpackage.zi0
    public final int m(dp0 dp0Var, gq0 gq0Var, int i) {
        dr0 dr0Var = this.r;
        dr0Var.getClass();
        return ((xi0) dr0Var).d(new tg0(dp0Var, dp0Var.getLayoutDirection()), new ut(gq0Var, oq0.e, pq0.e, 1), yp.b(i, 0, 13)).c();
    }

    @Override // defpackage.n01
    public final Object r0(Object obj) {
        dr0 dr0Var = this.r;
        dr0Var.getClass();
        return (hb) dr0Var;
    }

    @Override // defpackage.zx
    public final void s0() {
        fl.w(this);
    }

    @Override // defpackage.w31
    public final void t0() {
        dr0 dr0Var = this.r;
        dr0Var.getClass();
        ((z31) dr0Var).d.getClass();
    }

    public final String toString() {
        return this.r.toString();
    }

    @Override // defpackage.h60
    public final void u(pu0 pu0Var) {
        this.r.getClass();
        throw new ClassCastException();
    }

    @Override // defpackage.oz0
    public final boolean z() {
        return this.q;
    }

    @Override // defpackage.oi0
    public final void n(qi0 qi0Var) {
    }

    @Override // defpackage.oi0
    public final void r(long j) {
    }
}
