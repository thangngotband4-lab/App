package defpackage;

import java.util.concurrent.atomic.AtomicReferenceArray;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class fe1 extends rc1 {
    public final /* synthetic */ AtomicReferenceArray g;

    public fe1(long j, fe1 fe1Var, int i) {
        super(j, fe1Var, i);
        this.g = new AtomicReferenceArray(ee1.f);
    }

    @Override // defpackage.rc1
    public final int i() {
        return ee1.f;
    }

    @Override // defpackage.rc1
    public final void j(int i, ur urVar) {
        this.g.set(i, ee1.e);
        k();
    }

    public final String toString() {
        return "SemaphoreSegment[id=" + this.e + ", hashCode=" + hashCode() + ']';
    }
}
