package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public abstract class p91 {
    public static final m50 a;

    static {
        o91 o91Var = o91.l;
        zu1.g(3, o91Var);
        a = o91Var;
    }
}
