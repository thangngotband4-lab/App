package defpackage;

import android.view.ViewParent;
import java.util.ConcurrentModificationException;
import java.util.Iterator;
import java.util.Map;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class a60 implements Iterator, lh0 {
    public final /* synthetic */ int d;
    public int e;
    public Object f;
    public final Object g;

    public a60(dt0 dt0Var) {
        this.d = 2;
        this.g = dt0Var;
        this.e = -1;
        this.f = fl.A(new ct0(dt0Var, this, null));
    }

    public void a() {
        Object parent;
        int i = this.e;
        b60 b60Var = (b60) this.g;
        if (i == -2) {
            parent = ((y8) b60Var.b).a();
        } else {
            int i2 = uy1.l;
            Object obj = this.f;
            obj.getClass();
            parent = ((ViewParent) obj).getParent();
        }
        this.f = parent;
        this.e = parent == null ? 0 : 1;
    }

    @Override // java.util.Iterator
    public final boolean hasNext() {
        switch (this.d) {
            case 0:
                if (this.e < 0) {
                    a();
                }
                return this.e == 1;
            case 1:
                return ((je1) this.f).hasNext();
            case 2:
                return ((je1) this.f).hasNext();
            default:
                return this.e < ((Map) this.g).size();
        }
    }

    @Override // java.util.Iterator
    public final Object next() {
        Object obj = null;
        switch (this.d) {
            case 0:
                if (this.e < 0) {
                    a();
                }
                if (this.e == 0) {
                    tz.j();
                    return null;
                }
                Object obj2 = this.f;
                obj2.getClass();
                this.e = -1;
                return obj2;
            case 1:
                return ((je1) this.f).next();
            case 2:
                return ((je1) this.f).next();
            default:
                if (hasNext()) {
                    obj = this.f;
                    this.e++;
                    Object obj3 = ((Map) this.g).get(obj);
                    if (obj3 == null) {
                        throw new ConcurrentModificationException("Hash code of an element (" + obj + ") has changed after it was added to the persistent set.");
                    }
                    this.f = ((zn0) obj3).b;
                } else {
                    tz.j();
                }
                return obj;
        }
    }

    @Override // java.util.Iterator
    public final void remove() {
        int i = this.d;
        Object obj = this.g;
        switch (i) {
            case 0:
                throw new UnsupportedOperationException("Operation is not supported for read-only collection");
            case 1:
                int i2 = this.e;
                if (i2 != -1) {
                    ((ws0) obj).e.h(i2);
                    this.e = -1;
                    return;
                }
                return;
            case 2:
                int i3 = this.e;
                if (i3 != -1) {
                    ((dt0) obj).e.m(i3);
                    this.e = -1;
                    return;
                }
                return;
            default:
                throw new UnsupportedOperationException("Operation is not supported for read-only collection");
        }
    }

    public a60(b60 b60Var) {
        this.d = 0;
        this.g = b60Var;
        this.e = -2;
    }

    public a60(Object obj, Map map) {
        this.d = 3;
        this.f = obj;
        this.g = map;
    }

    public a60(ws0 ws0Var) {
        this.d = 1;
        this.g = ws0Var;
        this.e = -1;
        this.f = fl.A(new vs0(ws0Var, this, null));
    }
}
