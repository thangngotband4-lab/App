package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class he0 implements h50 {
    public final /* synthetic */ int d;
    public final /* synthetic */ zl1 e;

    public /* synthetic */ he0(zl1 zl1Var, int i) {
        this.d = i;
        this.e = zl1Var;
    }

    @Override // defpackage.h50
    public final Object g(Object obj) {
        int i = this.d;
        zl1 zl1Var = this.e;
        mu1 mu1Var = (mu1) obj;
        switch (i) {
            case 0:
                mu1Var.getClass();
                zl1 zl1Var2 = (zl1) mu1Var;
                nz1 nz1Var = zl1Var.s;
                if (!ng0.o(zl1Var2.r, nz1Var)) {
                    zl1Var2.r = nz1Var;
                    zl1Var2.M0();
                }
                return lu1.e;
            default:
                mu1Var.getClass();
                zl1Var.r = ((zl1) mu1Var).s;
                return Boolean.FALSE;
        }
    }
}
