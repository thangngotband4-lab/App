package defpackage;

import android.content.res.TypedArray;
import android.media.MediaDrm;
import android.media.MediaMetadataRetriever;
import androidx.compose.ui.input.pointer.PointerInputEventHandler;
import java.text.BreakIterator;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.TimeUnit;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class cd implements qy1 {
    public static volatile cd b;
    public final Object a;

    public cd(int i) {
        switch (i) {
            case 1:
                this.a = new Object();
                Executors.newFixedThreadPool(4, new du());
                break;
            default:
                this.a = new cd(1);
                break;
        }
    }

    public static final void a(boolean z, z71 z71Var, so1 so1Var, xo xoVar, int i) {
        int i2;
        qp1 qp1VarD;
        xoVar.X(-1344558920);
        if ((i & 6) == 0) {
            i2 = (xoVar.g(z) ? 4 : 2) | i;
        } else {
            i2 = i;
        }
        if ((i & 48) == 0) {
            i2 |= xoVar.d(z71Var.ordinal()) ? 32 : 16;
        }
        if ((i & 384) == 0) {
            i2 |= xoVar.h(so1Var) ? 256 : 128;
        }
        if (xoVar.O(i2 & 1, (i2 & 147) != 146)) {
            int i3 = i2 & 14;
            boolean zF = (i3 == 4) | xoVar.f(so1Var);
            Object objL = xoVar.L();
            dp1 dp1Var = ro.a;
            if (zF || objL == dp1Var) {
                objL = new po1(so1Var, z);
                xoVar.g0(objL);
            }
            qn1 qn1Var = (qn1) objL;
            boolean zH = (i3 == 4) | xoVar.h(so1Var);
            Object objL2 = xoVar.L();
            if (zH || objL2 == dp1Var) {
                objL2 = new to1(so1Var, z);
                xoVar.g0(objL2);
            }
            nw0 nw0Var = (nw0) objL2;
            boolean zG = wp1.g(so1Var.n().b);
            int i4 = (int) (z ? so1Var.n().b >> 32 : so1Var.n().b & 4294967295L);
            em0 em0Var = so1Var.d;
            float fE = 0.0f;
            if (em0Var != null && (qp1VarD = em0Var.d()) != null) {
                pp1 pp1Var = qp1VarD.a;
                if (i4 >= 0) {
                    op1 op1Var = pp1Var.a;
                    cs0 cs0Var = pp1Var.b;
                    if (op1Var.a.e.length() != 0) {
                        int iMin = Math.min(cs0Var.d(i4), Math.min(cs0Var.b - 1, cs0Var.f - 1));
                        if (i4 <= cs0Var.c(iMin, false)) {
                            cs0Var.l(iMin);
                            ArrayList arrayList = cs0Var.h;
                            c01 c01Var = (c01) arrayList.get(rm.C(iMin, arrayList));
                            b8 b8Var = c01Var.a;
                            int i5 = iMin - c01Var.d;
                            np1 np1Var = b8Var.d;
                            fE = np1Var.e(i5) - np1Var.g(i5);
                        }
                    }
                }
            }
            float f = fE;
            boolean zH2 = xoVar.h(qn1Var);
            Object objL3 = xoVar.L();
            if (zH2 || objL3 == dp1Var) {
                objL3 = new d7(6, qn1Var);
                xoVar.g0(objL3);
            }
            ng0.e(nw0Var, z, z71Var, zG, 0L, f, ll1.a(cr0.a, qn1Var, (PointerInputEventHandler) objL3), xoVar, (i2 << 3) & 1008);
        } else {
            xoVar.R();
        }
        l61 l61VarR = xoVar.r();
        if (l61VarR != null) {
            l61VarR.d = new f9(z, z71Var, so1Var, i);
        }
    }

    public static final long b() {
        return Thread.currentThread().getId();
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:19:0x0046  */
    /* JADX WARN: Type inference failed for: r11v0, types: [java.lang.Object, java.lang.String] */
    /* JADX WARN: Type inference failed for: r11v1, types: [java.text.BreakIterator] */
    /* JADX WARN: Type inference failed for: r4v2, types: [java.lang.Object, yc] */
    /* JADX WARN: Type inference failed for: r5v0 */
    /* JADX WARN: Type inference failed for: r5v1, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r5v10 */
    /* JADX WARN: Type inference failed for: r5v11 */
    /* JADX WARN: Type inference failed for: r5v2 */
    /* JADX WARN: Type inference failed for: r5v3 */
    /* JADX WARN: Type inference failed for: r5v4, types: [java.lang.CharSequence] */
    /* JADX WARN: Type inference failed for: r5v8 */
    /* JADX WARN: Type inference failed for: r5v9 */
    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:593)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static final int c(java.lang.String r11, int r12) {
        /*
            dz r0 = e()
            r1 = 0
            if (r0 == 0) goto L79
            int r2 = r0.c()
            r3 = 0
            r4 = 1
            if (r2 != r4) goto L10
            goto L11
        L10:
            r4 = r3
        L11:
            if (r4 == 0) goto L73
            java.lang.String r2 = "charSequence cannot be null"
            defpackage.jl.k(r11, r2)
            az r0 = r0.e
            yc r4 = r0.b
            r4.getClass()
            r0 = -1
            if (r12 < 0) goto L28
            int r2 = r11.length()
            if (r12 < r2) goto L2a
        L28:
            r5 = r11
            goto L69
        L2a:
            boolean r2 = r11 instanceof android.text.Spanned
            if (r2 == 0) goto L46
            r2 = r11
            android.text.Spanned r2 = (android.text.Spanned) r2
            int r5 = r12 + 1
            java.lang.Class<jv1> r6 = defpackage.jv1.class
            java.lang.Object[] r5 = r2.getSpans(r12, r5, r6)
            jv1[] r5 = (defpackage.jv1[]) r5
            int r6 = r5.length
            if (r6 <= 0) goto L46
            r3 = r5[r3]
            int r2 = r2.getSpanEnd(r3)
            r5 = r11
            goto L6a
        L46:
            int r2 = r12 + (-16)
            int r6 = java.lang.Math.max(r3, r2)
            int r2 = r11.length()
            int r3 = r12 + 16
            int r7 = java.lang.Math.min(r2, r3)
            kz r10 = new kz
            r10.<init>(r12)
            r8 = 2147483647(0x7fffffff, float:NaN)
            r9 = 1
            r5 = r11
            java.lang.Object r11 = r4.m(r5, r6, r7, r8, r9, r10)
            kz r11 = (defpackage.kz) r11
            int r2 = r11.f
            goto L6a
        L69:
            r2 = r0
        L6a:
            java.lang.Integer r11 = java.lang.Integer.valueOf(r2)
            if (r2 != r0) goto L71
            goto L7a
        L71:
            r1 = r11
            goto L7a
        L73:
            java.lang.String r11 = "Not initialized yet"
            defpackage.zi.f(r11)
            return r3
        L79:
            r5 = r11
        L7a:
            if (r1 == 0) goto L81
            int r11 = r1.intValue()
            return r11
        L81:
            java.text.BreakIterator r11 = java.text.BreakIterator.getCharacterInstance()
            r11.setText(r5)
            int r11 = r11.following(r12)
            return r11
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.cd.c(java.lang.String, int):int");
    }

    public static final int d(String str, int i) {
        dz dzVarE = e();
        Integer num = null;
        if (dzVarE != null) {
            Integer numValueOf = Integer.valueOf(dzVarE.b(str, Math.max(0, i - 1)));
            if (numValueOf.intValue() != -1) {
                num = numValueOf;
            }
        }
        if (num != null) {
            return num.intValue();
        }
        BreakIterator characterInstance = BreakIterator.getCharacterInstance();
        characterInstance.setText(str);
        return characterInstance.preceding(i);
    }

    public static final dz e() {
        if (!dz.d()) {
            return null;
        }
        dz dzVarA = dz.a();
        if (dzVarA.c() == 1) {
            return dzVarA;
        }
        return null;
    }

    public static int f(int i) {
        if (i == 1) {
            return 0;
        }
        if (i == 2) {
            return 1;
        }
        if (i == 4) {
            return 2;
        }
        if (i == 8) {
            return 3;
        }
        if (i == 16) {
            return 4;
        }
        if (i == 32) {
            return 5;
        }
        if (i == 64) {
            return 6;
        }
        if (i == 128) {
            return 7;
        }
        if (i == 256) {
            return 8;
        }
        if (i == 512) {
            return 9;
        }
        tz.l(f0.k("type needs to be >= FIRST and <= LAST, type=", i));
        return 0;
    }

    public static final int g(int i, int i2) {
        return (i >> i2) & 31;
    }

    public static /* synthetic */ void i(AutoCloseable autoCloseable) throws Exception {
        boolean zIsTerminated;
        if (autoCloseable instanceof AutoCloseable) {
            autoCloseable.close();
            return;
        }
        if (!(autoCloseable instanceof ExecutorService)) {
            if (autoCloseable instanceof TypedArray) {
                ((TypedArray) autoCloseable).recycle();
                return;
            } else if (autoCloseable instanceof MediaMetadataRetriever) {
                ((MediaMetadataRetriever) autoCloseable).release();
                return;
            } else {
                if (!(autoCloseable instanceof MediaDrm)) {
                    throw new IllegalArgumentException();
                }
                ((MediaDrm) autoCloseable).release();
                return;
            }
        }
        ExecutorService executorService = (ExecutorService) autoCloseable;
        if (executorService == ForkJoinPool.commonPool() || (zIsTerminated = executorService.isTerminated())) {
            return;
        }
        executorService.shutdown();
        boolean z = false;
        while (!zIsTerminated) {
            try {
                zIsTerminated = executorService.awaitTermination(1L, TimeUnit.DAYS);
            } catch (InterruptedException unused) {
                if (!z) {
                    executorService.shutdownNow();
                    z = true;
                }
            }
        }
        if (z) {
            Thread.currentThread().interrupt();
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r11v0, types: [h50] */
    /* JADX WARN: Type inference failed for: r1v11 */
    /* JADX WARN: Type inference failed for: r1v12, types: [er0] */
    /* JADX WARN: Type inference failed for: r1v13, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r1v14 */
    /* JADX WARN: Type inference failed for: r1v15 */
    /* JADX WARN: Type inference failed for: r1v16 */
    /* JADX WARN: Type inference failed for: r1v17 */
    /* JADX WARN: Type inference failed for: r1v18 */
    /* JADX WARN: Type inference failed for: r1v19 */
    /* JADX WARN: Type inference failed for: r1v6 */
    /* JADX WARN: Type inference failed for: r1v7, types: [er0] */
    /* JADX WARN: Type inference failed for: r4v0 */
    /* JADX WARN: Type inference failed for: r4v1 */
    /* JADX WARN: Type inference failed for: r4v10 */
    /* JADX WARN: Type inference failed for: r4v11 */
    /* JADX WARN: Type inference failed for: r4v2 */
    /* JADX WARN: Type inference failed for: r4v3, types: [it0] */
    /* JADX WARN: Type inference failed for: r4v4 */
    /* JADX WARN: Type inference failed for: r4v5 */
    /* JADX WARN: Type inference failed for: r4v6, types: [it0] */
    /* JADX WARN: Type inference failed for: r4v8 */
    /* JADX WARN: Type inference failed for: r4v9 */
    /* JADX WARN: Type inference failed for: r5v6 */
    public static final void j(ku kuVar, Object obj, h50 h50Var) {
        nu0 nu0Var;
        if (!((er0) kuVar).d.q) {
            sd0.b("visitAncestors called on an unattached node");
        }
        er0 er0Var = ((er0) kuVar).d.h;
        ij0 ij0VarM = tl.M(kuVar);
        while (ij0VarM != null) {
            if ((ij0VarM.J.f.g & 262144) != 0) {
                while (er0Var != null) {
                    if ((er0Var.f & 262144) != 0) {
                        ?? K = er0Var;
                        ?? it0Var = 0;
                        while (K != 0) {
                            if (K instanceof mu1) {
                                mu1 mu1Var = (mu1) K;
                                if (!(obj.equals(mu1Var.o()) ? ((Boolean) h50Var.g(mu1Var)).booleanValue() : true)) {
                                    return;
                                }
                            } else if ((K.f & 262144) != 0 && (K instanceof lu)) {
                                er0 er0Var2 = ((lu) K).s;
                                int i = 0;
                                K = K;
                                it0Var = it0Var;
                                while (er0Var2 != null) {
                                    if ((er0Var2.f & 262144) != 0) {
                                        i++;
                                        it0Var = it0Var;
                                        if (i == 1) {
                                            K = er0Var2;
                                        } else {
                                            if (it0Var == 0) {
                                                it0Var = new it0(new er0[16]);
                                            }
                                            if (K != 0) {
                                                it0Var.b(K);
                                                K = 0;
                                            }
                                            it0Var.b(er0Var2);
                                        }
                                    }
                                    er0Var2 = er0Var2.i;
                                    K = K;
                                    it0Var = it0Var;
                                }
                                if (i == 1) {
                                }
                            }
                            K = tl.k(it0Var);
                        }
                    }
                    er0Var = er0Var.h;
                }
            }
            ij0VarM = ij0VarM.u();
            er0Var = (ij0VarM == null || (nu0Var = ij0VarM.J) == null) ? null : nu0Var.e;
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r10v0, types: [java.lang.Object, ku, mu1] */
    /* JADX WARN: Type inference failed for: r11v0, types: [h50] */
    /* JADX WARN: Type inference failed for: r2v11 */
    /* JADX WARN: Type inference failed for: r2v12, types: [er0] */
    /* JADX WARN: Type inference failed for: r2v13, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r2v14 */
    /* JADX WARN: Type inference failed for: r2v15 */
    /* JADX WARN: Type inference failed for: r2v16 */
    /* JADX WARN: Type inference failed for: r2v17 */
    /* JADX WARN: Type inference failed for: r2v18 */
    /* JADX WARN: Type inference failed for: r2v19 */
    /* JADX WARN: Type inference failed for: r2v6 */
    /* JADX WARN: Type inference failed for: r2v7, types: [er0] */
    /* JADX WARN: Type inference failed for: r5v0 */
    /* JADX WARN: Type inference failed for: r5v1 */
    /* JADX WARN: Type inference failed for: r5v10 */
    /* JADX WARN: Type inference failed for: r5v11 */
    /* JADX WARN: Type inference failed for: r5v2 */
    /* JADX WARN: Type inference failed for: r5v3, types: [it0] */
    /* JADX WARN: Type inference failed for: r5v4 */
    /* JADX WARN: Type inference failed for: r5v5 */
    /* JADX WARN: Type inference failed for: r5v6, types: [it0] */
    /* JADX WARN: Type inference failed for: r5v8 */
    /* JADX WARN: Type inference failed for: r5v9 */
    /* JADX WARN: Type inference failed for: r6v7 */
    public static final void k(mu1 mu1Var, h50 h50Var) {
        nu0 nu0Var;
        er0 er0Var = (er0) mu1Var;
        if (!er0Var.d.q) {
            sd0.b("visitAncestors called on an unattached node");
        }
        er0 er0Var2 = er0Var.d.h;
        ij0 ij0VarM = tl.M(mu1Var);
        while (ij0VarM != null) {
            if ((ij0VarM.J.f.g & 262144) != 0) {
                while (er0Var2 != null) {
                    if ((er0Var2.f & 262144) != 0) {
                        ?? K = er0Var2;
                        ?? it0Var = 0;
                        while (K != 0) {
                            boolean zBooleanValue = true;
                            if (K instanceof mu1) {
                                mu1 mu1Var2 = (mu1) K;
                                if (ng0.o(mu1Var.o(), mu1Var2.o()) && mu1Var.getClass() == mu1Var2.getClass()) {
                                    zBooleanValue = ((Boolean) h50Var.g(mu1Var2)).booleanValue();
                                }
                                if (!zBooleanValue) {
                                    return;
                                }
                            } else if ((K.f & 262144) != 0 && (K instanceof lu)) {
                                er0 er0Var3 = ((lu) K).s;
                                int i = 0;
                                K = K;
                                it0Var = it0Var;
                                while (er0Var3 != null) {
                                    if ((er0Var3.f & 262144) != 0) {
                                        i++;
                                        it0Var = it0Var;
                                        if (i == 1) {
                                            K = er0Var3;
                                        } else {
                                            if (it0Var == 0) {
                                                it0Var = new it0(new er0[16]);
                                            }
                                            if (K != 0) {
                                                it0Var.b(K);
                                                K = 0;
                                            }
                                            it0Var.b(er0Var3);
                                        }
                                    }
                                    er0Var3 = er0Var3.i;
                                    K = K;
                                    it0Var = it0Var;
                                }
                                if (i == 1) {
                                }
                            }
                            K = tl.k(it0Var);
                        }
                    }
                    er0Var2 = er0Var2.h;
                }
            }
            ij0VarM = ij0VarM.u();
            er0Var2 = (ij0VarM == null || (nu0Var = ij0VarM.J) == null) ? null : nu0Var.e;
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r13v0, types: [h50] */
    /* JADX WARN: Type inference failed for: r5v0 */
    /* JADX WARN: Type inference failed for: r5v1, types: [er0] */
    /* JADX WARN: Type inference failed for: r5v10 */
    /* JADX WARN: Type inference failed for: r5v11 */
    /* JADX WARN: Type inference failed for: r5v12 */
    /* JADX WARN: Type inference failed for: r5v13 */
    /* JADX WARN: Type inference failed for: r5v14 */
    /* JADX WARN: Type inference failed for: r5v15 */
    /* JADX WARN: Type inference failed for: r5v7 */
    /* JADX WARN: Type inference failed for: r5v8, types: [er0] */
    /* JADX WARN: Type inference failed for: r5v9, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r6v0 */
    /* JADX WARN: Type inference failed for: r6v1 */
    /* JADX WARN: Type inference failed for: r6v10 */
    /* JADX WARN: Type inference failed for: r6v11 */
    /* JADX WARN: Type inference failed for: r6v2 */
    /* JADX WARN: Type inference failed for: r6v3, types: [it0] */
    /* JADX WARN: Type inference failed for: r6v4 */
    /* JADX WARN: Type inference failed for: r6v5 */
    /* JADX WARN: Type inference failed for: r6v6, types: [it0] */
    /* JADX WARN: Type inference failed for: r6v8 */
    /* JADX WARN: Type inference failed for: r6v9 */
    /* JADX WARN: Type inference failed for: r7v8 */
    public static final void l(ku kuVar, String str, h50 h50Var) {
        if (!((er0) kuVar).d.q) {
            sd0.b("visitSubtreeIf called on an unattached node");
        }
        it0 it0Var = new it0(new er0[16]);
        er0 er0Var = ((er0) kuVar).d;
        er0 er0Var2 = er0Var.i;
        if (er0Var2 == null) {
            tl.j(it0Var, er0Var);
        } else {
            it0Var.b(er0Var2);
        }
        while (true) {
            int i = it0Var.f;
            if (i == 0) {
                return;
            }
            er0 er0Var3 = (er0) it0Var.k(i - 1);
            if ((er0Var3.g & 262144) != 0) {
                for (er0 er0Var4 = er0Var3; er0Var4 != null && er0Var4.q; er0Var4 = er0Var4.i) {
                    if ((er0Var4.f & 262144) != 0) {
                        ?? K = er0Var4;
                        ?? it0Var2 = 0;
                        while (K != 0) {
                            if (K instanceof mu1) {
                                mu1 mu1Var = (mu1) K;
                                lu1 lu1Var = str.equals(mu1Var.o()) ? (lu1) h50Var.g(mu1Var) : lu1.d;
                                if (lu1Var == lu1.f) {
                                    return;
                                }
                                if (lu1Var == lu1.e) {
                                    break;
                                }
                            } else if ((K.f & 262144) != 0 && (K instanceof lu)) {
                                er0 er0Var5 = ((lu) K).s;
                                int i2 = 0;
                                K = K;
                                it0Var2 = it0Var2;
                                while (er0Var5 != null) {
                                    if ((er0Var5.f & 262144) != 0) {
                                        i2++;
                                        it0Var2 = it0Var2;
                                        if (i2 == 1) {
                                            K = er0Var5;
                                        } else {
                                            if (it0Var2 == 0) {
                                                it0Var2 = new it0(new er0[16]);
                                            }
                                            if (K != 0) {
                                                it0Var2.b(K);
                                                K = 0;
                                            }
                                            it0Var2.b(er0Var5);
                                        }
                                    }
                                    er0Var5 = er0Var5.i;
                                    K = K;
                                    it0Var2 = it0Var2;
                                }
                                if (i2 == 1) {
                                }
                            }
                            K = tl.k(it0Var2);
                        }
                    }
                }
            }
            tl.j(it0Var, er0Var3);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r12v0, types: [java.lang.Object, mu1] */
    /* JADX WARN: Type inference failed for: r13v0, types: [h50] */
    /* JADX WARN: Type inference failed for: r6v0 */
    /* JADX WARN: Type inference failed for: r6v1, types: [er0] */
    /* JADX WARN: Type inference failed for: r6v10 */
    /* JADX WARN: Type inference failed for: r6v11 */
    /* JADX WARN: Type inference failed for: r6v12 */
    /* JADX WARN: Type inference failed for: r6v13 */
    /* JADX WARN: Type inference failed for: r6v14 */
    /* JADX WARN: Type inference failed for: r6v15 */
    /* JADX WARN: Type inference failed for: r6v7 */
    /* JADX WARN: Type inference failed for: r6v8, types: [er0] */
    /* JADX WARN: Type inference failed for: r6v9, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r7v0 */
    /* JADX WARN: Type inference failed for: r7v1 */
    /* JADX WARN: Type inference failed for: r7v10 */
    /* JADX WARN: Type inference failed for: r7v11 */
    /* JADX WARN: Type inference failed for: r7v2 */
    /* JADX WARN: Type inference failed for: r7v3, types: [it0] */
    /* JADX WARN: Type inference failed for: r7v4 */
    /* JADX WARN: Type inference failed for: r7v5 */
    /* JADX WARN: Type inference failed for: r7v6, types: [it0] */
    /* JADX WARN: Type inference failed for: r7v8 */
    /* JADX WARN: Type inference failed for: r7v9 */
    /* JADX WARN: Type inference failed for: r8v9 */
    public static final void m(mu1 mu1Var, h50 h50Var) {
        er0 er0Var = (er0) mu1Var;
        if (!er0Var.d.q) {
            sd0.b("visitSubtreeIf called on an unattached node");
        }
        it0 it0Var = new it0(new er0[16]);
        er0 er0Var2 = er0Var.d;
        er0 er0Var3 = er0Var2.i;
        if (er0Var3 == null) {
            tl.j(it0Var, er0Var2);
        } else {
            it0Var.b(er0Var3);
        }
        while (true) {
            int i = it0Var.f;
            if (i == 0) {
                return;
            }
            er0 er0Var4 = (er0) it0Var.k(i - 1);
            if ((er0Var4.g & 262144) != 0) {
                for (er0 er0Var5 = er0Var4; er0Var5 != null && er0Var5.q; er0Var5 = er0Var5.i) {
                    if ((er0Var5.f & 262144) != 0) {
                        ?? K = er0Var5;
                        ?? it0Var2 = 0;
                        while (K != 0) {
                            if (K instanceof mu1) {
                                mu1 mu1Var2 = (mu1) K;
                                lu1 lu1Var = (ng0.o(mu1Var.o(), mu1Var2.o()) && mu1Var.getClass() == mu1Var2.getClass()) ? (lu1) h50Var.g(mu1Var2) : lu1.d;
                                if (lu1Var == lu1.f) {
                                    return;
                                }
                                if (lu1Var == lu1.e) {
                                    break;
                                }
                            } else if ((K.f & 262144) != 0 && (K instanceof lu)) {
                                er0 er0Var6 = ((lu) K).s;
                                int i2 = 0;
                                K = K;
                                it0Var2 = it0Var2;
                                while (er0Var6 != null) {
                                    if ((er0Var6.f & 262144) != 0) {
                                        i2++;
                                        it0Var2 = it0Var2;
                                        if (i2 == 1) {
                                            K = er0Var6;
                                        } else {
                                            if (it0Var2 == 0) {
                                                it0Var2 = new it0(new er0[16]);
                                            }
                                            if (K != 0) {
                                                it0Var2.b(K);
                                                K = 0;
                                            }
                                            it0Var2.b(er0Var6);
                                        }
                                    }
                                    er0Var6 = er0Var6.i;
                                    K = K;
                                    it0Var2 = it0Var2;
                                }
                                if (i2 == 1) {
                                }
                            }
                            K = tl.k(it0Var2);
                        }
                    }
                }
            }
            tl.j(it0Var, er0Var4);
        }
    }
}
