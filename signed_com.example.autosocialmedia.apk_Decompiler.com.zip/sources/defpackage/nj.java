package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class nj {
    public static final /* synthetic */ nj a = new nj();
    public static final int b = (int) ak1.q("kotlinx.coroutines.channels.defaultBuffer", 64, 1, 2147483646);
}
