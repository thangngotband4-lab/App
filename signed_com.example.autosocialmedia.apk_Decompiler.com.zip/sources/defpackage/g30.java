package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class g30 implements e30 {
    public boolean a;
    public i30 b;
    public i30 c;
    public i30 d;
    public i30 e;
    public i30 f;
    public i30 g;
    public i30 h;
    public i30 i;
    public h50 j;
    public h50 k;
    public x61 l;

    @Override // defpackage.e30
    public final void a(r20 r20Var) {
        this.k = r20Var;
    }

    @Override // defpackage.e30
    public final void b(r20 r20Var) {
        this.j = r20Var;
    }

    @Override // defpackage.e30
    public final boolean c() {
        return this.a;
    }

    @Override // defpackage.e30
    public final void d(boolean z) {
        this.a = z;
    }

    @Override // defpackage.e30
    public final void e(x61 x61Var) {
        this.l = x61Var;
    }
}
