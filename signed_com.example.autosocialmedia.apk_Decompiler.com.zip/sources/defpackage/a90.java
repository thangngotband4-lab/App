package defpackage;

import android.graphics.Rect;
import android.view.accessibility.AccessibilityNodeInfo;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class a90 implements h50 {
    public final /* synthetic */ int d;
    public final /* synthetic */ Object e;
    public final /* synthetic */ int f;
    public final /* synthetic */ int g;
    public final /* synthetic */ Object h;

    public /* synthetic */ a90(int i, int i2, c71 c71Var, e71 e71Var) {
        this.d = 3;
        this.f = i;
        this.g = i2;
        this.e = c71Var;
        this.h = e71Var;
    }

    @Override // defpackage.h50
    public final Object g(Object obj) {
        int iWidth;
        int i;
        int i2 = this.d;
        bw1 bw1Var = bw1.a;
        Object obj2 = this.h;
        Object obj3 = this.e;
        int i3 = this.g;
        int i4 = this.f;
        switch (i2) {
            case 0:
                ((h50) obj3).g(Integer.valueOf(tl.o(((Integer) obj).intValue(), i4, i3)));
                ((gt0) obj2).setValue(Boolean.FALSE);
                break;
            case 1:
                ((h50) obj3).g(Integer.valueOf(tl.o(((Integer) obj).intValue(), i4, i3)));
                ((gt0) obj2).setValue(Boolean.FALSE);
                break;
            case 2:
                ((h50) obj3).g(Integer.valueOf(tl.o(((Integer) obj).intValue(), i4, i3)));
                ((gt0) obj2).setValue(Boolean.FALSE);
                break;
            default:
                c71 c71Var = (c71) obj3;
                e71 e71Var = (e71) obj2;
                AccessibilityNodeInfo accessibilityNodeInfo = (AccessibilityNodeInfo) obj;
                accessibilityNodeInfo.getClass();
                Rect rect = new Rect();
                accessibilityNodeInfo.getBoundsInScreen(rect);
                if (!rect.isEmpty() && rect.exactCenterY() <= ((double) i4) * 0.12d && rect.exactCenterX() >= ((double) i3) * 0.8d && 40 <= (iWidth = rect.width()) && iWidth < 201 && (i = rect.left) > c71Var.d) {
                    c71Var.d = i;
                    e71Var.d = accessibilityNodeInfo;
                }
                break;
        }
        return bw1Var;
    }

    public /* synthetic */ a90(h50 h50Var, int i, int i2, gt0 gt0Var, int i3) {
        this.d = i3;
        this.e = h50Var;
        this.f = i;
        this.g = i2;
        this.h = gt0Var;
    }
}
