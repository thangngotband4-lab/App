package defpackage;

import android.content.Context;
import android.widget.Toast;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class if0 extends jl1 implements l50 {
    public final /* synthetic */ int e;
    public int f;
    public final /* synthetic */ Context g;
    public final /* synthetic */ String h;
    public final /* synthetic */ gt0 i;
    public final /* synthetic */ gt0 j;
    public final /* synthetic */ gt0 k;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ if0(Context context, String str, gt0 gt0Var, gt0 gt0Var2, gt0 gt0Var3, tq tqVar, int i) {
        super(2, tqVar);
        this.e = i;
        this.g = context;
        this.h = str;
        this.i = gt0Var;
        this.j = gt0Var2;
        this.k = gt0Var3;
    }

    @Override // defpackage.l50
    public final Object f(Object obj, Object obj2) {
        int i = this.e;
        bw1 bw1Var = bw1.a;
        ds dsVar = (ds) obj;
        tq tqVar = (tq) obj2;
        switch (i) {
        }
        return ((if0) o(tqVar, dsVar)).r(bw1Var);
    }

    @Override // defpackage.kf
    public final tq o(tq tqVar, Object obj) {
        switch (this.e) {
            case 0:
                return new if0(this.g, this.h, this.i, this.j, this.k, tqVar, 0);
            case 1:
                return new if0(this.g, this.h, this.i, this.j, this.k, tqVar, 1);
            case 2:
                return new if0(this.g, this.h, this.i, this.j, this.k, tqVar, 2);
            default:
                return new if0(this.g, this.h, this.i, this.j, this.k, tqVar, 3);
        }
    }

    @Override // defpackage.kf
    public final Object r(Object obj) {
        Object obj2;
        Object objH;
        Object obj3;
        Object objH2;
        Object obj4;
        Object objH3;
        Object obj5;
        Object objH4;
        int i = this.e;
        bw1 bw1Var = bw1.a;
        gt0 gt0Var = this.j;
        gt0 gt0Var2 = this.i;
        es esVar = es.d;
        gt0 gt0Var3 = this.k;
        switch (i) {
            case 0:
                int i2 = this.f;
                Context context = this.g;
                if (i2 == 0) {
                    vl.Q(obj);
                    q90 q90Var = (q90) gt0Var2.getValue();
                    q90Var.getClass();
                    String strB = q90Var.b();
                    this.f = 1;
                    au auVar = rv.a;
                    obj2 = null;
                    objH = m22.H(vt.f, new kf0(this.h, strB, context, null, 0), this);
                    if (objH == esVar) {
                    }
                } else if (i2 != 1) {
                    zi.f("call to 'resume' before 'invoke' with coroutine");
                } else {
                    vl.Q(obj);
                    objH = obj;
                    obj2 = null;
                }
                String str = (String) objH;
                gt0Var.setValue(Boolean.FALSE);
                if (str == null) {
                    gt0Var3.setValue("Cookies không hợp lệ hoặc chưa có tài khoản IG nào trên GoLike.");
                } else {
                    Toast.makeText(context, "Đã thêm: ".concat(str), 0).show();
                    gt0Var3.setValue(obj2);
                }
                break;
            case 1:
                int i3 = this.f;
                Context context2 = this.g;
                if (i3 == 0) {
                    vl.Q(obj);
                    q90 q90Var2 = (q90) gt0Var2.getValue();
                    q90Var2.getClass();
                    String strB2 = q90Var2.b();
                    this.f = 1;
                    au auVar2 = rv.a;
                    obj3 = null;
                    objH2 = m22.H(vt.f, new kf0(this.h, strB2, context2, null, 1), this);
                    if (objH2 == esVar) {
                    }
                } else if (i3 != 1) {
                    zi.f("call to 'resume' before 'invoke' with coroutine");
                } else {
                    vl.Q(obj);
                    objH2 = obj;
                    obj3 = null;
                }
                String str2 = (String) objH2;
                gt0Var.setValue(Boolean.FALSE);
                if (str2 == null) {
                    gt0Var3.setValue("Cookies không hợp lệ hoặc chưa có tài khoản Threads nào trên GoLike.");
                } else {
                    Toast.makeText(context2, "Đã thêm: ".concat(str2), 0).show();
                    gt0Var3.setValue(obj3);
                }
                break;
            case 2:
                int i4 = this.f;
                Context context3 = this.g;
                if (i4 == 0) {
                    vl.Q(obj);
                    q90 q90Var3 = (q90) gt0Var2.getValue();
                    q90Var3.getClass();
                    String strB3 = q90Var3.b();
                    this.f = 1;
                    au auVar3 = rv.a;
                    obj4 = null;
                    objH3 = m22.H(vt.f, new kf0(this.h, strB3, context3, null, 2), this);
                    if (objH3 == esVar) {
                    }
                } else if (i4 != 1) {
                    zi.f("call to 'resume' before 'invoke' with coroutine");
                } else {
                    vl.Q(obj);
                    objH3 = obj;
                    obj4 = null;
                }
                String str3 = (String) objH3;
                gt0Var.setValue(Boolean.FALSE);
                if (str3 == null) {
                    gt0Var3.setValue("Cookies không hợp lệ hoặc chưa có tài khoản X nào trên GoLike.");
                } else {
                    Toast.makeText(context3, "Đã thêm: ".concat(str3), 0).show();
                    gt0Var3.setValue(obj4);
                }
                break;
            default:
                int i5 = this.f;
                Context context4 = this.g;
                if (i5 == 0) {
                    vl.Q(obj);
                    int i6 = j22.b;
                    q90 q90Var4 = (q90) gt0Var2.getValue();
                    q90Var4.getClass();
                    String strB4 = q90Var4.b();
                    this.f = 1;
                    au auVar4 = rv.a;
                    obj5 = null;
                    objH4 = m22.H(vt.f, new kf0(this.h, strB4, context4, null, 3), this);
                    if (objH4 == esVar) {
                    }
                } else if (i5 != 1) {
                    zi.f("call to 'resume' before 'invoke' with coroutine");
                } else {
                    vl.Q(obj);
                    objH4 = obj;
                    obj5 = null;
                }
                String str4 = (String) objH4;
                int i7 = j22.b;
                gt0Var.setValue(Boolean.FALSE);
                if (str4 == null) {
                    gt0Var3.setValue("Cookies không hợp lệ (cần SAPISID) hoặc chưa có tài khoản YouTube nào trên GoLike.");
                } else {
                    Toast.makeText(context4, "Đã thêm: ".concat(str4), 0).show();
                    gt0Var3.setValue(obj5);
                }
                break;
        }
        return bw1Var;
    }
}
