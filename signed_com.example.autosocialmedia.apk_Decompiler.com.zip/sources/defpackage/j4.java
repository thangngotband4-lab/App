package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class j4 extends vl {
    public final int d;

    public j4(int i) {
        this.d = i;
    }

    public final boolean equals(Object obj) {
        return (obj instanceof j4) && ((j4) obj).d == this.d;
    }

    public final int hashCode() {
        return this.d * 31;
    }
}
