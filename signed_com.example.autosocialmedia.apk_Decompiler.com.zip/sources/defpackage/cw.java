package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class cw implements f20 {
    public final /* synthetic */ int d;
    public final /* synthetic */ Object e;
    public final /* synthetic */ Object f;

    public cw(dw dwVar, e71 e71Var, f20 f20Var) {
        this.d = 0;
        this.e = e71Var;
        this.f = f20Var;
    }

    /* JADX WARN: Removed duplicated region for block: B:101:0x01d2  */
    /* JADX WARN: Removed duplicated region for block: B:121:0x022c  */
    @Override // defpackage.f20
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final java.lang.Object k(java.lang.Object r22, defpackage.tq r23) {
        /*
            Method dump skipped, instruction units count: 620
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.cw.k(java.lang.Object, tq):java.lang.Object");
    }

    public /* synthetic */ cw(Object obj, int i, Object obj2) {
        this.d = i;
        this.e = obj;
        this.f = obj2;
    }

    public cw(l50 l50Var, e71 e71Var) {
        this.d = 1;
        this.f = l50Var;
        this.e = e71Var;
    }
}
