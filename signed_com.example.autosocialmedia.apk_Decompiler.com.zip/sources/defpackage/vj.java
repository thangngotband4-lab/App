package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class vj extends qj {
    public final m50 h;

    public vj(m50 m50Var, e20 e20Var, ur urVar, int i, sh shVar) {
        super(e20Var, urVar, i, shVar);
        this.h = m50Var;
    }

    @Override // defpackage.qj
    public final qj a(ur urVar, int i, sh shVar) {
        return new vj(this.h, this.g, urVar, i, shVar);
    }

    @Override // defpackage.qj
    public final Object e(f20 f20Var, tq tqVar) {
        Object objT = bm.t(new sj(this, f20Var, null), tqVar);
        return objT == es.d ? objT : bw1.a;
    }
}
