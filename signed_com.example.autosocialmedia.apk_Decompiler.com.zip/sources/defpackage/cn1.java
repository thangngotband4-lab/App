package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class cn1 extends um1 {
    public final String b;
    public final int c;
    public final h50 d;

    public cn1(Object obj, String str, int i, h50 h50Var) {
        super(obj);
        this.b = str;
        this.c = i;
        this.d = h50Var;
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder("TextContextMenuItem(key=");
        sb.append(this.a);
        sb.append(", label=\"");
        sb.append(this.b);
        sb.append("\", leadingIcon=");
        return f0.p(sb, this.c, ')');
    }
}
