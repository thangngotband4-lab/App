package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class kp1 {
    public final fp1 a;
    public final j31 b;

    public kp1(fp1 fp1Var, j31 j31Var) {
        this.a = fp1Var;
        this.b = j31Var;
    }

    public final void a(zo1 zo1Var, zo1 zo1Var2) {
        if (ng0.o((kp1) this.a.b.get(), this)) {
            this.b.d(zo1Var, zo1Var2);
        }
    }
}
