package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class em {
    public static final float[] a;
    public static final float[] b;
    public static final vt1 c;
    public static final vt1 d;
    public static final q81 e;
    public static final q81 f;
    public static final q81 g;
    public static final q81 h;
    public static final q81 i;
    public static final q81 j;
    public static final q81 k;
    public static final q81 l;
    public static final q81 m;
    public static final q81 n;
    public static final q81 o;
    public static final q81 p;
    public static final q81 q;
    public static final q81 r;
    public static final ji0 s;
    public static final ji0 t;
    public static final q81 u;
    public static final q81 v;
    public static final q81 w;
    public static final ow0 x;
    public static final am[] y;

    static {
        float[] fArr = {0.64f, 0.33f, 0.3f, 0.6f, 0.15f, 0.06f};
        a = fArr;
        float[] fArr2 = {0.67f, 0.33f, 0.21f, 0.71f, 0.14f, 0.08f};
        b = fArr2;
        float[] fArr3 = {0.708f, 0.292f, 0.17f, 0.797f, 0.131f, 0.046f};
        vt1 vt1Var = new vt1(2.4d, 0.9478672985781991d, 0.05213270142180095d, 0.07739938080495357d, 0.04045d);
        vt1 vt1Var2 = new vt1(2.2d, 0.9478672985781991d, 0.05213270142180095d, 0.07739938080495357d, 0.04045d);
        vt1 vt1Var3 = new vt1(-3.0d, 2.0d, 2.0d, 5.591816309728916d, 0.28466892d, 0.55991073d, -0.685490157d);
        c = vt1Var3;
        vt1 vt1Var4 = new vt1(-2.0d, -1.555223d, 1.860454d, 0.012683313515655966d, 18.8515625d, -18.6875d, 6.277394636015326d);
        d = vt1Var4;
        kz1 kz1Var = y5.w;
        q81 q81Var = new q81("sRGB IEC61966-2.1", fArr, kz1Var, vt1Var, 0);
        e = q81Var;
        q81 q81Var2 = new q81("sRGB IEC61966-2.1 (Linear)", fArr, kz1Var, 1.0d, 0.0f, 1.0f, 1);
        f = q81Var2;
        q81 q81Var3 = new q81("scRGB-nl IEC 61966-2-2:2003", fArr, kz1Var, null, new zi(19), new zi(20), -0.799f, 2.399f, vt1Var, 2);
        g = q81Var3;
        q81 q81Var4 = new q81("scRGB IEC 61966-2-2:2003", fArr, kz1Var, 1.0d, -0.5f, 7.499f, 3);
        h = q81Var4;
        q81 q81Var5 = new q81("Rec. ITU-R BT.709-5", new float[]{0.64f, 0.33f, 0.3f, 0.6f, 0.15f, 0.06f}, kz1Var, new vt1(2.2222222222222223d, 0.9099181073703367d, 0.09008189262966333d, 0.2222222222222222d, 0.081d), 4);
        i = q81Var5;
        q81 q81Var6 = new q81("Rec. ITU-R BT.2020-1", new float[]{0.708f, 0.292f, 0.17f, 0.797f, 0.131f, 0.046f}, kz1Var, new vt1(2.2222222222222223d, 0.9096697898662786d, 0.09033021013372146d, 0.2222222222222222d, 0.08145d), 5);
        j = q81Var6;
        q81 q81Var7 = new q81("SMPTE RP 431-2-2007 DCI (P3)", new float[]{0.68f, 0.32f, 0.265f, 0.69f, 0.15f, 0.06f}, new kz1(0.314f, 0.351f), 2.6d, 0.0f, 1.0f, 6);
        k = q81Var7;
        q81 q81Var8 = new q81("Display P3", new float[]{0.68f, 0.32f, 0.265f, 0.69f, 0.15f, 0.06f}, kz1Var, vt1Var, 7);
        l = q81Var8;
        q81 q81Var9 = new q81("NTSC (1953)", fArr2, y5.t, new vt1(2.2222222222222223d, 0.9099181073703367d, 0.09008189262966333d, 0.2222222222222222d, 0.081d), 8);
        m = q81Var9;
        q81 q81Var10 = new q81("SMPTE-C RGB", new float[]{0.63f, 0.34f, 0.31f, 0.595f, 0.155f, 0.07f}, kz1Var, new vt1(2.2222222222222223d, 0.9099181073703367d, 0.09008189262966333d, 0.2222222222222222d, 0.081d), 9);
        n = q81Var10;
        q81 q81Var11 = new q81("Adobe RGB (1998)", new float[]{0.64f, 0.33f, 0.21f, 0.71f, 0.15f, 0.06f}, kz1Var, 2.2d, 0.0f, 1.0f, 10);
        o = q81Var11;
        q81 q81Var12 = new q81("ROMM RGB ISO 22028-2:2013", new float[]{0.7347f, 0.2653f, 0.1596f, 0.8404f, 0.0366f, 1.0E-4f}, y5.u, new vt1(1.8d, 1.0d, 0.0d, 0.0625d, 0.031248d), 11);
        p = q81Var12;
        kz1 kz1Var2 = y5.v;
        q81 q81Var13 = new q81("SMPTE ST 2065-1:2012 ACES", new float[]{0.7347f, 0.2653f, 0.0f, 1.0f, 1.0E-4f, -0.077f}, kz1Var2, 1.0d, -65504.0f, 65504.0f, 12);
        q = q81Var13;
        q81 q81Var14 = new q81("Academy S-2014-004 ACEScg", new float[]{0.713f, 0.293f, 0.165f, 0.83f, 0.128f, 0.044f}, kz1Var2, 1.0d, -65504.0f, 65504.0f, 13);
        r = q81Var14;
        ji0 ji0Var = new ji0(14, 1, 12884901889L, "Generic XYZ");
        s = ji0Var;
        ji0 ji0Var2 = new ji0(15, 0, 12884901890L, "Generic L*a*b*");
        t = ji0Var2;
        q81 q81Var15 = new q81("None", fArr, kz1Var, vt1Var2, 16);
        u = q81Var15;
        q81 q81Var16 = new q81("Hybrid Log Gamma encoding", fArr3, kz1Var, null, new zi(21), new zi(22), 0.0f, 1.0f, vt1Var3, 17);
        v = q81Var16;
        q81 q81Var17 = new q81("Perceptual Quantizer encoding", fArr3, kz1Var, null, new zi(23), new zi(24), 0.0f, 1.0f, vt1Var4, 18);
        w = q81Var17;
        ow0 ow0Var = new ow0(12884901890L, "Oklab", 19);
        x = ow0Var;
        y = new am[]{q81Var, q81Var2, q81Var3, q81Var4, q81Var5, q81Var6, q81Var7, q81Var8, q81Var9, q81Var10, q81Var11, q81Var12, q81Var13, q81Var14, ji0Var, ji0Var2, q81Var15, q81Var16, q81Var17, ow0Var};
    }

    public static double a(vt1 vt1Var, double d2) {
        double d3 = d2 < 0.0d ? -1.0d : 1.0d;
        double d4 = d2 * d3;
        double d5 = vt1Var.b;
        double d6 = vt1Var.c;
        double d7 = vt1Var.d;
        double d8 = vt1Var.e;
        double d9 = vt1Var.f;
        double d10 = d5 * d4;
        return (vt1Var.g + 1.0d) * d3 * (d10 <= 1.0d ? Math.pow(d10, d6) : Math.exp((d4 - d9) * d7) + d8);
    }

    public static double b(vt1 vt1Var, double d2) {
        double d3 = d2 < 0.0d ? -1.0d : 1.0d;
        double d4 = 1.0d / vt1Var.b;
        double d5 = 1.0d / vt1Var.c;
        double d6 = 1.0d / vt1Var.d;
        double d7 = vt1Var.e;
        double d8 = vt1Var.f;
        double d9 = (d2 * d3) / (vt1Var.g + 1.0d);
        return d3 * (d9 <= 1.0d ? Math.pow(d9, d5) * d4 : (Math.log(d9 - d7) * d6) + d8);
    }

    public static double c(vt1 vt1Var, double d2) {
        double d3 = d2 < 0.0d ? -1.0d : 1.0d;
        double d4 = d2 * d3;
        double d5 = vt1Var.b;
        double d6 = vt1Var.d;
        double dPow = (Math.pow(d4, d6) * vt1Var.c) + d5;
        return Math.pow((dPow >= 0.0d ? dPow : 0.0d) / ((Math.pow(d4, d6) * vt1Var.f) + vt1Var.e), vt1Var.g) * d3;
    }

    public static double d(vt1 vt1Var, double d2) {
        double d3 = d2 < 0.0d ? -1.0d : 1.0d;
        double d4 = d2 * d3;
        double d5 = -vt1Var.b;
        double d6 = vt1Var.e;
        double d7 = 1.0d / vt1Var.g;
        return Math.pow(Math.max((Math.pow(d4, d7) * d6) + d5, 0.0d) / ((Math.pow(d4, d7) * (-vt1Var.f)) + vt1Var.c), 1.0d / vt1Var.d) * d3;
    }
}
