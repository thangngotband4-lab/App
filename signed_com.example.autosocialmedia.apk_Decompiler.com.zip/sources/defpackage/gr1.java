package defpackage;

import java.util.List;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class gr1 {
    public final ht1 a;
    public final String b;
    public final List c;

    public gr1(ht1 ht1Var, String str, List list) {
        ht1Var.getClass();
        this.a = ht1Var;
        this.b = str;
        this.c = list;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof gr1)) {
            return false;
        }
        gr1 gr1Var = (gr1) obj;
        return this.a == gr1Var.a && this.b.equals(gr1Var.b) && this.c.equals(gr1Var.c);
    }

    public final int hashCode() {
        return this.c.hashCode() + f0.e(this.a.hashCode() * 31, 31, this.b);
    }

    public final String toString() {
        return "VariantSpec(variant=" + this.a + ", displayName=" + this.b + ", packages=" + this.c + ")";
    }
}
