package defpackage;

import java.util.Random;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class y00 extends b0 {
    public final w9 e = new w9(1);

    @Override // defpackage.b0
    public final Random f() {
        Object obj = this.e.get();
        obj.getClass();
        return (Random) obj;
    }
}
