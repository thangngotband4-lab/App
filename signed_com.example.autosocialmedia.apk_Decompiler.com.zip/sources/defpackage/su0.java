package defpackage;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class su0 {
    public static final su0 d;
    public static final su0 e;
    public static final /* synthetic */ su0[] f;

    static {
        su0 su0Var = new su0("Min", 0);
        d = su0Var;
        su0 su0Var2 = new su0("Max", 1);
        e = su0Var2;
        f = new su0[]{su0Var, su0Var2};
    }

    public static su0 valueOf(String str) {
        return (su0) Enum.valueOf(su0.class, str);
    }

    public static su0[] values() {
        return (su0[]) f.clone();
    }
}
