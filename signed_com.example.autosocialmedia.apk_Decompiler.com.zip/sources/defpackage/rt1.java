package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public abstract class rt1 {
    public static final long a = vl1.h(0, 0, 0, 0);
    public static final /* synthetic */ int b = 0;
}
