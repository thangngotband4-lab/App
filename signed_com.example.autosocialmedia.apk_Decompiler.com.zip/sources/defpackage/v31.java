package defpackage;

import java.util.ArrayList;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class v31 {
    public final long a;
    public final long b;
    public final long c;
    public final long d;
    public final boolean e;
    public final float f;
    public final int g;
    public final boolean h;
    public final ArrayList i;
    public final long j;
    public final long k;

    public v31(long j, long j2, long j3, long j4, boolean z, float f, int i, boolean z2, ArrayList arrayList, long j5, long j6) {
        this.a = j;
        this.b = j2;
        this.c = j3;
        this.d = j4;
        this.e = z;
        this.f = f;
        this.g = i;
        this.h = z2;
        this.i = arrayList;
        this.j = j5;
        this.k = j6;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof v31)) {
            return false;
        }
        v31 v31Var = (v31) obj;
        return om.u(this.a, v31Var.a) && this.b == v31Var.b && jw0.b(this.c, v31Var.c) && jw0.b(this.d, v31Var.d) && this.e == v31Var.e && Float.compare(this.f, v31Var.f) == 0 && this.g == v31Var.g && this.h == v31Var.h && this.i.equals(v31Var.i) && jw0.b(this.j, v31Var.j) && jw0.b(this.k, v31Var.k);
    }

    public final int hashCode() {
        return Long.hashCode(this.k) + f0.c((this.i.hashCode() + f0.f(f0.b(this.g, f0.a(this.f, f0.f(f0.c(f0.c(f0.c(Long.hashCode(this.a) * 31, 31, this.b), 31, this.c), 31, this.d), 31, this.e), 31), 31), 31, this.h)) * 31, 31, this.j);
    }

    public final String toString() {
        return "PointerInputEventData(id=" + ((Object) om.U(this.a)) + ", uptime=" + this.b + ", positionOnScreen=" + ((Object) jw0.g(this.c)) + ", position=" + ((Object) jw0.g(this.d)) + ", down=" + this.e + ", pressure=" + this.f + ", type=" + ((Object) b41.a(this.g)) + ", activeHover=" + this.h + ", historical=" + this.i + ", scrollDelta=" + ((Object) jw0.g(this.j)) + ", originalEventPosition=" + ((Object) jw0.g(this.k)) + ')';
    }
}
