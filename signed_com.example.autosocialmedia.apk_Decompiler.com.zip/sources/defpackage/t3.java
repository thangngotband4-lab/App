package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class t3 implements w40 {
    public final /* synthetic */ int d;

    public /* synthetic */ t3(int i) {
        this.d = i;
    }

    @Override // defpackage.w40
    public final Object a() {
        switch (this.d) {
            case 0:
                uz0 uz0Var = z3.a;
                return ht.a;
            case 1:
                return new pi1(tl.b(1308617531));
            case 2:
                return Boolean.valueOf(te.i);
            case 3:
                return Boolean.valueOf(te.i);
            case 4:
                return Boolean.valueOf(te.i);
            case 5:
                return Boolean.valueOf(te.i);
            case 6:
                return Boolean.valueOf(te.i);
            case 7:
                return Boolean.valueOf(te.i);
            case 8:
                vj1 vj1Var = wf.a;
                return null;
            case 9:
                return zl.e(0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, -1);
            case 10:
                vj1 vj1Var2 = zl.a;
                return Boolean.TRUE;
            case 11:
                return bw1.a;
            case 12:
                return bw1.a;
            case 13:
                vj1 vj1Var3 = fp.a;
                return null;
            case 14:
                yo.b("Unexpected call to default provider");
                throw new ym();
            case 15:
                float f = fx.a;
                return Boolean.TRUE;
            case 16:
                return bw1.a;
            case 17:
                return bw1.a;
            case 18:
                mp mpVar = uc0.a;
                return kt.a;
            case 19:
                vj1 vj1Var4 = me0.a;
                return null;
            case e80.MAX_VERIFY /* 20 */:
                hb0 hb0Var = dg0.a;
                return Boolean.TRUE;
            case 21:
                return new hw(48.0f);
            case 22:
                return new ql0(0, 0);
            case 23:
                throw new IllegalStateException("CompositionLocal LocalLifecycleOwner not present");
            case 24:
                vj1 vj1Var5 = fo0.a;
                return a4.G;
            case 25:
                throw new IllegalStateException("CompositionLocal LocalSavedStateRegistryOwner not present");
            case 26:
                at.INSTANCE.getClass();
                at.b();
                return bw1.a;
            case 27:
                vj1 vj1Var6 = dq0.a;
                return Boolean.FALSE;
            case 28:
                return rr0.a;
            default:
                te.b();
                return bw1.a;
        }
    }
}
