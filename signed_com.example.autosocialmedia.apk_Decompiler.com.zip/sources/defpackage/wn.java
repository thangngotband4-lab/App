package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class wn implements m50 {
    public final /* synthetic */ int d;

    public /* synthetic */ wn(int i) {
        this.d = i;
    }

    @Override // defpackage.m50
    public final Object c(Object obj, Object obj2, Object obj3) {
        int i = this.d;
        cr0 cr0Var = cr0.a;
        bw1 bw1Var = bw1.a;
        switch (i) {
            case 0:
                xo xoVar = (xo) obj2;
                int iIntValue = ((Integer) obj3).intValue();
                ((bk0) obj).getClass();
                if (!xoVar.O(iIntValue & 1, (iIntValue & 17) != 16)) {
                    xoVar.R();
                } else {
                    y5.g("Facebook", null, sl.d, null, null, xoVar, 390, 26);
                }
                break;
            case 1:
                xo xoVar2 = (xo) obj2;
                int iIntValue2 = ((Integer) obj3).intValue();
                ((bk0) obj).getClass();
                if (!xoVar2.O(iIntValue2 & 1, (iIntValue2 & 17) != 16)) {
                    xoVar2.R();
                } else {
                    om.d(xoVar2, ig1.b(cr0Var, 24.0f));
                    mp1.b("Tài khoản Facebook", y5.B(cr0Var, 20.0f, 8.0f), sl.l(), ak1.h(18), p40.h, null, 0L, null, 0L, 0, false, 0, 0, null, xoVar2, 1597494, 0, 262056);
                }
                break;
            case 2:
                xo xoVar3 = (xo) obj2;
                int iIntValue3 = ((Integer) obj3).intValue();
                ((bk0) obj).getClass();
                if (!xoVar3.O(iIntValue3 & 1, (iIntValue3 & 17) != 16)) {
                    xoVar3.R();
                } else {
                    fr0 fr0VarC = y5.C(cr0Var, 16.0f, 0.0f, 2);
                    km kmVarA = im.a(new hd(8.0f, new dd(0)), a4.q, xoVar3, 6);
                    int iHashCode = Long.hashCode(xoVar3.T);
                    t11 t11VarL = xoVar3.l();
                    fr0 fr0VarM = om.M(xoVar3, fr0VarC);
                    oo.b.getClass();
                    kp kpVar = no.b;
                    xoVar3.Z();
                    if (xoVar3.S) {
                        xoVar3.k(kpVar);
                    } else {
                        xoVar3.j0();
                    }
                    ak1.o(xoVar3, no.e, kmVarA);
                    ak1.o(xoVar3, no.d, t11VarL);
                    ak1.j(xoVar3, Integer.valueOf(iHashCode), no.f);
                    ak1.n(xoVar3, no.g);
                    ak1.o(xoVar3, no.c, fr0VarM);
                    hc0 hc0VarX = jl.x();
                    long j = sl.d;
                    mg0.L(hc0VarX, "Nguyễn Văn A", "1.5K bạn bè • Active", "Online", null, j, sl.j(), xoVar3, 200112);
                    mg0.L(jl.x(), "Trần Thị B", "3.2K bạn bè • Active", "Online", null, j, sl.j(), xoVar3, 200112);
                    mg0.L(jl.x(), "Lê Văn C", "800 bạn bè • Paused", "1 giờ", null, j, sl.k(), xoVar3, 200112);
                    xoVar3.p(true);
                }
                break;
            case 3:
                xo xoVar4 = (xo) obj2;
                int iIntValue4 = ((Integer) obj3).intValue();
                ((bk0) obj).getClass();
                if (!xoVar4.O(iIntValue4 & 1, (iIntValue4 & 17) != 16)) {
                    xoVar4.R();
                } else {
                    y5.g("Auto GoLike", null, sl.c(), "Tự động kiếm xu trên các nền tảng", null, xoVar4, 3078, 18);
                }
                break;
            case 4:
                xo xoVar5 = (xo) obj2;
                int iIntValue5 = ((Integer) obj3).intValue();
                ((bk0) obj).getClass();
                if (!xoVar5.O(iIntValue5 & 1, (iIntValue5 & 17) != 16)) {
                    xoVar5.R();
                } else {
                    om.d(xoVar5, ig1.b(cr0Var, 16.0f));
                }
                break;
            case 5:
                xo xoVar6 = (xo) obj2;
                int iIntValue6 = ((Integer) obj3).intValue();
                ((bk0) obj).getClass();
                if (!xoVar6.O(iIntValue6 & 1, (iIntValue6 & 17) != 16)) {
                    xoVar6.R();
                } else {
                    om.d(xoVar6, ig1.b(cr0Var, 20.0f));
                }
                break;
            case 6:
                xo xoVar7 = (xo) obj2;
                int iIntValue7 = ((Integer) obj3).intValue();
                ((bk0) obj).getClass();
                if (!xoVar7.O(iIntValue7 & 1, (iIntValue7 & 17) != 16)) {
                    xoVar7.R();
                } else {
                    mp1.b("Chọn nền tảng", y5.B(cr0Var, 20.0f, 8.0f), sl.l(), ak1.h(18), p40.h, null, 0L, null, 0L, 0, false, 0, 0, null, xoVar7, 1597494, 0, 262056);
                }
                break;
            case 7:
                xo xoVar8 = (xo) obj2;
                int iIntValue8 = ((Integer) obj3).intValue();
                ((bk0) obj).getClass();
                if (!xoVar8.O(iIntValue8 & 1, (iIntValue8 & 17) != 16)) {
                    xoVar8.R();
                } else {
                    om.d(xoVar8, ig1.b(cr0Var, 8.0f));
                }
                break;
            case 8:
                xo xoVar9 = (xo) obj2;
                int iIntValue9 = ((Integer) obj3).intValue();
                ((bk0) obj).getClass();
                if (!xoVar9.O(iIntValue9 & 1, (iIntValue9 & 17) != 16)) {
                    xoVar9.R();
                } else {
                    mp1.b("Chưa có tài khoản TikTok nào. Hãy thêm trên web GoLike + quét ở tab Trang chủ.", y5.A(cr0Var, 8.0f), sl.n(), ak1.h(13), null, null, 0L, null, 0L, 0, false, 0, 0, null, xoVar9, 24630, 0, 262120);
                }
                break;
            case 9:
                xo xoVar10 = (xo) obj2;
                int iIntValue10 = ((Integer) obj3).intValue();
                ((bk0) obj).getClass();
                if (!xoVar10.O(iIntValue10 & 1, (iIntValue10 & 17) != 16)) {
                    xoVar10.R();
                } else {
                    mp1.b("Không có tài khoản nào trong nhóm này.", y5.A(cr0Var, 8.0f), sl.n(), ak1.h(13), null, null, 0L, null, 0L, 0, false, 0, 0, null, xoVar10, 24630, 0, 262120);
                }
                break;
            case 10:
                xo xoVar11 = (xo) obj2;
                int iIntValue11 = ((Integer) obj3).intValue();
                ((l91) obj).getClass();
                if (!xoVar11.O(iIntValue11 & 1, (iIntValue11 & 17) != 16)) {
                    xoVar11.R();
                } else {
                    mp1.b("Huỷ", null, sl.m(), 0L, null, null, 0L, null, 0L, 0, false, 0, 0, null, xoVar11, 6, 0, 262138);
                }
                break;
            case 11:
                xo xoVar12 = (xo) obj2;
                int iIntValue12 = ((Integer) obj3).intValue();
                ((bk0) obj).getClass();
                if (!xoVar12.O(iIntValue12 & 1, (iIntValue12 & 17) != 16)) {
                    xoVar12.R();
                } else {
                    mp1.b("Chưa có tài khoản nào.", y5.C(cr0Var, 0.0f, 8.0f, 1), sl.n(), ak1.h(13), null, null, 0L, null, 0L, 0, false, 0, 0, null, xoVar12, 24630, 0, 262120);
                }
                break;
            case 12:
                xo xoVar13 = (xo) obj2;
                int iIntValue13 = ((Integer) obj3).intValue();
                ((l91) obj).getClass();
                if (!xoVar13.O(iIntValue13 & 1, (iIntValue13 & 17) != 16)) {
                    xoVar13.R();
                } else {
                    mp1.b("Thêm", null, 0L, 0L, null, null, 0L, null, 0L, 0, false, 0, 0, null, xoVar13, 6, 0, 262142);
                }
                break;
            case 13:
                xo xoVar14 = (xo) obj2;
                int iIntValue14 = ((Integer) obj3).intValue();
                ((l91) obj).getClass();
                if (!xoVar14.O(iIntValue14 & 1, (iIntValue14 & 17) != 16)) {
                    xoVar14.R();
                } else {
                    mp1.b("Huỷ", null, 0L, 0L, null, null, 0L, null, 0L, 0, false, 0, 0, null, xoVar14, 6, 0, 262142);
                }
                break;
            case 14:
                xo xoVar15 = (xo) obj2;
                int iIntValue15 = ((Integer) obj3).intValue();
                ((l91) obj).getClass();
                if (!xoVar15.O(iIntValue15 & 1, (iIntValue15 & 17) != 16)) {
                    xoVar15.R();
                } else {
                    mp1.b("Mở Cài đặt", null, 0L, 0L, null, null, 0L, null, 0L, 0, false, 0, 0, null, xoVar15, 6, 0, 262142);
                }
                break;
            case 15:
                xo xoVar16 = (xo) obj2;
                int iIntValue16 = ((Integer) obj3).intValue();
                ((l91) obj).getClass();
                if (!xoVar16.O(iIntValue16 & 1, (iIntValue16 & 17) != 16)) {
                    xoVar16.R();
                } else {
                    mp1.b("Để sau", null, 0L, 0L, null, null, 0L, null, 0L, 0, false, 0, 0, null, xoVar16, 6, 0, 262142);
                }
                break;
            case 16:
                xo xoVar17 = (xo) obj2;
                int iIntValue17 = ((Integer) obj3).intValue();
                ((l91) obj).getClass();
                if (!xoVar17.O(iIntValue17 & 1, (iIntValue17 & 17) != 16)) {
                    xoVar17.R();
                } else {
                    mp1.b("Cấp quyền", null, 0L, 0L, null, null, 0L, null, 0L, 0, false, 0, 0, null, xoVar17, 6, 0, 262142);
                }
                break;
            case 17:
                xo xoVar18 = (xo) obj2;
                int iIntValue18 = ((Integer) obj3).intValue();
                ((l91) obj).getClass();
                if (!xoVar18.O(iIntValue18 & 1, (iIntValue18 & 17) != 16)) {
                    xoVar18.R();
                } else {
                    mp1.b("Bỏ qua", null, 0L, 0L, null, null, 0L, null, 0L, 0, false, 0, 0, null, xoVar18, 6, 0, 262142);
                }
                break;
            case 18:
                xo xoVar19 = (xo) obj2;
                int iIntValue19 = ((Integer) obj3).intValue();
                ((bk0) obj).getClass();
                if (!xoVar19.O(iIntValue19 & 1, (iIntValue19 & 17) != 16)) {
                    xoVar19.R();
                } else {
                    mg0.z("Tự động Follow", xoVar19, 6);
                }
                break;
            case 19:
                xo xoVar20 = (xo) obj2;
                int iIntValue20 = ((Integer) obj3).intValue();
                ((bk0) obj).getClass();
                if (!xoVar20.O(iIntValue20 & 1, (iIntValue20 & 17) != 16)) {
                    xoVar20.R();
                } else {
                    mg0.z("Kịch bản", xoVar20, 6);
                }
                break;
            case e80.MAX_VERIFY /* 20 */:
                xo xoVar21 = (xo) obj2;
                int iIntValue21 = ((Integer) obj3).intValue();
                ((bk0) obj).getClass();
                if (!xoVar21.O(iIntValue21 & 1, (iIntValue21 & 17) != 16)) {
                    xoVar21.R();
                } else {
                    mg0.z("Loại TikTok", xoVar21, 6);
                }
                break;
            case 21:
                xo xoVar22 = (xo) obj2;
                int iIntValue22 = ((Integer) obj3).intValue();
                ((bk0) obj).getClass();
                if (!xoVar22.O(iIntValue22 & 1, (iIntValue22 & 17) != 16)) {
                    xoVar22.R();
                } else {
                    mg0.z("Tài khoản chạy", xoVar22, 6);
                }
                break;
            case 22:
                xo xoVar23 = (xo) obj2;
                int iIntValue23 = ((Integer) obj3).intValue();
                ((bk0) obj).getClass();
                if (!xoVar23.O(iIntValue23 & 1, (iIntValue23 & 17) != 16)) {
                    xoVar23.R();
                } else {
                    mg0.z("Số video mỗi phiên", xoVar23, 6);
                }
                break;
            case 23:
                xo xoVar24 = (xo) obj2;
                int iIntValue24 = ((Integer) obj3).intValue();
                ((bk0) obj).getClass();
                if (!xoVar24.O(iIntValue24 & 1, (iIntValue24 & 17) != 16)) {
                    xoVar24.R();
                } else {
                    mg0.z("Thời gian xem mỗi video (giây)", xoVar24, 6);
                }
                break;
            case 24:
                xo xoVar25 = (xo) obj2;
                int iIntValue25 = ((Integer) obj3).intValue();
                ((bk0) obj).getClass();
                if (!xoVar25.O(iIntValue25 & 1, (iIntValue25 & 17) != 16)) {
                    xoVar25.R();
                } else {
                    mg0.z("Tự động thả tim", xoVar25, 6);
                }
                break;
            case 25:
                xo xoVar26 = (xo) obj2;
                int iIntValue26 = ((Integer) obj3).intValue();
                ((bk0) obj).getClass();
                if (!xoVar26.O(iIntValue26 & 1, (iIntValue26 & 17) != 16)) {
                    xoVar26.R();
                } else {
                    mg0.z("Tự động bình luận", xoVar26, 6);
                }
                break;
            case 26:
                xo xoVar27 = (xo) obj2;
                int iIntValue27 = ((Integer) obj3).intValue();
                ((bk0) obj).getClass();
                if (!xoVar27.O(iIntValue27 & 1, (iIntValue27 & 17) != 16)) {
                    xoVar27.R();
                } else {
                    mg0.z("Tải · Chia sẻ · Lưu", xoVar27, 6);
                }
                break;
            case 27:
                xo xoVar28 = (xo) obj2;
                int iIntValue28 = ((Integer) obj3).intValue();
                ((bk0) obj).getClass();
                if (!xoVar28.O(iIntValue28 & 1, (iIntValue28 & 17) != 16)) {
                    xoVar28.R();
                } else {
                    mg0.z("Bảo mật & Giới hạn", xoVar28, 6);
                }
                break;
            case 28:
                xo xoVar29 = (xo) obj2;
                int iIntValue29 = ((Integer) obj3).intValue();
                ((bk0) obj).getClass();
                if (!xoVar29.O(iIntValue29 & 1, (iIntValue29 & 17) != 16)) {
                    xoVar29.R();
                } else {
                    mg0.z("Giờ nghỉ đêm", xoVar29, 6);
                }
                break;
            default:
                xo xoVar30 = (xo) obj2;
                int iIntValue30 = ((Integer) obj3).intValue();
                ((bk0) obj).getClass();
                if (!xoVar30.O(iIntValue30 & 1, (iIntValue30 & 17) != 16)) {
                    xoVar30.R();
                } else {
                    mg0.z("Thoát app nghỉ", xoVar30, 6);
                }
                break;
        }
        return bw1Var;
    }
}
