package defpackage;

import kotlin.Metadata;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u000e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0001\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001¨\u0006\u0003"}, d2 = {"Lpk;", "Ljr0;", "Lok;", "material3"}, k = 1, mv = {2, 0, 0}, xi = 48)
public final class pk extends jr0 {
    public final n1 a;

    public pk(n1 n1Var) {
        this.a = n1Var;
    }

    @Override // defpackage.jr0
    public final er0 e() {
        ok okVar = new ok();
        okVar.r = this.a;
        return okVar;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof pk) {
            return this.a == ((pk) obj).a;
        }
        return false;
    }

    @Override // defpackage.jr0
    public final void f(er0 er0Var) {
        ok okVar = (ok) er0Var;
        okVar.r = this.a;
        bm.E(okVar);
    }

    public final int hashCode() {
        return this.a.hashCode();
    }
}
