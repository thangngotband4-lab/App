package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class fq extends jl1 implements l50 {
    public final /* synthetic */ int e = 1;
    public int f;
    public final /* synthetic */ long g;
    public /* synthetic */ Object h;
    public final /* synthetic */ Object i;
    public final /* synthetic */ Object j;
    public final /* synthetic */ Object k;
    public final /* synthetic */ Object l;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public fq(c31 c31Var, String str, long j, wp1 wp1Var, so1 so1Var, mw0 mw0Var, tq tqVar) {
        super(2, tqVar);
        this.h = c31Var;
        this.i = str;
        this.g = j;
        this.j = wp1Var;
        this.k = so1Var;
        this.l = mw0Var;
    }

    @Override // defpackage.l50
    public final Object f(Object obj, Object obj2) {
        int i = this.e;
        bw1 bw1Var = bw1.a;
        switch (i) {
            case 0:
                return ((fq) o((tq) obj2, (mc1) obj)).r(bw1Var);
            default:
                return ((fq) o((tq) obj2, (ds) obj)).r(bw1Var);
        }
    }

    @Override // defpackage.kf
    public final tq o(tq tqVar, Object obj) {
        int i = this.e;
        Object obj2 = this.l;
        Object obj3 = this.k;
        Object obj4 = this.j;
        Object obj5 = this.i;
        switch (i) {
            case 0:
                fq fqVar = new fq((kw1) obj5, (hq) obj4, (jh) obj3, this.g, (bh0) obj2, tqVar);
                fqVar.h = obj;
                return fqVar;
            default:
                return new fq((c31) this.h, (String) obj5, this.g, (wp1) obj4, (so1) obj3, (mw0) obj2, tqVar);
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:14:0x004f  */
    @Override // defpackage.kf
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final java.lang.Object r(java.lang.Object r18) {
        /*
            Method dump skipped, instruction units count: 252
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.fq.r(java.lang.Object):java.lang.Object");
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public fq(kw1 kw1Var, hq hqVar, jh jhVar, long j, bh0 bh0Var, tq tqVar) {
        super(2, tqVar);
        this.i = kw1Var;
        this.j = hqVar;
        this.k = jhVar;
        this.g = j;
        this.l = bh0Var;
    }
}
