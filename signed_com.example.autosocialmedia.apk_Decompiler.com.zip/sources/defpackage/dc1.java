package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class dc1 extends jl1 implements l50 {
    public /* synthetic */ Object e;
    public final /* synthetic */ long f;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public dc1(long j, tq tqVar) {
        super(2, tqVar);
        this.f = j;
    }

    @Override // defpackage.l50
    public final Object f(Object obj, Object obj2) {
        dc1 dc1Var = (dc1) o((tq) obj2, (mc1) obj);
        bw1 bw1Var = bw1.a;
        dc1Var.r(bw1Var);
        return bw1Var;
    }

    @Override // defpackage.kf
    public final tq o(tq tqVar, Object obj) {
        dc1 dc1Var = new dc1(this.f, tqVar);
        dc1Var.e = obj;
        return dc1Var;
    }

    @Override // defpackage.kf
    public final Object r(Object obj) {
        vl.Q(obj);
        oc1 oc1Var = ((mc1) this.e).a;
        oc1Var.c(oc1Var.k, this.f, 1);
        return bw1.a;
    }
}
