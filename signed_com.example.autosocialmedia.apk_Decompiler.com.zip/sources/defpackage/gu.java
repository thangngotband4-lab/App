package defpackage;

import android.content.Context;
import android.os.Build;
import androidx.compose.ui.platform.AndroidCompositionLocals_androidKt;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public abstract class gu {
    public static final j41 a;

    static {
        a = new j41((14 & 1) == 0, pc1.d, true);
    }

    public static final void a(of ofVar, vm1 vm1Var, xo xoVar, int i) {
        xo xoVar2;
        Context context;
        xoVar.X(1904307118);
        int i2 = (xoVar.f(ofVar) ? 4 : 2) | i | (xoVar.h(vm1Var) ? 32 : 16);
        if (xoVar.O(i2 & 1, (i2 & 19) != 18)) {
            if (Build.VERSION.SDK_INT >= 28) {
                xoVar.W(-1009482584);
                context = (Context) xoVar.j(AndroidCompositionLocals_androidKt.b);
                xoVar.p(false);
            } else {
                xoVar.W(-1009433480);
                xoVar.p(false);
                context = null;
            }
            boolean zH = xoVar.h(vm1Var) | ((i2 & 14) == 4) | xoVar.h(context);
            Object objL = xoVar.L();
            if (zH || objL == ro.a) {
                objL = new rf(vm1Var, context, ofVar, 3);
                xoVar.g0(objL);
            }
            xoVar2 = xoVar;
            rq.b(null, null, (h50) objL, xoVar2, 0, 3);
        } else {
            xoVar2 = xoVar;
            xoVar2.R();
        }
        l61 l61VarR = xoVar2.r();
        if (l61VarR != null) {
            l61VarR.d = new e60(ofVar, vm1Var, i, 7);
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:272:0x061b, code lost:
    
        r3 = new defpackage.ic0(r24.b(), r8 | r10.b);
        r13.a.put(r15, new java.lang.ref.WeakReference(r3));
        r0 = r3;
     */
    /* JADX WARN: Removed duplicated region for block: B:105:0x0238  */
    /* JADX WARN: Removed duplicated region for block: B:106:0x0241  */
    /* JADX WARN: Removed duplicated region for block: B:116:0x0265  */
    /* JADX WARN: Removed duplicated region for block: B:125:0x029e  */
    /* JADX WARN: Removed duplicated region for block: B:202:0x0481  */
    /* JADX WARN: Removed duplicated region for block: B:207:0x0493  */
    /* JADX WARN: Removed duplicated region for block: B:208:0x0496  */
    /* JADX WARN: Removed duplicated region for block: B:211:0x04a6  */
    /* JADX WARN: Removed duplicated region for block: B:218:0x04b6  */
    /* JADX WARN: Removed duplicated region for block: B:221:0x04f8  */
    /* JADX WARN: Removed duplicated region for block: B:222:0x04fd  */
    /* JADX WARN: Removed duplicated region for block: B:226:0x0517 A[ADDED_TO_REGION] */
    /* JADX WARN: Removed duplicated region for block: B:227:0x0519  */
    /* JADX WARN: Removed duplicated region for block: B:235:0x053c  */
    /* JADX WARN: Removed duplicated region for block: B:240:0x0556  */
    /* JADX WARN: Removed duplicated region for block: B:241:0x0559  */
    /* JADX WARN: Removed duplicated region for block: B:244:0x055f  */
    /* JADX WARN: Removed duplicated region for block: B:283:0x0687  */
    /* JADX WARN: Removed duplicated region for block: B:326:0x0618 A[SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static final void b(final int r61, long r62, defpackage.xo r64, final int r65) {
        /*
            Method dump skipped, instruction units count: 1864
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.gu.b(int, long, xo, int):void");
    }

    public static final void c(of ofVar, wm1 wm1Var, w40 w40Var, xo xoVar, int i) {
        int i2;
        xoVar.X(-2040393164);
        if ((i & 6) == 0) {
            i2 = ((i & 8) == 0 ? xoVar.f(ofVar) : xoVar.h(ofVar) ? 4 : 2) | i;
        } else {
            i2 = i;
        }
        if ((i & 48) == 0) {
            i2 |= (i & 64) == 0 ? xoVar.f(wm1Var) : xoVar.h(wm1Var) ? 32 : 16;
        }
        if ((i & 384) == 0) {
            i2 |= xoVar.h(w40Var) ? 256 : 128;
        }
        boolean z = false;
        if (xoVar.O(i2 & 1, (i2 & 147) != 146)) {
            boolean z2 = (i2 & 112) == 32 || ((i2 & 64) != 0 && xoVar.f(wm1Var));
            Object objL = xoVar.L();
            dp1 dp1Var = ro.a;
            int i3 = 8;
            if (z2 || objL == dp1Var) {
                objL = new tp0(new l1(5, new t2(wm1Var, i3, w40Var)));
                xoVar.g0(objL);
            }
            tp0 tp0Var = (tp0) objL;
            if ((i2 & 14) == 4 || ((i2 & 8) != 0 && xoVar.h(ofVar))) {
                z = true;
            }
            Object objL2 = xoVar.L();
            if (z || objL2 == dp1Var) {
                objL2 = new y8(5, ofVar);
                xoVar.g0(objL2);
            }
            u8.a(tp0Var, (w40) objL2, a, jl.C(1315155414, new e60(wm1Var, 6, ofVar), xoVar), xoVar, 3456, 0);
        } else {
            xoVar.R();
        }
        l61 l61VarR = xoVar.r();
        if (l61VarR != null) {
            l61VarR.d = new a9(ofVar, wm1Var, w40Var, i, 5);
        }
    }

    public static final void d(fr0 fr0Var, qn qnVar, xo xoVar, int i) {
        int i2;
        xoVar.X(1392105195);
        int i3 = 2;
        if ((i & 6) == 0) {
            i2 = (xoVar.f(fr0Var) ? 4 : 2) | i;
        } else {
            i2 = i;
        }
        if ((i & 48) == 0) {
            i2 |= xoVar.h(qnVar) ? 32 : 16;
        }
        if (xoVar.O(i2 & 1, (i2 & 19) != 18)) {
            ng0.d(fr0Var, gn1.a, qnVar, xoVar, ((i2 << 6) & 7168) | (i2 & 14) | 432);
        } else {
            xoVar.R();
        }
        l61 l61VarR = xoVar.r();
        if (l61VarR != null) {
            l61VarR.d = new r9(fr0Var, qnVar, i, i3);
        }
    }
}
