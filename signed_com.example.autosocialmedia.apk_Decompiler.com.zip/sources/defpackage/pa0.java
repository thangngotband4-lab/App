package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class pa0 implements Runnable {
    public final /* synthetic */ int d = 1;
    public Runnable e;
    public final /* synthetic */ wr f;

    public pa0(xi xiVar, qa0 qa0Var) {
        this.e = xiVar;
        this.f = qa0Var;
    }

    @Override // java.lang.Runnable
    public final void run() {
        int i = this.d;
        wr wrVar = this.f;
        switch (i) {
            case 0:
                ((xi) this.e).H((qa0) wrVar);
                break;
            default:
                ln0 ln0Var = (ln0) wrVar;
                wr wrVar2 = ln0Var.g;
                int i2 = 0;
                while (true) {
                    try {
                        this.e.run();
                    } catch (Throwable th) {
                        vl.B(rz.d, th);
                    }
                    Runnable runnableJ = ln0Var.j();
                    if (runnableJ == null) {
                        break;
                    } else {
                        this.e = runnableJ;
                        i2++;
                        if (i2 >= 16 && wrVar2.f(ln0Var)) {
                            wrVar2.e(ln0Var, this);
                            break;
                        }
                    }
                    break;
                }
                break;
        }
    }

    public pa0(ln0 ln0Var, Runnable runnable) {
        this.f = ln0Var;
        this.e = runnable;
    }
}
