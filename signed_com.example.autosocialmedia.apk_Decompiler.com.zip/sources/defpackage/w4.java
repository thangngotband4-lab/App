package defpackage;

import android.graphics.Rect;
import android.view.FocusFinder;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class w4 extends er0 implements yg, nd1, yh0, zi0, mu1 {
    public final g4 r = new g4(2, this);
    public final /* synthetic */ k5 s;

    public w4(k5 k5Var) {
        this.s = k5Var;
    }

    @Override // defpackage.yh0
    public final boolean T(KeyEvent keyEvent) {
        o20 o20Var;
        int[] iArr = x20.a;
        long jZ = vh0.z(keyEvent);
        if (sh0.a(jZ, sh0.b)) {
            o20Var = new o20(2);
        } else if (sh0.a(jZ, sh0.c)) {
            o20Var = new o20(1);
        } else if (sh0.a(jZ, sh0.p)) {
            o20Var = new o20(keyEvent.isShiftPressed() ? 2 : 1);
        } else {
            o20Var = sh0.a(jZ, sh0.g) ? new o20(4) : sh0.a(jZ, sh0.f) ? new o20(3) : (sh0.a(jZ, sh0.d) || sh0.a(jZ, sh0.C)) ? new o20(5) : (sh0.a(jZ, sh0.e) || sh0.a(jZ, sh0.D)) ? new o20(6) : (sh0.a(jZ, sh0.h) || sh0.a(jZ, sh0.r) || sh0.a(jZ, sh0.E)) ? new o20(7) : (sh0.a(jZ, sh0.a) || sh0.a(jZ, sh0.u)) ? new o20(8) : null;
        }
        if (o20Var != null) {
            int i = o20Var.a;
            if (vh0.A(keyEvent) == 2) {
                k5 k5Var = this.s;
                r30 r30VarF = ((d30) k5Var.getFocusOwner()).f();
                if (r30VarF == null || !r30VarF.r || !k5Var.x(i)) {
                    Boolean boolE = ((d30) k5Var.getFocusOwner()).e(i, k5Var.getEmbeddedViewFocusRect(), new g4(1, o20Var));
                    if (!(boolE != null ? boolE.booleanValue() : true)) {
                        if (i == 1 || i == 2) {
                            Integer numC = x20.c(i);
                            int iIntValue = numC != null ? numC.intValue() : 2;
                            FocusFinder focusFinder = FocusFinder.getInstance();
                            View rootView = k5Var.getRootView();
                            rootView.getClass();
                            View viewFindNextFocus = focusFinder.findNextFocus((ViewGroup) rootView, k5Var.getView(), iIntValue);
                            if (viewFindNextFocus == null || viewFindNextFocus.equals(k5Var)) {
                                return ((d30) k5Var.getFocusOwner()).h(i);
                            }
                        }
                    }
                }
                return true;
            }
        }
        return false;
    }

    @Override // defpackage.zi0
    public final mq0 d(nq0 nq0Var, gq0 gq0Var, long j) {
        k21 k21VarE = gq0Var.e(j);
        return nq0Var.O(k21VarE.d, k21VarE.e, vz.d, this.r, new v4(k21VarE, 0));
    }

    @Override // defpackage.yg
    public final Object d0(pu0 pu0Var, a5 a5Var, uq uqVar) {
        long jQ = pu0Var.Q(0L);
        x61 x61Var = (x61) a5Var.a();
        x61 x61VarI = x61Var != null ? x61Var.i(jQ) : null;
        if (x61VarI != null) {
            this.s.requestRectangleOnScreen(new Rect((int) x61VarI.a, (int) x61VarI.b, (int) x61VarI.c, (int) x61VarI.d), false);
        }
        return bw1.a;
    }

    @Override // defpackage.yh0
    public final boolean j(KeyEvent keyEvent) {
        return false;
    }

    @Override // defpackage.mu1
    public final Object o() {
        return "androidx.compose.ui.layout.WindowInsetsRulers";
    }

    @Override // defpackage.nd1
    public final void k0(yd1 yd1Var) {
    }
}
