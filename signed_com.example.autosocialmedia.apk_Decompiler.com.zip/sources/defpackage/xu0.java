package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class xu0 implements f20 {
    public static final xu0 d = new xu0();

    @Override // defpackage.f20
    public final Object k(Object obj, tq tqVar) {
        return bw1.a;
    }
}
