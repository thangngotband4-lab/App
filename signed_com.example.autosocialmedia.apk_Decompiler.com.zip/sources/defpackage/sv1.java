package defpackage;

import android.view.View;
import java.util.ArrayList;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class sv1 implements ad {
    public final Object a;
    public final ArrayList b = new ArrayList();
    public Object c;

    public sv1(ij0 ij0Var) {
        this.a = ij0Var;
        this.c = ij0Var;
    }

    public final void a() {
        this.b.clear();
        this.c = this.a;
        ((ij0) this.a).R();
    }

    @Override // defpackage.ad
    public final void c(int i, Object obj) {
        ((ij0) this.c).B(i, (ij0) obj);
    }

    @Override // defpackage.ad
    public final void d(Object obj) {
        this.b.add(this.c);
        this.c = obj;
    }

    @Override // defpackage.ad
    public final void e() {
        z61 rectManager;
        o4 o4Var;
        z61 rectManager2;
        ij0 ij0Var = (ij0) this.c;
        nu0 nu0Var = ij0Var.J;
        if (!ij0Var.H()) {
            sd0.a("onReuse is only expected on attached node");
        }
        ty1 ty1Var = ij0Var.s;
        if (ty1Var != null) {
            View view = ty1Var.e;
            if (view.getParent() != ty1Var) {
                ty1Var.addView(view);
            } else {
                ty1Var.i.a();
            }
        }
        wj0 wj0Var = ij0Var.L;
        if (wj0Var != null) {
            wj0Var.i(false);
        }
        ij0Var.x = false;
        if (ij0Var.U) {
            ij0Var.U = false;
        } else {
            er0 er0Var = ij0Var.J.e;
            for (er0 er0Var2 = er0Var; er0Var2 != null; er0Var2 = er0Var2.h) {
                if (er0Var2.q) {
                    er0Var2.H0();
                }
            }
            for (er0 er0Var3 = er0Var; er0Var3 != null; er0Var3 = er0Var3.h) {
                if (er0Var3.q) {
                    er0Var3.J0();
                }
            }
            while (er0Var != null) {
                if (er0Var.q) {
                    er0Var.D0();
                }
                er0Var = er0Var.h;
            }
        }
        int i = ij0Var.e;
        nz0 nz0Var = ij0Var.r;
        if (nz0Var != null && (rectManager2 = ((k5) nz0Var).getRectManager()) != null) {
            rectManager2.h(ij0Var);
        }
        ij0Var.e = md1.a.addAndGet(1);
        nz0 nz0Var2 = ij0Var.r;
        if (nz0Var2 != null) {
            k5 k5Var = (k5) nz0Var2;
            k5Var.m9getLayoutNodes().g(i);
            k5Var.m9getLayoutNodes().h(ij0Var.e, ij0Var);
        }
        for (er0 er0Var4 = nu0Var.f; er0Var4 != null; er0Var4 = er0Var4.i) {
            er0Var4.C0();
        }
        nu0Var.e();
        if (nu0Var.d(8)) {
            ij0Var.F();
        }
        ij0.Y(ij0Var);
        nz0 nz0Var3 = ij0Var.r;
        if (nz0Var3 != null) {
            k5 k5Var2 = (k5) nz0Var3;
            if (k5.i() && (o4Var = k5Var2.O) != null) {
                k5 k5Var3 = o4Var.f;
                l1 l1Var = o4Var.d;
                js0 js0Var = o4Var.k;
                if (js0Var.e(i)) {
                    l1Var.w(k5Var3, i, false);
                }
                ld1 ld1VarW = ij0Var.w();
                if (ld1VarW != null && ld1VarW.d.b(ud1.q)) {
                    js0Var.a(ij0Var.e);
                    l1Var.w(k5Var3, ij0Var.e, true);
                }
            }
        }
        nz0 nz0Var4 = ij0Var.r;
        if (nz0Var4 == null || (rectManager = ((k5) nz0Var4).getRectManager()) == null) {
            return;
        }
        rectManager.f(ij0Var, true);
    }

    @Override // defpackage.ad
    public final /* bridge */ /* synthetic */ void f(int i, Object obj) {
    }

    @Override // defpackage.ad
    public final void g() {
        nz0 nz0Var = ((ij0) this.a).r;
        if (nz0Var != null) {
            ((k5) nz0Var).y();
        }
    }

    @Override // defpackage.ad
    public final void h(int i, int i2, int i3) {
        ((ij0) this.c).L(i, i2, i3);
    }

    @Override // defpackage.ad
    public final Object i() {
        return this.c;
    }

    @Override // defpackage.ad
    public final void j(int i, int i2) {
        ((ij0) this.c).S(i, i2);
    }

    @Override // defpackage.ad
    public final void q() {
        this.c = this.b.remove(r0.size() - 1);
    }
}
