package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public interface rx1 extends sx1 {
    @Override // defpackage.px1
    default long b(fc fcVar, fc fcVar2, fc fcVar3) {
        return ((long) (n() + k())) * 1000000;
    }

    int k();

    int n();
}
