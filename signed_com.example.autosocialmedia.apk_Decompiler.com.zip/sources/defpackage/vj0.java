package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class vj0 {
    public final /* synthetic */ int a;
    public final /* synthetic */ wj0 b;
    public final /* synthetic */ Object c;

    public /* synthetic */ vj0(wj0 wj0Var, Object obj, int i) {
        this.a = i;
        this.b = wj0Var;
        this.c = obj;
    }

    public oj0 b() {
        wj0 wj0Var = this.b;
        ij0 ij0Var = (ij0) wj0Var.m.g(this.c);
        if (ij0Var != null) {
            return (oj0) wj0Var.i.g(ij0Var);
        }
        return null;
    }

    public final boolean c() {
        l11 l11Var;
        switch (this.a) {
            case 0:
                return true;
            default:
                oj0 oj0VarB = b();
                if (oj0VarB == null || (l11Var = oj0VarB.f) == null) {
                    return true;
                }
                return l11Var.c();
        }
    }

    private final void a() {
    }
}
