package defpackage;

import android.content.Context;
import android.widget.Toast;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class e3 implements w40 {
    public final /* synthetic */ int d;
    public final /* synthetic */ Object e;
    public final /* synthetic */ Object f;
    public final /* synthetic */ Object g;
    public final /* synthetic */ Object h;
    public final /* synthetic */ Object i;
    public final /* synthetic */ Object j;

    public /* synthetic */ e3(ds dsVar, gt0 gt0Var, gt0 gt0Var2, um0 um0Var, Context context, gt0 gt0Var3) {
        this.d = 1;
        this.e = dsVar;
        this.f = gt0Var;
        this.g = gt0Var2;
        this.i = um0Var;
        this.j = context;
        this.h = gt0Var3;
    }

    @Override // defpackage.w40
    public final Object a() {
        int i = this.d;
        boolean z = false;
        boolean z2 = true;
        bw1 bw1Var = bw1.a;
        Object obj = this.i;
        Object obj2 = this.j;
        Object obj3 = this.h;
        Object obj4 = this.g;
        Object obj5 = this.f;
        Object obj6 = this.e;
        switch (i) {
            case 0:
                m22.y((ds) obj6, null, new k3((lz) obj, (gt0) obj5, (gt0) obj4, (gt0) obj3, (gt0) obj2, null, 1), 3);
                break;
            case 1:
                gt0 gt0Var = (gt0) obj5;
                gt0 gt0Var2 = (gt0) obj4;
                gt0Var.setValue(Boolean.TRUE);
                gt0Var2.setValue(null);
                m22.y((ds) obj6, null, new v7((um0) obj, (Context) obj2, (gt0) obj3, gt0Var2, gt0Var, null, 3), 3);
                break;
            case 2:
                v91 v91Var = (v91) obj6;
                qa1 qa1Var = (qa1) obj;
                z91 z91Var = (z91) obj5;
                String str = (String) obj4;
                Object[] objArr = (Object[]) obj2;
                if (v91Var.e != z91Var) {
                    v91Var.e = z91Var;
                    z = true;
                }
                if (ng0.o(v91Var.f, str)) {
                    z2 = z;
                } else {
                    v91Var.f = str;
                }
                v91Var.d = qa1Var;
                v91Var.g = obj3;
                v91Var.h = objArr;
                y91 y91Var = v91Var.i;
                if (y91Var != null && z2) {
                    ((yc) y91Var).s();
                    v91Var.i = null;
                    v91Var.a();
                }
                break;
            case 3:
                gt0 gt0Var3 = (gt0) obj5;
                gt0 gt0Var4 = (gt0) obj4;
                gt0Var3.setValue(Boolean.TRUE);
                gt0Var4.setValue(null);
                m22.y((ds) obj6, null, new v7((Context) obj, (gt0) obj3, (gt0) obj2, gt0Var4, gt0Var3, null, 5), 3);
                break;
            default:
                Context context = (Context) obj6;
                gt0 gt0Var5 = (gt0) obj3;
                gt0 gt0Var6 = (gt0) obj2;
                gt0 gt0Var7 = (gt0) obj;
                ((gt0) obj5).setValue(Boolean.FALSE);
                bo0 bo0Var = new bo0(10);
                if (((Boolean) ((gt0) obj4).getValue()).booleanValue()) {
                    bo0Var.add(ht1.NORMAL);
                }
                if (((Boolean) gt0Var5.getValue()).booleanValue()) {
                    bo0Var.add(ht1.LITE);
                }
                if (((Boolean) gt0Var6.getValue()).booleanValue()) {
                    bo0Var.add(ht1.STUDIO);
                }
                bo0 bo0VarJ = jl.j(bo0Var);
                if (bo0VarJ.isEmpty()) {
                    Toast.makeText(context, "Hãy chọn ít nhất 1 loại TikTok.", 0).show();
                } else {
                    int iOrdinal = te.c(context).ordinal();
                    if (iOrdinal == 0) {
                        te.f(context, bo0VarJ);
                    } else if (iOrdinal != 1) {
                        tz.c();
                    } else {
                        gt0Var7.setValue(Boolean.TRUE);
                    }
                }
                break;
        }
        return bw1Var;
    }

    public /* synthetic */ e3(ds dsVar, gt0 gt0Var, gt0 gt0Var2, Context context, gt0 gt0Var3, gt0 gt0Var4) {
        this.d = 3;
        this.e = dsVar;
        this.f = gt0Var;
        this.g = gt0Var2;
        this.i = context;
        this.h = gt0Var3;
        this.j = gt0Var4;
    }

    public /* synthetic */ e3(Context context, gt0 gt0Var, gt0 gt0Var2, gt0 gt0Var3, gt0 gt0Var4, gt0 gt0Var5) {
        this.d = 4;
        this.e = context;
        this.f = gt0Var;
        this.g = gt0Var2;
        this.h = gt0Var3;
        this.j = gt0Var4;
        this.i = gt0Var5;
    }

    public /* synthetic */ e3(Object obj, Object obj2, Object obj3, Object obj4, Object obj5, Object obj6, int i) {
        this.d = i;
        this.e = obj;
        this.i = obj2;
        this.f = obj3;
        this.g = obj4;
        this.h = obj5;
        this.j = obj6;
    }
}
