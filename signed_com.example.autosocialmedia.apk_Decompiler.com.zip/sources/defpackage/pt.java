package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class pt {
    public et a;
    public final mv b;

    public pt(et etVar) {
        mv mvVar = zb1.c;
        this.a = etVar;
        this.b = mvVar;
    }
}
