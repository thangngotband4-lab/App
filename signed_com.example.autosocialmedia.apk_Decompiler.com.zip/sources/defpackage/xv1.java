package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class xv1 extends cb1 {
    public final ThreadLocal j;
    private volatile boolean threadLocalIsSet;

    /* JADX WARN: Illegal instructions before constructor call */
    public xv1(tq tqVar, ur urVar) {
        cj cjVar = cj.f;
        super(tqVar, urVar.k(cjVar) == null ? urVar.i(cjVar) : urVar);
        this.j = new ThreadLocal();
        if (tqVar.e().k(a4.w) instanceof wr) {
            return;
        }
        Object objN = ct.N(urVar, null);
        ct.J(urVar, objN);
        j0(urVar, objN);
    }

    public final boolean i0() {
        boolean z = this.threadLocalIsSet && this.j.get() == null;
        this.j.remove();
        return !z;
    }

    public final void j0(ur urVar, Object obj) {
        this.threadLocalIsSet = true;
        this.j.set(new a01(urVar, obj));
    }

    @Override // defpackage.cb1, defpackage.ih0
    public final void y(Object obj) {
        if (this.threadLocalIsSet) {
            a01 a01Var = (a01) this.j.get();
            if (a01Var != null) {
                ct.J((ur) a01Var.d, a01Var.e);
            }
            this.j.remove();
        }
        Object objU = hl.U(obj);
        tq tqVar = this.i;
        ur urVarE = tqVar.e();
        Object objN = ct.N(urVarE, null);
        xv1 xv1VarJ = objN != ct.W ? jl.J(tqVar, urVarE, objN) : null;
        try {
            this.i.h(objU);
            if (xv1VarJ == null || xv1VarJ.i0()) {
                ct.J(urVarE, objN);
            }
        } catch (Throwable th) {
            if (xv1VarJ == null || xv1VarJ.i0()) {
                ct.J(urVarE, objN);
            }
            throw th;
        }
    }
}
