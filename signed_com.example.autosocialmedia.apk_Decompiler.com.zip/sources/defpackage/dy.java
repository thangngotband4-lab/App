package defpackage;

import android.graphics.Paint;
import android.text.TextPaint;
import android.text.style.CharacterStyle;
import android.text.style.UpdateAppearance;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class dy extends CharacterStyle implements UpdateAppearance {
    public final cy d;

    public dy(cy cyVar) {
        this.d = cyVar;
    }

    @Override // android.text.style.CharacterStyle
    public final void updateDrawState(TextPaint textPaint) {
        if (textPaint != null) {
            e10 e10Var = e10.a;
            cy cyVar = this.d;
            if (ng0.o(cyVar, e10Var)) {
                textPaint.setStyle(Paint.Style.FILL);
                return;
            }
            if (!(cyVar instanceof lk1)) {
                tz.c();
                return;
            }
            textPaint.setStyle(Paint.Style.STROKE);
            lk1 lk1Var = (lk1) cyVar;
            textPaint.setStrokeWidth(lk1Var.a);
            textPaint.setStrokeMiter(lk1Var.b);
            int i = lk1Var.d;
            textPaint.setStrokeJoin(i == 0 ? Paint.Join.MITER : i == 1 ? Paint.Join.ROUND : i == 2 ? Paint.Join.BEVEL : Paint.Join.MITER);
            int i2 = lk1Var.c;
            textPaint.setStrokeCap(i2 == 0 ? Paint.Cap.BUTT : i2 == 1 ? Paint.Cap.ROUND : i2 == 2 ? Paint.Cap.SQUARE : Paint.Cap.BUTT);
            textPaint.setPathEffect(null);
        }
    }
}
