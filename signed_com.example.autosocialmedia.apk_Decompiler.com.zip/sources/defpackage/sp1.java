package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class sp1 {
    public final si1 a;
    public final si1 b;
    public final si1 c;
    public final si1 d;

    public sp1(si1 si1Var, si1 si1Var2, si1 si1Var3, si1 si1Var4) {
        this.a = si1Var;
        this.b = si1Var2;
        this.c = si1Var3;
        this.d = si1Var4;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || !(obj instanceof sp1)) {
            return false;
        }
        sp1 sp1Var = (sp1) obj;
        return ng0.o(this.a, sp1Var.a) && ng0.o(this.b, sp1Var.b) && ng0.o(this.c, sp1Var.c) && ng0.o(this.d, sp1Var.d);
    }

    public final int hashCode() {
        si1 si1Var = this.a;
        int iHashCode = (si1Var != null ? si1Var.hashCode() : 0) * 31;
        si1 si1Var2 = this.b;
        int iHashCode2 = (iHashCode + (si1Var2 != null ? si1Var2.hashCode() : 0)) * 31;
        si1 si1Var3 = this.c;
        int iHashCode3 = (iHashCode2 + (si1Var3 != null ? si1Var3.hashCode() : 0)) * 31;
        si1 si1Var4 = this.d;
        return iHashCode3 + (si1Var4 != null ? si1Var4.hashCode() : 0);
    }
}
