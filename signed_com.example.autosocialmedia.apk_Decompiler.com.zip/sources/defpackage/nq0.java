package defpackage;

import java.util.Map;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public interface nq0 extends gg0 {
    mq0 O(int i, int i2, Map map, h50 h50Var, h50 h50Var2);

    default mq0 i0(int i, int i2, Map map, h50 h50Var) {
        return O(i, i2, map, null, h50Var);
    }
}
