package defpackage;

import android.os.Parcel;
import android.os.Parcelable;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class l01 implements Parcelable.ClassLoaderCreator {
    public static m01 a(Parcel parcel, ClassLoader classLoader) {
        a4 a4Var;
        if (classLoader == null) {
            classLoader = l01.class.getClassLoader();
        }
        Object value = parcel.readValue(classLoader);
        int i = parcel.readInt();
        if (i == 0) {
            a4Var = a4.N;
        } else if (i == 1) {
            a4Var = a4.Z;
        } else {
            if (i != 2) {
                zi.f(f0.j(i, "Unsupported MutableState policy ", " was restored"));
                return null;
            }
            a4Var = a4.R;
        }
        return new m01(value, a4Var);
    }

    @Override // android.os.Parcelable.Creator
    public final Object createFromParcel(Parcel parcel) {
        return a(parcel, null);
    }

    @Override // android.os.Parcelable.Creator
    public final Object[] newArray(int i) {
        return new m01[i];
    }

    @Override // android.os.Parcelable.ClassLoaderCreator
    public final /* bridge */ /* synthetic */ Object createFromParcel(Parcel parcel, ClassLoader classLoader) {
        return a(parcel, classLoader);
    }
}
