package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class nf1 {
    public static final nf1 d = new nf1();
    public final long a;
    public final long b;
    public final float c;

    public /* synthetic */ nf1() {
        this(0.0f, tl.c(4278190080L), 0L);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof nf1)) {
            return false;
        }
        nf1 nf1Var = (nf1) obj;
        return ql.c(this.a, nf1Var.a) && jw0.b(this.b, nf1Var.b) && this.c == nf1Var.c;
    }

    public final int hashCode() {
        int i = ql.h;
        return Float.hashCode(this.c) + f0.c(Long.hashCode(this.a) * 31, 31, this.b);
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder("Shadow(color=");
        f0.u(this.a, sb, ", offset=");
        sb.append((Object) jw0.g(this.b));
        sb.append(", blurRadius=");
        return f0.o(sb, this.c, ')');
    }

    public nf1(float f, long j, long j2) {
        this.a = j;
        this.b = j2;
        this.c = f;
    }
}
