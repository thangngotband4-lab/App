package defpackage;

import java.util.ArrayList;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class h61 {
    public final ArrayList a = new ArrayList();

    public h61(Object obj) {
    }

    public final boolean a(int i, ka0 ka0Var, Object obj) {
        ArrayList arrayList = ka0Var.a;
        if (arrayList == null) {
            b(i, ka0Var, null);
            return true;
        }
        int size = arrayList.size();
        int i2 = 0;
        while (true) {
            if (i2 >= size) {
                break;
            }
            Object obj2 = arrayList.get(i2);
            if (!(obj2 instanceof i4)) {
                if (!(obj2 instanceof ka0)) {
                    tz.k(obj2, "Unexpected child source info ");
                    break;
                }
                if (a(i, (ka0) obj2, obj)) {
                    b(0, ka0Var, obj2);
                    return true;
                }
            } else if (obj2 == obj) {
                b(0, ka0Var, obj2);
                return true;
            }
            i2++;
        }
        return false;
    }

    public final void b(int i, ka0 ka0Var, Object obj) {
        this.a.add(new mo(i, null, null));
    }

    public final void c(int i, Object obj, ka0 ka0Var, Object obj2) {
        if (ng0.o(obj, ro.a)) {
            b(i, ka0Var, null);
        }
    }
}
