package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class o6 implements h50 {
    public final /* synthetic */ int d = 0;
    public final /* synthetic */ float e;
    public final /* synthetic */ Object f;
    public final /* synthetic */ Object g;

    public /* synthetic */ o6(float f, o7 o7Var, dg dgVar) {
        this.e = f;
        this.f = o7Var;
        this.g = dgVar;
    }

    @Override // defpackage.h50
    public final Object g(Object obj) {
        long jRound;
        int i = this.d;
        bw1 bw1Var = bw1.a;
        Object obj2 = this.g;
        float f = this.e;
        Object obj3 = this.f;
        switch (i) {
            case 0:
                o7 o7Var = (o7) obj3;
                dg dgVar = (dg) obj2;
                kj0 kj0Var = (kj0) obj;
                kj0Var.a();
                fj fjVar = kj0Var.d;
                yc ycVar = fjVar.e;
                long jI = ycVar.i();
                ycVar.f().l();
                try {
                    l1 l1Var = (l1) ycVar.a;
                    l1Var.G(f, 0.0f);
                    l1Var.C(45.0f, 0L);
                    fjVar.e(o7Var, dgVar);
                    return bw1Var;
                } finally {
                    f0.v(ycVar, jI);
                }
            case 1:
                k21 k21Var = (k21) obj3;
                j21 j21Var = (j21) obj;
                va vaVar = ((dr1) obj2).v;
                j21.j(j21Var, k21Var, vaVar != null ? (int) ((Number) vaVar.d()).floatValue() : (int) f, 0);
                return bw1Var;
            default:
                kw1 kw1Var = (kw1) obj3;
                h50 h50Var = (h50) obj2;
                long jLongValue = ((Long) obj).longValue();
                if (kw1Var.b == Long.MIN_VALUE) {
                    kw1Var.b = jLongValue;
                }
                float f2 = kw1Var.e;
                bc bcVar = new bc(f2);
                bc bcVar2 = kw1.f;
                if (f == 0.0f) {
                    jRound = kw1Var.a.b(new bc(f2), bcVar2, kw1Var.c);
                } else {
                    double d = (jLongValue - kw1Var.b) / f;
                    if (Double.isNaN(d)) {
                        tz.l("Cannot round NaN value.");
                        return null;
                    }
                    jRound = Math.round(d);
                }
                long j = jRound;
                float f3 = ((bc) kw1Var.a.o(j, bcVar, bcVar2, kw1Var.c)).a;
                kw1Var.c = (bc) kw1Var.a.l(j, bcVar, bcVar2, kw1Var.c);
                kw1Var.b = jLongValue;
                float f4 = kw1Var.e - f3;
                kw1Var.e = f3;
                h50Var.g(Float.valueOf(f4));
                return bw1Var;
        }
    }

    public /* synthetic */ o6(k21 k21Var, dr1 dr1Var, float f) {
        this.f = k21Var;
        this.g = dr1Var;
        this.e = f;
    }

    public /* synthetic */ o6(kw1 kw1Var, float f, h50 h50Var) {
        this.f = kw1Var;
        this.e = f;
        this.g = h50Var;
    }
}
