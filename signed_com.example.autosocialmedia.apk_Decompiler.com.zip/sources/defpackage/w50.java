package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public class w50 extends pi implements v50, kh0, t50 {
    public final int j;
    public final int k;

    public w50(int i, Object obj, Class cls, String str, String str2, int i2, int i3) {
        super(obj, cls, str, str2, (i2 & 1) == 1);
        this.j = i;
        this.k = 0;
    }

    @Override // defpackage.v50
    public final int b() {
        return this.j;
    }

    @Override // defpackage.pi
    public final kh0 d() {
        f71.a.getClass();
        return this;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r2v13 */
    /* JADX WARN: Type inference failed for: r2v3 */
    /* JADX WARN: Type inference failed for: r2v4, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r3v0, types: [java.lang.Object] */
    public final boolean equals(Object obj) {
        ?? r2;
        if (obj == this) {
            return true;
        }
        if (obj instanceof w50) {
            w50 w50Var = (w50) obj;
            return this.g.equals(w50Var.g) && this.h.equals(w50Var.h) && this.k == w50Var.k && this.j == w50Var.j && ng0.o(this.e, w50Var.e) && e().equals(w50Var.e());
        }
        if (!(obj instanceof w50)) {
            return false;
        }
        kh0 kh0Var = this.d;
        if (kh0Var == null) {
            d();
            this.d = this;
            this = this;
        } else {
            r2 = kh0Var;
        }
        return obj.equals(r2);
    }

    public final int hashCode() {
        e();
        return this.h.hashCode() + f0.e(e().hashCode() * 31, 31, this.g);
    }

    public final String toString() {
        kh0 kh0Var = this.d;
        if (kh0Var == null) {
            d();
            this.d = this;
            kh0Var = this;
        }
        if (kh0Var != this) {
            return kh0Var.toString();
        }
        String str = this.g;
        return "<init>".equals(str) ? "constructor (Kotlin reflection is not available)" : f0.n("function ", str, " (Kotlin reflection is not available)");
    }

    public w50(int i, Class cls, String str, String str2, int i2) {
        this(i, oi.d, cls, str, str2, i2, 0);
    }
}
