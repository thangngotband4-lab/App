package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class k extends jl1 implements l50 {
    public final /* synthetic */ int e;
    public final /* synthetic */ xk f;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ k(xk xkVar, tq tqVar, int i) {
        super(2, tqVar);
        this.e = i;
        this.f = xkVar;
    }

    @Override // defpackage.l50
    public final Object f(Object obj, Object obj2) {
        int i = this.e;
        bw1 bw1Var = bw1.a;
        ds dsVar = (ds) obj;
        tq tqVar = (tq) obj2;
        switch (i) {
            case 0:
                ((k) o(tqVar, dsVar)).r(bw1Var);
                break;
            default:
                ((k) o(tqVar, dsVar)).r(bw1Var);
                break;
        }
        return bw1Var;
    }

    @Override // defpackage.kf
    public final tq o(tq tqVar, Object obj) {
        int i = this.e;
        xk xkVar = this.f;
        switch (i) {
            case 0:
                return new k(xkVar, tqVar, 0);
            default:
                return new k(xkVar, tqVar, 1);
        }
    }

    @Override // defpackage.kf
    public final Object r(Object obj) {
        int i = this.e;
        bw1 bw1Var = bw1.a;
        tq tqVar = null;
        xk xkVar = this.f;
        switch (i) {
            case 0:
                vl.Q(obj);
                if (xkVar.E == null) {
                    ob0 ob0Var = new ob0();
                    ks0 ks0Var = xkVar.t;
                    if (ks0Var != null) {
                        m22.y(xkVar.A0(), null, new d(ks0Var, ob0Var, tqVar, 0), 3);
                    }
                    xkVar.E = ob0Var;
                }
                break;
            default:
                vl.Q(obj);
                ob0 ob0Var2 = xkVar.E;
                if (ob0Var2 != null) {
                    pb0 pb0Var = new pb0(ob0Var2);
                    ks0 ks0Var2 = xkVar.t;
                    if (ks0Var2 != null) {
                        m22.y(xkVar.A0(), null, new d(ks0Var2, pb0Var, tqVar, 1), 3);
                    }
                    xkVar.E = null;
                }
                break;
        }
        return bw1Var;
    }
}
