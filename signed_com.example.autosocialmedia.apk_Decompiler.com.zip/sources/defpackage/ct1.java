package defpackage;

import com.example.autosocialmedia.service.AutoAccessibilityService;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class ct1 extends uq {
    public AutoAccessibilityService d;
    public h50 e;
    public /* synthetic */ Object f;
    public final /* synthetic */ ft1 g;
    public int h;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public ct1(ft1 ft1Var, uq uqVar) {
        super(uqVar);
        this.g = ft1Var;
    }

    @Override // defpackage.kf
    public final Object r(Object obj) {
        this.f = obj;
        this.h |= Integer.MIN_VALUE;
        return this.g.d(null, null, this);
    }
}
