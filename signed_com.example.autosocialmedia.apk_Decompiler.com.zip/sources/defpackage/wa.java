package defpackage;

import android.view.View;
import java.util.Set;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class wa extends jl1 implements l50 {
    public final /* synthetic */ int e;
    public int f;
    public final /* synthetic */ Object g;
    public final /* synthetic */ Object h;
    public Object i;
    public Object j;
    public Object k;
    public /* synthetic */ Object l;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public wa(String str, s90 s90Var, Set set, gt0 gt0Var, gt0 gt0Var2, gt0 gt0Var3, tq tqVar) {
        super(2, tqVar);
        this.e = 1;
        this.i = str;
        this.j = s90Var;
        this.k = set;
        this.g = gt0Var;
        this.h = gt0Var2;
        this.l = gt0Var3;
    }

    @Override // defpackage.l50
    public final Object f(Object obj, Object obj2) {
        int i = this.e;
        bw1 bw1Var = bw1.a;
        ds dsVar = (ds) obj;
        tq tqVar = (tq) obj2;
        switch (i) {
        }
        return ((wa) o(tqVar, dsVar)).r(bw1Var);
    }

    @Override // defpackage.kf
    public final tq o(tq tqVar, Object obj) {
        int i = this.e;
        Object obj2 = this.h;
        Object obj3 = this.g;
        switch (i) {
            case 0:
                wa waVar = new wa((oj) this.k, (va) this.l, (gt0) obj3, (gt0) obj2, tqVar);
                waVar.j = obj;
                return waVar;
            case 1:
                return new wa((String) this.i, (s90) this.j, (Set) this.k, (gt0) obj3, (gt0) obj2, (gt0) this.l, tqVar);
            case 2:
                wa waVar2 = new wa((pt0) obj3, (h50) obj2, tqVar, 2);
                waVar2.l = obj;
                return waVar2;
            case 3:
                wa waVar3 = new wa((qt0) obj3, (h50) obj2, tqVar, 3);
                waVar3.l = obj;
                return waVar3;
            default:
                wa waVar4 = new wa((e71) this.i, (r61) this.k, (en0) this.l, (a12) obj3, (View) obj2, tqVar);
                waVar4.j = obj;
                return waVar4;
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:135:0x02d9  */
    /* JADX WARN: Removed duplicated region for block: B:138:0x02e3  */
    /* JADX WARN: Removed duplicated region for block: B:175:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r2v0, types: [st0] */
    /* JADX WARN: Type inference failed for: r2v31, types: [int] */
    /* JADX WARN: Type inference failed for: r2v32 */
    /* JADX WARN: Type inference failed for: r2v33, types: [bh0] */
    /* JADX WARN: Type inference failed for: r2v36 */
    /* JADX WARN: Type inference failed for: r2v37 */
    /* JADX WARN: Type inference failed for: r2v38, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r2v40, types: [bh0] */
    /* JADX WARN: Type inference failed for: r2v42, types: [bh0] */
    /* JADX WARN: Type inference failed for: r2v43 */
    /* JADX WARN: Type inference failed for: r2v44 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:134:0x02d7 -> B:136:0x02db). Please report as a decompilation issue!!! */
    @Override // defpackage.kf
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final java.lang.Object r(java.lang.Object r21) throws java.lang.Throwable {
        /*
            Method dump skipped, instruction units count: 796
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.wa.r(java.lang.Object):java.lang.Object");
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public wa(e71 e71Var, r61 r61Var, en0 en0Var, a12 a12Var, View view, tq tqVar) {
        super(2, tqVar);
        this.e = 4;
        this.i = e71Var;
        this.k = r61Var;
        this.l = en0Var;
        this.g = a12Var;
        this.h = view;
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ wa(Object obj, h50 h50Var, tq tqVar, int i) {
        super(2, tqVar);
        this.e = i;
        this.g = obj;
        this.h = h50Var;
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public wa(oj ojVar, va vaVar, gt0 gt0Var, gt0 gt0Var2, tq tqVar) {
        super(2, tqVar);
        this.e = 0;
        this.k = ojVar;
        this.l = vaVar;
        this.g = gt0Var;
        this.h = gt0Var2;
    }
}
