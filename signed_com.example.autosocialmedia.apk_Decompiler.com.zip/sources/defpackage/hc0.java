package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class hc0 {
    public static int k;
    public static final dp1 l = new dp1(27);
    public final String a;
    public final float b;
    public final float c;
    public final float d;
    public final float e;
    public final kx1 f;
    public final long g;
    public final int h;
    public final boolean i;
    public final int j;

    public hc0(String str, float f, float f2, float f3, float f4, kx1 kx1Var, long j, int i, boolean z) {
        int i2;
        synchronized (l) {
            i2 = k;
            k = i2 + 1;
        }
        this.a = str;
        this.b = f;
        this.c = f2;
        this.d = f3;
        this.e = f4;
        this.f = kx1Var;
        this.g = j;
        this.h = i;
        this.i = z;
        this.j = i2;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof hc0)) {
            return false;
        }
        hc0 hc0Var = (hc0) obj;
        return ng0.o(this.a, hc0Var.a) && hw.b(this.b, hc0Var.b) && hw.b(this.c, hc0Var.c) && this.d == hc0Var.d && this.e == hc0Var.e && this.f.equals(hc0Var.f) && ql.c(this.g, hc0Var.g) && this.h == hc0Var.h && this.i == hc0Var.i;
    }

    public final int hashCode() {
        int iHashCode = (this.f.hashCode() + f0.a(this.e, f0.a(this.d, f0.a(this.c, f0.a(this.b, this.a.hashCode() * 31, 31), 31), 31), 31)) * 31;
        int i = ql.h;
        return Boolean.hashCode(this.i) + f0.b(this.h, f0.c(iHashCode, 31, this.g), 31);
    }
}
