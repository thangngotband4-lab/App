package defpackage;

import android.content.Context;
import java.util.LinkedHashMap;
import org.json.JSONException;
import org.json.JSONObject;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class s90 {
    public static final int $stable = 8;
    private static final String CONTEXT = "asm:golike-session:v1";
    public static final r90 Companion = new r90();
    private static volatile s90 INSTANCE = null;
    private static final String KEY = "session_v1";
    private static final String K_AUTH = "auth";
    private static final String K_COIN = "coin";
    private static final String K_ID = "id";
    private static final String K_NAME = "name";
    private static final String K_USERNAME = "username";
    private static final String PREFS_NAME = "asm_golike_enc";
    private final ht0 _session;
    private final lj1 session;
    private final qc1 store;

    public s90(Context context) {
        Object d81Var;
        LinkedHashMap linkedHashMap = qc1.c;
        qc1 qc1VarQ = vl.q(context, PREFS_NAME);
        this.store = qc1VarQ;
        String strA = qc1VarQ.a(KEY, CONTEXT);
        if (strA != null) {
            try {
                JSONObject jSONObject = new JSONObject(strA);
                String string = jSONObject.getString(K_AUTH);
                string.getClass();
                long jOptLong = jSONObject.optLong(K_ID);
                String strOptString = jSONObject.optString(K_NAME);
                strOptString.getClass();
                String strOptString2 = jSONObject.optString(K_USERNAME);
                strOptString2.getClass();
                String strOptString3 = jSONObject.optString(K_COIN, "0");
                strOptString3.getClass();
                d81Var = new q90(string, strOptString, strOptString2, strOptString3, jOptLong);
            } catch (Throwable th) {
                d81Var = new d81(th);
            }
            obj = (q90) (d81Var instanceof d81 ? null : d81Var);
        }
        nj1 nj1VarF = eq0.f(obj);
        this._session = nj1VarF;
        this.session = nj1VarF;
    }

    public final void c() {
        this.store.c(KEY);
        ((nj1) this._session).h(null);
    }

    public final lj1 d() {
        return this.session;
    }

    public final void e(q90 q90Var) throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put(K_AUTH, q90Var.b());
        jSONObject.put(K_ID, q90Var.e());
        jSONObject.put(K_NAME, q90Var.d());
        jSONObject.put(K_USERNAME, q90Var.f());
        jSONObject.put(K_COIN, q90Var.c());
        qc1 qc1Var = this.store;
        String string = jSONObject.toString();
        string.getClass();
        qc1Var.b(KEY, CONTEXT, string);
        nj1 nj1Var = (nj1) this._session;
        nj1Var.getClass();
        nj1Var.i(null, q90Var);
    }
}
