package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class no1 extends jl1 implements l50 {
    public int e;
    public final /* synthetic */ so1 f;
    public final /* synthetic */ boolean g;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public no1(so1 so1Var, boolean z, tq tqVar) {
        super(2, tqVar);
        this.f = so1Var;
        this.g = z;
    }

    @Override // defpackage.l50
    public final Object f(Object obj, Object obj2) {
        return ((no1) o((tq) obj2, (ds) obj)).r(bw1.a);
    }

    @Override // defpackage.kf
    public final tq o(tq tqVar, Object obj) {
        return new no1(this.f, this.g, tqVar);
    }

    @Override // defpackage.kf
    public final Object r(Object obj) {
        al alVar;
        int i = this.e;
        kc kcVarH = null;
        bw1 bw1Var = bw1.a;
        if (i != 0) {
            if (i == 1) {
                vl.Q(obj);
                return bw1Var;
            }
            zi.f("call to 'resume' before 'invoke' with coroutine");
            return null;
        }
        vl.Q(obj);
        so1 so1Var = this.f;
        if (!wp1.c(so1Var.n().b)) {
            kcVarH = ui1.h(so1Var.n());
            if (this.g) {
                int iE = wp1.e(so1Var.n().b);
                so1Var.c.g(so1.e(so1Var.n().a, jj1.b(iE, iE)));
                so1Var.q(na0.d);
            }
        }
        if (kcVarH != null && (alVar = so1Var.g) != null) {
            zk zkVarO = vh0.O(kcVarH);
            this.e = 1;
            ((r4) alVar).a(zkVarO);
            es esVar = es.d;
            if (bw1Var == esVar) {
                return esVar;
            }
        }
        return bw1Var;
    }
}
