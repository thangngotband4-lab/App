package defpackage;

import android.graphics.Canvas;
import android.text.TextUtils;
import java.util.List;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class b8 {
    public final f8 a;
    public final int b;
    public final long c;
    public final np1 d;
    public final CharSequence e;
    public final List f;

    /* JADX WARN: Removed duplicated region for block: B:104:0x0143  */
    /* JADX WARN: Removed duplicated region for block: B:106:0x014e  */
    /* JADX WARN: Removed duplicated region for block: B:118:0x019a  */
    /* JADX WARN: Removed duplicated region for block: B:138:0x01d1  */
    /* JADX WARN: Removed duplicated region for block: B:141:0x020d  */
    /* JADX WARN: Removed duplicated region for block: B:142:0x0210  */
    /* JADX WARN: Removed duplicated region for block: B:146:0x0244  */
    /* JADX WARN: Removed duplicated region for block: B:151:0x0273  */
    /* JADX WARN: Removed duplicated region for block: B:152:0x0277  */
    /* JADX WARN: Removed duplicated region for block: B:72:0x00e6  */
    /* JADX WARN: Removed duplicated region for block: B:84:0x0101  */
    /* JADX WARN: Removed duplicated region for block: B:93:0x011a  */
    /* JADX WARN: Removed duplicated region for block: B:95:0x0123  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public b8(defpackage.f8 r22, int r23, int r24, long r25) {
        /*
            Method dump skipped, instruction units count: 840
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.b8.<init>(f8, int, int, long):void");
    }

    public final np1 a(int i, int i2, TextUtils.TruncateAt truncateAt, int i3, int i4, int i5, int i6, int i7, CharSequence charSequence) {
        w21 w21Var;
        float fD = d();
        f8 f8Var = this.a;
        t9 t9Var = f8Var.g;
        int i8 = f8Var.l;
        wi0 wi0Var = f8Var.i;
        dq1 dq1Var = f8Var.b;
        c8 c8Var = d8.a;
        k31 k31Var = dq1Var.c;
        return new np1(charSequence, fD, t9Var, i, truncateAt, i8, (k31Var == null || (w21Var = k31Var.b) == null) ? false : w21Var.a, i3, i5, i6, i7, i4, i2, wi0Var);
    }

    public final float b() {
        return this.d.a();
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:44:0x00d5  */
    /* JADX WARN: Type inference failed for: r12v17, types: [r7] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final long c(defpackage.x61 r11, int r12, defpackage.tz r13) {
        /*
            Method dump skipped, instruction units count: 243
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.b8.c(x61, int, tz):long");
    }

    public final float d() {
        return xp.h(this.c);
    }

    public final void e(dj djVar) {
        Canvas canvasA = q4.a(djVar);
        np1 np1Var = this.d;
        if (np1Var.d) {
            canvasA.save();
            canvasA.clipRect(0.0f, 0.0f, d(), b());
        }
        int i = np1Var.h;
        if (canvasA.getClipBounds(np1Var.p)) {
            if (i != 0) {
                canvasA.translate(0.0f, i);
            }
            ThreadLocal threadLocal = rp1.a;
            Object rm1Var = threadLocal.get();
            if (rm1Var == null) {
                rm1Var = new rm1();
                threadLocal.set(rm1Var);
            }
            rm1 rm1Var2 = (rm1) rm1Var;
            rm1Var2.a = canvasA;
            try {
                np1Var.f.draw(rm1Var2);
                if (i != 0) {
                    canvasA.translate(0.0f, (-1.0f) * i);
                }
            } finally {
                rm1Var2.a = null;
            }
        }
        if (np1Var.d) {
            canvasA.restore();
        }
    }

    public final void f(dj djVar, long j, nf1 nf1Var, mn1 mn1Var, cy cyVar) {
        t9 t9Var = this.a.g;
        int i = t9Var.c;
        t9Var.d(j);
        t9Var.f(nf1Var);
        t9Var.g(mn1Var);
        t9Var.e(cyVar);
        t9Var.b(3);
        e(djVar);
        t9Var.b(i);
    }

    public final void g(dj djVar, oh ohVar, float f, nf1 nf1Var, mn1 mn1Var, cy cyVar) {
        t9 t9Var = this.a.g;
        int i = t9Var.c;
        float fD = d();
        t9Var.c(ohVar, (((long) Float.floatToRawIntBits(b())) & 4294967295L) | (Float.floatToRawIntBits(fD) << 32), f);
        t9Var.f(nf1Var);
        t9Var.g(mn1Var);
        t9Var.e(cyVar);
        t9Var.b(3);
        e(djVar);
        t9Var.b(i);
    }
}
