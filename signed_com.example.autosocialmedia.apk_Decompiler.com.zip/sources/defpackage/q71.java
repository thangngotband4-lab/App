package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class q71 {
    public final ko0 a;

    public q71(ko0 ko0Var) {
        this.a = ko0Var;
    }

    public final String toString() {
        return "Removed[" + this.a + ']';
    }
}
