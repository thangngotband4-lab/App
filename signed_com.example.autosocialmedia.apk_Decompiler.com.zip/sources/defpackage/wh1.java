package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class wh1 implements h50 {
    public final /* synthetic */ int d;
    public final /* synthetic */ h50 e;
    public final /* synthetic */ h50 f;

    public /* synthetic */ wh1(h50 h50Var, h50 h50Var2, int i) {
        this.d = i;
        this.e = h50Var;
        this.f = h50Var2;
    }

    @Override // defpackage.h50
    public final Object g(Object obj) {
        int i = this.d;
        bw1 bw1Var = bw1.a;
        h50 h50Var = this.f;
        h50 h50Var2 = this.e;
        switch (i) {
            case 0:
                h50Var2.g(obj);
                h50Var.g(obj);
                break;
            default:
                h50Var2.g(obj);
                h50Var.g(obj);
                break;
        }
        return bw1Var;
    }
}
