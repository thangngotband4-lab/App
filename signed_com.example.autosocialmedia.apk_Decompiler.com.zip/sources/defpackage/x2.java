package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class x2 implements w40 {
    public final /* synthetic */ int d;
    public final /* synthetic */ Object e;
    public final /* synthetic */ Object f;
    public final /* synthetic */ Object g;

    public /* synthetic */ x2(xo xoVar, lj ljVar, ih1 ih1Var, bs0 bs0Var) {
        this.d = 3;
        this.e = xoVar;
        this.f = ljVar;
        this.g = ih1Var;
    }

    /* JADX WARN: Code restructure failed: missing block: B:88:0x0229, code lost:
    
        if (r10.w == false) goto L94;
     */
    /* JADX WARN: Code restructure failed: missing block: B:89:0x022b, code lost:
    
        r11 = (defpackage.x61) r10.u.a();
     */
    /* JADX WARN: Code restructure failed: missing block: B:90:0x0234, code lost:
    
        if (r11 == null) goto L94;
     */
    /* JADX WARN: Code restructure failed: missing block: B:92:0x0242, code lost:
    
        if (defpackage.hq.N0(r10, r11, 0, 0, 3) != true) goto L94;
     */
    /* JADX WARN: Code restructure failed: missing block: B:93:0x0244, code lost:
    
        r10.w = false;
     */
    /* JADX WARN: Code restructure failed: missing block: B:94:0x0246, code lost:
    
        r9.e = defpackage.hq.M0(r10, r8, 0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:95:0x024c, code lost:
    
        return r6;
     */
    /* JADX WARN: Removed duplicated region for block: B:69:0x01bb A[LOOP:3: B:61:0x0190->B:69:0x01bb, LOOP_END] */
    @Override // defpackage.w40
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final java.lang.Object a() {
        /*
            Method dump skipped, instruction units count: 770
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.x2.a():java.lang.Object");
    }

    public /* synthetic */ x2(Object obj, Object obj2, Object obj3, int i) {
        this.d = i;
        this.e = obj;
        this.f = obj2;
        this.g = obj3;
    }
}
