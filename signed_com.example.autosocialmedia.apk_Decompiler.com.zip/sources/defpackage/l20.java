package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class l20 extends uq {
    public jl1 d;
    public e71 e;
    public cw f;
    public /* synthetic */ Object g;
    public int h;

    @Override // defpackage.kf
    public final Object r(Object obj) {
        this.g = obj;
        this.h |= Integer.MIN_VALUE;
        return bm.A(null, null, this);
    }
}
