package defpackage;

import android.graphics.Shader;
import android.text.TextPaint;
import android.text.style.CharacterStyle;
import android.text.style.UpdateAppearance;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class mf1 extends CharacterStyle implements UpdateAppearance {
    public final lf1 d;
    public final float e;
    public final m01 f = hl.I(new gg1(9205357640488583168L));
    public final bv g = hl.s(new y8(19, this));

    public mf1(lf1 lf1Var, float f) {
        this.d = lf1Var;
        this.e = f;
    }

    @Override // android.text.style.CharacterStyle
    public final void updateDrawState(TextPaint textPaint) {
        zu1.t(textPaint, this.e);
        textPaint.setShader((Shader) this.g.getValue());
    }
}
