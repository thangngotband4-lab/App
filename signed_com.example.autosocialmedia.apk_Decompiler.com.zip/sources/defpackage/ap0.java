package defpackage;

import java.util.Arrays;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class ap0 implements wu {
    public boolean d;
    public long e = 9223372034707292159L;
    public long f = 0;
    public final /* synthetic */ dp0 g;

    public ap0(dp0 dp0Var) {
        this.g = dp0Var;
    }

    public final void a(kb0 kb0Var, float f) {
        dp0 dp0Var = this.g;
        m91 m91Var = dp0Var.p;
        if (m91Var == null) {
            m91Var = new m91();
            dp0Var.p = m91Var;
        }
        int iQ = sd.Q(m91Var.b, kb0Var);
        if (iQ >= 0) {
            float[] fArr = m91Var.c;
            if (fArr[iQ] != f) {
                fArr[iQ] = f;
                m91Var.d[iQ] = 1;
                return;
            } else {
                byte[] bArr = m91Var.d;
                if (bArr[iQ] == 2) {
                    bArr[iQ] = 0;
                    return;
                }
                return;
            }
        }
        int i = m91Var.a;
        kb0[] kb0VarArr = m91Var.b;
        if (i == kb0VarArr.length) {
            int i2 = i * 2;
            m91Var.b = (kb0[]) Arrays.copyOf(kb0VarArr, i2);
            m91Var.c = Arrays.copyOf(m91Var.c, i2);
            m91Var.d = Arrays.copyOf(m91Var.d, i2);
        }
        m91Var.b[i] = kb0Var;
        m91Var.d[i] = 3;
        m91Var.c[i] = f;
        m91Var.a++;
    }

    @Override // defpackage.wu
    public final float b() {
        return this.g.b();
    }

    @Override // defpackage.wu
    public final float k() {
        return this.g.k();
    }
}
