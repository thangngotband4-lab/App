package defpackage;

import java.util.List;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public abstract class fx {
    public static final float a = 0.125f / 18.0f;

    /* JADX WARN: Code restructure failed: missing block: B:46:0x00b7, code lost:
    
        if (defpackage.jw0.b(defpackage.bm.P(r6, true), 0) == false) goto L47;
     */
    /* JADX WARN: Removed duplicated region for block: B:20:0x0059 A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:21:0x005a  */
    /* JADX WARN: Removed duplicated region for block: B:24:0x0069  */
    /* JADX WARN: Removed duplicated region for block: B:31:0x0083  */
    /* JADX WARN: Removed duplicated region for block: B:32:0x0085  */
    /* JADX WARN: Removed duplicated region for block: B:53:0x007e A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0013  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:21:0x005a -> B:22:0x005d). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static final java.lang.Object a(defpackage.ol1 r12, long r13, defpackage.uq r15) {
        /*
            boolean r0 = r15 instanceof defpackage.zw
            if (r0 == 0) goto L13
            r0 = r15
            zw r0 = (defpackage.zw) r0
            int r1 = r0.g
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L13
            int r1 = r1 - r2
            r0.g = r1
            goto L18
        L13:
            zw r0 = new zw
            r0.<init>(r15)
        L18:
            java.lang.Object r15 = r0.f
            int r1 = r0.g
            r2 = 1
            r3 = 0
            if (r1 == 0) goto L33
            if (r1 != r2) goto L2d
            d71 r12 = r0.e
            ol1 r13 = r0.d
            defpackage.vl.Q(r15)
            r11 = r13
            r13 = r12
            r12 = r11
            goto L5d
        L2d:
            java.lang.String r12 = "call to 'resume' before 'invoke' with coroutine"
            defpackage.zi.f(r12)
            return r3
        L33:
            defpackage.vl.Q(r15)
            pl1 r15 = r12.i
            m31 r15 = r15.v
            boolean r15 = e(r15, r13)
            if (r15 == 0) goto L42
            goto Lc2
        L42:
            d71 r15 = new d71
            r15.<init>()
            r15.d = r13
        L49:
            r0.d = r12
            r0.e = r15
            r0.g = r2
            n31 r13 = defpackage.n31.e
            java.lang.Object r13 = r12.a(r13, r0)
            es r14 = defpackage.es.d
            if (r13 != r14) goto L5a
            return r14
        L5a:
            r11 = r15
            r15 = r13
            r13 = r11
        L5d:
            m31 r15 = (defpackage.m31) r15
            java.util.List r14 = r15.a
            int r1 = r14.size()
            r4 = 0
            r5 = r4
        L67:
            if (r5 >= r1) goto L7e
            java.lang.Object r6 = r14.get(r5)
            r7 = r6
            t31 r7 = (defpackage.t31) r7
            long r7 = r7.a
            long r9 = r13.d
            boolean r7 = defpackage.om.u(r7, r9)
            if (r7 == 0) goto L7b
            goto L7f
        L7b:
            int r5 = r5 + 1
            goto L67
        L7e:
            r6 = r3
        L7f:
            t31 r6 = (defpackage.t31) r6
            if (r6 != 0) goto L85
            r6 = r3
            goto Lb9
        L85:
            boolean r14 = defpackage.bm.p(r6)
            if (r14 == 0) goto Lad
            java.util.List r14 = r15.a
            int r15 = r14.size()
        L91:
            if (r4 >= r15) goto La2
            java.lang.Object r1 = r14.get(r4)
            r5 = r1
            t31 r5 = (defpackage.t31) r5
            boolean r5 = r5.d
            if (r5 == 0) goto L9f
            goto La3
        L9f:
            int r4 = r4 + 1
            goto L91
        La2:
            r1 = r3
        La3:
            t31 r1 = (defpackage.t31) r1
            if (r1 != 0) goto La8
            goto Lb9
        La8:
            long r14 = r1.a
            r13.d = r14
            goto Lc3
        Lad:
            long r14 = defpackage.bm.P(r6, r2)
            r4 = 0
            boolean r14 = defpackage.jw0.b(r14, r4)
            if (r14 != 0) goto Lc3
        Lb9:
            if (r6 == 0) goto Lc2
            boolean r12 = r6.b()
            if (r12 != 0) goto Lc2
            return r6
        Lc2:
            return r3
        Lc3:
            r15 = r13
            goto L49
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.fx.a(ol1, long, uq):java.lang.Object");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0013  */
    /* JADX WARN: Type inference failed for: r9v3, types: [e71] */
    /* JADX WARN: Type inference failed for: r9v5 */
    /* JADX WARN: Type inference failed for: r9v6 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static final java.lang.Object b(defpackage.ol1 r8, long r9, defpackage.uq r11) {
        /*
            boolean r0 = r11 instanceof defpackage.ax
            if (r0 == 0) goto L13
            r0 = r11
            ax r0 = (defpackage.ax) r0
            int r1 = r0.h
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L13
            int r1 = r1 - r2
            r0.h = r1
            goto L18
        L13:
            ax r0 = new ax
            r0.<init>(r11)
        L18:
            java.lang.Object r11 = r0.g
            int r1 = r0.h
            r2 = 1
            r3 = 0
            if (r1 == 0) goto L32
            if (r1 != r2) goto L2c
            a71 r8 = r0.f
            e71 r9 = r0.e
            t31 r10 = r0.d
            defpackage.vl.Q(r11)     // Catch: defpackage.o31 -> La4
            goto L97
        L2c:
            java.lang.String r8 = "call to 'resume' before 'invoke' with coroutine"
            defpackage.zi.f(r8)
            return r3
        L32:
            defpackage.vl.Q(r11)
            pl1 r11 = r8.i
            m31 r11 = r11.v
            boolean r11 = e(r11, r9)
            if (r11 == 0) goto L40
            goto La3
        L40:
            pl1 r11 = r8.i
            m31 r11 = r11.v
            java.util.List r11 = r11.a
            int r1 = r11.size()
            r4 = 0
        L4b:
            if (r4 >= r1) goto L60
            java.lang.Object r5 = r11.get(r4)
            r6 = r5
            t31 r6 = (defpackage.t31) r6
            long r6 = r6.a
            boolean r6 = defpackage.om.u(r6, r9)
            if (r6 == 0) goto L5d
            goto L61
        L5d:
            int r4 = r4 + 1
            goto L4b
        L60:
            r5 = r3
        L61:
            r10 = r5
            t31 r10 = (defpackage.t31) r10
            if (r10 != 0) goto L67
            goto La3
        L67:
            e71 r9 = new e71
            r9.<init>()
            e71 r11 = new e71
            r11.<init>()
            r11.d = r10
            ry1 r1 = r8.f()
            long r4 = r1.c()
            a71 r1 = new a71     // Catch: defpackage.o31 -> La4
            r1.<init>()     // Catch: defpackage.o31 -> La4
            bx r6 = new bx     // Catch: defpackage.o31 -> La4
            r6.<init>(r1, r11, r9, r3)     // Catch: defpackage.o31 -> La4
            r0.d = r10     // Catch: defpackage.o31 -> La4
            r0.e = r9     // Catch: defpackage.o31 -> La4
            r0.f = r1     // Catch: defpackage.o31 -> La4
            r0.h = r2     // Catch: defpackage.o31 -> La4
            java.lang.Object r8 = r8.i(r4, r6, r0)     // Catch: defpackage.o31 -> La4
            es r11 = defpackage.es.d
            if (r8 != r11) goto L96
            return r11
        L96:
            r8 = r1
        L97:
            boolean r8 = r8.d     // Catch: defpackage.o31 -> La4
            if (r8 == 0) goto La3
            java.lang.Object r8 = r9.d     // Catch: defpackage.o31 -> La4
            t31 r8 = (defpackage.t31) r8     // Catch: defpackage.o31 -> La4
            if (r8 != 0) goto La2
            return r10
        La2:
            return r8
        La3:
            return r3
        La4:
            java.lang.Object r8 = r9.d
            t31 r8 = (defpackage.t31) r8
            if (r8 != 0) goto Lab
            goto Lac
        Lab:
            r10 = r8
        Lac:
            return r10
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.fx.b(ol1, long, uq):java.lang.Object");
    }

    /* JADX WARN: Removed duplicated region for block: B:24:0x00a0  */
    /* JADX WARN: Removed duplicated region for block: B:27:0x00b1  */
    /* JADX WARN: Removed duplicated region for block: B:40:0x00ea  */
    /* JADX WARN: Removed duplicated region for block: B:51:0x010f  */
    /* JADX WARN: Removed duplicated region for block: B:65:0x0169  */
    /* JADX WARN: Removed duplicated region for block: B:67:0x00d0 A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:71:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0017  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:61:0x0160 -> B:62:0x0162). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static final java.lang.Object c(defpackage.ol1 r20, long r21, defpackage.a8 r23, defpackage.kf r24) {
        /*
            Method dump skipped, instruction units count: 371
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.fx.c(ol1, long, a8, kf):java.lang.Object");
    }

    /* JADX WARN: Removed duplicated region for block: B:17:0x0043 A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:20:0x0048  */
    /* JADX WARN: Removed duplicated region for block: B:22:0x004b  */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0013  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:16:0x0041 -> B:18:0x0044). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static final java.lang.Object d(defpackage.ol1 r4, long r5, defpackage.h50 r7, defpackage.uq r8) {
        /*
            boolean r0 = r8 instanceof defpackage.ex
            if (r0 == 0) goto L13
            r0 = r8
            ex r0 = (defpackage.ex) r0
            int r1 = r0.g
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L13
            int r1 = r1 - r2
            r0.g = r1
            goto L18
        L13:
            ex r0 = new ex
            r0.<init>(r8)
        L18:
            java.lang.Object r8 = r0.f
            int r1 = r0.g
            r2 = 1
            if (r1 == 0) goto L32
            if (r1 != r2) goto L2b
            h50 r4 = r0.e
            ol1 r5 = r0.d
            defpackage.vl.Q(r8)
            r7 = r4
            r4 = r5
            goto L44
        L2b:
            java.lang.String r4 = "call to 'resume' before 'invoke' with coroutine"
            defpackage.zi.f(r4)
            r4 = 0
            return r4
        L32:
            defpackage.vl.Q(r8)
        L35:
            r0.d = r4
            r0.e = r7
            r0.g = r2
            java.lang.Object r8 = a(r4, r5, r0)
            es r5 = defpackage.es.d
            if (r8 != r5) goto L44
            return r5
        L44:
            t31 r8 = (defpackage.t31) r8
            if (r8 != 0) goto L4b
            java.lang.Boolean r4 = java.lang.Boolean.FALSE
            return r4
        L4b:
            boolean r5 = defpackage.bm.p(r8)
            if (r5 == 0) goto L54
            java.lang.Boolean r4 = java.lang.Boolean.TRUE
            return r4
        L54:
            r7.g(r8)
            long r5 = r8.a
            goto L35
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.fx.d(ol1, long, h50, uq):java.lang.Object");
    }

    public static final boolean e(m31 m31Var, long j) {
        Object obj;
        List list = m31Var.a;
        int size = list.size();
        boolean z = false;
        int i = 0;
        while (true) {
            if (i >= size) {
                obj = null;
                break;
            }
            obj = list.get(i);
            if (om.u(((t31) obj).a, j)) {
                break;
            }
            i++;
        }
        t31 t31Var = (t31) obj;
        if (t31Var != null && t31Var.d) {
            z = true;
        }
        return true ^ z;
    }

    public static final float f(ry1 ry1Var, int i) {
        return i == 2 ? ry1Var.d() * a : ry1Var.d();
    }
}
