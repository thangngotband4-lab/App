package defpackage;

import java.util.Iterator;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class ri1 implements cp, Iterable, lh0 {
    public final jh1 d;
    public final int e;
    public final i71 f;

    public ri1(jh1 jh1Var, int i, ka0 ka0Var, i71 i71Var) {
        this.d = jh1Var;
        this.e = i;
        this.f = i71Var;
    }

    public final boolean equals(Object obj) {
        if (!(obj instanceof ri1)) {
            return false;
        }
        ri1 ri1Var = (ri1) obj;
        return ri1Var.e == this.e && ri1Var.d == this.d && ri1Var.f.equals(this.f);
    }

    public final int hashCode() {
        return this.f.hashCode() + ((this.d.hashCode() + (this.e * 31)) * 31);
    }

    @Override // java.lang.Iterable
    public final Iterator iterator() {
        return new tu(this.d, this.e, null, this.f);
    }
}
