package defpackage;

import android.animation.ValueAnimator;
import android.os.Build;
import android.view.View;
import android.view.WindowInsets;
import com.example.autosocialmedia.R;
import java.util.Objects;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class sz1 implements View.OnApplyWindowInsetsListener {
    public final oz1 a;
    public m02 b;

    public sz1(View view, oz1 oz1Var) {
        m02 m02VarB;
        this.a = oz1Var;
        int i = oy1.a;
        m02 m02VarA = ky1.a(view);
        if (m02VarA != null) {
            int i2 = Build.VERSION.SDK_INT;
            m02VarB = (i2 >= 34 ? new b02(m02VarA) : i2 >= 30 ? new a02(m02VarA) : i2 >= 29 ? new zz1(m02VarA) : new yz1(m02VarA)).b();
        } else {
            m02VarB = null;
        }
        this.b = m02VarB;
    }

    @Override // android.view.View.OnApplyWindowInsetsListener
    public final WindowInsets onApplyWindowInsets(View view, WindowInsets windowInsets) {
        int[] iArr;
        boolean z;
        if (!view.isLaidOut()) {
            this.b = m02.c(windowInsets, view);
            return view.getTag(R.id.tag_on_apply_window_listener) != null ? windowInsets : view.onApplyWindowInsets(windowInsets);
        }
        m02 m02VarC = m02.c(windowInsets, view);
        j02 j02Var = m02VarC.a;
        if (this.b == null) {
            int i = oy1.a;
            this.b = ky1.a(view);
        }
        if (this.b == null) {
            this.b = m02VarC;
            if (view.getTag(R.id.tag_on_apply_window_listener) == null) {
                return view.onApplyWindowInsets(windowInsets);
            }
        } else {
            oz1 oz1VarJ = tz1.j(view);
            if (oz1VarJ == null || !Objects.equals(oz1VarJ.d, m02VarC)) {
                int[] iArr2 = new int[1];
                int[] iArr3 = new int[1];
                m02 m02Var = this.b;
                int i2 = 1;
                while (i2 <= 512) {
                    ge0 ge0VarG = j02Var.g(i2);
                    ge0 ge0VarG2 = m02Var.a.g(i2);
                    int i3 = ge0VarG.a;
                    int i4 = ge0VarG.d;
                    int i5 = ge0VarG.c;
                    int i6 = ge0VarG.b;
                    int i7 = ge0VarG2.a;
                    int i8 = ge0VarG2.d;
                    int[] iArr4 = iArr2;
                    int i9 = ge0VarG2.c;
                    int i10 = ge0VarG2.b;
                    if (i3 > i7 || i6 > i10 || i5 > i9 || i4 > i8) {
                        iArr = iArr3;
                        z = true;
                    } else {
                        iArr = iArr3;
                        z = false;
                    }
                    if (z != (i3 < i7 || i6 < i10 || i5 < i9 || i4 < i8)) {
                        if (z) {
                            iArr4[0] = iArr4[0] | i2;
                        } else {
                            iArr[0] = iArr[0] | i2;
                        }
                    }
                    i2 <<= 1;
                    iArr2 = iArr4;
                    iArr3 = iArr;
                }
                boolean z2 = false;
                int i11 = iArr2[0];
                int i12 = iArr3[0];
                int i13 = i11 | i12;
                if (i13 == 0) {
                    this.b = m02VarC;
                    if (view.getTag(R.id.tag_on_apply_window_listener) == null) {
                        return view.onApplyWindowInsets(windowInsets);
                    }
                } else {
                    m02 m02Var2 = this.b;
                    xz1 xz1Var = new xz1(i13, (i11 & 8) != 0 ? tz1.e : (i12 & 8) != 0 ? tz1.f : (i11 & 519) != 0 ? tz1.g : (i12 & 519) != 0 ? tz1.h : null, (i13 & 8) != 0 ? 160L : 250L);
                    xz1Var.a.e(0.0f);
                    ValueAnimator duration = ValueAnimator.ofFloat(0.0f, 1.0f).setDuration(xz1Var.a.b());
                    ge0 ge0VarG3 = j02Var.g(i13);
                    ge0 ge0VarG4 = m02Var2.a.g(i13);
                    int iMin = Math.min(ge0VarG3.a, ge0VarG4.a);
                    int i14 = ge0VarG3.b;
                    int i15 = ge0VarG4.b;
                    int iMin2 = Math.min(i14, i15);
                    int i16 = ge0VarG3.c;
                    int i17 = ge0VarG4.c;
                    int iMin3 = Math.min(i16, i17);
                    int i18 = ge0VarG3.d;
                    int i19 = ge0VarG4.d;
                    ae0 ae0Var = new ae0(26, ge0.b(iMin, iMin2, iMin3, Math.min(i18, i19)), ge0.b(Math.max(ge0VarG3.a, ge0VarG4.a), Math.max(i14, i15), Math.max(i16, i17), Math.max(i18, i19)), z2);
                    tz1.g(view, xz1Var, m02VarC, false);
                    duration.addUpdateListener(new pz1(xz1Var, m02VarC, m02Var2, i13, view));
                    duration.addListener(new qz1(xz1Var, view));
                    fx0 fx0Var = new fx0(view, new rz1(view, xz1Var, ae0Var, duration));
                    view.getViewTreeObserver().addOnPreDrawListener(fx0Var);
                    view.addOnAttachStateChangeListener(fx0Var);
                    this.b = m02VarC;
                    if (view.getTag(R.id.tag_on_apply_window_listener) == null) {
                        return view.onApplyWindowInsets(windowInsets);
                    }
                }
            } else if (view.getTag(R.id.tag_on_apply_window_listener) == null) {
                return view.onApplyWindowInsets(windowInsets);
            }
        }
        return windowInsets;
    }
}
