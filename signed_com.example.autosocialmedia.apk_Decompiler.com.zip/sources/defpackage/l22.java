package defpackage;

import android.content.Context;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class l22 {
    public static final int $stable = 8;
    private static final String A_COOKIES = "cookies";
    private static final String A_ID = "id";
    private static final String A_USERNAME = "username";
    private static final String CONTEXT = "asm:youtube:v1";
    private static final String C_AUTO_SWITCH = "auto_switch";
    private static final String C_BLOCK_IDX = "block_idx";
    private static final String C_DELAY_MAX = "delay_max";
    private static final String C_DELAY_MIN = "delay_min";
    private static final String C_DO_COMMENT = "do_comment";
    private static final String C_DO_LIKE = "do_like";
    private static final String C_DO_SUBSCRIBE = "do_subscribe";
    private static final String C_JOB_PER_ACC = "job_per_acc";
    private static final String C_NO_JOBS_WAIT = "no_jobs_wait";
    private static final String C_NV_FAIL = "nv_fail";
    private static final String C_PRE_MAX = "pre_max";
    private static final String C_PRE_MIN = "pre_min";
    private static final String C_REST_AFTER = "rest_after";
    private static final String C_REST_ENABLED = "rest_enabled";
    private static final String C_REST_MAX = "rest_max";
    private static final String C_REST_MIN = "rest_min";
    public static final k22 Companion = new k22();
    private static volatile l22 INSTANCE = null;
    private static final String K_ACCOUNTS = "yt_accounts";
    private static final String K_CONFIG = "yt_config";
    private static final String PREFS_NAME = "asm_youtube_enc";
    private final ht0 _accounts;
    private final ht0 _config;
    private final lj1 accounts;
    private final lj1 config;
    private final qc1 store;

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r2v17 */
    /* JADX WARN: Type inference failed for: r2v3 */
    /* JADX WARN: Type inference failed for: r2v5 */
    /* JADX WARN: Type inference failed for: r5v0, types: [d81] */
    /* JADX WARN: Type inference failed for: r5v1 */
    /* JADX WARN: Type inference failed for: r5v3, types: [java.util.ArrayList] */
    public l22(Context context) {
        ?? d81Var;
        Object d81Var2;
        e22 e22Var;
        LinkedHashMap linkedHashMap = qc1.c;
        qc1 qc1VarQ = vl.q(context, PREFS_NAME);
        this.store = qc1VarQ;
        String strA = qc1VarQ.a(K_ACCOUNTS, CONTEXT);
        uz uzVar = uz.d;
        List list = uzVar;
        if (strA != null) {
            try {
                JSONArray jSONArray = new JSONArray(strA);
                uf0 uf0VarR = tl.R(0, jSONArray.length());
                d81Var = new ArrayList(ll.R(uf0VarR));
                Iterator it = uf0VarR.iterator();
                while (((tf0) it).f) {
                    JSONObject jSONObject = jSONArray.getJSONObject(((tf0) it).nextInt());
                    long jOptLong = jSONObject.optLong(A_ID);
                    String strOptString = jSONObject.optString(A_USERNAME);
                    strOptString.getClass();
                    String strOptString2 = jSONObject.optString(A_COOKIES);
                    strOptString2.getClass();
                    d81Var.add(new z12(jOptLong, strOptString, strOptString2));
                }
            } catch (Throwable th) {
                d81Var = new d81(th);
            }
            list = (List) (d81Var instanceof d81 ? uzVar : d81Var);
        }
        nj1 nj1VarF = eq0.f(list);
        this._accounts = nj1VarF;
        this.accounts = nj1VarF;
        String strA2 = this.store.a(K_CONFIG, CONTEXT);
        if (strA2 == null) {
            e22Var = new e22();
        } else {
            e22 e22Var2 = new e22();
            try {
                JSONObject jSONObject2 = new JSONObject(strA2);
                d81Var2 = new e22(jSONObject2.optBoolean(C_DO_SUBSCRIBE, e22Var2.h()), jSONObject2.optBoolean(C_DO_LIKE, e22Var2.g()), jSONObject2.optBoolean(C_DO_COMMENT, e22Var2.f()), jSONObject2.optInt(C_PRE_MIN, e22Var2.m()), jSONObject2.optInt(C_PRE_MAX, e22Var2.l()), jSONObject2.optInt(C_DELAY_MIN, e22Var2.e()), jSONObject2.optInt(C_DELAY_MAX, e22Var2.d()), jSONObject2.optInt(C_NO_JOBS_WAIT, e22Var2.j()), jSONObject2.optInt(C_NV_FAIL, e22Var2.k()), jSONObject2.optInt(C_BLOCK_IDX, e22Var2.c()), jSONObject2.optBoolean(C_AUTO_SWITCH, e22Var2.b()), jSONObject2.optInt(C_JOB_PER_ACC, e22Var2.i()), jSONObject2.optBoolean(C_REST_ENABLED, e22Var2.o()), jSONObject2.optInt(C_REST_AFTER, e22Var2.n()), jSONObject2.optInt(C_REST_MIN, e22Var2.q()), jSONObject2.optInt(C_REST_MAX, e22Var2.p()));
            } catch (Throwable th2) {
                d81Var2 = new d81(th2);
            }
            e22Var = (e22) (d81Var2 instanceof d81 ? new e22() : d81Var2);
        }
        nj1 nj1VarF2 = eq0.f(e22Var);
        this._config = nj1VarF2;
        this.config = nj1VarF2;
    }

    public final lj1 c() {
        return this.accounts;
    }

    public final lj1 d() {
        return this.config;
    }

    public final void e(ArrayList arrayList) throws JSONException {
        JSONArray jSONArray = new JSONArray();
        int size = arrayList.size();
        int i = 0;
        while (i < size) {
            Object obj = arrayList.get(i);
            i++;
            z12 z12Var = (z12) obj;
            JSONObject jSONObject = new JSONObject();
            jSONObject.put(A_ID, z12Var.b());
            jSONObject.put(A_USERNAME, z12Var.c());
            jSONObject.put(A_COOKIES, z12Var.a());
            jSONArray.put(jSONObject);
        }
        qc1 qc1Var = this.store;
        String string = jSONArray.toString();
        string.getClass();
        qc1Var.b(K_ACCOUNTS, CONTEXT, string);
    }

    public final void f(long j) throws JSONException {
        Iterable iterable = (Iterable) ((nj1) this._accounts).getValue();
        ArrayList arrayList = new ArrayList();
        for (Object obj : iterable) {
            if (((z12) obj).b() != j) {
                arrayList.add(obj);
            }
        }
        e(arrayList);
        nj1 nj1Var = (nj1) this._accounts;
        nj1Var.getClass();
        nj1Var.i(null, arrayList);
    }

    public final void g(e22 e22Var) throws JSONException {
        e22Var.getClass();
        JSONObject jSONObject = new JSONObject();
        jSONObject.put(C_DO_SUBSCRIBE, e22Var.h());
        jSONObject.put(C_DO_LIKE, e22Var.g());
        jSONObject.put(C_DO_COMMENT, e22Var.f());
        jSONObject.put(C_PRE_MIN, e22Var.m());
        jSONObject.put(C_PRE_MAX, e22Var.l());
        jSONObject.put(C_DELAY_MIN, e22Var.e());
        jSONObject.put(C_DELAY_MAX, e22Var.d());
        jSONObject.put(C_NO_JOBS_WAIT, e22Var.j());
        jSONObject.put(C_NV_FAIL, e22Var.k());
        jSONObject.put(C_BLOCK_IDX, e22Var.c());
        jSONObject.put(C_AUTO_SWITCH, e22Var.b());
        jSONObject.put(C_JOB_PER_ACC, e22Var.i());
        jSONObject.put(C_REST_ENABLED, e22Var.o());
        jSONObject.put(C_REST_AFTER, e22Var.n());
        jSONObject.put(C_REST_MIN, e22Var.q());
        jSONObject.put(C_REST_MAX, e22Var.p());
        qc1 qc1Var = this.store;
        String string = jSONObject.toString();
        string.getClass();
        qc1Var.b(K_CONFIG, CONTEXT, string);
        nj1 nj1Var = (nj1) this._config;
        nj1Var.getClass();
        nj1Var.i(null, e22Var);
    }

    public final void h(z12 z12Var) throws JSONException {
        ArrayList arrayListK0 = il.k0((Collection) ((nj1) this._accounts).getValue());
        int size = arrayListK0.size();
        int i = 0;
        int i2 = 0;
        while (true) {
            if (i2 >= size) {
                i = -1;
                break;
            }
            Object obj = arrayListK0.get(i2);
            i2++;
            if (((z12) obj).b() == z12Var.b()) {
                break;
            } else {
                i++;
            }
        }
        if (i >= 0) {
            arrayListK0.set(i, z12Var);
        } else {
            arrayListK0.add(z12Var);
        }
        e(arrayListK0);
        nj1 nj1Var = (nj1) this._accounts;
        nj1Var.getClass();
        nj1Var.i(null, arrayListK0);
    }
}
