package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class ix1 extends cx1 {
    public final ha0 b;
    public String c;
    public boolean d;
    public final wx e;
    public w40 f;
    public final m01 g;
    public dg h;
    public final m01 i;
    public long j;
    public float k;
    public float l;
    public final hx1 m;

    public ix1(ha0 ha0Var) {
        this.b = ha0Var;
        ha0Var.i = new hx1(this, 0);
        this.c = "";
        this.d = true;
        this.e = new wx();
        this.f = kp.r;
        this.g = hl.I(null);
        this.i = hl.I(new gg1(0L));
        this.j = 9205357640488583168L;
        this.k = 1.0f;
        this.l = 1.0f;
        this.m = new hx1(this, 1);
    }

    @Override // defpackage.cx1
    public final void a(ay ayVar) {
        e(ayVar, 1.0f, null);
    }

    /* JADX WARN: Removed duplicated region for block: B:23:0x003d  */
    /* JADX WARN: Removed duplicated region for block: B:34:0x005e  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void e(defpackage.ay r32, float r33, defpackage.dg r34) {
        /*
            Method dump skipped, instruction units count: 426
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.ix1.e(ay, float, dg):void");
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder("Params: \tname: ");
        sb.append(this.c);
        sb.append("\n\tviewportWidth: ");
        m01 m01Var = this.i;
        sb.append(Float.intBitsToFloat((int) (((gg1) m01Var.getValue()).a >> 32)));
        sb.append("\n\tviewportHeight: ");
        sb.append(Float.intBitsToFloat((int) (((gg1) m01Var.getValue()).a & 4294967295L)));
        sb.append("\n");
        return sb.toString();
    }
}
