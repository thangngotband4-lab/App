package defpackage;

import java.util.List;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class k91 implements lq0, h91 {
    public final gd a;
    public final ag b;

    public k91(gd gdVar, ag agVar) {
        this.a = gdVar;
        this.b = agVar;
    }

    @Override // defpackage.h91
    public final mq0 a(k21[] k21VarArr, nq0 nq0Var, int[] iArr, int i, int i2) {
        return nq0Var.i0(i, i2, vz.d, new w3(k21VarArr, this, i2, iArr));
    }

    @Override // defpackage.lq0
    public final int b(gg0 gg0Var, List list, int i) {
        int iP = gg0Var.P(this.a.a());
        if (list.isEmpty()) {
            return 0;
        }
        int iMin = Math.min((list.size() - 1) * iP, i);
        int size = list.size();
        int iMax = 0;
        float f = 0.0f;
        for (int i2 = 0; i2 < size; i2++) {
            gq0 gq0Var = (gq0) list.get(i2);
            float fV = fl.v(fl.t(gq0Var));
            if (fV == 0.0f) {
                int iMin2 = Math.min(gq0Var.Z(Integer.MAX_VALUE), i == Integer.MAX_VALUE ? Integer.MAX_VALUE : i - iMin);
                iMin += iMin2;
                iMax = Math.max(iMax, gq0Var.f(iMin2));
            } else if (fV > 0.0f) {
                f += fV;
            }
        }
        int iRound = f == 0.0f ? 0 : i == Integer.MAX_VALUE ? Integer.MAX_VALUE : Math.round(Math.max(i - iMin, 0) / f);
        int size2 = list.size();
        for (int i3 = 0; i3 < size2; i3++) {
            gq0 gq0Var2 = (gq0) list.get(i3);
            float fV2 = fl.v(fl.t(gq0Var2));
            if (fV2 > 0.0f) {
                iMax = Math.max(iMax, gq0Var2.f(iRound != Integer.MAX_VALUE ? Math.round(iRound * fV2) : Integer.MAX_VALUE));
            }
        }
        return iMax;
    }

    @Override // defpackage.h91
    public final void c(int i, nq0 nq0Var, int[] iArr, int[] iArr2) {
        this.a.b(nq0Var, i, iArr, nq0Var.getLayoutDirection(), iArr2);
    }

    @Override // defpackage.lq0
    public final int d(gg0 gg0Var, List list, int i) {
        int iP = gg0Var.P(this.a.a());
        if (list.isEmpty()) {
            return 0;
        }
        int size = list.size();
        int iMax = 0;
        int i2 = 0;
        float f = 0.0f;
        for (int i3 = 0; i3 < size; i3++) {
            gq0 gq0Var = (gq0) list.get(i3);
            float fV = fl.v(fl.t(gq0Var));
            int iZ = gq0Var.Z(i);
            if (fV == 0.0f) {
                i2 += iZ;
            } else if (fV > 0.0f) {
                f += fV;
                iMax = Math.max(iMax, Math.round(iZ / fV));
            }
        }
        return ((list.size() - 1) * iP) + Math.round(iMax * f) + i2;
    }

    @Override // defpackage.h91
    public final long e(int i, int i2, int i3, boolean z) {
        return !z ? yp.a(i, i2, 0, i3) : jl.q(i, i2, 0, i3);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof k91)) {
            return false;
        }
        k91 k91Var = (k91) obj;
        return this.a.equals(k91Var.a) && ng0.o(this.b, k91Var.b);
    }

    @Override // defpackage.h91
    public final int f(k21 k21Var) {
        return k21Var.e;
    }

    @Override // defpackage.lq0
    public final mq0 g(nq0 nq0Var, List list, long j) {
        return hl.G(this, xp.j(j), xp.i(j), xp.h(j), xp.g(j), nq0Var.P(this.a.a()), nq0Var, list, new k21[list.size()], list.size());
    }

    @Override // defpackage.lq0
    public final int h(gg0 gg0Var, List list, int i) {
        int iP = gg0Var.P(this.a.a());
        if (list.isEmpty()) {
            return 0;
        }
        int iMin = Math.min((list.size() - 1) * iP, i);
        int size = list.size();
        int iMax = 0;
        float f = 0.0f;
        for (int i2 = 0; i2 < size; i2++) {
            gq0 gq0Var = (gq0) list.get(i2);
            float fV = fl.v(fl.t(gq0Var));
            if (fV == 0.0f) {
                int iMin2 = Math.min(gq0Var.Z(Integer.MAX_VALUE), i == Integer.MAX_VALUE ? Integer.MAX_VALUE : i - iMin);
                iMin += iMin2;
                iMax = Math.max(iMax, gq0Var.c0(iMin2));
            } else if (fV > 0.0f) {
                f += fV;
            }
        }
        int iRound = f == 0.0f ? 0 : i == Integer.MAX_VALUE ? Integer.MAX_VALUE : Math.round(Math.max(i - iMin, 0) / f);
        int size2 = list.size();
        for (int i3 = 0; i3 < size2; i3++) {
            gq0 gq0Var2 = (gq0) list.get(i3);
            float fV2 = fl.v(fl.t(gq0Var2));
            if (fV2 > 0.0f) {
                iMax = Math.max(iMax, gq0Var2.c0(iRound != Integer.MAX_VALUE ? Math.round(iRound * fV2) : Integer.MAX_VALUE));
            }
        }
        return iMax;
    }

    public final int hashCode() {
        return Float.hashCode(this.b.a) + (this.a.hashCode() * 31);
    }

    @Override // defpackage.h91
    public final int i(k21 k21Var) {
        return k21Var.d;
    }

    @Override // defpackage.lq0
    public final int j(gg0 gg0Var, List list, int i) {
        int iP = gg0Var.P(this.a.a());
        if (list.isEmpty()) {
            return 0;
        }
        int size = list.size();
        int iMax = 0;
        int i2 = 0;
        float f = 0.0f;
        for (int i3 = 0; i3 < size; i3++) {
            gq0 gq0Var = (gq0) list.get(i3);
            float fV = fl.v(fl.t(gq0Var));
            int iS = gq0Var.S(i);
            if (fV == 0.0f) {
                i2 += iS;
            } else if (fV > 0.0f) {
                f += fV;
                iMax = Math.max(iMax, Math.round(iS / fV));
            }
        }
        return ((list.size() - 1) * iP) + Math.round(iMax * f) + i2;
    }

    public final String toString() {
        return "RowMeasurePolicy(horizontalArrangement=" + this.a + ", verticalAlignment=" + this.b + ')';
    }
}
