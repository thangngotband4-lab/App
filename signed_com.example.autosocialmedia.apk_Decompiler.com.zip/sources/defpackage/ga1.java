package defpackage;

import android.os.Bundle;
import com.example.autosocialmedia.MainActivity;
import java.util.Arrays;
import java.util.Map;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class ga1 implements ja1 {
    public final ka1 a;
    public boolean b;
    public Bundle c;
    public final ul1 d;

    public ga1(ka1 ka1Var, MainActivity mainActivity) {
        ka1Var.getClass();
        this.a = ka1Var;
        this.d = new ul1(new an(mainActivity, 1));
    }

    @Override // defpackage.ja1
    public final Bundle a() {
        Bundle bundleN = y5.n((a01[]) Arrays.copyOf(new a01[0], 0));
        Bundle bundle = this.c;
        if (bundle != null) {
            bundleN.putAll(bundle);
        }
        for (Map.Entry entry : ((ha1) this.d.getValue()).b.entrySet()) {
            String str = (String) entry.getKey();
            Bundle bundleA = ((bn) ((da1) entry.getValue()).a.e).a();
            if (!bundleA.isEmpty()) {
                str.getClass();
                bundleN.putBundle(str, bundleA);
            }
        }
        this.b = false;
        return bundleN;
    }

    public final void b() {
        if (this.b) {
            return;
        }
        Bundle bundleA = this.a.a("androidx.lifecycle.internal.SavedStateHandlesProvider");
        Bundle bundleN = y5.n((a01[]) Arrays.copyOf(new a01[0], 0));
        Bundle bundle = this.c;
        if (bundle != null) {
            bundleN.putAll(bundle);
        }
        if (bundleA != null) {
            bundleN.putAll(bundleA);
        }
        this.c = bundleN;
        this.b = true;
    }
}
