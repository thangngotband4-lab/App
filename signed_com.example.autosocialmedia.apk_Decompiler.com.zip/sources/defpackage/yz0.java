package defpackage;

import kotlin.Metadata;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u000e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0082\b\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001¨\u0006\u0003"}, d2 = {"Lyz0;", "Ljr0;", "Lzz0;", "ui"}, k = 1, mv = {2, 0, 0}, xi = 48)
final /* data */ class yz0 extends jr0 {
    public final xz0 a;
    public final dg b;

    public yz0(xz0 xz0Var, dg dgVar) {
        this.a = xz0Var;
        this.b = dgVar;
    }

    @Override // defpackage.jr0
    public final er0 e() {
        bg bgVar = a4.i;
        zz0 zz0Var = new zz0();
        zz0Var.r = this.a;
        zz0Var.s = true;
        zz0Var.t = bgVar;
        zz0Var.u = iq.a;
        zz0Var.v = 1.0f;
        zz0Var.w = this.b;
        return zz0Var;
    }

    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:593)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof yz0)) {
            return false;
        }
        yz0 yz0Var = (yz0) obj;
        if (!ng0.o(this.a, yz0Var.a)) {
            return false;
        }
        bg bgVar = a4.i;
        return bgVar.equals(bgVar) && Float.compare(1.0f, 1.0f) == 0 && ng0.o(this.b, yz0Var.b);
    }

    @Override // defpackage.jr0
    public final void f(er0 er0Var) {
        zz0 zz0Var = (zz0) er0Var;
        boolean z = zz0Var.s;
        xz0 xz0Var = this.a;
        boolean z2 = (z && gg1.a(zz0Var.r.d(), xz0Var.d())) ? false : true;
        zz0Var.r = xz0Var;
        zz0Var.s = true;
        zz0Var.t = a4.i;
        zz0Var.u = iq.a;
        zz0Var.v = 1.0f;
        zz0Var.w = this.b;
        if (z2) {
            rm.I(zz0Var);
        }
        fl.w(zz0Var);
    }

    public final int hashCode() {
        int iA = f0.a(1.0f, (iq.a.hashCode() + ((Float.hashCode(0.0f) + (Float.hashCode(0.0f) * 31) + f0.f(this.a.hashCode() * 31, 31, true)) * 31)) * 31, 31);
        dg dgVar = this.b;
        return iA + (dgVar == null ? 0 : dgVar.hashCode());
    }

    public final String toString() {
        return "PainterElement(painter=" + this.a + ", sizeToIntrinsics=true, alignment=" + a4.i + ", contentScale=" + iq.a + ", alpha=1.0, colorFilter=" + this.b + ')';
    }
}
