package defpackage;

import kotlin.Metadata;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u000e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0082\b\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001¨\u0006\u0003"}, d2 = {"Lyl0;", "Ljr0;", "Lzl0;", "foundation"}, k = 1, mv = {2, 0, 0}, xi = 48)
final /* data */ class yl0 extends jr0 {
    public final w7 a;
    public final em0 b;
    public final so1 c;

    public yl0(w7 w7Var, em0 em0Var, so1 so1Var) {
        this.a = w7Var;
        this.b = em0Var;
        this.c = so1Var;
    }

    @Override // defpackage.jr0
    public final er0 e() {
        return new zl0(this.a, this.b, this.c);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof yl0) {
            yl0 yl0Var = (yl0) obj;
            return ng0.o(this.a, yl0Var.a) && this.b == yl0Var.b && this.c == yl0Var.c;
        }
        return false;
    }

    @Override // defpackage.jr0
    public final void f(er0 er0Var) {
        zl0 zl0Var = (zl0) er0Var;
        if (zl0Var.q) {
            zl0Var.r.g();
            zl0Var.r.k(zl0Var);
        }
        w7 w7Var = this.a;
        zl0Var.r = w7Var;
        if (zl0Var.q) {
            if (w7Var.a != null) {
                vd0.c("Expected textInputModifierNode to be null");
            }
            w7Var.a = zl0Var;
        }
        zl0Var.s = this.b;
        zl0Var.t = this.c;
    }

    public final int hashCode() {
        return this.c.hashCode() + ((this.b.hashCode() + (this.a.hashCode() * 31)) * 31);
    }

    public final String toString() {
        return "LegacyAdaptingPlatformTextInputModifier(serviceAdapter=" + this.a + ", legacyTextFieldState=" + this.b + ", textFieldSelectionManager=" + this.c + ')';
    }
}
