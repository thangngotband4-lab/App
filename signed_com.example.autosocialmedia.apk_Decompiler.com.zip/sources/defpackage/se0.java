package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class se0 implements l50 {
    public final /* synthetic */ int d;
    public final /* synthetic */ h50 e;
    public final /* synthetic */ gt0 f;

    public /* synthetic */ se0(h50 h50Var, gt0 gt0Var, int i) {
        this.d = i;
        this.e = h50Var;
        this.f = gt0Var;
    }

    @Override // defpackage.l50
    public final Object f(Object obj, Object obj2) {
        int i = this.d;
        bw1 bw1Var = bw1.a;
        dp1 dp1Var = ro.a;
        final gt0 gt0Var = this.f;
        final h50 h50Var = this.e;
        final int i2 = 2;
        final int i3 = 1;
        switch (i) {
            case 0:
                xo xoVar = (xo) obj;
                int iIntValue = ((Integer) obj2).intValue();
                if (!xoVar.O(iIntValue & 1, (iIntValue & 3) != 2)) {
                    xoVar.R();
                } else {
                    boolean zF = xoVar.f(h50Var);
                    Object objL = xoVar.L();
                    if (zF || objL == dp1Var) {
                        final int i4 = z ? 1 : 0;
                        objL = new w40() { // from class: bf0
                            @Override // defpackage.w40
                            public final Object a() {
                                int i5 = i4;
                                bw1 bw1Var2 = bw1.a;
                                gt0 gt0Var2 = gt0Var;
                                h50 h50Var2 = h50Var;
                                switch (i5) {
                                    case 0:
                                        if (!bk1.s((String) gt0Var2.getValue())) {
                                            h50Var2.g(bk1.A((String) gt0Var2.getValue()).toString());
                                        }
                                        break;
                                    case 1:
                                        if (!bk1.s((String) gt0Var2.getValue())) {
                                            h50Var2.g(bk1.A((String) gt0Var2.getValue()).toString());
                                        }
                                        break;
                                    case 2:
                                        if (!bk1.s((String) gt0Var2.getValue())) {
                                            h50Var2.g(bk1.A((String) gt0Var2.getValue()).toString());
                                        }
                                        break;
                                    default:
                                        if (!bk1.s((String) gt0Var2.getValue())) {
                                            h50Var2.g(bk1.A((String) gt0Var2.getValue()).toString());
                                        }
                                        break;
                                }
                                return bw1Var2;
                            }
                        };
                        xoVar.g0(objL);
                    }
                    ct.v((w40) objL, null, false, null, null, null, m22.k, xoVar, 805306368, 510);
                }
                break;
            case 1:
                xo xoVar2 = (xo) obj;
                int iIntValue2 = ((Integer) obj2).intValue();
                if (!xoVar2.O(iIntValue2 & 1, (iIntValue2 & 3) != 2)) {
                    xoVar2.R();
                } else {
                    boolean zF2 = xoVar2.f(h50Var);
                    Object objL2 = xoVar2.L();
                    if (zF2 || objL2 == dp1Var) {
                        objL2 = new w40() { // from class: bf0
                            @Override // defpackage.w40
                            public final Object a() {
                                int i5 = i3;
                                bw1 bw1Var2 = bw1.a;
                                gt0 gt0Var2 = gt0Var;
                                h50 h50Var2 = h50Var;
                                switch (i5) {
                                    case 0:
                                        if (!bk1.s((String) gt0Var2.getValue())) {
                                            h50Var2.g(bk1.A((String) gt0Var2.getValue()).toString());
                                        }
                                        break;
                                    case 1:
                                        if (!bk1.s((String) gt0Var2.getValue())) {
                                            h50Var2.g(bk1.A((String) gt0Var2.getValue()).toString());
                                        }
                                        break;
                                    case 2:
                                        if (!bk1.s((String) gt0Var2.getValue())) {
                                            h50Var2.g(bk1.A((String) gt0Var2.getValue()).toString());
                                        }
                                        break;
                                    default:
                                        if (!bk1.s((String) gt0Var2.getValue())) {
                                            h50Var2.g(bk1.A((String) gt0Var2.getValue()).toString());
                                        }
                                        break;
                                }
                                return bw1Var2;
                            }
                        };
                        xoVar2.g0(objL2);
                    }
                    ct.v((w40) objL2, null, false, null, null, null, zu1.o, xoVar2, 805306368, 510);
                }
                break;
            case 2:
                xo xoVar3 = (xo) obj;
                int iIntValue3 = ((Integer) obj2).intValue();
                if (!xoVar3.O(iIntValue3 & 1, (iIntValue3 & 3) != 2)) {
                    xoVar3.R();
                } else {
                    boolean zF3 = xoVar3.f(h50Var);
                    Object objL3 = xoVar3.L();
                    if (zF3 || objL3 == dp1Var) {
                        objL3 = new w40() { // from class: bf0
                            @Override // defpackage.w40
                            public final Object a() {
                                int i5 = i2;
                                bw1 bw1Var2 = bw1.a;
                                gt0 gt0Var2 = gt0Var;
                                h50 h50Var2 = h50Var;
                                switch (i5) {
                                    case 0:
                                        if (!bk1.s((String) gt0Var2.getValue())) {
                                            h50Var2.g(bk1.A((String) gt0Var2.getValue()).toString());
                                        }
                                        break;
                                    case 1:
                                        if (!bk1.s((String) gt0Var2.getValue())) {
                                            h50Var2.g(bk1.A((String) gt0Var2.getValue()).toString());
                                        }
                                        break;
                                    case 2:
                                        if (!bk1.s((String) gt0Var2.getValue())) {
                                            h50Var2.g(bk1.A((String) gt0Var2.getValue()).toString());
                                        }
                                        break;
                                    default:
                                        if (!bk1.s((String) gt0Var2.getValue())) {
                                            h50Var2.g(bk1.A((String) gt0Var2.getValue()).toString());
                                        }
                                        break;
                                }
                                return bw1Var2;
                            }
                        };
                        xoVar3.g0(objL3);
                    }
                    ct.v((w40) objL3, null, false, null, null, null, mg0.K, xoVar3, 805306368, 510);
                }
                break;
            default:
                xo xoVar4 = (xo) obj;
                int iIntValue4 = ((Integer) obj2).intValue();
                if (!xoVar4.O(iIntValue4 & 1, (iIntValue4 & 3) != 2)) {
                    xoVar4.R();
                } else {
                    boolean zF4 = xoVar4.f(h50Var);
                    Object objL4 = xoVar4.L();
                    if (zF4 || objL4 == dp1Var) {
                        final int i5 = 3;
                        objL4 = new w40() { // from class: bf0
                            @Override // defpackage.w40
                            public final Object a() {
                                int i52 = i5;
                                bw1 bw1Var2 = bw1.a;
                                gt0 gt0Var2 = gt0Var;
                                h50 h50Var2 = h50Var;
                                switch (i52) {
                                    case 0:
                                        if (!bk1.s((String) gt0Var2.getValue())) {
                                            h50Var2.g(bk1.A((String) gt0Var2.getValue()).toString());
                                        }
                                        break;
                                    case 1:
                                        if (!bk1.s((String) gt0Var2.getValue())) {
                                            h50Var2.g(bk1.A((String) gt0Var2.getValue()).toString());
                                        }
                                        break;
                                    case 2:
                                        if (!bk1.s((String) gt0Var2.getValue())) {
                                            h50Var2.g(bk1.A((String) gt0Var2.getValue()).toString());
                                        }
                                        break;
                                    default:
                                        if (!bk1.s((String) gt0Var2.getValue())) {
                                            h50Var2.g(bk1.A((String) gt0Var2.getValue()).toString());
                                        }
                                        break;
                                }
                                return bw1Var2;
                            }
                        };
                        xoVar4.g0(objL4);
                    }
                    ct.v((w40) objL4, null, false, null, null, null, vh0.p, xoVar4, 805306368, 510);
                }
                break;
        }
        return bw1Var;
    }
}
