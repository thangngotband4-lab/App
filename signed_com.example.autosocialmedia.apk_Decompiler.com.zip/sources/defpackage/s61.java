package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class s61 implements ad {
    public final hs0 a = new hs0();
    public final ts0 b = new ts0();
    public final Object c;

    public s61(Object obj) {
        this.c = obj;
    }

    public final void a(sv1 sv1Var, l71 l71Var) {
        Exception exc;
        hs0 hs0Var = this.a;
        int i = hs0Var.b;
        ts0 ts0Var = new ts0();
        int i2 = 0;
        int i3 = 0;
        while (true) {
            ts0 ts0Var2 = this.b;
            if (i2 >= i) {
                if (i3 != ts0Var2.b) {
                    yo.a("Applier operation size mismatch");
                }
                ts0Var2.d();
                hs0Var.b = 0;
                sv1Var.g();
                return;
            }
            int i4 = i2 + 1;
            try {
                try {
                    switch (hs0Var.c(i2)) {
                        case 0:
                            sv1Var.q();
                            i2 = i4;
                            break;
                        case 1:
                            int i5 = i3 + 1;
                            sv1Var.d(ts0Var2.f(i3));
                            i3 = i5;
                            i2 = i4;
                            break;
                        case 2:
                            int i6 = i2 + 2;
                            i2 += 3;
                            sv1Var.j(hs0Var.c(i4), hs0Var.c(i6));
                            break;
                        case 3:
                            int i7 = i2 + 2;
                            try {
                                int i8 = i2 + 3;
                                try {
                                    i2 += 4;
                                    sv1Var.h(hs0Var.c(i4), hs0Var.c(i7), hs0Var.c(i8));
                                } catch (Exception e) {
                                    exc = e;
                                    i2 = i8;
                                }
                            } catch (Exception e2) {
                                exc = e2;
                                i2 = i7;
                            }
                            break;
                        case 4:
                            sv1Var.a();
                            i2 = i4;
                            break;
                        case 5:
                            i2 += 2;
                            int i9 = i3 + 1;
                            sv1Var.c(hs0Var.c(i4), ts0Var2.f(i3));
                            i3 = i9;
                            break;
                        case 6:
                            i2 += 2;
                            try {
                                hs0Var.c(i4);
                                int i10 = i3 + 1;
                                i3 = i10;
                            } catch (Exception e3) {
                                exc = e3;
                            }
                            break;
                        case 7:
                            int i11 = i3 + 1;
                            Object objF = ts0Var2.f(i3);
                            objF.getClass();
                            zu1.g(2, objF);
                            i3 += 2;
                            sv1Var.m((l50) objF, ts0Var2.f(i11));
                            i2 = i4;
                            break;
                        case 8:
                            Object obj = sv1Var.c;
                            if (obj instanceof eo) {
                                eo eoVar = (eo) obj;
                                if (l71Var.f.j(eoVar)) {
                                    eoVar.c();
                                }
                            }
                            ts0Var.a(obj);
                            sv1Var.e();
                            i2 = i4;
                            break;
                        default:
                            i2 = i4;
                            break;
                    }
                } catch (Throwable th) {
                    sv1Var.g();
                    throw th;
                }
            } catch (Exception e4) {
                exc = e4;
                i2 = i4;
            }
            exc = e3;
            throw new go(ts0Var2, ts0Var, hs0Var, i2 - 1, exc);
        }
    }

    @Override // defpackage.ad
    public final void c(int i, Object obj) {
        hs0 hs0Var = this.a;
        hs0Var.a(5);
        hs0Var.a(i);
        this.b.a(obj);
    }

    @Override // defpackage.ad
    public final void d(Object obj) {
        this.a.a(1);
        this.b.a(obj);
    }

    @Override // defpackage.ad
    public final void e() {
        this.a.a(8);
    }

    @Override // defpackage.ad
    public final void f(int i, Object obj) {
        hs0 hs0Var = this.a;
        hs0Var.a(6);
        hs0Var.a(i);
        this.b.a(obj);
    }

    @Override // defpackage.ad
    public final void h(int i, int i2, int i3) {
        hs0 hs0Var = this.a;
        hs0Var.a(3);
        hs0Var.a(i);
        hs0Var.a(i2);
        hs0Var.a(i3);
    }

    @Override // defpackage.ad
    public final Object i() {
        return this.c;
    }

    @Override // defpackage.ad
    public final void j(int i, int i2) {
        hs0 hs0Var = this.a;
        hs0Var.a(2);
        hs0Var.a(i);
        hs0Var.a(i2);
    }

    @Override // defpackage.ad
    public final void m(l50 l50Var, Object obj) {
        this.a.a(7);
        ts0 ts0Var = this.b;
        ts0Var.a(l50Var);
        ts0Var.a(obj);
    }

    @Override // defpackage.ad
    public final void q() {
        this.a.a(0);
    }
}
