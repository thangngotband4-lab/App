package defpackage;

import android.content.Context;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class ze1 {
    public final af1 a(Context context) {
        af1 af1Var;
        context.getClass();
        af1 af1Var2 = af1.INSTANCE;
        if (af1Var2 != null) {
            return af1Var2;
        }
        synchronized (this) {
            af1Var = af1.INSTANCE;
            if (af1Var == null) {
                af1Var = new af1(context);
                af1.INSTANCE = af1Var;
            }
        }
        return af1Var;
    }
}
