package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class a5 extends ki0 implements w40 {
    public final /* synthetic */ int e;
    public final /* synthetic */ Object f;
    public final /* synthetic */ Object g;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ a5(Object obj, int i, Object obj2) {
        super(0);
        this.e = i;
        this.f = obj;
        this.g = obj2;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v18 */
    /* JADX WARN: Type inference failed for: r0v19, types: [er0] */
    /* JADX WARN: Type inference failed for: r0v21 */
    /* JADX WARN: Type inference failed for: r0v22, types: [er0] */
    /* JADX WARN: Type inference failed for: r0v23, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r0v24 */
    /* JADX WARN: Type inference failed for: r0v25 */
    /* JADX WARN: Type inference failed for: r0v26 */
    /* JADX WARN: Type inference failed for: r0v27 */
    /* JADX WARN: Type inference failed for: r0v29 */
    /* JADX WARN: Type inference failed for: r0v30 */
    /* JADX WARN: Type inference failed for: r6v10 */
    /* JADX WARN: Type inference failed for: r6v11 */
    /* JADX WARN: Type inference failed for: r6v12, types: [it0] */
    /* JADX WARN: Type inference failed for: r6v13 */
    /* JADX WARN: Type inference failed for: r6v14 */
    /* JADX WARN: Type inference failed for: r6v15, types: [it0] */
    /* JADX WARN: Type inference failed for: r6v18 */
    /* JADX WARN: Type inference failed for: r6v19 */
    /* JADX WARN: Type inference failed for: r6v20 */
    /* JADX WARN: Type inference failed for: r6v21 */
    /* JADX WARN: Type inference failed for: r6v9 */
    /* JADX WARN: Type inference failed for: r7v18 */
    @Override // defpackage.w40
    public final Object a() {
        pd1 pd1Var;
        ij0 ij0Var;
        int i = this.e;
        bw1 bw1Var = bw1.a;
        Object obj = this.g;
        Object obj2 = this.f;
        switch (i) {
            case 0:
                break;
            case 1:
                r5 r5Var = (r5) obj;
                ob1 ob1Var = (ob1) obj2;
                jb1 jb1Var = ob1Var.h;
                jb1 jb1Var2 = ob1Var.i;
                Float f = ob1Var.f;
                Float f2 = ob1Var.g;
                float fFloatValue = (jb1Var == null || f == null) ? 0.0f : ((Number) jb1Var.a.a()).floatValue() - f.floatValue();
                float fFloatValue2 = (jb1Var2 == null || f2 == null) ? 0.0f : ((Number) jb1Var2.a.a()).floatValue() - f2.floatValue();
                if (fFloatValue != 0.0f || fFloatValue2 != 0.0f) {
                    int iT = r5Var.t(ob1Var.d);
                    rd1 rd1Var = (rd1) r5Var.l().b(r5Var.o);
                    if (rd1Var != null) {
                        try {
                            i1 i1Var = r5Var.q;
                            if (i1Var != null) {
                                i1Var.a.setBoundsInScreen(r5Var.d(rd1Var));
                            }
                            break;
                        } catch (IllegalStateException unused) {
                        }
                    }
                    rd1 rd1Var2 = (rd1) r5Var.l().b(r5Var.p);
                    if (rd1Var2 != null) {
                        try {
                            i1 i1Var2 = r5Var.r;
                            if (i1Var2 != null) {
                                i1Var2.a.setBoundsInScreen(r5Var.d(rd1Var2));
                            }
                            break;
                        } catch (IllegalStateException unused2) {
                        }
                    }
                    r5Var.g.invalidate();
                    rd1 rd1Var3 = (rd1) r5Var.l().b(iT);
                    if (rd1Var3 != null && (pd1Var = rd1Var3.a) != null && (ij0Var = pd1Var.c) != null) {
                        if (jb1Var != null) {
                            r5Var.t.h(iT, jb1Var);
                        }
                        if (jb1Var2 != null) {
                            r5Var.u.h(iT, jb1Var2);
                        }
                        r5Var.p(ij0Var);
                    }
                }
                if (jb1Var != null) {
                    ob1Var.f = (Float) jb1Var.a.a();
                }
                if (jb1Var2 != null) {
                    ob1Var.g = (Float) jb1Var2.a.a();
                }
                break;
            case 2:
                w40 w40Var = (w40) obj2;
                if (w40Var == null || (r10 = (x61) w40Var.a()) == null) {
                    pu0 pu0Var = (pu0) obj;
                    if (!pu0Var.U0().q) {
                        pu0Var = null;
                    }
                    if (pu0Var != null) {
                    }
                }
                break;
            case 3:
                ((ji) obj2).t.g((ki) obj);
                break;
            case 4:
                ((e71) obj2).d = rm.x((p30) obj, i21.a);
                break;
            case 5:
                ((e71) obj2).d = ((r30) obj).O0();
                break;
            case 6:
                ((bb0) obj2).d((er0) obj);
                break;
            case 7:
                nu0 nu0Var = ((ij0) obj2).J;
                e71 e71Var = (e71) obj;
                if ((nu0Var.f.g & 8) != 0) {
                    for (er0 er0Var = nu0Var.e; er0Var != null; er0Var = er0Var.h) {
                        if ((er0Var.f & 8) != 0) {
                            ?? K = er0Var;
                            ?? it0Var = 0;
                            while (K != 0) {
                                if (K instanceof nd1) {
                                    nd1 nd1Var = (nd1) K;
                                    if (nd1Var.m0()) {
                                        ld1 ld1Var = new ld1();
                                        e71Var.d = ld1Var;
                                        ld1Var.g = true;
                                    }
                                    if (nd1Var.n0()) {
                                        ((ld1) e71Var.d).f = true;
                                    }
                                    nd1Var.k0((yd1) e71Var.d);
                                } else if ((K.f & 8) != 0 && (K instanceof lu)) {
                                    er0 er0Var2 = ((lu) K).s;
                                    int i2 = 0;
                                    K = K;
                                    it0Var = it0Var;
                                    while (er0Var2 != null) {
                                        if ((er0Var2.f & 8) != 0) {
                                            i2++;
                                            it0Var = it0Var;
                                            if (i2 == 1) {
                                                K = er0Var2;
                                            } else {
                                                if (it0Var == 0) {
                                                    it0Var = new it0(new er0[16]);
                                                }
                                                if (K != 0) {
                                                    it0Var.b(K);
                                                    K = 0;
                                                }
                                                it0Var.b(er0Var2);
                                            }
                                        }
                                        er0Var2 = er0Var2.i;
                                        K = K;
                                        it0Var = it0Var;
                                    }
                                    if (i2 == 1) {
                                    }
                                }
                                K = tl.k(it0Var);
                            }
                        }
                    }
                }
                break;
            default:
                i81 i81Var = pu0.P;
                ((h50) obj2).g(i81Var);
                pu0 pu0Var2 = (pu0) obj;
                qf1 qf1Var = pu0Var2.G;
                qf1 qf1Var2 = i81Var.m;
                boolean z = qf1Var != qf1Var2;
                boolean z2 = pu0Var2.H;
                boolean z3 = i81Var.n;
                boolean z4 = z2 != z3;
                if (z || z4) {
                    pu0Var2.G = qf1Var2;
                    pu0Var2.H = z3;
                    if (pu0Var2.I && (z4 || (z3 && z))) {
                        pu0Var2.r.F();
                    }
                }
                pu0Var2.I = true;
                i81Var.s = i81Var.m.a(i81Var.o, i81Var.q, i81Var.p);
                break;
        }
        return bw1Var;
    }
}
