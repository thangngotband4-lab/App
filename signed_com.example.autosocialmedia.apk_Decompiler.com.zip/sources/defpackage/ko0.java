package defpackage;

import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import sun.misc.Unsafe;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public class ko0 {
    public static final /* synthetic */ AtomicReferenceFieldUpdater d = AtomicReferenceFieldUpdater.newUpdater(ko0.class, Object.class, "_next$volatile");
    public static final /* synthetic */ AtomicReferenceFieldUpdater e;
    public static final /* synthetic */ AtomicReferenceFieldUpdater f;
    public static final /* synthetic */ long g;
    public static final /* synthetic */ long h;
    public static final /* synthetic */ long i;
    private volatile /* synthetic */ Object _next$volatile = this;
    private volatile /* synthetic */ Object _prev$volatile = this;
    private volatile /* synthetic */ Object _removedRef$volatile;

    static {
        Unsafe unsafe = yi.a;
        g = unsafe.objectFieldOffset(ko0.class.getDeclaredField("_next$volatile"));
        e = AtomicReferenceFieldUpdater.newUpdater(ko0.class, Object.class, "_prev$volatile");
        h = unsafe.objectFieldOffset(ko0.class.getDeclaredField("_prev$volatile"));
        f = AtomicReferenceFieldUpdater.newUpdater(ko0.class, Object.class, "_removedRef$volatile");
        i = unsafe.objectFieldOffset(ko0.class.getDeclaredField("_removedRef$volatile"));
    }

    public static ko0 i(ko0 ko0Var) {
        while (ko0Var.n()) {
            e.getClass();
            ko0Var = (ko0) yi.a.getObjectVolatile(ko0Var, h);
        }
        return ko0Var;
    }

    public final boolean e(ko0 ko0Var, int i2) {
        ko0 ko0VarM;
        do {
            ko0VarM = m();
            if (ko0VarM instanceof co0) {
                return (((co0) ko0VarM).j & i2) == 0 && ko0VarM.e(ko0Var, i2);
            }
        } while (!ko0VarM.f(ko0Var, this));
        return true;
    }

    public final boolean f(ko0 ko0Var, ko0 ko0Var2) {
        e.getClass();
        Unsafe unsafe = yi.a;
        unsafe.putObjectVolatile(ko0Var, h, this);
        AtomicReferenceFieldUpdater atomicReferenceFieldUpdater = d;
        atomicReferenceFieldUpdater.getClass();
        unsafe.putObjectVolatile(ko0Var, g, ko0Var2);
        if (!f0.B(atomicReferenceFieldUpdater, this, ko0Var2, ko0Var)) {
            return false;
        }
        ko0Var.j(ko0Var2);
        return true;
    }

    public final void g(ru0 ru0Var) {
        e.getClass();
        Unsafe unsafe = yi.a;
        unsafe.putObjectVolatile(ru0Var, h, this);
        AtomicReferenceFieldUpdater atomicReferenceFieldUpdater = d;
        atomicReferenceFieldUpdater.getClass();
        unsafe.putObjectVolatile(ru0Var, g, this);
        while (k() == this) {
            if (f0.B(atomicReferenceFieldUpdater, this, this, ru0Var)) {
                ru0Var.j(this);
                return;
            }
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:13:0x002d, code lost:
    
        return r5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x0043, code lost:
    
        if (defpackage.f0.B(r7, r6, r5, ((defpackage.q71) r9).a) != false) goto L23;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final defpackage.ko0 h() {
        /*
            r12 = this;
        L0:
            java.util.concurrent.atomic.AtomicReferenceFieldUpdater r0 = defpackage.ko0.e
            r0.getClass()
            sun.misc.Unsafe r1 = defpackage.yi.a
            long r2 = defpackage.ko0.h
            java.lang.Object r1 = r1.getObjectVolatile(r12, r2)
            ko0 r1 = (defpackage.ko0) r1
            r4 = 0
            r5 = r1
        L11:
            r6 = r4
        L12:
            java.util.concurrent.atomic.AtomicReferenceFieldUpdater r7 = defpackage.ko0.d
            r7.getClass()
            if (r5 == 0) goto L5f
            sun.misc.Unsafe r8 = defpackage.yi.a
            long r9 = defpackage.ko0.g
            java.lang.Object r9 = r8.getObjectVolatile(r5, r9)
            if (r9 != r12) goto L2e
            if (r1 != r5) goto L26
            goto L2d
        L26:
            boolean r0 = defpackage.f0.B(r0, r12, r1, r5)
            if (r0 != 0) goto L2d
            goto L0
        L2d:
            return r5
        L2e:
            boolean r10 = r12.n()
            if (r10 == 0) goto L35
            return r4
        L35:
            boolean r10 = r9 instanceof defpackage.q71
            if (r10 == 0) goto L55
            if (r6 == 0) goto L48
            q71 r9 = (defpackage.q71) r9
            ko0 r8 = r9.a
            boolean r5 = defpackage.f0.B(r7, r6, r5, r8)
            if (r5 != 0) goto L46
            goto L0
        L46:
            r5 = r6
            goto L11
        L48:
            if (r5 == 0) goto L51
            java.lang.Object r5 = r8.getObjectVolatile(r5, r2)
            ko0 r5 = (defpackage.ko0) r5
            goto L12
        L51:
            defpackage.zi.e()
            return r4
        L55:
            r9.getClass()
            r6 = r9
            ko0 r6 = (defpackage.ko0) r6
            r11 = r6
            r6 = r5
            r5 = r11
            goto L12
        L5f:
            defpackage.zi.e()
            return r4
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.ko0.h():ko0");
    }

    public final void j(ko0 ko0Var) {
        AtomicReferenceFieldUpdater atomicReferenceFieldUpdater;
        ko0 ko0Var2;
        do {
            atomicReferenceFieldUpdater = e;
            atomicReferenceFieldUpdater.getClass();
            if (ko0Var == null) {
                zi.e();
                return;
            } else {
                ko0Var2 = (ko0) yi.a.getObjectVolatile(ko0Var, h);
                if (k() != ko0Var) {
                    return;
                }
            }
        } while (!f0.B(atomicReferenceFieldUpdater, ko0Var, ko0Var2, this));
        if (n()) {
            ko0Var.h();
        }
    }

    public final Object k() {
        d.getClass();
        return yi.a.getObjectVolatile(this, g);
    }

    public final ko0 l() {
        Object objK = k();
        q71 q71Var = objK instanceof q71 ? (q71) objK : null;
        if (q71Var != null) {
            return q71Var.a;
        }
        objK.getClass();
        return (ko0) objK;
    }

    public final ko0 m() {
        ko0 ko0VarH = h();
        if (ko0VarH != null) {
            return ko0VarH;
        }
        e.getClass();
        return i((ko0) yi.a.getObjectVolatile(this, h));
    }

    public boolean n() {
        return k() instanceof q71;
    }

    public final q71 o() {
        f.getClass();
        Unsafe unsafe = yi.a;
        long j = i;
        q71 q71Var = (q71) unsafe.getObjectVolatile(this, j);
        if (q71Var != null) {
            return q71Var;
        }
        q71 q71Var2 = new q71(this);
        unsafe.putObjectVolatile(this, j, q71Var2);
        return q71Var2;
    }

    public String toString() {
        return new il0(1, 1, ct.class, this, "classSimpleName", "getClassSimpleName(Ljava/lang/Object;)Ljava/lang/String;") + '@' + ct.D(this);
    }
}
