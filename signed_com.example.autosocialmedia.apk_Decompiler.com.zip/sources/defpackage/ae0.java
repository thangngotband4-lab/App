package defpackage;

import android.os.Build;
import android.text.Spannable;
import android.text.SpannableString;
import android.view.View;
import android.view.WindowInsetsAnimation;
import android.view.autofill.AutofillId;
import android.view.contentcapture.ContentCaptureSession;
import android.view.inputmethod.InputMethodManager;
import java.lang.ref.Reference;
import java.lang.ref.ReferenceQueue;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Objects;
import java.util.regex.Matcher;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class ae0 implements jz, e20, aj, oy0, qa1, sc1 {
    public final /* synthetic */ int d;
    public Object e;
    public Object f;

    public ae0(int i) {
        this.d = i;
        switch (i) {
            case 11:
                this.e = hl.I(Boolean.FALSE);
                break;
            case 13:
                this.e = new at0();
                this.f = new at0();
                break;
            case 15:
                this.e = new it0(new ij0[16]);
                break;
            case 19:
                this.e = new LinkedHashMap();
                this.f = new LinkedHashMap();
                break;
            case 23:
                this.e = new vl1();
                this.f = new kp0(16);
                break;
            case 25:
                this.e = new it0(new Reference[16]);
                this.f = new ReferenceQueue();
                break;
            default:
                this.e = new zx1(0);
                this.f = new zx1(0);
                break;
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r4v0 */
    /* JADX WARN: Type inference failed for: r4v1, types: [er0] */
    /* JADX WARN: Type inference failed for: r4v10 */
    /* JADX WARN: Type inference failed for: r4v11 */
    /* JADX WARN: Type inference failed for: r4v3 */
    /* JADX WARN: Type inference failed for: r4v4, types: [er0] */
    /* JADX WARN: Type inference failed for: r4v5, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r4v6 */
    /* JADX WARN: Type inference failed for: r4v7 */
    /* JADX WARN: Type inference failed for: r4v8 */
    /* JADX WARN: Type inference failed for: r4v9 */
    /* JADX WARN: Type inference failed for: r5v0 */
    /* JADX WARN: Type inference failed for: r5v1 */
    /* JADX WARN: Type inference failed for: r5v10 */
    /* JADX WARN: Type inference failed for: r5v11 */
    /* JADX WARN: Type inference failed for: r5v2 */
    /* JADX WARN: Type inference failed for: r5v3, types: [it0] */
    /* JADX WARN: Type inference failed for: r5v4 */
    /* JADX WARN: Type inference failed for: r5v5 */
    /* JADX WARN: Type inference failed for: r5v6, types: [it0] */
    /* JADX WARN: Type inference failed for: r5v8 */
    /* JADX WARN: Type inference failed for: r5v9 */
    /* JADX WARN: Type inference failed for: r6v5 */
    public static void m(ij0 ij0Var) {
        if (ij0Var.T > 0) {
            if (ij0Var.K.d == ej0.h && !ij0Var.p() && !ij0Var.q() && !ij0Var.U && ij0Var.I()) {
                er0 er0Var = ij0Var.J.f;
                if ((er0Var.g & 256) != 0) {
                    while (er0Var != null) {
                        if ((er0Var.f & 256) != 0) {
                            ?? K = er0Var;
                            ?? it0Var = 0;
                            while (K != 0) {
                                if (K instanceof h60) {
                                    h60 h60Var = (h60) K;
                                    h60Var.u(tl.K(h60Var, 256));
                                } else if ((K.f & 256) != 0 && (K instanceof lu)) {
                                    er0 er0Var2 = ((lu) K).s;
                                    int i = 0;
                                    K = K;
                                    it0Var = it0Var;
                                    while (er0Var2 != null) {
                                        if ((er0Var2.f & 256) != 0) {
                                            i++;
                                            it0Var = it0Var;
                                            if (i == 1) {
                                                K = er0Var2;
                                            } else {
                                                if (it0Var == 0) {
                                                    it0Var = new it0(new er0[16]);
                                                }
                                                if (K != 0) {
                                                    it0Var.b(K);
                                                    K = 0;
                                                }
                                                it0Var.b(er0Var2);
                                            }
                                        }
                                        er0Var2 = er0Var2.i;
                                        K = K;
                                        it0Var = it0Var;
                                    }
                                    if (i == 1) {
                                    }
                                }
                                K = tl.k(it0Var);
                            }
                        }
                        if ((er0Var.g & 256) == 0) {
                            break;
                        } else {
                            er0Var = er0Var.i;
                        }
                    }
                }
            }
            ij0Var.S = false;
            it0 it0VarY = ij0Var.y();
            Object[] objArr = it0VarY.d;
            int i2 = it0VarY.f;
            for (int i3 = 0; i3 < i2; i3++) {
                m((ij0) objArr[i3]);
            }
        }
    }

    @Override // defpackage.jz
    public Object a() {
        return (ew1) this.e;
    }

    @Override // defpackage.e20
    public Object b(f20 f20Var, tq tqVar) {
        Object objB = ((vj) this.e).b(new pb(new a71(), f20Var, (o61) this.f, 2), tqVar);
        return objB == es.d ? objB : bw1.a;
    }

    @Override // defpackage.aj
    public void cancel() {
        switch (this.d) {
            case 14:
                ww0 ww0Var = (ww0) this.f;
                kd kdVar = ww0Var.b;
                xw0 xw0Var = (xw0) this.e;
                kdVar.remove(xw0Var);
                if (ng0.o(ww0Var.c, xw0Var)) {
                    ww0Var.c = null;
                }
                xw0Var.a.remove(this);
                w40 w40Var = xw0Var.b;
                if (w40Var != null) {
                    w40Var.a();
                }
                xw0Var.b = null;
                break;
            default:
                if (!((td) this.f).compareAndSet(1, 1)) {
                    ((x2) this.e).a();
                }
                break;
        }
    }

    @Override // defpackage.oy0
    public List d(Integer num) {
        List listD = ((oy0) this.e).d(null);
        mh1 mh1Var = (mh1) this.f;
        int i = mh1Var.v;
        return i < 0 ? listD : il.d0(vl.i(mh1Var, num, i, Integer.valueOf(mh1Var.E(mh1Var.b, i))), listD);
    }

    @Override // defpackage.sc1
    public int e(int i) {
        do {
            i = ((o01) this.f).j(i);
            if (i == -1) {
                return -1;
            }
        } while (Character.isWhitespace(((CharSequence) this.e).charAt(i)));
        return i;
    }

    @Override // defpackage.sc1
    public int f(int i) {
        do {
            i = ((o01) this.f).i(i);
            if (i == -1) {
                return -1;
            }
        } while (Character.isWhitespace(((CharSequence) this.e).charAt(i - 1)));
        return i;
    }

    @Override // defpackage.qa1
    public Object g(Object obj) {
        return ((h50) this.f).g(obj);
    }

    @Override // defpackage.jz
    public boolean h(CharSequence charSequence, int i, int i2, iv1 iv1Var) {
        if ((iv1Var.c & 4) > 0) {
            return true;
        }
        if (((ew1) this.e) == null) {
            this.e = new ew1(charSequence instanceof Spannable ? (Spannable) charSequence : new SpannableString(charSequence));
        }
        ((dp1) this.f).getClass();
        ((ew1) this.e).setSpan(new jv1(iv1Var), i, i2, 33);
        return true;
    }

    @Override // defpackage.sc1
    public int i(int i) {
        CharSequence charSequence = (CharSequence) this.e;
        do {
            i = ((o01) this.f).i(i);
            if (i == -1 || i == charSequence.length()) {
                return -1;
            }
        } while (Character.isWhitespace(charSequence.charAt(i)));
        return i;
    }

    @Override // defpackage.sc1
    public int j(int i) {
        do {
            i = ((o01) this.f).j(i);
            if (i == -1 || i == 0) {
                return -1;
            }
        } while (Character.isWhitespace(((CharSequence) this.e).charAt(i - 1)));
        return i;
    }

    @Override // defpackage.qa1
    public Object k(v91 v91Var, Object obj) {
        return ((l50) this.e).f(v91Var, obj);
    }

    public zo1 l(List list) {
        vy vyVar;
        Exception e;
        vy vyVar2;
        try {
            int size = list.size();
            int i = 0;
            vyVar = null;
            while (i < size) {
                try {
                    vyVar2 = (vy) list.get(i);
                } catch (Exception e2) {
                    e = e2;
                }
                try {
                    vyVar2.a((wy) this.f);
                    i++;
                    vyVar = vyVar2;
                } catch (Exception e3) {
                    e = e3;
                    vyVar = vyVar2;
                    StringBuilder sb = new StringBuilder();
                    StringBuilder sb2 = new StringBuilder("Error while applying EditCommand batch to buffer (length=");
                    sb2.append(((wy) this.f).a.b());
                    sb2.append(", composition=");
                    sb2.append(((wy) this.f).c());
                    sb2.append(", selection=");
                    wy wyVar = (wy) this.f;
                    sb2.append((Object) wp1.h(jj1.b(wyVar.b, wyVar.c)));
                    sb2.append("):");
                    sb.append(sb2.toString());
                    sb.append('\n');
                    il.Z(list, sb, new l(vyVar, 9, this), 60);
                    throw new RuntimeException(sb.toString(), e);
                }
            }
            wy wyVar2 = (wy) this.f;
            wyVar2.getClass();
            kc kcVar = new kc(wyVar2.a.toString());
            wy wyVar3 = (wy) this.f;
            long jB = jj1.b(wyVar3.b, wyVar3.c);
            wp1 wp1Var = wp1.g(((zo1) this.e).b) ? null : new wp1(jB);
            zo1 zo1Var = new zo1(kcVar, wp1Var != null ? wp1Var.a : jj1.b(wp1.e(jB), wp1.f(jB)), ((wy) this.f).c());
            this.e = zo1Var;
            return zo1Var;
        } catch (Exception e4) {
            vyVar = null;
            e = e4;
        }
    }

    public InputMethodManager n() {
        return (InputMethodManager) ((zj0) this.f).getValue();
    }

    public lq0 o() {
        return (lq0) ((m01) this.f).getValue();
    }

    public uf0 p() {
        Matcher matcher = (Matcher) this.e;
        return tl.R(matcher.start(), matcher.end());
    }

    public AutofillId q(long j) {
        if (Build.VERSION.SDK_INT < 29) {
            return null;
        }
        ContentCaptureSession contentCaptureSessionG = cq.g(this.f);
        ke keVarF = ak1.f((View) this.e);
        Objects.requireNonNull(keVarF);
        return cq.A(contentCaptureSessionG, dm.h(keVarF.a), j);
    }

    public void r() {
        if (((zc0) this.f) != null) {
            this.f = null;
            ((xk) this.e).R0(true);
        }
    }

    public String toString() {
        switch (this.d) {
            case 26:
                return "Bounds{lower=" + ((ge0) this.e) + " upper=" + ((ge0) this.f) + "}";
            default:
                return super.toString();
        }
    }

    public /* synthetic */ ae0(int i, boolean z) {
        this.d = i;
    }

    public /* synthetic */ ae0(Object obj, int i, Object obj2) {
        this.d = i;
        this.f = obj;
        this.e = obj2;
    }

    public ae0(ij0 ij0Var, lq0 lq0Var) {
        this.d = 6;
        this.e = ij0Var;
        this.f = hl.I(lq0Var);
    }

    public ae0(x2 x2Var) {
        this.d = 16;
        this.e = x2Var;
        this.f = new td(0);
    }

    public ae0(View view) {
        this.d = 0;
        this.e = view;
        this.f = vl.C(new y8(8, this));
    }

    public ae0(mk0 mk0Var) {
        this.d = 7;
        this.e = mk0Var;
        ps0 ps0Var = ew0.a;
        this.f = new ps0();
    }

    /* JADX WARN: 'this' call moved to the top of the method (can break code semantics) */
    public ae0(Object obj) {
        this(11);
        this.d = 11;
        this.f = hl.I(obj);
        hl.I(obj);
    }

    public ae0(WindowInsetsAnimation.Bounds bounds) {
        this.d = 26;
        this.e = ge0.c(bounds.getLowerBound());
        this.f = ge0.c(bounds.getUpperBound());
    }

    public /* synthetic */ ae0(int i, Object obj, Object obj2, boolean z) {
        this.d = i;
        this.e = obj;
        this.f = obj2;
    }

    public ae0(xk xkVar) {
        this.d = 1;
        this.e = xkVar;
    }
}
