package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public abstract class wh {
    public static final yj a = new yj(-1, null, null, 0);
    public static final int b = ak1.r(32, 12, "kotlinx.coroutines.bufferedChannel.segmentSize");
    public static final int c = ak1.r(10000, 12, "kotlinx.coroutines.bufferedChannel.expandBufferCompletionWaitIterations");
    public static final lz d;
    public static final lz e;
    public static final lz f;
    public static final lz g;
    public static final lz h;
    public static final lz i;
    public static final lz j;
    public static final lz k;
    public static final lz l;
    public static final lz m;
    public static final lz n;
    public static final lz o;
    public static final lz p;
    public static final lz q;
    public static final lz r;
    public static final lz s;

    static {
        int i2 = 2;
        d = new lz("BUFFERED", i2);
        e = new lz("SHOULD_BUFFER", i2);
        f = new lz("S_RESUMING_BY_RCV", i2);
        g = new lz("RESUMING_BY_EB", i2);
        h = new lz("POISONED", i2);
        i = new lz("DONE_RCV", i2);
        j = new lz("INTERRUPTED_SEND", i2);
        k = new lz("INTERRUPTED_RCV", i2);
        l = new lz("CHANNEL_CLOSED", i2);
        m = new lz("SUSPEND", i2);
        n = new lz("SUSPEND_NO_WAITER", i2);
        o = new lz("FAILED", i2);
        p = new lz("NO_RECEIVE_RESULT", i2);
        q = new lz("CLOSE_HANDLER_CLOSED", i2);
        r = new lz("CLOSE_HANDLER_INVOKED", i2);
        s = new lz("NO_CLOSE_CAUSE", i2);
    }
}
