package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public abstract class e31 {
    public static final vj1 a = new vj1(new mv0(3));
    public static final d31 b = new d31();
}
