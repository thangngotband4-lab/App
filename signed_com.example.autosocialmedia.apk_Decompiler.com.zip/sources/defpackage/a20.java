package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class a20 implements l50 {
    public final /* synthetic */ int d = 1;
    public final /* synthetic */ fr0 e;
    public final /* synthetic */ long f;
    public final /* synthetic */ long g;
    public final /* synthetic */ int h;
    public final /* synthetic */ Object i;
    public final /* synthetic */ Object j;
    public final /* synthetic */ Object k;
    public final /* synthetic */ Object l;

    public /* synthetic */ a20(w40 w40Var, fr0 fr0Var, qf1 qf1Var, long j, long j2, v10 v10Var, qn qnVar, int i) {
        this.i = w40Var;
        this.e = fr0Var;
        this.j = qf1Var;
        this.f = j;
        this.g = j2;
        this.k = v10Var;
        this.l = qnVar;
        this.h = i;
    }

    @Override // defpackage.l50
    public final Object f(Object obj, Object obj2) {
        int i = this.d;
        bw1 bw1Var = bw1.a;
        int i2 = this.h;
        Object obj3 = this.l;
        Object obj4 = this.k;
        Object obj5 = this.j;
        Object obj6 = this.i;
        switch (i) {
            case 0:
                ((Integer) obj2).getClass();
                int iT = bm.T(i2 | 1);
                vl.c((w40) obj6, this.e, (qf1) obj5, this.f, this.g, (v10) obj4, (qn) obj3, (xo) obj, iT);
                break;
            default:
                ((Integer) obj2).getClass();
                int iT2 = bm.T(i2 | 1);
                mg0.L((hc0) obj6, (String) obj5, (String) obj4, (String) obj3, this.e, this.f, this.g, (xo) obj, iT2);
                break;
        }
        return bw1Var;
    }

    public /* synthetic */ a20(hc0 hc0Var, String str, String str2, String str3, fr0 fr0Var, long j, long j2, int i) {
        this.i = hc0Var;
        this.j = str;
        this.k = str2;
        this.l = str3;
        this.e = fr0Var;
        this.f = j;
        this.g = j2;
        this.h = i;
    }
}
