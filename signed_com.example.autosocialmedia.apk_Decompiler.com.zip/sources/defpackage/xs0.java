package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class xs0 extends ys0 implements qh0, h50 {
    public xs0(String str, String str2) {
        super(oi.d, wd1.class, str, str2, 1);
    }

    @Override // defpackage.pi
    public final kh0 d() {
        f71.a.getClass();
        return this;
    }

    @Override // defpackage.h50
    public final Object g(Object obj) {
        j();
        throw null;
    }

    public final void j() {
        if (this.j) {
            throw new UnsupportedOperationException("Kotlin reflection is not yet supported for synthetic Java properties. Please follow/upvote https://youtrack.jetbrains.com/issue/KT-55980");
        }
        kh0 kh0VarH = h();
        if (kh0VarH == this) {
            throw new hs("Kotlin reflection implementation is not found at runtime. Make sure you have kotlin-reflect.jar in the classpath");
        }
        ((xs0) ((qh0) kh0VarH)).j();
    }
}
