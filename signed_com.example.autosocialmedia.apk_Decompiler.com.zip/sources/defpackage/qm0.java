package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class qm0 extends rm0 {
    public static final int $stable = 8;
    private final jm0 info;

    public qm0(jm0 jm0Var) {
        this.info = jm0Var;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        return (obj instanceof qm0) && ng0.o(this.info, ((qm0) obj).info);
    }

    public final int hashCode() {
        return this.info.hashCode();
    }

    public final String toString() {
        return "Ok(info=" + this.info + ")";
    }
}
