package defpackage;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class pq0 {
    public static final pq0 d;
    public static final pq0 e;
    public static final /* synthetic */ pq0[] f;

    static {
        pq0 pq0Var = new pq0("Width", 0);
        d = pq0Var;
        pq0 pq0Var2 = new pq0("Height", 1);
        e = pq0Var2;
        f = new pq0[]{pq0Var, pq0Var2};
    }

    public static pq0 valueOf(String str) {
        return (pq0) Enum.valueOf(pq0.class, str);
    }

    public static pq0[] values() {
        return (pq0[]) f.clone();
    }
}
