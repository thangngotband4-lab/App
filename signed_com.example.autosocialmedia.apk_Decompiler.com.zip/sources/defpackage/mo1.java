package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class mo1 extends jl1 implements h50 {
    public final /* synthetic */ int e;
    public final /* synthetic */ so1 f;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ mo1(so1 so1Var, tq tqVar, int i) {
        super(1, tqVar);
        this.e = i;
        this.f = so1Var;
    }

    @Override // defpackage.h50
    public final Object g(Object obj) {
        int i = this.e;
        bw1 bw1Var = bw1.a;
        so1 so1Var = this.f;
        tq tqVar = (tq) obj;
        switch (i) {
            case 0:
                new mo1(so1Var, tqVar, 0).r(bw1Var);
                break;
            case 1:
                new mo1(so1Var, tqVar, 1).r(bw1Var);
                break;
            case 2:
                new mo1(so1Var, tqVar, 2).r(bw1Var);
                break;
            default:
                new mo1(so1Var, tqVar, 3).r(bw1Var);
                break;
        }
        return bw1Var;
    }

    @Override // defpackage.kf
    public final Object r(Object obj) {
        int i = this.e;
        bw1 bw1Var = bw1.a;
        so1 so1Var = this.f;
        switch (i) {
            case 0:
                vl.Q(obj);
                so1Var.A = false;
                break;
            case 1:
                vl.Q(obj);
                so1Var.f();
                break;
            case 2:
                vl.Q(obj);
                so1Var.d(so1Var.A);
                break;
            default:
                vl.Q(obj);
                so1Var.p();
                break;
        }
        return bw1Var;
    }
}
