package defpackage;

import java.util.AbstractCollection;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.ListIterator;
import java.util.NoSuchElementException;
import java.util.RandomAccess;
import java.util.Set;

/* JADX INFO: loaded from: classes.dex */
public abstract class il extends pl {
    public static double U(ArrayList arrayList) {
        int size = arrayList.size();
        double dFloatValue = 0.0d;
        int i = 0;
        int i2 = 0;
        while (i2 < size) {
            Object obj = arrayList.get(i2);
            i2++;
            dFloatValue += (double) ((Number) obj).floatValue();
            i++;
            if (i < 0) {
                kl.P();
                throw null;
            }
        }
        if (i == 0) {
            return Double.NaN;
        }
        return dFloatValue / ((double) i);
    }

    public static boolean V(Iterable iterable, Object obj) {
        int iIndexOf;
        iterable.getClass();
        if (iterable instanceof Collection) {
            return ((Collection) iterable).contains(obj);
        }
        if (!(iterable instanceof List)) {
            Iterator it = iterable.iterator();
            int i = 0;
            while (true) {
                if (!it.hasNext()) {
                    iIndexOf = -1;
                    break;
                }
                Object next = it.next();
                if (i < 0) {
                    kl.Q();
                    throw null;
                }
                if (ng0.o(obj, next)) {
                    iIndexOf = i;
                    break;
                }
                i++;
            }
        } else {
            iIndexOf = ((List) iterable).indexOf(obj);
        }
        return iIndexOf >= 0;
    }

    public static Object W(List list) {
        list.getClass();
        if (list.isEmpty()) {
            throw new NoSuchElementException("List is empty.");
        }
        return list.get(0);
    }

    public static Object X(List list) {
        list.getClass();
        if (list.isEmpty()) {
            return null;
        }
        return list.get(0);
    }

    public static final void Y(Iterable iterable, StringBuilder sb, CharSequence charSequence, CharSequence charSequence2, CharSequence charSequence3, CharSequence charSequence4, h50 h50Var) {
        iterable.getClass();
        sb.append(charSequence2);
        int i = 0;
        for (Object obj : iterable) {
            i++;
            if (i > 1) {
                sb.append(charSequence);
            }
            ck1.a(sb, obj, h50Var);
        }
        sb.append(charSequence3);
    }

    public static /* synthetic */ void Z(List list, StringBuilder sb, l lVar, int i) {
        if ((i & 64) != 0) {
            lVar = null;
        }
        Y(list, sb, "\n", "", "", "...", lVar);
    }

    public static String a0(Iterable iterable, String str, String str2, String str3, h50 h50Var, int i) {
        if ((i & 1) != 0) {
            str = ", ";
        }
        String str4 = str;
        String str5 = (i & 2) != 0 ? "" : str2;
        String str6 = (i & 4) != 0 ? "" : str3;
        if ((i & 32) != 0) {
            h50Var = null;
        }
        iterable.getClass();
        StringBuilder sb = new StringBuilder();
        Y(iterable, sb, str4, str5, str6, "...", h50Var);
        return sb.toString();
    }

    public static Object b0(List list) {
        list.getClass();
        if (list.isEmpty()) {
            throw new NoSuchElementException("List is empty.");
        }
        return list.get(list.size() - 1);
    }

    public static Object c0(List list) {
        list.getClass();
        if (list.isEmpty()) {
            return null;
        }
        return list.get(list.size() - 1);
    }

    public static ArrayList d0(Collection collection, Iterable iterable) {
        collection.getClass();
        iterable.getClass();
        if (!(iterable instanceof Collection)) {
            ArrayList arrayList = new ArrayList(collection);
            pl.T(iterable, arrayList);
            return arrayList;
        }
        Collection collection2 = (Collection) iterable;
        ArrayList arrayList2 = new ArrayList(collection2.size() + collection.size());
        arrayList2.addAll(collection);
        arrayList2.addAll(collection2);
        return arrayList2;
    }

    public static ArrayList e0(Collection collection, Object obj) {
        collection.getClass();
        ArrayList arrayList = new ArrayList(collection.size() + 1);
        arrayList.addAll(collection);
        arrayList.add(obj);
        return arrayList;
    }

    public static List f0(ArrayList arrayList, Comparator comparator) {
        arrayList.getClass();
        if (arrayList.size() <= 1) {
            return j0(arrayList);
        }
        Object[] array = arrayList.toArray(new Object[0]);
        array.getClass();
        if (array.length > 1) {
            Arrays.sort(array, comparator);
        }
        List listAsList = Arrays.asList(array);
        listAsList.getClass();
        return listAsList;
    }

    public static List g0(int i, List list) {
        list.getClass();
        if (i < 0) {
            tz.e(f0.j(i, "Requested element count ", " is less than zero."));
            return null;
        }
        uz uzVar = uz.d;
        if (i == 0) {
            return uzVar;
        }
        if (i >= list.size()) {
            return j0(list);
        }
        if (i == 1) {
            return jl.B(W(list));
        }
        ArrayList arrayList = new ArrayList(i);
        Iterator it = list.iterator();
        int i2 = 0;
        while (it.hasNext()) {
            arrayList.add(it.next());
            i2++;
            if (i2 == i) {
                break;
            }
        }
        int size = arrayList.size();
        return size != 0 ? size != 1 ? arrayList : jl.B(arrayList.get(0)) : uzVar;
    }

    public static List h0(int i, List list) {
        if (i < 0) {
            tz.e(f0.j(i, "Requested element count ", " is less than zero."));
            return null;
        }
        if (i == 0) {
            return uz.d;
        }
        int size = list.size();
        if (i >= size) {
            return j0(list);
        }
        if (i == 1) {
            return jl.B(b0(list));
        }
        ArrayList arrayList = new ArrayList(i);
        if (list instanceof RandomAccess) {
            for (int i2 = size - i; i2 < size; i2++) {
                arrayList.add(list.get(i2));
            }
        } else {
            ListIterator listIterator = list.listIterator(size - i);
            while (listIterator.hasNext()) {
                arrayList.add(listIterator.next());
            }
        }
        return arrayList;
    }

    public static final void i0(Iterable iterable, AbstractCollection abstractCollection) {
        iterable.getClass();
        Iterator it = iterable.iterator();
        while (it.hasNext()) {
            abstractCollection.add(it.next());
        }
    }

    public static List j0(Iterable iterable) {
        ArrayList arrayList;
        iterable.getClass();
        boolean z = iterable instanceof Collection;
        uz uzVar = uz.d;
        if (!z) {
            if (z) {
                arrayList = new ArrayList((Collection) iterable);
            } else {
                arrayList = new ArrayList();
                i0(iterable, arrayList);
            }
            int size = arrayList.size();
            return size != 0 ? size != 1 ? arrayList : jl.B(arrayList.get(0)) : uzVar;
        }
        Collection collection = (Collection) iterable;
        int size2 = collection.size();
        if (size2 == 0) {
            return uzVar;
        }
        if (size2 != 1) {
            return new ArrayList(collection);
        }
        return jl.B(iterable instanceof List ? ((List) iterable).get(0) : collection.iterator().next());
    }

    public static ArrayList k0(Collection collection) {
        collection.getClass();
        return new ArrayList(collection);
    }

    public static Set l0(List list) {
        list.getClass();
        int size = list.size();
        if (size == 0) {
            return yz.d;
        }
        if (size != 1) {
            LinkedHashSet linkedHashSet = new LinkedHashSet(om.K(list.size()));
            i0(list, linkedHashSet);
            return linkedHashSet;
        }
        Set setSingleton = Collections.singleton(list.get(0));
        setSingleton.getClass();
        return setSingleton;
    }
}
