package defpackage;

import android.os.Build;
import android.view.autofill.AutofillValue;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class ot1 extends xk {
    public boolean P;
    public h50 Q;
    public final y8 R;

    public ot1(boolean z, ks0 ks0Var, boolean z2, a91 a91Var, h50 h50Var) {
        super(ks0Var, null, false, z2, null, a91Var, new gk(h50Var, z, 2));
        this.P = z;
        this.Q = h50Var;
        this.R = new y8(25, this);
    }

    @Override // defpackage.xk
    public final void P0(yd1 yd1Var) {
        wd1.e(yd1Var, this.P ? pt1.d : pt1.e);
        l6 l6Var = a4.v;
        xd1 xd1Var = ud1.r;
        qh0[] qh0VarArr = wd1.a;
        qh0 qh0Var = qh0VarArr[9];
        yd1Var.a(xd1Var, l6Var);
        h7 h7Var = Build.VERSION.SDK_INT >= 26 ? new h7(AutofillValue.forToggle(this.P)) : null;
        if (h7Var != null) {
            xd1 xd1Var2 = ud1.s;
            qh0 qh0Var2 = qh0VarArr[10];
            yd1Var.a(xd1Var2, h7Var);
        }
        wd1.b(yd1Var, new nt1(yd1Var, 0));
    }
}
