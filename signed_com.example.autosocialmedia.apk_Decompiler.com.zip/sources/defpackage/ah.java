package defpackage;

import java.util.concurrent.CancellationException;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class ah {
    public final it0 a;

    public ah(int i) {
        switch (i) {
            case 1:
                this.a = new it0(new ck0[16]);
                break;
            default:
                this.a = new it0(new eq[16]);
                break;
        }
    }

    public void a(CancellationException cancellationException) {
        it0 it0Var = this.a;
        int i = it0Var.f;
        vi[] viVarArr = new vi[i];
        for (int i2 = 0; i2 < i; i2++) {
            viVarArr[i2] = ((eq) it0Var.d[i2]).b;
        }
        for (int i3 = 0; i3 < i; i3++) {
            viVarArr[i3].l(cancellationException);
        }
        if (it0Var.f == 0) {
            return;
        }
        vd0.c("uncancelled requests present");
    }

    public void b() {
        it0 it0Var = this.a;
        uf0 uf0VarR = tl.R(0, it0Var.f);
        int i = uf0VarR.d;
        int i2 = uf0VarR.e;
        if (i <= i2) {
            while (true) {
                ((eq) it0Var.d[i]).b.h(bw1.a);
                if (i == i2) {
                    break;
                } else {
                    i++;
                }
            }
        }
        it0Var.g();
    }
}
