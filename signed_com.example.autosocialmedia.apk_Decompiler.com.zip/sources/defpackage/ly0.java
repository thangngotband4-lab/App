package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class ly0 extends ny0 {
    public static final ly0 c = new ly0(1, 0, 2);

    @Override // defpackage.ny0
    public final void a(y50 y50Var, ad adVar, mh1 mh1Var, l71 l71Var, oy0 oy0Var) {
        int iC = y50Var.c(0);
        for (int i = 0; i < iC; i++) {
            adVar.q();
        }
    }
}
