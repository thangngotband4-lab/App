package defpackage;

import android.content.Context;
import java.util.ArrayList;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class b70 implements m50 {
    public final /* synthetic */ int d;
    public final /* synthetic */ w40 e;
    public final /* synthetic */ w40 f;
    public final /* synthetic */ Object g;
    public final /* synthetic */ Object h;
    public final /* synthetic */ Object i;
    public final /* synthetic */ Object j;

    public /* synthetic */ b70(w40 w40Var, w40 w40Var2, Object obj, Object obj2, Object obj3, Object obj4, int i) {
        this.d = i;
        this.e = w40Var;
        this.f = w40Var2;
        this.g = obj;
        this.h = obj2;
        this.i = obj3;
        this.j = obj4;
    }

    @Override // defpackage.m50
    public final Object c(Object obj, Object obj2, Object obj3) {
        boolean z;
        int i = this.d;
        bw1 bw1Var = bw1.a;
        dp1 dp1Var = ro.a;
        cr0 cr0Var = cr0.a;
        Object obj4 = this.j;
        Object obj5 = this.i;
        Object obj6 = this.h;
        Object obj7 = this.g;
        switch (i) {
            case 0:
                w40 w40Var = (w40) obj7;
                w40 w40Var2 = (w40) obj6;
                w40 w40Var3 = (w40) obj5;
                Context context = (Context) obj4;
                xo xoVar = (xo) obj2;
                int iIntValue = ((Integer) obj3).intValue();
                ((bk0) obj).getClass();
                if (!xoVar.O(iIntValue & 1, (iIntValue & 17) != 16)) {
                    xoVar.R();
                } else {
                    fr0 fr0VarC = y5.C(cr0Var, 16.0f, 0.0f, 2);
                    km kmVarA = im.a(new hd(12.0f, new dd(0)), a4.q, xoVar, 6);
                    int iHashCode = Long.hashCode(xoVar.T);
                    t11 t11VarL = xoVar.l();
                    fr0 fr0VarM = om.M(xoVar, fr0VarC);
                    oo.b.getClass();
                    kp kpVar = no.b;
                    xoVar.Z();
                    if (xoVar.S) {
                        xoVar.k(kpVar);
                    } else {
                        xoVar.j0();
                    }
                    ak1.o(xoVar, no.e, kmVarA);
                    ak1.o(xoVar, no.d, t11VarL);
                    ak1.j(xoVar, Integer.valueOf(iHashCode), no.f);
                    ak1.n(xoVar, no.g);
                    ak1.o(xoVar, no.c, fr0VarM);
                    e70.d(fl.p(), "Auto GoLike TikTok", "Tự động like, follow, xem video kiếm xu", sl.b, true, this.e, xoVar, 28080);
                    e70.d(hl.A(), "Auto GoLike Instagram", "Follow/Like/Comment qua API — không cần Trợ năng", sl.d(), true, this.f, xoVar, 25008);
                    e70.d(vh0.x(), "Auto GoLike X", "Follow/Like/Comment Twitter qua API — không cần Trợ năng", sl.a(), true, w40Var, xoVar, 25008);
                    e70.d(vh0.x(), "Auto GoLike Threads", "Follow/Like Threads qua API — không cần Trợ năng", sl.b(), true, w40Var2, xoVar, 25008);
                    e70.d(vl.z(), "Auto GoLike YouTube", "Subscribe/Comment YouTube qua API — không cần Trợ năng", e70.a, true, w40Var3, xoVar, 28080);
                    hc0 hc0VarX = jl.x();
                    long j = sl.d;
                    boolean zH = xoVar.h(context);
                    Object objL = xoVar.L();
                    if (zH || objL == dp1Var) {
                        z = true;
                        objL = new f3(context, 1);
                        xoVar.g0(objL);
                    } else {
                        z = true;
                    }
                    e70.d(hc0VarX, "Auto GoLike Facebook", "Đang phát triển — sắp có mặt", j, false, (w40) objL, xoVar, 28080);
                    xoVar.p(z);
                }
                break;
            default:
                gt0 gt0Var = (gt0) obj7;
                gt0 gt0Var2 = (gt0) obj6;
                gt0 gt0Var3 = (gt0) obj5;
                gt0 gt0Var4 = (gt0) obj4;
                xo xoVar2 = (xo) obj2;
                int iIntValue2 = ((Integer) obj3).intValue();
                ((bk0) obj).getClass();
                if (!xoVar2.O(iIntValue2 & 1, (iIntValue2 & 17) != 16)) {
                    xoVar2.R();
                } else {
                    fr0 fr0VarC2 = y5.C(cr0Var, 16.0f, 0.0f, 2);
                    km kmVarA2 = im.a(new hd(12.0f, new dd(0)), a4.q, xoVar2, 6);
                    int iHashCode2 = Long.hashCode(xoVar2.T);
                    t11 t11VarL2 = xoVar2.l();
                    fr0 fr0VarM2 = om.M(xoVar2, fr0VarC2);
                    oo.b.getClass();
                    kp kpVar2 = no.b;
                    xoVar2.Z();
                    if (xoVar2.S) {
                        xoVar2.k(kpVar2);
                    } else {
                        xoVar2.j0();
                    }
                    ak1.o(xoVar2, no.e, kmVarA2);
                    ak1.o(xoVar2, no.d, t11VarL2);
                    ak1.j(xoVar2, Integer.valueOf(iHashCode2), no.f);
                    ak1.n(xoVar2, no.g);
                    ak1.o(xoVar2, no.c, fr0VarM2);
                    hc0 hc0VarX2 = tl.x();
                    boolean zBooleanValue = ((Boolean) gt0Var.getValue()).booleanValue();
                    Object objL2 = xoVar2.L();
                    if (objL2 == dp1Var) {
                        objL2 = new qp0(gt0Var, 26);
                        xoVar2.g0(objL2);
                    }
                    long j2 = sl.b;
                    ct.j(hc0VarX2, "Auto GoLike", "Tự động like video theo hashtag, trending", zBooleanValue, (h50) objL2, null, j2, this.e, xoVar2, 1597872, 32);
                    hc0 hc0VarB = bm.f;
                    if (hc0VarB == null) {
                        gc0 gc0Var = new gc0("Rounded.SmartDisplay", 24.0f, 24.0f, 24.0f, 24.0f, 0L, 0, false, 96);
                        int i2 = lx1.a;
                        pi1 pi1Var = new pi1(ql.b);
                        l1 l1Var = new l1(16);
                        l1Var.v(20.0f, 4.0f);
                        l1Var.q(4.0f);
                        l1Var.l(2.9f, 4.0f, 2.0f, 4.9f, 2.0f, 6.0f);
                        l1Var.I(12.0f);
                        l1Var.m(0.0f, 1.1f, 0.9f, 2.0f, 2.0f, 2.0f);
                        l1Var.r(16.0f);
                        l1Var.m(1.1f, 0.0f, 2.0f, -0.9f, 2.0f, -2.0f);
                        l1Var.H(6.0f);
                        l1Var.l(22.0f, 4.9f, 21.1f, 4.0f, 20.0f, 4.0f);
                        l1Var.i();
                        l1Var.v(9.5f, 14.67f);
                        l1Var.H(9.33f);
                        l1Var.m(0.0f, -0.79f, 0.88f, -1.27f, 1.54f, -0.84f);
                        l1Var.u(4.15f, 2.67f);
                        l1Var.m(0.61f, 0.39f, 0.61f, 1.29f, 0.0f, 1.68f);
                        l1Var.u(-4.15f, 2.67f);
                        l1Var.l(10.38f, 15.94f, 9.5f, 15.46f, 9.5f, 14.67f);
                        l1Var.i();
                        gc0.a(gc0Var, (ArrayList) l1Var.e, pi1Var);
                        hc0VarB = gc0Var.b();
                        bm.f = hc0VarB;
                    }
                    hc0 hc0Var = hc0VarB;
                    boolean zBooleanValue2 = ((Boolean) gt0Var2.getValue()).booleanValue();
                    Object objL3 = xoVar2.L();
                    if (objL3 == dp1Var) {
                        objL3 = new qp0(gt0Var2, 27);
                        xoVar2.g0(objL3);
                    }
                    long j3 = sl.c;
                    ct.j(hc0Var, "Nuôi TikTok", "Tự động xem video, tăng watch time cho tài khoản", zBooleanValue2, (h50) objL3, null, j3, this.f, xoVar2, 1597872, 32);
                    hc0 hc0VarQ = fl.q();
                    boolean zBooleanValue3 = ((Boolean) gt0Var3.getValue()).booleanValue();
                    Object objL4 = xoVar2.L();
                    if (objL4 == dp1Var) {
                        objL4 = new qp0(gt0Var3, 28);
                        xoVar2.g0(objL4);
                    }
                    ct.j(hc0VarQ, "Auto Follow", "Follow/Unfollow tự động theo chiến lược", zBooleanValue3, (h50) objL4, null, j2, null, xoVar2, 1597872, 160);
                    hc0 hc0VarW = om.w();
                    boolean zBooleanValue4 = ((Boolean) gt0Var4.getValue()).booleanValue();
                    Object objL5 = xoVar2.L();
                    if (objL5 == dp1Var) {
                        objL5 = new qp0(gt0Var4, 29);
                        xoVar2.g0(objL5);
                    }
                    ct.j(hc0VarW, "Auto Comment", "Bình luận tự động với template đa dạng", zBooleanValue4, (h50) objL5, null, j3, null, xoVar2, 1597872, 160);
                    xoVar2.p(true);
                }
                break;
        }
        return bw1Var;
    }
}
