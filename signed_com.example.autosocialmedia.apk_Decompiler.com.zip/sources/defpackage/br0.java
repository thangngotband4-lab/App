package defpackage;

import java.util.LinkedHashMap;
import java.util.Map;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class br0 extends er0 implements hp, zi0 {
    public LinkedHashMap r;

    @Override // defpackage.zi0
    public final mq0 d(nq0 nq0Var, gq0 gq0Var, long j) {
        float f = ((hw) rm.x(this, dg0.c)).d;
        if (f < 0.0f) {
            f = 0.0f;
        }
        k21 k21VarE = gq0Var.e(j);
        boolean z = this.q && !Float.isNaN(f) && hw.a(f, 0.0f) > 0;
        int iP = !Float.isNaN(f) ? nq0Var.P(f) : 0;
        int iMax = k21VarE.d;
        if (z) {
            iMax = Math.max(iMax, iP);
        }
        int iMax2 = k21VarE.e;
        if (z) {
            iMax2 = Math.max(iMax2, iP);
        }
        if (z) {
            LinkedHashMap linkedHashMap = this.r;
            if (linkedHashMap == null) {
                linkedHashMap = new LinkedHashMap(2);
                this.r = linkedHashMap;
            }
            ey1 ey1Var = dg0.b;
            int iRound = Math.round((iP - k21VarE.d) / 2.0f);
            if (iRound < 0) {
                iRound = 0;
            }
            linkedHashMap.put(ey1Var, Integer.valueOf(iRound));
            hb0 hb0Var = dg0.a;
            int iRound2 = Math.round((iP - k21VarE.e) / 2.0f);
            linkedHashMap.put(hb0Var, Integer.valueOf(iRound2 >= 0 ? iRound2 : 0));
        }
        Map map = this.r;
        if (map == null) {
            map = vz.d;
        }
        return nq0Var.i0(iMax, iMax2, map, new ke0(iMax, iMax2, k21VarE));
    }
}
