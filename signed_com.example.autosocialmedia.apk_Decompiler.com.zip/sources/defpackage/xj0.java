package defpackage;

import kotlin.Metadata;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u000e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0001\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001¨\u0006\u0003"}, d2 = {"Lxj0;", "Ljr0;", "Lyj0;", "foundation-layout"}, k = 1, mv = {2, 0, 0}, xi = 48)
public final class xj0 extends jr0 {
    public final float a;
    public final boolean b;

    public xj0(float f, boolean z) {
        this.a = f;
        this.b = z;
    }

    @Override // defpackage.jr0
    public final er0 e() {
        yj0 yj0Var = new yj0();
        yj0Var.r = this.a;
        yj0Var.s = this.b;
        return yj0Var;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        xj0 xj0Var = obj instanceof xj0 ? (xj0) obj : null;
        return xj0Var != null && this.a == xj0Var.a && this.b == xj0Var.b;
    }

    @Override // defpackage.jr0
    public final void f(er0 er0Var) {
        yj0 yj0Var = (yj0) er0Var;
        yj0Var.r = this.a;
        yj0Var.s = this.b;
    }

    public final int hashCode() {
        return Boolean.hashCode(this.b) + (Float.hashCode(this.a) * 31);
    }
}
