package defpackage;

import android.os.Trace;
import android.view.Choreographer;
import android.view.View;
import java.util.PriorityQueue;
import java.util.concurrent.TimeUnit;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class x8 implements r41, View.OnAttachStateChangeListener, Runnable, Choreographer.FrameCallback {
    public static long k;
    public final View d;
    public boolean f;
    public boolean i;
    public long j;
    public final PriorityQueue e = new PriorityQueue(11, new v8(0));
    public final Choreographer g = Choreographer.getInstance();
    public final w8 h = new w8();

    /* JADX WARN: Removed duplicated region for block: B:10:0x0040  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public x8(android.view.View r5) {
        /*
            r4 = this;
            r4.<init>()
            r4.d = r5
            java.util.PriorityQueue r0 = new java.util.PriorityQueue
            v8 r1 = new v8
            r2 = 0
            r1.<init>(r2)
            r2 = 11
            r0.<init>(r2, r1)
            r4.e = r0
            android.view.Choreographer r0 = android.view.Choreographer.getInstance()
            r4.g = r0
            w8 r0 = new w8
            r0.<init>()
            r4.h = r0
            long r0 = defpackage.x8.k
            r2 = 0
            int r0 = (r0 > r2 ? 1 : (r0 == r2 ? 0 : -1))
            if (r0 != 0) goto L49
            android.view.Display r0 = r5.getDisplay()
            boolean r1 = r5.isInEditMode()
            if (r1 != 0) goto L40
            if (r0 == 0) goto L40
            float r0 = r0.getRefreshRate()
            r1 = 1106247680(0x41f00000, float:30.0)
            int r1 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r1 < 0) goto L40
            goto L42
        L40:
            r0 = 1114636288(0x42700000, float:60.0)
        L42:
            r1 = 1315859240(0x4e6e6b28, float:1.0E9)
            float r1 = r1 / r0
            long r0 = (long) r1
            defpackage.x8.k = r0
        L49:
            r5.addOnAttachStateChangeListener(r4)
            boolean r5 = r5.isAttachedToWindow()
            if (r5 == 0) goto L55
            r5 = 1
            r4.i = r5
        L55:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.x8.<init>(android.view.View):void");
    }

    @Override // defpackage.r41
    public final void a(q41 q41Var) {
        this.e.add(new b51(1, q41Var));
        if (this.f) {
            return;
        }
        this.f = true;
        this.d.post(this);
    }

    public final boolean b() {
        w8 w8Var = this.h;
        long jA = w8Var.a();
        m22.G(jA, "compose:lazy:prefetch:available_time_nanos");
        boolean z = true;
        if (jA > 0) {
            PriorityQueue priorityQueue = this.e;
            Object objPeek = priorityQueue.peek();
            objPeek.getClass();
            if (!((b51) objPeek).b.c(w8Var)) {
                priorityQueue.poll();
                z = false;
            }
            w8Var.a = false;
        }
        return z;
    }

    @Override // android.view.Choreographer.FrameCallback
    public final void doFrame(long j) {
        if (this.i) {
            this.j = j;
            this.d.post(this);
        }
    }

    @Override // android.view.View.OnAttachStateChangeListener
    public final void onViewAttachedToWindow(View view) {
        this.i = true;
    }

    @Override // android.view.View.OnAttachStateChangeListener
    public final void onViewDetachedFromWindow(View view) {
        this.i = false;
        this.d.removeCallbacks(this);
        this.g.removeFrameCallback(this);
    }

    @Override // java.lang.Runnable
    public final void run() {
        PriorityQueue priorityQueue = this.e;
        if (!priorityQueue.isEmpty() && this.f && this.i) {
            View view = this.d;
            if (view.getWindowVisibility() == 0) {
                long nanos = TimeUnit.MILLISECONDS.toNanos(view.getDrawingTime());
                boolean z = System.nanoTime() > (2 * k) + nanos;
                w8 w8Var = this.h;
                w8Var.a = z;
                w8Var.b = Math.max(this.j, nanos) + k;
                boolean zB = false;
                while (!priorityQueue.isEmpty() && !zB) {
                    if (w8Var.a) {
                        Trace.beginSection("compose:lazy:prefetch:idle_frame");
                        try {
                            zB = b();
                        } finally {
                            Trace.endSection();
                        }
                    } else {
                        zB = b();
                    }
                }
                if (zB) {
                    this.g.postFrameCallback(this);
                } else {
                    this.f = false;
                }
                m22.G(0L, "compose:lazy:prefetch:available_time_nanos");
                return;
            }
        }
        this.f = false;
    }
}
