package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class qb extends ki0 implements l50 {
    public final /* synthetic */ int e;
    public final /* synthetic */ boolean f;
    public final /* synthetic */ fr0 g;
    public final /* synthetic */ k00 h;
    public final /* synthetic */ w00 i;
    public final /* synthetic */ String j;
    public final /* synthetic */ qn k;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ qb(boolean z, fr0 fr0Var, k00 k00Var, w00 w00Var, String str, qn qnVar, int i, int i2) {
        super(2);
        this.e = i2;
        this.f = z;
        this.g = fr0Var;
        this.h = k00Var;
        this.i = w00Var;
        this.j = str;
        this.k = qnVar;
    }

    @Override // defpackage.l50
    public final Object f(Object obj, Object obj2) {
        int i = this.e;
        bw1 bw1Var = bw1.a;
        switch (i) {
            case 0:
                ((Number) obj2).intValue();
                int iT = bm.T(196609);
                y5.c(this.f, this.g, this.h, this.i, this.j, this.k, (xo) obj, iT);
                break;
            default:
                ((Number) obj2).intValue();
                int iT2 = bm.T(1600519);
                y5.d(this.f, this.g, this.h, this.i, this.j, this.k, (xo) obj, iT2);
                break;
        }
        return bw1Var;
    }
}
