package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class nt0 {
    public final bh0 a;

    public nt0(bh0 bh0Var) {
        this.a = bh0Var;
    }
}
