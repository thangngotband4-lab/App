package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class iq0 {
    public final ij0 a;
    public boolean c;
    public boolean d;
    public xp i;
    public final yc b = new yc(3);
    public final ae0 e = new ae0(15);
    public final it0 f = new it0(new ij0[16]);
    public final long g = 1;
    public final it0 h = new it0(new hq0[16]);

    public iq0(ij0 ij0Var) {
        this.a = ij0Var;
    }

    /* JADX WARN: Removed duplicated region for block: B:8:0x0018  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static boolean b(defpackage.ij0 r5, defpackage.xp r6) throws java.lang.Throwable {
        /*
            ij0 r0 = r5.l
            mj0 r1 = r5.K
            r2 = 0
            if (r0 != 0) goto L8
            return r2
        L8:
            if (r6 == 0) goto L1a
            if (r0 == 0) goto L18
            jp0 r0 = r1.q
            r0.getClass()
            long r3 = r6.a
            boolean r6 = r0.B0(r3)
            goto L2f
        L18:
            r6 = r2
            goto L2f
        L1a:
            jp0 r6 = r1.q
            if (r6 == 0) goto L21
            xp r1 = r6.q
            goto L22
        L21:
            r1 = 0
        L22:
            if (r1 == 0) goto L18
            if (r0 == 0) goto L18
            r6.getClass()
            long r0 = r1.a
            boolean r6 = r6.B0(r0)
        L2f:
            ij0 r0 = r5.u()
            if (r6 == 0) goto L57
            if (r0 == 0) goto L57
            ij0 r1 = r0.l
            r3 = 3
            if (r1 != 0) goto L40
            defpackage.ij0.X(r0, r2, r3)
            return r6
        L40:
            gj0 r1 = r5.s()
            gj0 r4 = defpackage.gj0.d
            if (r1 != r4) goto L4c
            defpackage.ij0.V(r0, r2, r3)
            return r6
        L4c:
            gj0 r5 = r5.s()
            gj0 r1 = defpackage.gj0.e
            if (r5 != r1) goto L57
            r0.U(r2)
        L57:
            return r6
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.iq0.b(ij0, xp):boolean");
    }

    public static boolean c(ij0 ij0Var, xp xpVar) {
        boolean zP = xpVar != null ? ij0Var.P(xpVar) : ij0.Q(ij0Var);
        ij0 ij0VarU = ij0Var.u();
        if (zP && ij0VarU != null) {
            if (ij0Var.r() == gj0.d) {
                ij0.X(ij0VarU, false, 3);
                return zP;
            }
            if (ij0Var.r() == gj0.e) {
                ij0VarU.W(false);
            }
        }
        return zP;
    }

    public static boolean h(ij0 ij0Var) {
        jp0 jp0Var;
        jj0 jj0Var;
        if (ij0Var.K.e) {
            return (ij0Var.s() == gj0.f && ((jp0Var = ij0Var.K.q) == null || (jj0Var = jp0Var.u) == null || !jj0Var.e())) ? false : true;
        }
        return false;
    }

    public static boolean i(ij0 ij0Var) {
        if (!ij0Var.q()) {
            return false;
        }
        do {
            if (ij0Var.r() == gj0.f && !ij0Var.K.p.A.e()) {
                ij0 ij0VarU = ij0Var.u();
                if ((ij0VarU != null ? ij0VarU.K.d : null) != ej0.d) {
                    return false;
                }
            }
            ij0Var = ij0Var.u();
            if (ij0Var == null) {
                return false;
            }
        } while (!ij0Var.I());
        return true;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:13:0x0032  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void a(boolean r7) {
        /*
            r6 = this;
            r0 = 1
            ae0 r1 = r6.e
            if (r7 == 0) goto L17
            java.lang.Object r7 = r1.e
            it0 r7 = (defpackage.it0) r7
            ij0 r6 = r6.a
            int r2 = r6.T
            if (r2 <= 0) goto L17
            r7.g()
            r7.b(r6)
            r6.S = r0
        L17:
            java.lang.Object r6 = r1.e
            it0 r6 = (defpackage.it0) r6
            int r7 = r6.f
            if (r7 == 0) goto L62
            u30 r2 = defpackage.u30.d
            java.lang.Object[] r3 = r6.d
            r4 = 0
            java.util.Arrays.sort(r3, r4, r7, r2)
            int r7 = r6.f
            java.lang.Object r2 = r1.f
            ij0[] r2 = (defpackage.ij0[]) r2
            if (r2 == 0) goto L32
            int r3 = r2.length
            if (r3 >= r7) goto L3a
        L32:
            r2 = 16
            int r2 = java.lang.Math.max(r2, r7)
            ij0[] r2 = new defpackage.ij0[r2]
        L3a:
            r3 = 0
            r1.f = r3
        L3d:
            if (r4 >= r7) goto L48
            java.lang.Object[] r5 = r6.d
            r5 = r5[r4]
            r2[r4] = r5
            int r4 = r4 + 1
            goto L3d
        L48:
            r6.g()
            int r7 = r7 - r0
        L4c:
            r6 = -1
            if (r6 >= r7) goto L60
            r6 = r2[r7]
            r6.getClass()
            boolean r0 = r6.S
            if (r0 == 0) goto L5b
            defpackage.ae0.m(r6)
        L5b:
            r2[r7] = r3
            int r7 = r7 + (-1)
            goto L4c
        L60:
            r1.f = r2
        L62:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.iq0.a(boolean):void");
    }

    public final void d() {
        it0 it0Var = this.h;
        int i = it0Var.f;
        if (i != 0) {
            Object[] objArr = it0Var.d;
            for (int i2 = 0; i2 < i; i2++) {
                hq0 hq0Var = (hq0) objArr[i2];
                if (hq0Var.a.H()) {
                    boolean z = hq0Var.b;
                    ij0 ij0Var = hq0Var.a;
                    boolean z2 = hq0Var.c;
                    if (z) {
                        ij0.V(ij0Var, z2, 2);
                    } else {
                        ij0.X(ij0Var, z2, 2);
                    }
                }
            }
            it0Var.g();
        }
    }

    public final void e(ij0 ij0Var) {
        it0 it0VarY = ij0Var.y();
        Object[] objArr = it0VarY.d;
        int i = it0VarY.f;
        for (int i2 = 0; i2 < i; i2++) {
            ij0 ij0Var2 = (ij0) objArr[i2];
            if (ng0.o(ij0Var2.J(), Boolean.TRUE) && !ij0Var2.U) {
                if (this.b.b(ij0Var2)) {
                    ij0Var2.K();
                }
                e(ij0Var2);
            }
        }
    }

    public final void f(ij0 ij0Var, boolean z) {
        if (!this.c) {
            sd0.b("forceMeasureTheSubtree should be executed during the measureAndLayout pass");
        }
        if (z ? ij0Var.K.e : ij0Var.q()) {
            sd0.a("node not yet measured");
        }
        g(ij0Var, z);
    }

    public final void g(ij0 ij0Var, boolean z) {
        jp0 jp0Var;
        jj0 jj0Var;
        it0 it0VarY = ij0Var.y();
        Object[] objArr = it0VarY.d;
        int i = it0VarY.f;
        for (int i2 = 0; i2 < i; i2++) {
            ij0 ij0Var2 = (ij0) objArr[i2];
            gj0 gj0Var = gj0.d;
            if ((!z && (ij0Var2.r() == gj0Var || ij0Var2.K.p.A.e())) || (z && (ij0Var2.s() == gj0Var || ((jp0Var = ij0Var2.K.q) != null && (jj0Var = jp0Var.u) != null && jj0Var.e())))) {
                boolean z2 = fl.z(ij0Var2);
                mj0 mj0Var = ij0Var2.K;
                if (z2 && !z) {
                    if (mj0Var.e && this.b.b(ij0Var2)) {
                        m(ij0Var2, true, false);
                    } else {
                        f(ij0Var2, true);
                    }
                }
                if (z ? mj0Var.e : ij0Var2.q()) {
                    m(ij0Var2, z, false);
                }
                if (!(z ? mj0Var.e : ij0Var2.q())) {
                    g(ij0Var2, z);
                }
            }
        }
        if (z ? ij0Var.K.e : ij0Var.q()) {
            m(ij0Var, z, false);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r12v1 */
    /* JADX WARN: Type inference failed for: r12v11 */
    /* JADX WARN: Type inference failed for: r12v12 */
    /* JADX WARN: Type inference failed for: r12v13 */
    /* JADX WARN: Type inference failed for: r12v2, types: [er0] */
    /* JADX WARN: Type inference failed for: r12v3, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r12v4 */
    /* JADX WARN: Type inference failed for: r12v5 */
    /* JADX WARN: Type inference failed for: r12v6 */
    /* JADX WARN: Type inference failed for: r12v7 */
    /* JADX WARN: Type inference failed for: r12v8 */
    /* JADX WARN: Type inference failed for: r12v9, types: [er0] */
    /* JADX WARN: Type inference failed for: r13v0 */
    /* JADX WARN: Type inference failed for: r13v1 */
    /* JADX WARN: Type inference failed for: r13v10 */
    /* JADX WARN: Type inference failed for: r13v11 */
    /* JADX WARN: Type inference failed for: r13v12 */
    /* JADX WARN: Type inference failed for: r13v2 */
    /* JADX WARN: Type inference failed for: r13v3 */
    /* JADX WARN: Type inference failed for: r13v4, types: [it0] */
    /* JADX WARN: Type inference failed for: r13v6 */
    /* JADX WARN: Type inference failed for: r13v7, types: [it0] */
    /* JADX WARN: Type inference failed for: r13v8 */
    /* JADX WARN: Type inference failed for: r13v9 */
    /* JADX WARN: Type inference failed for: r14v4 */
    /* JADX WARN: Type inference failed for: r15v0 */
    /* JADX WARN: Type inference failed for: r15v1, types: [int] */
    /* JADX WARN: Type inference failed for: r15v2 */
    /* JADX WARN: Type inference failed for: r15v3, types: [int] */
    /* JADX WARN: Type inference failed for: r15v4 */
    public final boolean j(w40 w40Var) {
        boolean z;
        er0 er0Var;
        ?? K;
        boolean z2;
        ij0 ij0Var;
        boolean z3;
        yc ycVar = this.b;
        ij0 ij0Var2 = this.a;
        if (!ij0Var2.H()) {
            sd0.a("performMeasureAndLayout called with unattached root");
        }
        if (!ij0Var2.I()) {
            sd0.a("performMeasureAndLayout called with unplaced root");
        }
        if (this.c) {
            sd0.a("performMeasureAndLayout called during measure layout");
        }
        boolean z4 = false;
        if (this.i != null) {
            this.c = true;
            this.d = true;
            try {
                boolean zK = ycVar.k();
                l1 l1Var = (l1) ycVar.a;
                if (zK) {
                    z = false;
                    while (true) {
                        l1 l1Var2 = (l1) ycVar.c;
                        l1 l1Var3 = (l1) ycVar.b;
                        if (!((qi1) l1Var.e).isEmpty()) {
                            ij0Var = (ij0) ((qi1) l1Var.e).first();
                            l1Var.B(ij0Var);
                            z3 = ij0Var.l != null;
                            z2 = false;
                        } else if (!((qi1) l1Var3.e).isEmpty()) {
                            ij0Var = (ij0) ((qi1) l1Var3.e).first();
                            l1Var3.B(ij0Var);
                            z3 = ij0Var.l != null;
                            z2 = true;
                        } else {
                            if (((qi1) l1Var2.e).isEmpty()) {
                                break;
                            }
                            ij0 ij0Var3 = (ij0) ((qi1) l1Var2.e).first();
                            l1Var2.B(ij0Var3);
                            z2 = true;
                            ij0Var = ij0Var3;
                            z3 = false;
                        }
                        boolean zM = m(ij0Var, z3, z2);
                        if (!z2) {
                            if (ij0Var.K.f) {
                                ycVar.a(ij0Var, ug0.e);
                            }
                            if (ij0Var.p()) {
                                ycVar.a(ij0Var, ug0.g);
                            }
                        }
                        if (ij0Var == ij0Var2 && zM) {
                            z = true;
                        }
                    }
                    if (w40Var != null) {
                        w40Var.a();
                    }
                } else {
                    z = false;
                }
            } finally {
            }
        } else {
            z = false;
        }
        it0 it0Var = this.f;
        Object[] objArr = it0Var.d;
        int i = it0Var.f;
        int i2 = 0;
        while (i2 < i) {
            nu0 nu0Var = ((ij0) objArr[i2]).J;
            yd0 yd0Var = nu0Var.c;
            boolean zG = qu0.g(4194304);
            if (zG) {
                er0Var = yd0Var.U;
            } else {
                er0Var = yd0Var.U.h;
                if (er0Var == null) {
                }
                i2++;
                z4 = false;
            }
            i81 i81Var = pu0.P;
            er0 er0VarW0 = yd0Var.W0(zG);
            while (er0VarW0 != null && (er0VarW0.g & 4194304) != 0) {
                if ((er0VarW0.f & 4194304) != 0) {
                    ?? r12 = er0VarW0;
                    ?? it0Var2 = 0;
                    while (r12 != 0) {
                        if (r12 instanceof oi0) {
                            ((oi0) r12).n(nu0Var.c);
                        } else {
                            if ((r12.f & 4194304) != 0 && (r12 instanceof lu)) {
                                er0 er0Var2 = ((lu) r12).s;
                                ?? r15 = z4;
                                K = r12;
                                it0Var2 = it0Var2;
                                while (er0Var2 != null) {
                                    if ((er0Var2.f & 4194304) != 0) {
                                        r15++;
                                        it0Var2 = it0Var2;
                                        if (r15 == 1) {
                                            K = er0Var2;
                                        } else {
                                            if (it0Var2 == 0) {
                                                it0Var2 = new it0(new er0[16]);
                                            }
                                            if (K != 0) {
                                                it0Var2.b(K);
                                                K = 0;
                                            }
                                            it0Var2.b(er0Var2);
                                        }
                                    }
                                    er0Var2 = er0Var2.i;
                                    K = K;
                                    it0Var2 = it0Var2;
                                    r15 = r15;
                                }
                                if (r15 == 1) {
                                }
                            }
                            z4 = false;
                            r12 = K;
                            it0Var2 = it0Var2;
                        }
                        K = tl.k(it0Var2);
                        z4 = false;
                        r12 = K;
                        it0Var2 = it0Var2;
                    }
                }
                if (er0VarW0 != er0Var) {
                    er0VarW0 = er0VarW0.i;
                    z4 = false;
                }
            }
            i2++;
            z4 = false;
        }
        it0Var.g();
        return z;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r7v1 */
    /* JADX WARN: Type inference failed for: r7v10 */
    /* JADX WARN: Type inference failed for: r7v11 */
    /* JADX WARN: Type inference failed for: r7v12 */
    /* JADX WARN: Type inference failed for: r7v2, types: [er0] */
    /* JADX WARN: Type inference failed for: r7v4 */
    /* JADX WARN: Type inference failed for: r7v5, types: [er0] */
    /* JADX WARN: Type inference failed for: r7v6, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r7v7 */
    /* JADX WARN: Type inference failed for: r7v8 */
    /* JADX WARN: Type inference failed for: r7v9 */
    /* JADX WARN: Type inference failed for: r8v0 */
    /* JADX WARN: Type inference failed for: r8v1 */
    /* JADX WARN: Type inference failed for: r8v10 */
    /* JADX WARN: Type inference failed for: r8v11 */
    /* JADX WARN: Type inference failed for: r8v2 */
    /* JADX WARN: Type inference failed for: r8v3, types: [it0] */
    /* JADX WARN: Type inference failed for: r8v4 */
    /* JADX WARN: Type inference failed for: r8v5 */
    /* JADX WARN: Type inference failed for: r8v6, types: [it0] */
    /* JADX WARN: Type inference failed for: r8v8 */
    /* JADX WARN: Type inference failed for: r8v9 */
    /* JADX WARN: Type inference failed for: r9v5 */
    public final void k(ij0 ij0Var, long j) {
        er0 er0Var;
        if (ij0Var.U) {
            return;
        }
        ij0 ij0Var2 = this.a;
        if (ij0Var == ij0Var2) {
            sd0.a("measureAndLayout called on root");
        }
        if (!ij0Var2.H()) {
            sd0.a("performMeasureAndLayout called with unattached root");
        }
        if (!ij0Var2.I()) {
            sd0.a("performMeasureAndLayout called with unplaced root");
        }
        if (this.c) {
            sd0.a("performMeasureAndLayout called during measure layout");
        }
        if (this.i != null) {
            this.c = true;
            this.d = false;
            try {
                yc ycVar = this.b;
                ((l1) ycVar.a).B(ij0Var);
                ((l1) ycVar.b).B(ij0Var);
                ((l1) ycVar.c).B(ij0Var);
                if ((b(ij0Var, new xp(j)) || ij0Var.K.f) && ng0.o(ij0Var.J(), Boolean.TRUE)) {
                    ij0Var.K();
                }
                e(ij0Var);
                c(ij0Var, new xp(j));
                if (ij0Var.p() && ij0Var.I()) {
                    ij0Var.T();
                    ae0 ae0Var = this.e;
                    ae0Var.getClass();
                    if (ij0Var.T > 0) {
                        ((it0) ae0Var.e).b(ij0Var);
                        ij0Var.S = true;
                    }
                }
                d();
            } finally {
            }
        }
        it0 it0Var = this.f;
        Object[] objArr = it0Var.d;
        int i = it0Var.f;
        for (int i2 = 0; i2 < i; i2++) {
            nu0 nu0Var = ((ij0) objArr[i2]).J;
            yd0 yd0Var = nu0Var.c;
            boolean zG = qu0.g(4194304);
            if (zG) {
                er0Var = yd0Var.U;
            } else {
                er0Var = yd0Var.U.h;
                if (er0Var == null) {
                }
            }
            i81 i81Var = pu0.P;
            for (er0 er0VarW0 = yd0Var.W0(zG); er0VarW0 != null && (er0VarW0.g & 4194304) != 0; er0VarW0 = er0VarW0.i) {
                if ((er0VarW0.f & 4194304) != 0) {
                    ?? K = er0VarW0;
                    ?? it0Var2 = 0;
                    while (K != 0) {
                        if (K instanceof oi0) {
                            ((oi0) K).n(nu0Var.c);
                        } else if ((K.f & 4194304) != 0 && (K instanceof lu)) {
                            er0 er0Var2 = ((lu) K).s;
                            int i3 = 0;
                            K = K;
                            it0Var2 = it0Var2;
                            while (er0Var2 != null) {
                                if ((er0Var2.f & 4194304) != 0) {
                                    i3++;
                                    it0Var2 = it0Var2;
                                    if (i3 == 1) {
                                        K = er0Var2;
                                    } else {
                                        if (it0Var2 == 0) {
                                            it0Var2 = new it0(new er0[16]);
                                        }
                                        if (K != 0) {
                                            it0Var2.b(K);
                                            K = 0;
                                        }
                                        it0Var2.b(er0Var2);
                                    }
                                }
                                er0Var2 = er0Var2.i;
                                K = K;
                                it0Var2 = it0Var2;
                            }
                            if (i3 == 1) {
                            }
                        }
                        K = tl.k(it0Var2);
                    }
                }
                if (er0VarW0 != er0Var) {
                }
            }
        }
        it0Var.g();
    }

    public final void l() {
        yc ycVar = this.b;
        if (ycVar.k()) {
            ij0 ij0Var = this.a;
            if (!ij0Var.H()) {
                sd0.a("performMeasureAndLayout called with unattached root");
            }
            if (!ij0Var.I()) {
                sd0.a("performMeasureAndLayout called with unplaced root");
            }
            if (this.c) {
                sd0.a("performMeasureAndLayout called during measure layout");
            }
            if (this.i != null) {
                this.c = true;
                this.d = false;
                try {
                    if (!((qi1) ((l1) ycVar.c).e).isEmpty() && !((qi1) ((l1) ycVar.a).e).isEmpty()) {
                        if (ij0Var.l != null) {
                            o(ij0Var, true);
                        } else {
                            n(ij0Var);
                        }
                    }
                    o(ij0Var, false);
                } catch (Throwable th) {
                    try {
                        throw th;
                    } finally {
                        this.c = false;
                        this.d = false;
                    }
                }
            }
        }
    }

    public final boolean m(ij0 ij0Var, boolean z, boolean z2) {
        xp xpVar;
        boolean zB;
        j21 placementScope;
        yd0 yd0Var;
        ij0 ij0VarU;
        jp0 jp0Var;
        jj0 jj0Var;
        boolean z3 = ij0Var.U;
        mj0 mj0Var = ij0Var.K;
        if (z3 || (!ij0Var.I() && !mj0Var.p.w && !i(ij0Var) && !ng0.o(ij0Var.J(), Boolean.TRUE) && !h(ij0Var) && !mj0Var.p.A.e() && ((jp0Var = mj0Var.q) == null || (jj0Var = jp0Var.u) == null || !jj0Var.e()))) {
            return false;
        }
        ij0 ij0Var2 = this.a;
        if (ij0Var == ij0Var2) {
            xpVar = this.i;
            xpVar.getClass();
        } else {
            xpVar = null;
        }
        if (z) {
            zB = mj0Var.e ? b(ij0Var, xpVar) : false;
            if (z2 && ((zB || mj0Var.f) && ng0.o(ij0Var.J(), Boolean.TRUE))) {
                ij0Var.K();
            }
        } else {
            boolean zC = ij0Var.q() ? c(ij0Var, xpVar) : false;
            if (z2 && ij0Var.p() && (ij0Var == ij0Var2 || ((ij0VarU = ij0Var.u()) != null && ij0VarU.I() && mj0Var.p.w))) {
                if (ij0Var == ij0Var2) {
                    if (ij0Var.G == gj0.f) {
                        ij0Var.f();
                    }
                    ij0 ij0VarU2 = ij0Var.u();
                    if (ij0VarU2 == null || (yd0Var = ij0VarU2.J.c) == null || (placementScope = yd0Var.o) == null) {
                        placementScope = ((k5) lj0.a(ij0Var)).getPlacementScope();
                    }
                    j21.j(placementScope, mj0Var.p, 0, 0);
                } else {
                    ij0Var.T();
                }
                ae0 ae0Var = this.e;
                ae0Var.getClass();
                if (ij0Var.T > 0) {
                    ((it0) ae0Var.e).b(ij0Var);
                    ij0Var.S = true;
                }
            }
            zB = zC;
        }
        d();
        return zB;
    }

    public final void n(ij0 ij0Var) throws Throwable {
        it0 it0VarY = ij0Var.y();
        Object[] objArr = it0VarY.d;
        int i = it0VarY.f;
        for (int i2 = 0; i2 < i; i2++) {
            ij0 ij0Var2 = (ij0) objArr[i2];
            if (ij0Var2.r() == gj0.d || ij0Var2.K.p.A.e()) {
                if (fl.z(ij0Var2)) {
                    o(ij0Var2, true);
                } else {
                    n(ij0Var2);
                }
            }
        }
    }

    public final void o(ij0 ij0Var, boolean z) throws Throwable {
        xp xpVar;
        if (ij0Var.U) {
            return;
        }
        if (ij0Var == this.a) {
            xpVar = this.i;
            xpVar.getClass();
        } else {
            xpVar = null;
        }
        if (z) {
            b(ij0Var, xpVar);
        } else {
            c(ij0Var, xpVar);
        }
    }

    public final boolean p(ij0 ij0Var, boolean z) {
        int iOrdinal = ij0Var.K.d.ordinal();
        if (iOrdinal != 0 && iOrdinal != 1) {
            if (iOrdinal == 2 || iOrdinal == 3) {
                this.h.b(new hq0(ij0Var, false, z));
            } else {
                if (iOrdinal != 4) {
                    tz.c();
                    return false;
                }
                if (!ij0Var.q() || z) {
                    ij0Var.K.p.x = true;
                    if (!ij0Var.U && (ij0Var.I() || i(ij0Var))) {
                        ij0 ij0VarU = ij0Var.u();
                        if (ij0VarU == null || !ij0VarU.q()) {
                            this.b.a(ij0Var, ug0.f);
                        }
                        if (!this.d) {
                            return true;
                        }
                    }
                }
            }
        }
        return false;
    }

    public final void q(long j) {
        xp xpVar = this.i;
        if (xpVar == null ? false : xp.b(xpVar.a, j)) {
            return;
        }
        if (this.c) {
            sd0.a("updateRootConstraints called while measuring");
        }
        this.i = new xp(j);
        ij0 ij0Var = this.a;
        ij0 ij0Var2 = ij0Var.l;
        mj0 mj0Var = ij0Var.K;
        if (ij0Var2 != null) {
            mj0Var.e = true;
        }
        mj0Var.p.x = true;
        this.b.a(ij0Var, ij0Var2 != null ? ug0.d : ug0.f);
    }
}
