package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class ax0 extends er0 implements h60 {
    public h50 r;

    @Override // defpackage.h60
    public final void u(pu0 pu0Var) {
        this.r.g(pu0Var);
    }
}
