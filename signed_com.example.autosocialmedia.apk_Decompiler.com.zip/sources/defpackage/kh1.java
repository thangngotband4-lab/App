package defpackage;

import java.util.Iterator;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class kh1 implements cp, Iterable, lh0 {
    public final jh1 d;
    public final int e;
    public final int f;

    public kh1(jh1 jh1Var, int i, int i2) {
        this.d = jh1Var;
        this.e = i;
        this.f = i2;
    }

    public final boolean equals(Object obj) {
        if (!(obj instanceof kh1)) {
            return false;
        }
        kh1 kh1Var = (kh1) obj;
        return kh1Var.e == this.e && kh1Var.f == this.f && kh1Var.d == this.d;
    }

    public final int hashCode() {
        return (this.d.hashCode() * 31) + this.e;
    }

    @Override // java.lang.Iterable
    public final Iterator iterator() {
        jh1 jh1Var = this.d;
        if (jh1Var.k != this.f) {
            lh1.e();
        }
        int i = this.e;
        jh1Var.f(i);
        return new ja0(jh1Var, i + 1, jh1Var.d[(i * 5) + 3] + i);
    }
}
