package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class ck {
    public final long a;
    public final long b;
    public final long c;
    public final long d;
    public final long e;
    public final long f;
    public final long g;
    public final long h;
    public final long i;
    public final long j;
    public final long k;
    public final long l;

    public ck(long j, long j2, long j3, long j4, long j5, long j6, long j7, long j8, long j9, long j10, long j11, long j12) {
        this.a = j;
        this.b = j2;
        this.c = j3;
        this.d = j4;
        this.e = j5;
        this.f = j6;
        this.g = j7;
        this.h = j8;
        this.i = j9;
        this.j = j10;
        this.k = j11;
        this.l = j12;
    }

    public static yi1 a(pt1 pt1Var, xo xoVar) {
        if (pt1Var == pt1.e) {
            xoVar.W(1539262271);
            yi1 yi1VarU = bm.U(sr0.g, xoVar);
            xoVar.p(false);
            return yi1VarU;
        }
        xoVar.W(1539355581);
        yi1 yi1VarU2 = bm.U(sr0.f, xoVar);
        xoVar.p(false);
        return yi1VarU2;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || !(obj instanceof ck)) {
            return false;
        }
        ck ckVar = (ck) obj;
        return ql.c(this.a, ckVar.a) && ql.c(this.b, ckVar.b) && ql.c(this.c, ckVar.c) && ql.c(this.d, ckVar.d) && ql.c(this.e, ckVar.e) && ql.c(this.f, ckVar.f) && ql.c(this.g, ckVar.g) && ql.c(this.h, ckVar.h) && ql.c(this.i, ckVar.i) && ql.c(this.j, ckVar.j) && ql.c(this.k, ckVar.k) && ql.c(this.l, ckVar.l);
    }

    public final int hashCode() {
        int i = ql.h;
        return Long.hashCode(this.l) + f0.c(f0.c(f0.c(f0.c(f0.c(f0.c(f0.c(f0.c(f0.c(f0.c(Long.hashCode(this.a) * 31, 31, this.b), 31, this.c), 31, this.d), 31, this.e), 31, this.f), 31, this.g), 31, this.h), 31, this.i), 31, this.j), 31, this.k);
    }
}
