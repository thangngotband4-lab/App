package defpackage;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class hp0 {
    public static final hp0 d;
    public static final hp0 e;
    public static final hp0 f;
    public static final /* synthetic */ hp0[] g;

    static {
        hp0 hp0Var = new hp0("IsPlacedInLookahead", 0);
        d = hp0Var;
        hp0 hp0Var2 = new hp0("IsPlacedInApproach", 1);
        e = hp0Var2;
        hp0 hp0Var3 = new hp0("IsNotPlaced", 2);
        f = hp0Var3;
        g = new hp0[]{hp0Var, hp0Var2, hp0Var3};
    }

    public static hp0 valueOf(String str) {
        return (hp0) Enum.valueOf(hp0.class, str);
    }

    public static hp0[] values() {
        return (hp0[]) g.clone();
    }
}
