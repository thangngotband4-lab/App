package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class oh1 implements iy {
    public final int a;

    public oh1(int i) {
        this.a = i;
    }

    @Override // defpackage.zb
    public final rx1 a(yu1 yu1Var) {
        return new wx1(this.a);
    }

    public final boolean equals(Object obj) {
        return (obj instanceof oh1) && ((oh1) obj).a == this.a;
    }

    public final int hashCode() {
        return this.a;
    }
}
