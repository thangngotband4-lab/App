package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class qq implements w40 {
    public final /* synthetic */ int d;
    public final /* synthetic */ boolean e;
    public final /* synthetic */ w40 f;

    public /* synthetic */ qq(boolean z, w40 w40Var, int i) {
        this.d = i;
        this.e = z;
        this.f = w40Var;
    }

    @Override // defpackage.w40
    public final Object a() {
        int i = this.d;
        bw1 bw1Var = bw1.a;
        w40 w40Var = this.f;
        boolean z = this.e;
        switch (i) {
            case 0:
                if (z) {
                    w40Var.a();
                }
                break;
            default:
                if (!z) {
                    w40Var.a();
                } else {
                    te.b();
                }
                break;
        }
        return bw1Var;
    }
}
