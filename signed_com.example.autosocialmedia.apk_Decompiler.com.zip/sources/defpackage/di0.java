package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class di0 {
    public static final di0 b = new di0(null, 63);
    public final h50 a;

    public di0(h50 h50Var, int i) {
        this.a = (i & 1) != 0 ? null : h50Var;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof di0) {
            return this.a == ((di0) obj).a;
        }
        return false;
    }

    public final int hashCode() {
        h50 h50Var = this.a;
        return (h50Var != null ? h50Var.hashCode() : 0) * 28629151;
    }
}
