package defpackage;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class z71 {
    public static final z71 d;
    public static final z71 e;
    public static final /* synthetic */ z71[] f;

    static {
        z71 z71Var = new z71("Ltr", 0);
        d = z71Var;
        z71 z71Var2 = new z71("Rtl", 1);
        e = z71Var2;
        f = new z71[]{z71Var, z71Var2};
    }

    public static z71 valueOf(String str) {
        return (z71) Enum.valueOf(z71.class, str);
    }

    public static z71[] values() {
        return (z71[]) f.clone();
    }
}
