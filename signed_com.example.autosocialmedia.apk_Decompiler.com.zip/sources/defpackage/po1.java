package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class po1 implements qn1 {
    public final /* synthetic */ so1 a;
    public final /* synthetic */ boolean b;

    public po1(so1 so1Var, boolean z) {
        this.a = so1Var;
        this.b = z;
    }

    @Override // defpackage.qn1
    public final void b() {
        so1 so1Var = this.a;
        so1Var.q.setValue(null);
        so1Var.r.setValue(null);
        so1Var.t(true);
    }

    @Override // defpackage.qn1
    public final void c() {
        so1 so1Var = this.a;
        so1Var.q.setValue(null);
        so1Var.r.setValue(null);
        so1Var.t(true);
    }

    @Override // defpackage.qn1
    public final void d() {
        qp1 qp1VarD;
        boolean z = this.b;
        la0 la0Var = z ? la0.e : la0.f;
        so1 so1Var = this.a;
        so1Var.q.setValue(la0Var);
        long jA = gd1.a(so1Var.l(z));
        em0 em0Var = so1Var.d;
        if (em0Var == null || (qp1VarD = em0Var.d()) == null) {
            return;
        }
        long jE = qp1VarD.e(jA);
        so1Var.n = jE;
        so1Var.r.setValue(new jw0(jE));
        so1Var.p = 0L;
        so1Var.s = -1;
        em0 em0Var2 = so1Var.d;
        if (em0Var2 != null) {
            em0Var2.q.setValue(Boolean.TRUE);
        }
        so1Var.t(false);
    }

    @Override // defpackage.qn1
    public final void e(long j) {
        so1 so1Var = this.a;
        long jE = jw0.e(so1Var.p, j);
        so1Var.p = jE;
        so1Var.r.setValue(new jw0(jw0.e(so1Var.n, jE)));
        zo1 zo1VarN = so1Var.n();
        jw0 jw0VarI = so1Var.i();
        jw0VarI.getClass();
        so1.c(so1Var, zo1VarN, jw0VarI.a, false, this.b, a4.Y, true);
        so1Var.t(false);
    }

    @Override // defpackage.qn1
    public final void onCancel() {
    }

    @Override // defpackage.qn1
    public final void a(long j, tz tzVar) {
    }
}
