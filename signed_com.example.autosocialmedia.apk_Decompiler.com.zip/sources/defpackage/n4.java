package defpackage;

import android.view.autofill.AutofillManager;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class n4 extends ki0 implements n50 {
    public final /* synthetic */ o4 e;
    public final /* synthetic */ ij0 f;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public n4(o4 o4Var, ij0 ij0Var) {
        super(4);
        this.e = o4Var;
        this.f = ij0Var;
    }

    @Override // defpackage.n50
    public final Object m(Object obj, Object obj2, Object obj3, Object obj4) {
        int iIntValue = ((Number) obj).intValue();
        int iIntValue2 = ((Number) obj2).intValue();
        int iIntValue3 = ((Number) obj3).intValue();
        int iIntValue4 = ((Number) obj4).intValue();
        o4 o4Var = this.e;
        o4Var.i.set(iIntValue, iIntValue2, iIntValue3, iIntValue4);
        l1 l1Var = o4Var.d;
        ((AutofillManager) l1Var.e).requestAutofill(o4Var.f, this.f.e, o4Var.i);
        return bw1.a;
    }
}
