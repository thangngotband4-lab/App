package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class cr implements l50 {
    public final /* synthetic */ int d = 1;
    public final /* synthetic */ boolean e;
    public final /* synthetic */ Object f;

    public /* synthetic */ cr(mg1 mg1Var, boolean z) {
        this.f = mg1Var;
        this.e = z;
    }

    @Override // defpackage.l50
    public final Object f(Object obj, Object obj2) {
        int i = this.d;
        bw1 bw1Var = bw1.a;
        boolean z = this.e;
        Object obj3 = this.f;
        switch (i) {
            case 0:
                ((Integer) obj2).getClass();
                rm.j((so1) obj3, z, (xo) obj, bm.T(1));
                break;
            default:
                ay ayVar = (ay) obj;
                sg1 sg1Var = sg1.a;
                long jA = ((mg1) obj3).a(z, true);
                float f = sg1.b;
                ay.e0(ayVar, jA, ayVar.y(f) / 2.0f, ((jw0) obj2).a, 120);
                break;
        }
        return bw1Var;
    }

    public /* synthetic */ cr(so1 so1Var, boolean z, int i) {
        this.f = so1Var;
        this.e = z;
    }
}
