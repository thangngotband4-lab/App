package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class wy {
    public final o01 a;
    public int b;
    public int c;
    public int d;
    public int e;

    public wy(kc kcVar, long j) {
        String str = kcVar.e;
        o01 o01Var = new o01();
        o01Var.d = str;
        o01Var.b = -1;
        o01Var.c = -1;
        this.a = o01Var;
        this.b = wp1.f(j);
        this.c = wp1.e(j);
        this.d = -1;
        this.e = -1;
        int iF = wp1.f(j);
        int iE = wp1.e(j);
        if (iF < 0 || iF > str.length()) {
            zi.g(f0.q(iF, "start (", ") offset is outside of text region "), str.length());
            throw null;
        }
        if (iE < 0 || iE > str.length()) {
            zi.g(f0.q(iE, "end (", ") offset is outside of text region "), str.length());
            throw null;
        }
        if (iF <= iE) {
            return;
        }
        tz.l(f0.l("Do not set reversed range: ", iF, " > ", iE));
        throw null;
    }

    public final void a(int i, int i2) {
        long jB = jj1.b(i, i2);
        this.a.k(i, i2, "");
        long jS = tl.S(jj1.b(this.b, this.c), jB);
        h(wp1.f(jS));
        g(wp1.e(jS));
        int i3 = this.d;
        if (i3 != -1) {
            long jS2 = tl.S(jj1.b(i3, this.e), jB);
            if (wp1.c(jS2)) {
                this.d = -1;
                this.e = -1;
            } else {
                this.d = wp1.f(jS2);
                this.e = wp1.e(jS2);
            }
        }
    }

    public final char b(int i) {
        o01 o01Var = this.a;
        y50 y50Var = (y50) o01Var.e;
        if (y50Var == null) {
            return ((String) o01Var.d).charAt(i);
        }
        if (i < o01Var.b) {
            return ((String) o01Var.d).charAt(i);
        }
        int iB = y50Var.b - y50Var.b();
        int i2 = o01Var.b;
        if (i >= iB + i2) {
            return ((String) o01Var.d).charAt(i - ((iB - o01Var.c) + i2));
        }
        int i3 = i - i2;
        int i4 = y50Var.c;
        char[] cArr = (char[]) y50Var.e;
        return i3 < i4 ? cArr[i3] : cArr[(i3 - i4) + y50Var.d];
    }

    public final wp1 c() {
        int i = this.d;
        if (i != -1) {
            return new wp1(jj1.b(i, this.e));
        }
        return null;
    }

    public final void d(int i, int i2, String str) {
        o01 o01Var = this.a;
        if (i < 0 || i > o01Var.b()) {
            zi.g(f0.q(i, "start (", ") offset is outside of text region "), o01Var.b());
            return;
        }
        if (i2 < 0 || i2 > o01Var.b()) {
            zi.g(f0.q(i2, "end (", ") offset is outside of text region "), o01Var.b());
            return;
        }
        if (i > i2) {
            tz.l(f0.l("Do not set reversed range: ", i, " > ", i2));
            return;
        }
        o01Var.k(i, i2, str);
        h(str.length() + i);
        g(str.length() + i);
        this.d = -1;
        this.e = -1;
    }

    public final void e(int i, int i2) {
        o01 o01Var = this.a;
        if (i < 0 || i > o01Var.b()) {
            zi.g(f0.q(i, "start (", ") offset is outside of text region "), o01Var.b());
            return;
        }
        if (i2 < 0 || i2 > o01Var.b()) {
            zi.g(f0.q(i2, "end (", ") offset is outside of text region "), o01Var.b());
        } else if (i >= i2) {
            tz.l(f0.l("Do not set reversed or empty range: ", i, " > ", i2));
        } else {
            this.d = i;
            this.e = i2;
        }
    }

    public final void f(int i, int i2) {
        o01 o01Var = this.a;
        if (i < 0 || i > o01Var.b()) {
            zi.g(f0.q(i, "start (", ") offset is outside of text region "), o01Var.b());
            return;
        }
        if (i2 < 0 || i2 > o01Var.b()) {
            zi.g(f0.q(i2, "end (", ") offset is outside of text region "), o01Var.b());
        } else if (i > i2) {
            tz.l(f0.l("Do not set reversed range: ", i, " > ", i2));
        } else {
            h(i);
            g(i2);
        }
    }

    public final void g(int i) {
        if (!(i >= 0)) {
            td0.a("Cannot set selectionEnd to a negative value: " + i);
        }
        this.c = i;
    }

    public final void h(int i) {
        if (!(i >= 0)) {
            td0.a("Cannot set selectionStart to a negative value: " + i);
        }
        this.b = i;
    }

    public final String toString() {
        return this.a.toString();
    }
}
