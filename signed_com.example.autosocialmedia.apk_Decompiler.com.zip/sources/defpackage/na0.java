package defpackage;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class na0 {
    public static final na0 d;
    public static final na0 e;
    public static final na0 f;
    public static final /* synthetic */ na0[] g;

    static {
        na0 na0Var = new na0("None", 0);
        d = na0Var;
        na0 na0Var2 = new na0("Selection", 1);
        e = na0Var2;
        na0 na0Var3 = new na0("Cursor", 2);
        f = na0Var3;
        g = new na0[]{na0Var, na0Var2, na0Var3};
    }

    public static na0 valueOf(String str) {
        return (na0) Enum.valueOf(na0.class, str);
    }

    public static na0[] values() {
        return (na0[]) g.clone();
    }
}
