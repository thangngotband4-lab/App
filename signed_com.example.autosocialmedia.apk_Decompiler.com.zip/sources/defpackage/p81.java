package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class p81 extends ki0 implements h50 {
    public final /* synthetic */ int e;
    public final /* synthetic */ q81 f;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ p81(q81 q81Var, int i) {
        super(1);
        this.e = i;
        this.f = q81Var;
    }

    @Override // defpackage.h50
    public final Object g(Object obj) {
        int i = this.e;
        q81 q81Var = this.f;
        switch (i) {
            case 0:
                return Double.valueOf(q81Var.n.b(tl.m(((Number) obj).doubleValue(), q81Var.e, q81Var.f)));
            default:
                return Double.valueOf(tl.m(q81Var.k.b(((Number) obj).doubleValue()), q81Var.e, q81Var.f));
        }
    }
}
