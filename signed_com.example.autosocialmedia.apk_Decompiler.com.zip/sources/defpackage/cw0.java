package defpackage;

import android.content.Context;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashMap;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class cw0 {
    public static final int $stable = 8;
    private static final String CONTEXT = "asm:nurture-config:v1";
    public static final bw0 Companion = new bw0();
    private static volatile cw0 INSTANCE = null;
    private static final String K_AUTO_FOLLOW = "autoFollowEnabled";
    private static final String K_AUTO_LIKE = "autoLikeEnabled";
    private static final String K_COMMENT_POOL = "commentPool";
    private static final String K_COMMENT_RATE = "commentRatePercent";
    private static final String K_CONFIG = "config";
    private static final String K_COOLDOWN = "cooldownSecondsBetweenAccounts";
    private static final String K_DAILY_LIMIT = "dailyVideoLimit";
    private static final String K_DOWNLOAD_RATE = "downloadRatePercent";
    private static final String K_EXIT_AFTER_VIDEOS_CNT = "exitAppAfterVideosCount";
    private static final String K_EXIT_AFTER_VIDEOS_EN = "exitAppAfterVideosEnabled";
    private static final String K_EXIT_REST_MAX = "exitAppRestSecsMax";
    private static final String K_EXIT_REST_MIN = "exitAppRestSecsMin";
    private static final String K_FAVORITE_RATE = "favoriteRatePercent";
    private static final String K_FOLLOW_RATE = "followRatePercent";
    private static final String K_HUMAN_LIKE = "humanLikeEnabled";
    private static final String K_LIKE_RATE = "likeRatePercent";
    private static final String K_NIGHT_END = "nightEndHour";
    private static final String K_NIGHT_MODE = "nightModeEnabled";
    private static final String K_NIGHT_START = "nightStartHour";
    private static final String K_SELECTED = "selectedUsernames";
    private static final String K_SHARE_RATE = "shareRatePercent";
    private static final String K_VARIANT = "tiktokVariant";
    private static final String K_VERIFY_SWITCH = "verifySwitchEnabled";
    private static final String K_VIDEOS = "videosPerSession";
    private static final String K_WATCH_MAX = "watchSecondsMax";
    private static final String K_WATCH_MIN = "watchSecondsMin";
    private static final String PREFS_NAME = "asm_nurture_enc";
    private final ht0 _config;
    private final lj1 config;
    private final qc1 store;

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r20v1, types: [java.util.List] */
    /* JADX WARN: Type inference failed for: r3v5, types: [java.util.List] */
    /* JADX WARN: Type inference failed for: r4v11, types: [java.util.ArrayList] */
    /* JADX WARN: Type inference failed for: r4v7 */
    /* JADX WARN: Type inference failed for: r4v8 */
    /* JADX WARN: Type inference failed for: r7v0, types: [java.util.ArrayList] */
    /* JADX WARN: Type inference failed for: r7v1 */
    /* JADX WARN: Type inference failed for: r7v3 */
    public cw0(Context context) {
        Object d81Var;
        dv0 dv0Var;
        ?? arrayList;
        ht1 ht1Var;
        int i;
        ?? arrayList2;
        LinkedHashMap linkedHashMap = qc1.c;
        qc1 qc1VarQ = vl.q(context, PREFS_NAME);
        this.store = qc1VarQ;
        String strA = qc1VarQ.a(K_CONFIG, CONTEXT);
        if (strA == null) {
            dv0.Companion.getClass();
            dv0Var = dv0.DEFAULT;
        } else {
            try {
                JSONObject jSONObject = new JSONObject(strA);
                JSONArray jSONArrayOptJSONArray = jSONObject.optJSONArray(K_SELECTED);
                uz uzVar = uz.d;
                if (jSONArrayOptJSONArray == null) {
                    arrayList = uzVar;
                } else {
                    uf0 uf0VarR = tl.R(0, jSONArrayOptJSONArray.length());
                    arrayList = new ArrayList(ll.R(uf0VarR));
                    Iterator it = uf0VarR.iterator();
                    while (((tf0) it).f) {
                        arrayList.add(jSONArrayOptJSONArray.getString(((tf0) it).nextInt()));
                    }
                }
                int iOptInt = jSONObject.optInt(K_VIDEOS, 30);
                int iOptInt2 = jSONObject.optInt(K_WATCH_MIN, 10);
                int iOptInt3 = jSONObject.optInt(K_WATCH_MAX, 25);
                boolean zOptBoolean = jSONObject.optBoolean(K_AUTO_LIKE, true);
                int iOptInt4 = jSONObject.optInt(K_LIKE_RATE, 15);
                boolean zOptBoolean2 = jSONObject.optBoolean(K_AUTO_FOLLOW, false);
                int iOptInt5 = jSONObject.optInt(K_FOLLOW_RATE, 5);
                boolean zOptBoolean3 = jSONObject.optBoolean(K_HUMAN_LIKE, true);
                boolean zOptBoolean4 = jSONObject.optBoolean(K_VERIFY_SWITCH, true);
                int iOptInt6 = jSONObject.optInt(K_DAILY_LIMIT, dv0.MAX_VIDEOS);
                int iOptInt7 = jSONObject.optInt(K_COOLDOWN, 45);
                boolean zOptBoolean5 = jSONObject.optBoolean(K_NIGHT_MODE, false);
                int iOptInt8 = jSONObject.optInt(K_NIGHT_START, 23);
                int iOptInt9 = jSONObject.optInt(K_NIGHT_END, 6);
                gt1 gt1Var = ht1.Companion;
                String strOptString = jSONObject.has(K_VARIANT) ? jSONObject.optString(K_VARIANT) : null;
                gt1Var.getClass();
                ht1 ht1VarA = gt1.a(strOptString);
                int iOptInt10 = jSONObject.optInt(K_COMMENT_RATE, 0);
                JSONArray jSONArrayOptJSONArray2 = jSONObject.optJSONArray(K_COMMENT_POOL);
                if (jSONArrayOptJSONArray2 != null) {
                    ht1Var = ht1VarA;
                    i = iOptInt10;
                    uf0 uf0VarR2 = tl.R(0, jSONArrayOptJSONArray2.length());
                    arrayList2 = new ArrayList(ll.R(uf0VarR2));
                    Iterator it2 = uf0VarR2.iterator();
                    while (((tf0) it2).f) {
                        arrayList2.add(jSONArrayOptJSONArray2.getString(((tf0) it2).nextInt()));
                    }
                } else {
                    ht1Var = ht1VarA;
                    i = iOptInt10;
                    arrayList2 = uzVar;
                }
                d81Var = new dv0(arrayList, iOptInt, iOptInt2, iOptInt3, zOptBoolean, iOptInt4, zOptBoolean2, iOptInt5, zOptBoolean3, zOptBoolean4, iOptInt6, iOptInt7, zOptBoolean5, iOptInt8, iOptInt9, ht1Var, i, arrayList2, jSONObject.optBoolean(K_EXIT_AFTER_VIDEOS_EN, false), jSONObject.optInt(K_EXIT_AFTER_VIDEOS_CNT, 20), jSONObject.optInt(K_EXIT_REST_MIN, 30), jSONObject.optInt(K_EXIT_REST_MAX, 90), jSONObject.optInt(K_DOWNLOAD_RATE, 0), jSONObject.optInt(K_SHARE_RATE, 0), jSONObject.optInt(K_FAVORITE_RATE, 0)).B();
            } catch (Throwable th) {
                d81Var = new d81(th);
            }
            dv0.Companion.getClass();
            dv0Var = (dv0) (d81Var instanceof d81 ? dv0.DEFAULT : d81Var);
        }
        nj1 nj1VarF = eq0.f(dv0Var);
        this._config = nj1VarF;
        this.config = nj1VarF;
    }

    public final lj1 c() {
        return this.config;
    }

    public final void d(dv0 dv0Var) throws JSONException {
        dv0 dv0VarB = dv0Var.B();
        JSONObject jSONObject = new JSONObject();
        jSONObject.put(K_SELECTED, new JSONArray((Collection) dv0VarB.t()));
        jSONObject.put(K_VIDEOS, dv0VarB.x());
        jSONObject.put(K_WATCH_MIN, dv0VarB.z());
        jSONObject.put(K_WATCH_MAX, dv0VarB.y());
        jSONObject.put(K_AUTO_LIKE, dv0VarB.c());
        jSONObject.put(K_LIKE_RATE, dv0VarB.p());
        jSONObject.put(K_AUTO_FOLLOW, dv0VarB.b());
        jSONObject.put(K_FOLLOW_RATE, dv0VarB.n());
        jSONObject.put(K_HUMAN_LIKE, dv0VarB.o());
        jSONObject.put(K_VERIFY_SWITCH, dv0VarB.w());
        jSONObject.put(K_DAILY_LIMIT, dv0VarB.g());
        jSONObject.put(K_COOLDOWN, dv0VarB.f());
        jSONObject.put(K_NIGHT_MODE, dv0VarB.r());
        jSONObject.put(K_NIGHT_START, dv0VarB.s());
        jSONObject.put(K_NIGHT_END, dv0VarB.q());
        jSONObject.put(K_VARIANT, dv0VarB.v().name());
        jSONObject.put(K_COMMENT_RATE, dv0VarB.e());
        jSONObject.put(K_COMMENT_POOL, new JSONArray((Collection) dv0VarB.d()));
        jSONObject.put(K_EXIT_AFTER_VIDEOS_EN, dv0VarB.j());
        jSONObject.put(K_EXIT_AFTER_VIDEOS_CNT, dv0VarB.i());
        jSONObject.put(K_EXIT_REST_MIN, dv0VarB.l());
        jSONObject.put(K_EXIT_REST_MAX, dv0VarB.k());
        jSONObject.put(K_DOWNLOAD_RATE, dv0VarB.h());
        jSONObject.put(K_SHARE_RATE, dv0VarB.u());
        jSONObject.put(K_FAVORITE_RATE, dv0VarB.m());
        qc1 qc1Var = this.store;
        String string = jSONObject.toString();
        string.getClass();
        qc1Var.b(K_CONFIG, CONTEXT, string);
        nj1 nj1Var = (nj1) this._config;
        nj1Var.getClass();
        nj1Var.i(null, dv0VarB);
    }
}
