package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class fb1 extends ib1 {
    public static final fb1 d = new fb1("golike", "Auto GoLike", vl.y());

    public final boolean equals(Object obj) {
        return this == obj || (obj instanceof fb1);
    }

    public final int hashCode() {
        return -1853447554;
    }

    public final String toString() {
        return "GoLike";
    }
}
