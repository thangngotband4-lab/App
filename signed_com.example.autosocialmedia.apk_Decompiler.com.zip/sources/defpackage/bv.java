package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class bv extends sj1 implements kj1 {
    public final w40 e;
    public final a4 f;
    public av g = new av(yh1.j().g());

    public bv(w40 w40Var, a4 a4Var) {
        this.e = w40Var;
        this.f = a4Var;
    }

    @Override // defpackage.rj1
    public final tj1 a() {
        return this.g;
    }

    @Override // defpackage.rj1
    public final void c(tj1 tj1Var) {
        tj1Var.getClass();
        this.g = (av) tj1Var;
    }

    /* JADX WARN: Removed duplicated region for block: B:29:0x0097  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final defpackage.av g(defpackage.av r21, defpackage.ph1 r22, boolean r23, defpackage.w40 r24) {
        /*
            Method dump skipped, instruction units count: 408
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.bv.g(av, ph1, boolean, w40):av");
    }

    @Override // defpackage.kj1
    public final Object getValue() {
        h50 h50VarE = yh1.j().e();
        if (h50VarE != null) {
            h50VarE.g(this);
        }
        ph1 ph1VarJ = yh1.j();
        return g((av) yh1.i(this.g, ph1VarJ), ph1VarJ, true, this.e).f;
    }

    public final av h() {
        ph1 ph1VarJ = yh1.j();
        return g((av) yh1.i(this.g, ph1VarJ), ph1VarJ, false, this.e);
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder("DerivedState(value=");
        av avVar = (av) yh1.h(this.g);
        sb.append(avVar.c(this, yh1.j()) ? String.valueOf(avVar.f) : "<Not calculated>");
        sb.append(")@");
        sb.append(hashCode());
        return sb.toString();
    }
}
