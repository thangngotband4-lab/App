package defpackage;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Icon;
import androidx.compose.ui.platform.AndroidCompositionLocals_androidKt;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class a4 implements tr, wk0, xh, h81 {
    public final /* synthetic */ int d;
    public static final bg e = new bg(-1.0f, -1.0f);
    public static final bg f = new bg(0.0f, -1.0f);
    public static final bg g = new bg(1.0f, -1.0f);
    public static final bg h = new bg(-1.0f, 0.0f);
    public static final bg i = new bg(0.0f, 0.0f);
    public static final bg j = new bg(1.0f, 0.0f);
    public static final bg k = new bg(-1.0f, 1.0f);
    public static final bg l = new bg(0.0f, 1.0f);
    public static final bg m = new bg(1.0f, 1.0f);
    public static final ag n = new ag(-1.0f);
    public static final ag o = new ag(0.0f);
    public static final ag p = new ag(1.0f);
    public static final zf q = new zf(-1.0f);
    public static final zf r = new zf(0.0f);
    public static final zf s = new zf(1.0f);
    public static final zi t = new zi(0);
    public static final l6 u = new l6(1);
    public static final l6 v = new l6(2);
    public static final /* synthetic */ a4 w = new a4(4);
    public static final /* synthetic */ a4 x = new a4(5);
    public static final a4 y = new a4(6);
    public static final a4 z = new a4(7);
    public static final a4 A = new a4(8);
    public static final ri0 B = ri0.d;
    public static final xu C = new xu(1.0f, 1.0f);
    public static final a4 D = new a4(9);
    public static final a4 E = new a4(10);
    public static final x61 F = new x61(Float.NaN, Float.NaN, Float.NaN, Float.NaN);
    public static final a4 G = new a4(12);
    public static final /* synthetic */ a4 H = new a4(13);
    public static final /* synthetic */ a4 I = new a4(14);
    public static final /* synthetic */ a4 J = new a4(15);
    public static final /* synthetic */ a4 K = new a4(16);
    public static final /* synthetic */ a4 L = new a4(17);
    public static final a4 M = new a4(18);
    public static final a4 N = new a4(19);
    public static final a4 O = new a4(20);
    public static final a4 P = new a4(21);
    public static final /* synthetic */ a4 Q = new a4(22);
    public static final a4 R = new a4(23);
    public static final a4 S = new a4(24);
    public static final a4 T = new a4(25);
    public static final a4 U = new a4(26);
    public static final tz V = new tz(12);
    public static final tz W = new tz(13);
    public static final tz X = new tz(14);
    public static final tz Y = new tz(15);
    public static final a4 Z = new a4(28);
    public static final a4 a0 = new a4(29);

    public /* synthetic */ a4(int i2) {
        this.d = i2;
    }

    public static fr0 h(fr0 fr0Var, bg bgVar) {
        return fr0Var.c(new rg(bgVar));
    }

    public static rn1 i(int i2, xo xoVar) {
        return l((xl) xoVar.j(zl.a), xoVar);
    }

    public static rn1 j(long j2, long j3, long j4, long j5, long j6, long j7, long j8, xo xoVar, int i2) {
        long j9 = ql.g;
        return l((xl) xoVar.j(zl.a), xoVar).a(j2, j3, j9, j9, j9, j9, j9, j9, (i2 & 256) != 0 ? j9 : j4, j9, null, j5, (i2 & 4096) != 0 ? j9 : j6, j9, j9, j9, j9, j9, j9, j9, j9, j9, j9, (8388608 & i2) != 0 ? j9 : j7, (i2 & 16777216) != 0 ? j9 : j8, j9, j9, j9, j9, j9, j9, j9, j9, j9, j9, j9, j9, j9, j9, j9, j9, j9, j9);
    }

    public static rn1 l(xl xlVar, xo xoVar) {
        boolean z2;
        rn1 rn1VarA = xlVar.d0;
        if (rn1VarA == null) {
            xoVar.W(390452338);
            xoVar.p(false);
            rn1VarA = null;
            z2 = false;
        } else {
            xoVar.W(390452339);
            xp1 xp1Var = (xp1) xoVar.j(yp1.a);
            if (ng0.o(rn1VarA.k, xp1Var)) {
                z2 = false;
            } else {
                rn1VarA = rn1VarA.a(rn1VarA.a, rn1VarA.b, rn1VarA.c, rn1VarA.d, rn1VarA.e, rn1VarA.f, rn1VarA.g, rn1VarA.h, rn1VarA.i, rn1VarA.j, xp1Var, rn1VarA.l, rn1VarA.m, rn1VarA.n, rn1VarA.o, rn1VarA.p, rn1VarA.q, rn1VarA.r, rn1VarA.s, rn1VarA.t, rn1VarA.u, rn1VarA.v, rn1VarA.w, rn1VarA.x, rn1VarA.y, rn1VarA.z, rn1VarA.A, rn1VarA.B, rn1VarA.C, rn1VarA.D, rn1VarA.E, rn1VarA.F, rn1VarA.G, rn1VarA.H, rn1VarA.I, rn1VarA.J, rn1VarA.K, rn1VarA.L, rn1VarA.M, rn1VarA.N, rn1VarA.O, rn1VarA.P, rn1VarA.Q);
                xlVar.d0 = rn1VarA;
                z2 = false;
            }
            xoVar.p(z2);
        }
        if (rn1VarA != null) {
            xoVar.W(-1788515437);
            xoVar.p(z2);
            return rn1VarA;
        }
        xoVar.W(-1788321191);
        long jC = zl.c(xlVar, zu1.Q);
        long jC2 = zl.c(xlVar, zu1.W);
        yl ylVar = zu1.D;
        long jB = ql.b(0.38f, zl.c(xlVar, ylVar));
        long jC3 = zl.c(xlVar, zu1.K);
        long j2 = ql.f;
        long jC4 = zl.c(xlVar, zu1.B);
        long jC5 = zl.c(xlVar, zu1.J);
        xp1 xp1Var2 = (xp1) xoVar.j(yp1.a);
        long jC6 = zl.c(xlVar, zu1.T);
        long jC7 = zl.c(xlVar, zu1.c0);
        long jB2 = ql.b(0.12f, zl.c(xlVar, zu1.G));
        long jC8 = zl.c(xlVar, zu1.N);
        long jC9 = zl.c(xlVar, zu1.S);
        long jC10 = zl.c(xlVar, zu1.b0);
        long jB3 = ql.b(0.38f, zl.c(xlVar, zu1.F));
        long jC11 = zl.c(xlVar, zu1.M);
        long jC12 = zl.c(xlVar, zu1.V);
        long jC13 = zl.c(xlVar, zu1.e0);
        long jB4 = ql.b(0.38f, zl.c(xlVar, zu1.I));
        long jC14 = zl.c(xlVar, zu1.P);
        long jC15 = zl.c(xlVar, zu1.R);
        long jC16 = zl.c(xlVar, zu1.a0);
        long jB5 = ql.b(0.38f, zl.c(xlVar, zu1.E));
        long jC17 = zl.c(xlVar, zu1.L);
        yl ylVar2 = zu1.X;
        long jC18 = zl.c(xlVar, ylVar2);
        long jC19 = zl.c(xlVar, ylVar2);
        long jB6 = ql.b(0.38f, zl.c(xlVar, ylVar));
        long jC20 = zl.c(xlVar, ylVar2);
        long jC21 = zl.c(xlVar, zu1.U);
        long jC22 = zl.c(xlVar, zu1.d0);
        long jB7 = ql.b(0.38f, zl.c(xlVar, zu1.H));
        long jC23 = zl.c(xlVar, zu1.O);
        yl ylVar3 = zu1.Y;
        long jC24 = zl.c(xlVar, ylVar3);
        long jC25 = zl.c(xlVar, ylVar3);
        long jB8 = ql.b(0.38f, zl.c(xlVar, ylVar3));
        long jC26 = zl.c(xlVar, ylVar3);
        yl ylVar4 = zu1.Z;
        rn1 rn1Var = new rn1(jC, jC2, jB, jC3, j2, j2, j2, j2, jC4, jC5, xp1Var2, jC6, jC7, jB2, jC8, jC9, jC10, jB3, jC11, jC12, jC13, jB4, jC14, jC15, jC16, jB5, jC17, jC18, jC19, jB6, jC20, jC21, jC22, jB7, jC23, jC24, jC25, jB8, jC26, zl.c(xlVar, ylVar4), zl.c(xlVar, ylVar4), ql.b(0.38f, zl.c(xlVar, ylVar4)), zl.c(xlVar, ylVar4));
        xlVar.d0 = rn1Var;
        xoVar.p(z2);
        return rn1Var;
    }

    @Override // defpackage.xh
    public wu b() {
        return C;
    }

    @Override // defpackage.xh
    public long c() {
        return 9205357640488583168L;
    }

    /* JADX WARN: Removed duplicated region for block: B:114:0x0219  */
    /* JADX WARN: Removed duplicated region for block: B:117:0x0225  */
    /* JADX WARN: Removed duplicated region for block: B:119:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:27:0x0059  */
    /* JADX WARN: Removed duplicated region for block: B:28:0x005c  */
    /* JADX WARN: Removed duplicated region for block: B:31:0x0065  */
    /* JADX WARN: Removed duplicated region for block: B:32:0x0068  */
    /* JADX WARN: Removed duplicated region for block: B:35:0x0070  */
    /* JADX WARN: Removed duplicated region for block: B:43:0x0085  */
    /* JADX WARN: Removed duplicated region for block: B:46:0x008c  */
    /* JADX WARN: Removed duplicated region for block: B:54:0x00a1  */
    /* JADX WARN: Removed duplicated region for block: B:57:0x00ad  */
    /* JADX WARN: Removed duplicated region for block: B:58:0x00af  */
    /* JADX WARN: Removed duplicated region for block: B:61:0x00b8  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public void d(final boolean r25, final boolean r26, final defpackage.ks0 r27, defpackage.fr0 r28, final defpackage.rn1 r29, final defpackage.qf1 r30, float r31, float r32, defpackage.xo r33, final int r34, final int r35) {
        /*
            Method dump skipped, instruction units count: 565
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.a4.d(boolean, boolean, ks0, fr0, rn1, qf1, float, float, xo, int, int):void");
    }

    public void e(final String str, final l50 l50Var, final boolean z2, final boolean z3, final tz tzVar, final ks0 ks0Var, final boolean z4, final l50 l50Var2, final l50 l50Var3, final l50 l50Var4, final rn1 rn1Var, uz0 uz0Var, final qn qnVar, xo xoVar, final int i2) {
        int i3;
        boolean z5;
        boolean z6;
        final uz0 uz0Var2;
        uz0 uz0Var3;
        int i4;
        qn qnVar2;
        xoVar.X(-1732281618);
        if ((i2 & 6) == 0) {
            i3 = (xoVar.f(str) ? 4 : 2) | i2;
        } else {
            i3 = i2;
        }
        if ((i2 & 48) == 0) {
            i3 |= xoVar.h(l50Var) ? 32 : 16;
        }
        if ((i2 & 384) == 0) {
            z5 = z2;
            i3 |= xoVar.g(z5) ? 256 : 128;
        } else {
            z5 = z2;
        }
        if ((i2 & 3072) == 0) {
            z6 = z3;
            i3 |= xoVar.g(z6) ? 2048 : 1024;
        } else {
            z6 = z3;
        }
        if ((i2 & 24576) == 0) {
            i3 |= xoVar.f(tzVar) ? 16384 : 8192;
        }
        if ((i2 & 196608) == 0) {
            i3 |= xoVar.f(ks0Var) ? 131072 : 65536;
        }
        if ((i2 & 1572864) == 0) {
            i3 |= xoVar.g(z4) ? 1048576 : 524288;
        }
        if ((i2 & 12582912) == 0) {
            i3 |= xoVar.h(l50Var2) ? 8388608 : 4194304;
        }
        if ((i2 & 100663296) == 0) {
            i3 |= xoVar.h(l50Var3) ? 67108864 : 33554432;
        }
        if ((i2 & 805306368) == 0) {
            i3 |= xoVar.h(null) ? 536870912 : 268435456;
        }
        int i5 = 14155776 | (xoVar.h(null) ? 4 : 2) | (xoVar.h(null) ? 32 : 16) | (xoVar.h(null) ? 256 : 128) | (xoVar.h(l50Var4) ? 2048 : 1024) | (xoVar.f(rn1Var) ? 16384 : 8192) | 65536;
        if (xoVar.O(i3 & 1, ((i3 & 306783379) == 306783378 && (4793491 & i5) == 4793490) ? false : true)) {
            xoVar.T();
            if ((i2 & 1) == 0 || xoVar.y()) {
                uz0Var3 = new uz0(16.0f, 16.0f, 16.0f, 16.0f);
                i4 = i5 & (-458753);
            } else {
                xoVar.R();
                i4 = i5 & (-458753);
                uz0Var3 = uz0Var;
            }
            xoVar.q();
            boolean z7 = ((i3 & 57344) == 16384) | ((i3 & 14) == 4);
            Object objL = xoVar.L();
            if (z7 || objL == ro.a) {
                kc kcVar = new kc(str);
                tzVar.getClass();
                objL = new xt1(kcVar, lw0.a);
                xoVar.g0(objL);
            }
            String str2 = ((xt1) objL).a.e;
            do1 do1Var = new do1();
            if (l50Var2 == null) {
                xoVar.W(1927058812);
                xoVar.p(false);
                qnVar2 = null;
            } else {
                xoVar.W(1927058813);
                qn qnVarC = jl.C(-1459717586, new fu(1, l50Var2), xoVar);
                xoVar.p(false);
                qnVar2 = qnVarC;
            }
            int i6 = i3 >> 9;
            int i7 = i4 << 21;
            yj1.a(str2, l50Var, do1Var, qnVar2, l50Var3, l50Var4, z6, z5, z4, ks0Var, uz0Var3, rn1Var, qnVar, xoVar, ((i3 << 3) & 896) | 6 | (i6 & 458752) | (i6 & 3670016) | (i7 & 29360128) | (i7 & 234881024) | (i7 & 1879048192), (i3 & 896) | ((i4 >> 9) & 14) | ((i3 >> 6) & 112) | (i6 & 7168) | ((i3 >> 3) & 57344) | ((i4 << 6) & 3670016) | 12582912);
            uz0Var2 = uz0Var3;
        } else {
            xoVar.R();
            uz0Var2 = uz0Var;
        }
        l61 l61VarR = xoVar.r();
        if (l61VarR != null) {
            l61VarR.d = new l50() { // from class: xy0
                @Override // defpackage.l50
                public final Object f(Object obj, Object obj2) {
                    ((Integer) obj2).getClass();
                    int iT = bm.T(i2 | 1);
                    this.d.e(str, l50Var, z2, z3, tzVar, ks0Var, z4, l50Var2, l50Var3, l50Var4, rn1Var, uz0Var2, qnVar, (xo) obj, iT);
                    return bw1.a;
                }
            };
        }
    }

    public void f(Drawable drawable, xo xoVar, int i2) {
        xoVar.X(257732500);
        int i3 = (xoVar.h(drawable) ? 4 : 2) | i2;
        if (xoVar.O(i3 & 1, (i3 & 3) != 2)) {
            fr0 fr0VarF = ig1.f(cr0.a, pq.e);
            boolean zH = xoVar.h(drawable);
            Object objL = xoVar.L();
            if (zH || objL == ro.a) {
                objL = new l(28, drawable);
                xoVar.g0(objL);
            }
            tg.a(y5.p(fr0VarF, (h50) objL), xoVar, 0);
        } else {
            xoVar.R();
        }
        l61 l61VarR = xoVar.r();
        if (l61VarR != null) {
            l61VarR.d = new e60(this, drawable, i2, 17);
        }
    }

    public void g(final Icon icon, xo xoVar, final int i2) {
        l61 l61VarR;
        l50 l50Var;
        xoVar.X(2116504409);
        int i3 = (xoVar.h(icon) ? 4 : 2) | i2;
        final int i4 = 0;
        final int i5 = 1;
        if (xoVar.O(i3 & 1, (i3 & 19) != 18)) {
            Context context = (Context) xoVar.j(AndroidCompositionLocals_androidKt.b);
            boolean zF = xoVar.f(icon) | xoVar.f(context);
            Object objL = xoVar.L();
            if (zF || objL == ro.a) {
                objL = icon.loadDrawable(context);
                xoVar.g0(objL);
            }
            Drawable drawable = (Drawable) objL;
            if (drawable == null) {
                l61VarR = xoVar.r();
                if (l61VarR != null) {
                    l50Var = new l50(this, icon, i2, i4) { // from class: bn1
                        public final /* synthetic */ int d;
                        public final /* synthetic */ a4 e;
                        public final /* synthetic */ Icon f;

                        {
                            this.d = i4;
                            this.e = this;
                        }

                        @Override // defpackage.l50
                        public final Object f(Object obj, Object obj2) {
                            int i6 = this.d;
                            bw1 bw1Var = bw1.a;
                            Icon icon2 = this.f;
                            a4 a4Var = this.e;
                            xo xoVar2 = (xo) obj;
                            ((Integer) obj2).getClass();
                            switch (i6) {
                                case 0:
                                    a4Var.g(icon2, xoVar2, bm.T(49));
                                    break;
                                default:
                                    a4Var.g(icon2, xoVar2, bm.T(49));
                                    break;
                            }
                            return bw1Var;
                        }
                    };
                    l61VarR.d = l50Var;
                }
                return;
            }
            f(drawable, xoVar, 48);
        } else {
            xoVar.R();
        }
        l61VarR = xoVar.r();
        if (l61VarR != null) {
            l50Var = new l50(this, icon, i2, i5) { // from class: bn1
                public final /* synthetic */ int d;
                public final /* synthetic */ a4 e;
                public final /* synthetic */ Icon f;

                {
                    this.d = i5;
                    this.e = this;
                }

                @Override // defpackage.l50
                public final Object f(Object obj, Object obj2) {
                    int i6 = this.d;
                    bw1 bw1Var = bw1.a;
                    Icon icon2 = this.f;
                    a4 a4Var = this.e;
                    xo xoVar2 = (xo) obj;
                    ((Integer) obj2).getClass();
                    switch (i6) {
                        case 0:
                            a4Var.g(icon2, xoVar2, bm.T(49));
                            break;
                        default:
                            a4Var.g(icon2, xoVar2, bm.T(49));
                            break;
                    }
                    return bw1Var;
                }
            };
            l61VarR.d = l50Var;
        }
    }

    @Override // defpackage.xh
    public ri0 getLayoutDirection() {
        return B;
    }

    public boolean k(Object obj, Object obj2) {
        switch (this.d) {
            case 19:
                return false;
            case 23:
                return obj == obj2;
            default:
                return ng0.o(obj, obj2);
        }
    }

    public String toString() {
        switch (this.d) {
            case 19:
                return "NeverEqualPolicy";
            case 23:
                return "ReferentialEqualityPolicy";
            case 28:
                return "StructuralEqualityPolicy";
            default:
                return super.toString();
        }
    }

    @Override // defpackage.wk0
    public void a() {
    }

    @Override // defpackage.wk0
    public void cancel() {
    }
}
