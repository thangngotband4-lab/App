package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class k60 extends ft0 {
    @Override // defpackage.ft0
    public final ft0 C(h50 h50Var, h50 h50Var2) {
        return (ft0) ((ph1) yh1.e(new xh1(new mr(h50Var, 1, h50Var2), 0)));
    }

    @Override // defpackage.ft0, defpackage.ph1
    public final void c() {
        synchronized (yh1.c) {
            o();
        }
    }

    @Override // defpackage.ft0, defpackage.ph1
    public final void k() {
        jl.I();
        throw null;
    }

    @Override // defpackage.ft0, defpackage.ph1
    public final void l() {
        jl.I();
        throw null;
    }

    @Override // defpackage.ft0, defpackage.ph1
    public final void m() {
        yh1.a();
    }

    @Override // defpackage.ft0, defpackage.ph1
    public final ph1 u(h50 h50Var) {
        int i = 0;
        return (i61) ((ph1) yh1.e(new xh1(new j60(h50Var, i), i)));
    }

    @Override // defpackage.ft0
    public final rm w() {
        throw new IllegalStateException("Cannot apply the global snapshot directly. Call Snapshot.advanceGlobalSnapshot");
    }
}
