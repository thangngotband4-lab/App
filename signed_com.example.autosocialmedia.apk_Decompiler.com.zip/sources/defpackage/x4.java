package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class x4 {
    public final en0 a;
    public final na1 b;
    public final dz1 c;

    public x4(en0 en0Var, na1 na1Var, dz1 dz1Var) {
        this.a = en0Var;
        this.b = na1Var;
        this.c = dz1Var;
    }
}
