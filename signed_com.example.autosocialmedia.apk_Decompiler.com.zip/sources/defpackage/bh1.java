package defpackage;

import java.util.List;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class bh1 implements lq0 {
    public final /* synthetic */ hh1 a;

    public bh1(hh1 hh1Var) {
        this.a = hh1Var;
    }

    @Override // defpackage.lq0
    public final mq0 g(nq0 nq0Var, List list, long j) {
        int iMax;
        int iMax2;
        int i;
        int i2;
        int iD;
        hh1 hh1Var = this.a;
        int i3 = hh1Var.a;
        float[] fArr = hh1Var.f;
        ry0 ry0Var = hh1Var.l;
        int size = list.size();
        int i4 = 0;
        while (true) {
            if (i4 >= size) {
                do0.b("Collection contains no element matching the predicate.");
                zi.h();
                return null;
            }
            gq0 gq0Var = (gq0) list.get(i4);
            if (zu1.q(gq0Var) == ng1.d) {
                final k21 k21VarE = gq0Var.e(j);
                int size2 = list.size();
                for (int i5 = 0; i5 < size2; i5++) {
                    gq0 gq0Var2 = (gq0) list.get(i5);
                    if (zu1.q(gq0Var2) == ng1.e) {
                        boolean z = true;
                        ry0 ry0Var2 = ry0.d;
                        k21 k21VarE2 = ry0Var == ry0Var2 ? gq0Var2.e(xp.a(yp.j(0, -k21VarE.e, 1, j), 0, 0, 0, 0, 14)) : gq0Var2.e(xp.a(yp.j(-k21VarE.d, 0, 2, j), 0, 0, 0, 0, 11));
                        final c71 c71Var = new c71();
                        float fB = hh1Var.b();
                        fArr.getClass();
                        if (!ng0.n(fB, fArr.length != 0 ? Float.valueOf(fArr[0]) : null) && !ng0.n(fB, sd.S(fArr))) {
                            z = false;
                        }
                        int iD0 = k21VarE2.d0(fh1.f);
                        int i6 = iD0 != Integer.MIN_VALUE ? iD0 : 0;
                        if (ry0Var == ry0Var2) {
                            iMax = Math.max(k21VarE2.d, k21VarE.d);
                            int i7 = k21VarE.e;
                            int i8 = k21VarE2.e;
                            iMax2 = i7 + i8;
                            i = (iMax - k21VarE2.d) / 2;
                            i2 = i7 / 2;
                            iD = (iMax - k21VarE.d) / 2;
                            c71Var.d = (i3 <= 0 || z) ? eq0.D(i8 * fB) : eq0.D((i8 - (i6 * 2)) * fB) + i6;
                        } else {
                            iMax = k21VarE.d + k21VarE2.d;
                            iMax2 = Math.max(k21VarE2.e, k21VarE.e);
                            i = k21VarE.d / 2;
                            i2 = (iMax2 - k21VarE2.e) / 2;
                            iD = (i3 <= 0 || z) ? eq0.D(k21VarE2.d * fB) : eq0.D((k21VarE2.d - (i6 * 2)) * fB) + i6;
                            c71Var.d = (iMax2 - k21VarE.e) / 2;
                        }
                        final int i9 = i2;
                        final int i10 = i;
                        final int i11 = iD;
                        hh1Var.g.h(iMax);
                        hh1Var.h.h(iMax2);
                        final k21 k21Var = k21VarE2;
                        return nq0Var.i0(iMax, iMax2, vz.d, new h50() { // from class: ah1
                            @Override // defpackage.h50
                            public final Object g(Object obj) {
                                j21 j21Var = (j21) obj;
                                j21.j(j21Var, k21Var, i10, i9);
                                j21.j(j21Var, k21VarE, i11, c71Var.d);
                                return bw1.a;
                            }
                        });
                    }
                }
                do0.b("Collection contains no element matching the predicate.");
                zi.h();
                return null;
            }
            i4++;
        }
    }
}
