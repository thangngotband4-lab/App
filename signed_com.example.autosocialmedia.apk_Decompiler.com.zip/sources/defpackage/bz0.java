package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class bz0 implements l50 {
    public final /* synthetic */ int d;
    public final /* synthetic */ boolean e;
    public final /* synthetic */ boolean f;
    public final /* synthetic */ ks0 g;
    public final /* synthetic */ rn1 h;
    public final /* synthetic */ qf1 i;

    public /* synthetic */ bz0(boolean z, boolean z2, ks0 ks0Var, rn1 rn1Var, qf1 qf1Var, int i) {
        this.d = i;
        this.e = z;
        this.f = z2;
        this.g = ks0Var;
        this.h = rn1Var;
        this.i = qf1Var;
    }

    @Override // defpackage.l50
    public final Object f(Object obj, Object obj2) {
        int i = this.d;
        bw1 bw1Var = bw1.a;
        switch (i) {
            case 0:
                xo xoVar = (xo) obj;
                int iIntValue = ((Number) obj2).intValue();
                if (!xoVar.O(iIntValue & 1, (iIntValue & 3) != 2)) {
                    xoVar.R();
                } else {
                    a4.O.d(this.e, this.f, this.g, null, this.h, this.i, 0.0f, 0.0f, xoVar, 100663296, dv0.MAX_VIDEOS);
                }
                break;
            default:
                xo xoVar2 = (xo) obj;
                int iIntValue2 = ((Number) obj2).intValue();
                if (!xoVar2.O(iIntValue2 & 1, (iIntValue2 & 3) != 2)) {
                    xoVar2.R();
                } else {
                    a4.O.d(this.e, this.f, this.g, null, this.h, this.i, 0.0f, 0.0f, xoVar2, 100663296, dv0.MAX_VIDEOS);
                }
                break;
        }
        return bw1Var;
    }
}
