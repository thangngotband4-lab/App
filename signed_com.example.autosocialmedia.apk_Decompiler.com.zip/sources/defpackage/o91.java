package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class o91 extends w50 implements m50 {
    public static final o91 l = new o91(3, f20.class, "emit", "emit(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", 0);

    @Override // defpackage.m50
    public final Object c(Object obj, Object obj2, Object obj3) {
        return ((f20) obj).k(obj2, (tq) obj3);
    }
}
