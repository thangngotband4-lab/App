package defpackage;

import android.graphics.Bitmap;
import android.os.Handler;
import android.webkit.CookieManager;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class xb0 extends WebViewClient {
    public final /* synthetic */ int a;
    public final /* synthetic */ gt0 b;
    public final /* synthetic */ Handler c;
    public final /* synthetic */ Object d;
    public final /* synthetic */ h50 e;

    public xb0(gt0 gt0Var, ConcurrentHashMap.KeySetView keySetView, Handler handler, h50 h50Var) {
        this.a = 4;
        this.b = gt0Var;
        this.d = keySetView;
        this.c = handler;
        this.e = h50Var;
    }

    @Override // android.webkit.WebViewClient
    public void onPageFinished(WebView webView, String str) {
        String cookie;
        String cookie2;
        int i = this.a;
        h50 h50Var = this.e;
        Handler handler = this.c;
        gt0 gt0Var = this.b;
        Object obj = this.d;
        int i2 = 1;
        switch (i) {
            case 0:
                gt0 gt0Var2 = (gt0) obj;
                gt0Var.setValue(str != null ? str : "");
                if (str != null && bk1.n(str, "instagram.com", true) && (cookie = CookieManager.getInstance().getCookie("https://www.instagram.com/")) != null && bk1.n(cookie, "sessionid=", true) && !cookie.equals((String) gt0Var2.getValue())) {
                    gt0Var2.setValue(cookie);
                    handler.post(new b80(h50Var, i2, cookie));
                    break;
                }
                break;
            case 1:
                gt0 gt0Var3 = (gt0) obj;
                gt0Var.setValue(str != null ? str : "");
                if (str != null) {
                    if (bk1.n(str, "threads.com", true) || bk1.n(str, "threads.net", true)) {
                        String cookie3 = CookieManager.getInstance().getCookie("https://www.threads.com/");
                        if ((cookie3 != null || (cookie3 = CookieManager.getInstance().getCookie("https://www.threads.net/")) != null) && bk1.n(cookie3, "sessionid=", true) && !cookie3.equals((String) gt0Var3.getValue())) {
                            gt0Var3.setValue(cookie3);
                            handler.post(new b80(h50Var, 2, cookie3));
                        }
                    }
                }
                break;
            case 2:
                gt0 gt0Var4 = (gt0) obj;
                gt0Var.setValue(str != null ? str : "");
                if (str != null) {
                    if (bk1.n(str, "x.com", true) || bk1.n(str, "twitter.com", true)) {
                        String cookie4 = CookieManager.getInstance().getCookie("https://x.com/");
                        if ((cookie4 != null || (cookie4 = CookieManager.getInstance().getCookie("https://twitter.com/")) != null) && bk1.n(cookie4, "auth_token=", true) && !cookie4.equals((String) gt0Var4.getValue())) {
                            gt0Var4.setValue(cookie4);
                            handler.post(new b80(h50Var, 3, cookie4));
                        }
                    }
                }
                break;
            case 3:
                gt0 gt0Var5 = (gt0) obj;
                gt0Var.setValue(str != null ? str : "");
                if (str != null && bk1.n(str, "youtube.com", true) && (cookie2 = CookieManager.getInstance().getCookie("https://www.youtube.com/")) != null && bk1.n(cookie2, "SAPISID", false) && !cookie2.equals((String) gt0Var5.getValue())) {
                    gt0Var5.setValue(cookie2);
                    handler.post(new b80(h50Var, 4, cookie2));
                    break;
                }
                break;
            default:
                super.onPageFinished(webView, str);
                break;
        }
    }

    @Override // android.webkit.WebViewClient
    public final void onPageStarted(WebView webView, String str, Bitmap bitmap) {
        int i = this.a;
        gt0 gt0Var = this.b;
        switch (i) {
            case 0:
                if (str == null) {
                    str = "";
                }
                gt0Var.setValue(str);
                break;
            case 1:
                if (str == null) {
                    str = "";
                }
                gt0Var.setValue(str);
                break;
            case 2:
                if (str == null) {
                    str = "";
                }
                gt0Var.setValue(str);
                break;
            case 3:
                if (str == null) {
                    str = "";
                }
                gt0Var.setValue(str);
                break;
            default:
                if (str == null) {
                    str = "";
                }
                gt0Var.setValue(str);
                break;
        }
    }

    @Override // android.webkit.WebViewClient
    public WebResourceResponse shouldInterceptRequest(WebView webView, WebResourceRequest webResourceRequest) {
        switch (this.a) {
            case 4:
                webView.getClass();
                webResourceRequest.getClass();
                String string = webResourceRequest.getUrl().toString();
                string.getClass();
                if (!bk1.n(string, "gateway.golike.net", true)) {
                    return null;
                }
                Map<String, String> requestHeaders = webResourceRequest.getRequestHeaders();
                String str = requestHeaders.get("authorization");
                if ((str == null && (str = requestHeaders.get("Authorization")) == null) || !kk1.m(str, "Bearer ", true)) {
                    return null;
                }
                String string2 = bk1.A(str.substring(7)).toString();
                if (string2.length() == 0 || string2.equalsIgnoreCase("null") || string2.equalsIgnoreCase("undefined") || string2.length() < 20 || !((ConcurrentHashMap.KeySetView) this.d).add(str)) {
                    return null;
                }
                this.c.post(new b80(this.e, 0, str));
                return null;
            default:
                return super.shouldInterceptRequest(webView, webResourceRequest);
        }
    }

    public /* synthetic */ xb0(gt0 gt0Var, Handler handler, gt0 gt0Var2, h50 h50Var, int i) {
        this.a = i;
        this.b = gt0Var;
        this.c = handler;
        this.d = gt0Var2;
        this.e = h50Var;
    }
}
