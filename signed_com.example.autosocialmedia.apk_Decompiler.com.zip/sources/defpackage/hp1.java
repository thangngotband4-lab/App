package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class hp1 implements sx1 {
    public final /* synthetic */ int a;
    public Object b;

    public hp1(fc fcVar, float f, float f2) {
        this.a = 2;
        int iB = fcVar.b();
        t10[] t10VarArr = new t10[iB];
        for (int i = 0; i < iB; i++) {
            t10VarArr[i] = new t10(f, f2, fcVar.a(i));
        }
        this.b = t10VarArr;
    }

    @Override // defpackage.sx1, defpackage.px1
    public boolean a() {
        ((l4) this.b).getClass();
        return false;
    }

    @Override // defpackage.px1
    public long b(fc fcVar, fc fcVar2, fc fcVar3) {
        return ((l4) this.b).b(fcVar, fcVar2, fcVar3);
    }

    public long c(long j) {
        hu huVar = (hu) this.b;
        huVar.getClass();
        if (xx1.b(j) <= 0.0f || xx1.c(j) <= 0.0f) {
            sd0.b("maximumVelocity should be a positive value. You specified=" + ((Object) xx1.g(j)));
        }
        return jj1.c(huVar.a.b(xx1.b(j)), huVar.b.b(xx1.c(j)));
    }

    public s10 d(int i) {
        switch (this.a) {
            case 2:
                return ((t10[]) this.b)[i];
            case 3:
                return (t10) this.b;
            default:
                return (s10) this.b;
        }
    }

    @Override // defpackage.px1
    public fc l(long j, fc fcVar, fc fcVar2, fc fcVar3) {
        return ((l4) this.b).l(j, fcVar, fcVar2, fcVar3);
    }

    @Override // defpackage.px1
    public fc o(long j, fc fcVar, fc fcVar2, fc fcVar3) {
        return ((l4) this.b).o(j, fcVar, fcVar2, fcVar3);
    }

    @Override // defpackage.px1
    public fc p(fc fcVar, fc fcVar2, fc fcVar3) {
        return ((l4) this.b).p(fcVar, fcVar2, fcVar3);
    }

    public hp1(int i) {
        this.a = i;
        switch (i) {
            case 6:
                this.b = new hu();
                break;
        }
    }

    public hp1(float f, float f2, fc fcVar) {
        hp1 hp1Var;
        this.a = 5;
        int[] iArr = qx1.a;
        if (fcVar != null) {
            hp1Var = new hp1(fcVar, f, f2);
        } else {
            hp1Var = new hp1(f, f2);
        }
        this.b = new l4(hp1Var);
    }

    public /* synthetic */ hp1(int i, Object obj) {
        this.a = i;
        this.b = obj;
    }

    public hp1(float f, float f2) {
        this.a = 3;
        this.b = new t10(f, f2, 0.01f);
    }
}
