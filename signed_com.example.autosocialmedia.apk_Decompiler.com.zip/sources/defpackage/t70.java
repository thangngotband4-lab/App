package defpackage;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class t70 extends uq {
    public c80 d;
    public boolean e;
    public /* synthetic */ Object f;
    public final /* synthetic */ y70 g;
    public int h;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public t70(y70 y70Var, uq uqVar) {
        super(uqVar);
        this.g = y70Var;
    }

    @Override // defpackage.kf
    public final Object r(Object obj) {
        this.f = obj;
        this.h |= Integer.MIN_VALUE;
        return this.g.k(null, null, this);
    }
}
