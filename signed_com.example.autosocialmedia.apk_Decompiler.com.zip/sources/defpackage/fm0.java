package defpackage;

import android.graphics.Rect;
import android.os.LocaleList;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.Locale;

/* JADX INFO: compiled from: r8-map-id-cfb89cc8f080d38e6700b9f32cce01b1a1953de4929e871f1f6451849b409358 */
/* JADX INFO: loaded from: classes.dex */
public final class fm0 {
    public final View a;
    public final ae0 b;
    public em0 e;
    public so1 f;
    public ry1 g;
    public Rect l;
    public final am0 m;
    public h50 c = new g70(16);
    public h50 d = new g70(17);
    public zo1 h = new zo1(wp1.b, "", 4);
    public mc0 i = mc0.g;
    public final ArrayList j = new ArrayList();
    public final zj0 k = vl.C(new y8(10, this));

    public fm0(View view, u7 u7Var, ae0 ae0Var) {
        this.a = view;
        this.b = ae0Var;
        this.m = new am0(u7Var, ae0Var);
    }

    public final u61 a(EditorInfo editorInfo) {
        int i;
        int i2;
        zo1 zo1Var = this.h;
        String str = zo1Var.a.e;
        long j = zo1Var.b;
        mc0 mc0Var = this.i;
        int i3 = mc0Var.e;
        int i4 = mc0Var.d;
        boolean z = mc0Var.a;
        if (i3 == 1) {
            i = z ? 6 : 0;
        } else if (i3 == 0) {
            i = 1;
        } else if (i3 == 2) {
            i = 2;
        } else if (i3 == 6) {
            i = 5;
        } else if (i3 == 5) {
            i = 7;
        } else if (i3 == 3) {
            i = 3;
        } else if (i3 == 4) {
            i = 4;
        } else {
            if (i3 != 7) {
                zi.f("invalid ImeAction");
                return null;
            }
        }
        editorInfo.imeOptions = i;
        io0 io0Var = mc0Var.f;
        if (ng0.o(io0Var, io0.f)) {
            editorInfo.hintLocales = null;
        } else {
            ArrayList arrayList = new ArrayList(ll.R(io0Var));
            Iterator it = io0Var.d.iterator();
            while (it.hasNext()) {
                arrayList.add(((ho0) it.next()).a);
            }
            Locale[] localeArr = (Locale[]) arrayList.toArray(new Locale[0]);
            editorInfo.hintLocales = new LocaleList((Locale[]) Arrays.copyOf(localeArr, localeArr.length));
        }
        if (i4 == 1) {
            i2 = 1;
        } else if (i4 == 2) {
            editorInfo.imeOptions |= Integer.MIN_VALUE;
            i2 = 1;
        } else if (i4 == 3) {
            i2 = 2;
        } else if (i4 == 4) {
            i2 = 3;
        } else if (i4 == 5) {
            i2 = 17;
        } else if (i4 == 6) {
            i2 = 33;
        } else if (i4 == 7) {
            i2 = 129;
        } else if (i4 == 8) {
            i2 = 18;
        } else {
            if (i4 != 9) {
                zi.f("Invalid Keyboard Type");
                return null;
            }
            i2 = 8194;
        }
        editorInfo.inputType = i2;
        if (!z && (i2 & 1) == 1) {
            editorInfo.inputType = 131072 | i2;
            if (mc0Var.e == 1) {
                editorInfo.imeOptions |= 1073741824;
            }
        }
        int i5 = editorInfo.inputType;
        if ((i5 & 1) == 1) {
            int i6 = mc0Var.b;
            if (i6 == 1) {
                editorInfo.inputType = i5 | 4096;
            } else if (i6 == 2) {
                editorInfo.inputType = i5 | 8192;
            } else if (i6 == 3) {
                editorInfo.inputType = i5 | 16384;
            }
            if (mc0Var.c) {
                editorInfo.inputType |= 32768;
            }
        }
        int i7 = wp1.c;
        editorInfo.initialSelStart = (int) (j >> 32);
        editorInfo.initialSelEnd = (int) (j & 4294967295L);
        vl.L(editorInfo, str);
        editorInfo.imeOptions |= 33554432;
        if (!ok1.a || i4 == 7 || i4 == 8) {
            vl.M(editorInfo, false);
        } else {
            vl.M(editorInfo, true);
            editorInfo.setSupportedHandwritingGestures(kl.N(r0.D(), r0.V(), r0.R(), r0.T(), r0.X(), r0.Z(), r0.b0()));
            editorInfo.setSupportedHandwritingGesturePreviews(hf1.M(r0.D(), r0.V(), r0.R(), r0.T()));
        }
        bm0 bm0Var = cm0.a;
        if (dz.d()) {
            dz.a().g(editorInfo);
        }
        u61 u61Var = new u61(this.h, new l1(13, this), this.i.c, this.e, this.f, this.g);
        this.j.add(new WeakReference(u61Var));
        return u61Var;
    }
}
